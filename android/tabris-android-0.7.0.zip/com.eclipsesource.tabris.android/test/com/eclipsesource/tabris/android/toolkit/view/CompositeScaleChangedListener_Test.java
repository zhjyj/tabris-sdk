/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import android.widget.SeekBar.OnSeekBarChangeListener;

public class CompositeScaleChangedListener_Test {

  @Test
  public void testNotifyOnItemClick() {
    CompositeScaleChangedListener compListener = new CompositeScaleChangedListener();
    OnSeekBarChangeListener listener1 = mock( OnSeekBarChangeListener.class );
    OnSeekBarChangeListener listener2 = mock( OnSeekBarChangeListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    Scale scale = mock( Scale.class );

    compListener.onStopTrackingTouch( scale );

    verify( listener1 ).onStopTrackingTouch( scale );
    verify( listener2 ).onStopTrackingTouch( scale );
  }

}
