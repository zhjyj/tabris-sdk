/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.content.Context;
import android.util.AttributeSet;

import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowProgressBar;

@Implements(ProgressBar.class)
public class TabrisProgressBar extends ShadowProgressBar {

  private int defStyle;

  @Override
  public void __constructor__( Context context, AttributeSet attributeSet, int defStyle ) {
    super.__constructor__( context, attributeSet, defStyle );
    this.defStyle = defStyle;
  }

  public int getDefStyle() {
    return defStyle;
  }

}
