/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;

import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.LocalizableException;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.operator.CompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ShellOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TextOperator;
import com.eclipsesource.tabris.android.toolkit.operator.UiCallbackOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.RecordingFocusTrackingListener;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowDisplay;
import com.xtremelabs.robolectric.shadows.ShadowTextView;
import com.xtremelabs.robolectric.shadows.ShadowView;

@RunWith(RobolectricTestRunner.class)
public class AndroidWidgetToolkit_Test {

  private static final String DISPLAY_ID = "w1";
  private static final String SHELL_ID = "w2";
  private static final String WIDGET1_ID = "w3";
  private static final String WIDGET2_ID = "w4";

  private TabrisActivity activity;
  private FrameLayout rootLayout;
  private AndroidWidgetToolkit awt;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    awt = new AndroidWidgetToolkit( activity );
    when( processor.getWidgetToolkit() ).thenReturn( awt );
    activity.setProcessor( processor );
    rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Shell shell = new Shell( activity, mock( ShellAnimationSupport.class ) );
    awt.registerObjectById( SHELL_ID, shell );
  }

  @Test(expected = NullPointerException.class)
  public void testProcessNull() throws Exception {

    awt.process( null );
  }

  @Test
  public void testProcessCreateOperationOk() throws Exception {
    ArrayList<Operation> operations = new ArrayList<Operation>();
    CreateOperation op = new CreateOperation();
    operations.add( op );
    op.setType( CompositeOperator.TYPE );
    op.setTarget( WIDGET1_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( SHELL_ID );
    op.setProperties( props );

    View view = findViewById( WIDGET1_ID );
    assertNull( view );

    awt.process( operations );

    view = findViewById( WIDGET1_ID );
    assertTrue( view instanceof FrameLayout );
  }

  private View findViewById( String widgetId ) {
    return activity.getProcessor().getWidgetToolkit().findObjectById( widgetId, View.class );
  }

  @Test
  public void testProcessDestroyOperationOk() throws Exception {
    ArrayList<Operation> operations = new ArrayList<Operation>();
    DestroyOperation op = new DestroyOperation();
    operations.add( op );
    op.setTarget( WIDGET1_ID );
    Composite comp = new Composite( activity );
    comp.setTag( WIDGET1_ID );
    rootLayout.addView( comp );
    awt.registerObjectById( WIDGET1_ID, comp );

    View view = findViewById( WIDGET1_ID );
    assertTrue( view instanceof Composite );

    awt.process( operations );

    view = findViewById( WIDGET1_ID );
    assertNull( view );
  }

  @Test
  public void testProcessDestroyOperationOnExistingWidget() throws Exception {
    class AndroidWidgetToolkitUnderTest extends AndroidWidgetToolkit {

      public AndroidWidgetToolkitUnderTest( TabrisActivity activity ) {
        super( activity );
      }

      public boolean errorShown;

      @Override
      public void showError( Throwable throwable ) {
        errorShown = true;
      }
    };
    AndroidWidgetToolkitUnderTest awt = new AndroidWidgetToolkitUnderTest( activity );
    Operation op = mock( Operation.class );
    when( op.getTarget() ).thenReturn( WIDGET2_ID );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( op );

    View view = findViewById( WIDGET1_ID );
    assertNull( view );

    awt.process( operations );

    view = findViewById( WIDGET1_ID );
    assertNull( view );
    assertTrue( awt.errorShown );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testProcessOperationNoTarget() throws Exception {

    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( mock( Operation.class ) );

    awt.process( operations );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testProcessOperationNoTarget2() throws Exception {

    ArrayList<Operation> operations = new ArrayList<Operation>();
    Operation op = mock( Operation.class );
    when( op.getTarget() ).thenReturn( "" );
    operations.add( op );

    awt.process( operations );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetOperatorNull() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    awt.getOperator( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetOperatorWithNullTarget() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    Operation op = mock( Operation.class );

    awt.getOperator( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetOperatorWithEmptyTarget() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    Operation op = mock( Operation.class );
    when( op.getTarget() ).thenReturn( "" );

    awt.getOperator( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFindObjectByIdWithNullId() {

    awt.findObjectById( null, Object.class );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegisterObjectByIdWithNullId() {

    awt.registerObjectById( null, new Object() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegisterObjectByIdWithNullObject() {

    awt.registerObjectById( "id", null );
  }

  @Test
  public void testRegisterAndGetObjectById() {

    Object object = new Object();

    awt.registerObjectById( "id", object );

    Object foundObject = awt.findObjectById( "id", Object.class );

    assertEquals( object, foundObject );
  }

  @Test(expected = IllegalStateException.class)
  public void testRegisterAndGetObjectByIdWithWrongType() {

    Object object = new Object();

    awt.registerObjectById( "id", object );

    awt.findObjectById( "id", String.class );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUnregisterObjectByIdNull() {

    awt.unregisterObjectById( null );
  }

  @Test
  public void testUnregisterObjectByIdNotFound() {

    Object result = awt.unregisterObjectById( "abc" );

    assertNull( result );
  }

  @Test
  public void testGetOperatorsForCreateOperations() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    CreateOperation operation = new CreateOperation();
    Map<Class<? extends Object>, IOperator> operatorsMap = awt.getOperatorsMap();

    Set<Entry<Class<? extends Object>, IOperator>> entrySet = operatorsMap.entrySet();

    for( Entry<Class<? extends Object>, IOperator> entry : entrySet ) {
      IOperator operator = entry.getValue();
      // the ui callback is not created so we do exclude it from this check
      if( operator instanceof UiCallbackOperator ) {
        continue;
      }
      operation.setType( operator.getType() );
      operation.setTarget( "w3" );

      IOperator result = awt.getOperator( operation );

      assertEquals( operator.getClass(), result.getClass() );
    }
  }

  @Test
  public void testGetOperatorForSetOperationOnNoneExistingShell() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivity();
    activity.setContentView( R.layout.protocol );
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( "w2" );
    SetProperties properties = new SetProperties();
    properties.setText( "Hello World!" );
    operation.setProperties( properties );

    IOperator operator = awt.getOperator( operation );

    assertNull( operator );
  }

  @Test
  public void testGetOperatorForSetOperationOnShell() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( "w23" );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Shell shell = new Shell( activity, mock( ShellAnimationSupport.class ) );
    rootLayout.addView( shell );
    awt.registerObjectById( "w23", shell );

    IOperator operator = awt.getOperator( operation );

    assertEquals( ShellOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForSetOperationOnText() throws Exception {
    awt.registerObjectById( WIDGET1_ID, new Text( activity ) );
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );

    assertEquals( TextOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForSetOperationOnComposite() throws Exception {
    awt.registerObjectById( WIDGET1_ID, new Composite( activity ) );
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );

    assertEquals( CompositeOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForListenOperation() throws Exception {
    awt.registerObjectById( WIDGET1_ID, new Composite( activity ) );
    ListenOperation operation = new ListenOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );

    assertEquals( CompositeOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForSetOperationOnObjectNotFound() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( "notAvailable" );

    IOperator result = awt.getOperator( setOp );

    assertNull( result );
  }

  @Test
  public void testGetOperatorForSetOperationOnObjectOk() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    IOperator operator = mock( IOperator.class );
    awt.getOperatorsMap().put( Object.class, operator );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( "objId" );
    awt.registerObjectById( "objId", new Object() );

    IOperator result = awt.getOperator( setOp );

    assertEquals( operator, result );
  }

  @Test
  public void testGetOperatorForDestroyOperation() throws Exception {
    awt.registerObjectById( WIDGET1_ID, new Composite( activity ) );
    DestroyOperation operation = new DestroyOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );
    assertEquals( CompositeOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForModalShellDestroyOperation() {
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShell shell = new ModalShell( activity, animSupportMock );
    awt.registerObjectById( WIDGET1_ID, shell );
    DestroyOperation operation = new DestroyOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );

    assertEquals( ShellOperator.class, operator.getClass() );
  }

  @Test
  public void testProcessListenOperationOk() throws Exception {
    Button button = new Button( activity );
    awt.registerObjectById( WIDGET1_ID, button );
    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET1_ID );
    ListenProperties props = new ListenProperties();
    props.setSelection( true );
    op.setProperties( props );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( op );

    assertNull( shadowButton.getOnClickListener() );

    awt.process( operations );

    assertNotNull( shadowButton.getOnClickListener() );
  }

  @Test
  public void testGetSurfaceWidth() {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    View rootLayout = uiActivity.findViewById( R.id.root_layout );
    ShadowView shadowRootLayout = Robolectric.shadowOf( rootLayout );
    shadowRootLayout.setRight( 480 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );

    int surfaceWidth = awt.getSurfaceWidth();

    assertEquals( 480, surfaceWidth );
  }

  @Test
  public void testGetListenerRegistry() {
    IWidgetToolkit toolkit = new AndroidWidgetToolkit( activity );

    assertNotNull( toolkit.getListenerRegistry() );
  }

  @Test
  public void testGetSurfaceHeight() {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    View rootLayout = uiActivity.findViewById( R.id.root_layout );
    ShadowView shadowRootLayout = Robolectric.shadowOf( rootLayout );
    shadowRootLayout.setBottom( 765 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );

    int surfaceHeight = awt.getSurfaceHeight();

    assertEquals( 765, surfaceHeight );
  }

  @Test
  public void testGetDpiX() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setXdpi( 300 );
    awt = new AndroidWidgetToolkit( activity );

    int dpi = awt.getSurfaceDpiX();

    assertEquals( 300, dpi );
  }

  @Test
  public void testGetDpi() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setYdpi( 200 );
    awt = new AndroidWidgetToolkit( activity );

    int dpi = awt.getSurfaceDpiY();

    assertEquals( 200, dpi );
  }

  @Test
  public void testGetDensityFactor() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 3f );
    awt = new AndroidWidgetToolkit( activity );

    float density = awt.getDensityFactor();

    assertEquals( 3f, density, 0f );
  }

  @Test
  public void testGetDensityDpi() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensityDpi( DisplayMetrics.DENSITY_HIGH );
    awt = new AndroidWidgetToolkit( activity );

    int density = awt.getDensityDpi();

    assertEquals( DisplayMetrics.DENSITY_HIGH, density );
  }

  @Test
  public void testGetColorDepth() throws Exception {
    awt = new AndroidWidgetToolkit( activity );
    int depth = awt.getSurfaceColorDepth();

    assertEquals( 24, depth );
  }

  @Test
  public void testGetProgressIndicator() {
    awt = new AndroidWidgetToolkit( activity );
    IProgressIndicator expectedIndicator = mock( IProgressIndicator.class );
    awt.setProgressIndicator( expectedIndicator );

    IProgressIndicator indicator = awt.getProgressIndicator();

    assertEquals( expectedIndicator, indicator );
  }

  @Test
  public void testExecuteDelayedInUiThreadWhileFinishing() {
    awt = new AndroidWidgetToolkit( activity );
    activity.finish();
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable delayedRunnable = mock( Runnable.class );

    awt.executeDelayedInUiThread( delayedRunnable, 42 );

    verify( handler, never() ).postDelayed( any( Runnable.class ), eq( 42 ) );
  }

  @Test
  public void testExecuteDelayedInUiThreadWhileNotFinishing() {
    awt = new AndroidWidgetToolkit( activity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable delayedRunnable = mock( Runnable.class );

    awt.executeDelayedInUiThread( delayedRunnable, 42 );

    verify( handler ).postDelayed( delayedRunnable, 42 );
  }

  @Test
  public void testCancelWhileFinishing() {
    awt = new AndroidWidgetToolkit( activity );
    Handler handler = mock( Handler.class );
    Runnable delayedRunnable = mock( Runnable.class );

    awt.cancelInUiThread( delayedRunnable );

    verify( handler, never() ).removeCallbacks( eq( delayedRunnable ) );
  }

  @Test
  public void testCancelWhileNotFinishing() {
    awt = new AndroidWidgetToolkit( activity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable delayedRunnable = mock( Runnable.class );

    awt.cancelInUiThread( delayedRunnable );

    verify( handler ).removeCallbacks( delayedRunnable );
  }

  @Test
  public void testGetOperatorForCallOperation() throws Exception {
    awt.registerObjectById( WIDGET1_ID, new Composite( activity ) );
    CallOperation operation = new CallOperation();
    operation.setTarget( WIDGET1_ID );

    IOperator operator = awt.getOperator( operation );
    assertEquals( CompositeOperator.class, operator.getClass() );
  }

  @Test
  public void testGetOperatorForCallOperationOnDisplayLayout() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivity();
    CallOperation operation = new CallOperation();
    operation.setTarget( "w1" );
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    IOperator operator = awt.getOperator( operation );

    assertEquals( DisplayOperator.class, operator.getClass() );
  }

  @Test
  public void testDivideByDensityFactorInt() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 2 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    int scaledValue = awt.divideByDensityFactor( 100 );

    assertEquals( 50, scaledValue );
  }

  @Test
  public void testDivideByDensityFactorFloat() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 2 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    float scaledValue = awt.divideByDensityFactor( 100f );

    assertEquals( 50f, scaledValue, 0 );
  }

  @Test
  public void testDivideByDensityFactorZero() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 2 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    int scaledValue = awt.divideByDensityFactor( 0 );

    assertEquals( 0, scaledValue );
  }

  @Test
  public void testMultiplyByDensityFactorInt() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 2 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    int scaledValue = awt.multiplyByDensityFactor( 200 );

    assertEquals( 400, scaledValue );
  }

  @Test
  public void testMultiplyByDensityFactorFloat() throws Exception {
    Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
    ShadowDisplay shadowDisplay = Robolectric.shadowOf( defaultDisplay );
    shadowDisplay.setDensity( 2 );
    IWidgetToolkit awt = new AndroidWidgetToolkit( activity );

    float scaledValue = awt.multiplyByDensityFactor( 200f );

    assertEquals( 400f, scaledValue, 0 );
  }

  @Test
  public void testDispose() throws Exception {
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( activity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    awt.setBitmapCache( cache );
    UiCallbackOperator uiCallbackOperator = new UiCallbackOperator( activity );
    awt.getOperatorsMap().put( UiCallback.class, uiCallbackOperator );
    UiCallback uiCallback = mock( UiCallback.class );
    awt.getObjectRegistry().put( "uicb", uiCallback );

    awt.dispose();

    verify( handler ).removeCallbacksAndMessages( 0 );
    verify( cache ).clear();
    verify( uiCallback ).setActive( false );
  }

  @Test
  public void testExecuteInUiThreadWhileFinishing() throws Exception {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    uiActivity.finish();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable runnable = mock( Runnable.class );

    awt.executeInUiThread( runnable );

    verify( handler, never() ).post( runnable );
  }

  @Test
  public void testExecuteInUiThreadWhileNotFinishing() throws Exception {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable runnable = mock( Runnable.class );

    awt.executeInUiThread( runnable );

    verify( handler ).post( runnable );
  }

  @Test
  public void testShowErrorShowingDialog() throws Exception {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );
    Handler handler = mock( Handler.class );
    awt.setHandler( handler );
    Runnable runnable = mock( Runnable.class );

    awt.executeInUiThread( runnable );

    verify( handler ).post( runnable );
  }

  @Test
  public void testShowError() throws Exception {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );
    ErrorDialog dialog = mock( ErrorDialog.class );
    awt.setErrorDialog( dialog );
    Throwable throwable = mock( Throwable.class );

    awt.showError( throwable );

    verify( dialog ).show( eq( throwable ) );
  }

  @Test
  public void testShowLocalizableException() throws Exception {
    TabrisActivity uiActivity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = new AndroidWidgetToolkit( uiActivity );
    ErrorDialog dialog = mock( ErrorDialog.class );
    awt.setErrorDialog( dialog );
    LocalizableException exception = mock( LocalizableException.class );
    when( exception.getKey() ).thenReturn( LocalizableException.SESSION_TIMEOUT );

    awt.showError( exception );

    verify( exception ).getKey();
    String expectedMessage = uiActivity.getString( R.string.dialog_restart_message );
    HasExpectedMessage hasExpectedMessage = new HasExpectedMessage( expectedMessage );
    verify( dialog ).show( argThat( hasExpectedMessage ) );
  }

  class HasExpectedMessage extends ArgumentMatcher<Throwable> {

    private final String expectedMessage;

    public HasExpectedMessage( String expectedMessage ) {
      this.expectedMessage = expectedMessage;
    }

    @Override
    public boolean matches( Object throwable ) {
      if( throwable instanceof Throwable ) {
        return ( ( Throwable )throwable ).getMessage().equals( expectedMessage );
      }
      return false;
    }

  }

  @Test
  public void testGetBitmapDrawableCache() throws Exception {
    ReferenceAwareLRUCache<String, BitmapDrawable> bitmapCache = awt.getBitmapCache();

    assertNotNull( bitmapCache );

    ReferenceAwareLRUCache<String, BitmapDrawable> bitmapCache2 = awt.getBitmapCache();

    assertEquals( bitmapCache, bitmapCache2 );
  }

  @Test
  public void testObjectRegistryContainsDisplayView() throws Exception {
    com.eclipsesource.tabris.android.toolkit.view.Display display = awt.findObjectById( DISPLAY_ID,
                                                                                        com.eclipsesource.tabris.android.toolkit.view.Display.class );

    assertNotNull( display );
  }

  @Test
  public void testGetFocusTrackingListener() throws Exception {
    RecordingFocusTrackingListener listener = awt.getFocusTrackingListener();

    assertNotNull( listener );

    RecordingFocusTrackingListener listener2 = awt.getFocusTrackingListener();

    assertEquals( listener, listener2 );
  }
}
