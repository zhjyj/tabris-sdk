/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.content.DialogInterface;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAlertDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeDatePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
public class DateTimeDatePickerDialog_Test {

  class DialogUnderTest extends DateTimeDatePickerDialog {

    private int year;
    private int month;
    private int day;
    private int updatedCount;

    public DialogUnderTest( Activity activity, Calendar calendar ) {
      super( activity, calendar );
    }

    public void expected( int year, int month, int day ) {
      this.year = year;
      this.month = month;
      this.day = day;
    }

    @Override
    public void updateDate( int year, int month, int day ) {
      super.updateDate( year, month, day );
      assertEquals( this.year, year );
      assertEquals( this.month, month );
      assertEquals( this.day, day );
      updatedCount++;
    }

    public int getUpdatedCount() {
      return updatedCount;
    }

  }

  @Test(expected = NullPointerException.class)
  public void testCreateNullActivity() {
    new DateTimeDatePickerDialog( null, Calendar.getInstance() );
  }

  @Test(expected = NullPointerException.class)
  public void testCreateNullCalendar() {
    new DateTimeDatePickerDialog( new Activity(), null );
  }

  @Test
  public void testCreateOk() {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    DateTimeDatePickerDialog dialog = new DateTimeDatePickerDialog( new Activity(),
                                                                    Calendar.getInstance() );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    assertNotNull( shadowDialog.getCustomTitleView().findViewById( R.id.alertTitle ) );
    assertNotNull( shadowDialog.getCustomTitleView().findViewById( R.id.icon ) );
  }

  @Test
  public void testReset() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DateTimeDatePickerDialog dialog = new DateTimeDatePickerDialog( new Activity(), calendar );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.reset();

    verify( spinner ).setDate( calendar.getTime() );
  }

  @Test
  public void testChangeTime() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DateTimeDatePickerDialog dialog = new DateTimeDatePickerDialog( new Activity(), calendar );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );
    Calendar newCalendar = ( Calendar )calendar.clone();
    newCalendar.set( Calendar.YEAR, calendar.get( Calendar.YEAR ) + 1 );
    newCalendar.set( Calendar.MONTH, calendar.get( Calendar.MONTH ) + 1 );
    newCalendar.set( Calendar.DAY_OF_MONTH, calendar.get( Calendar.DAY_OF_MONTH ) + 1 );

    verify( spinner ).setDate( calendar.getTime() );
    verify( spinner ).formatDate( calendar.getTime() );

    dialog.onDateChanged( null,
                          newCalendar.get( Calendar.YEAR ),
                          newCalendar.get( Calendar.MONTH ),
                          newCalendar.get( Calendar.DAY_OF_MONTH ) );
    dialog.onClick( mock( DialogInterface.class ), 0 );

    verify( spinner ).formatDate( newCalendar.getTime() );
    verify( spinner ).setDate( newCalendar.getTime() );
    verifyNoMoreInteractions( spinner );
  }

  @Test
  public void testSetYear() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DialogUnderTest dialog = new DialogUnderTest( new Activity(), calendar );
    dialog.expected( 2000, calendar.get( Calendar.MONTH ), calendar.get( Calendar.DAY_OF_MONTH ) );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.setYear( 2000 );

    // we can exactly assert what date is set on the spinner because there is
    // now Shadow object for the dialog
    verify( spinner, times( 2 ) ).setDate( any( Date.class ) );
    assertEquals( 1, dialog.getUpdatedCount() );
  }

  @Test
  public void testSetMonth() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DialogUnderTest dialog = new DialogUnderTest( new Activity(), calendar );
    dialog.expected( calendar.get( Calendar.YEAR ), 2, calendar.get( Calendar.DAY_OF_MONTH ) );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.setMonth( 2 );

    // we can exactly assert what date is set on the spinner because there is
    // now Shadow object for the dialog
    verify( spinner, times( 2 ) ).setDate( any( Date.class ) );
    assertEquals( 1, dialog.getUpdatedCount() );
  }

  @Test
  public void testSetDay() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DialogUnderTest dialog = new DialogUnderTest( new Activity(), calendar );
    dialog.expected( calendar.get( Calendar.YEAR ), calendar.get( Calendar.MONTH ), 23 );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.setDay( 23 );

    // we can exactly assert what date is set on the spinner because there is
    // now Shadow object for the dialog
    verify( spinner, times( 2 ) ).setDate( any( Date.class ) );
    assertEquals( 1, dialog.getUpdatedCount() );
  }
}
