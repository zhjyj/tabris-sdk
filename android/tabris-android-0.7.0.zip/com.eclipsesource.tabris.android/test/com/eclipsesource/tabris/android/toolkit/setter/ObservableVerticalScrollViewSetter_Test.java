/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ObservableVerticalScrollViewSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ObservableVerticalScrollViewSetter<ObservableVerticalScrollView> setter = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( new TabrisActivity() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ObservableVerticalScrollViewSetter<ObservableVerticalScrollView> setter = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( new TabrisActivity() );
    setter.execute( mock( ObservableVerticalScrollView.class ), null );
  }

  @Test
  public void testSetOrigin() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.multiplyByDensityFactor( 20 ) ).thenReturn( 30 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 45 );
    activity.setProcessor( processor );
    ObservableVerticalScrollViewSetter<ObservableVerticalScrollView> setter = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( activity );
    ObservableVerticalScrollView view = mock( ObservableVerticalScrollView.class );
    SetProperties props = new SetProperties();
    props.setOrigin( Arrays.asList( 20, 30 ) );

    setter.execute( view, props );

    verify( view ).doSmoothScrollTo( 30, 45 );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOriginWrongArgs() throws Exception {
    ObservableVerticalScrollViewSetter<ObservableVerticalScrollView> setter = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( new TabrisActivity() );
    ObservableVerticalScrollView view = mock( ObservableVerticalScrollView.class );
    SetProperties props = new SetProperties();
    props.setOrigin( Arrays.asList( 30 ) );

    setter.execute( view, props );
  }

  @Test
  public void testNoSetPropertiesSpecified() throws Exception {
    ObservableVerticalScrollViewSetter<ObservableVerticalScrollView> setter = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( new TabrisActivity() );
    ObservableVerticalScrollView view = mock( ObservableVerticalScrollView.class );
    SetProperties props = new SetProperties();

    setter.execute( view, props );

    verifyNoMoreInteractions( view );
  }
}
