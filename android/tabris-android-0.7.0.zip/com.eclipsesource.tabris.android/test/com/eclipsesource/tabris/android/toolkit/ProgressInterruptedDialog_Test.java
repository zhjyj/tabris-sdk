/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
public class ProgressInterruptedDialog_Test {

  class TestProgressInterruptedDialog extends ProgressInterruptedDialog {

    private Dialog delegate;

    public TestProgressInterruptedDialog( final Activity activity, AndroidWidgetToolkit awt ) {
      super( activity, awt );
    }

    @Override
    protected Dialog getDialogDelegate( Activity activity ) {
      if( delegate == null ) {
        delegate = mock( Dialog.class );
      }
      return delegate;
    }
  }

  @Test
  public void testShow() {
    Activity activity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = mock( AndroidWidgetToolkit.class );
    ErrorDialog dialog = new ProgressInterruptedDialog( activity, awt );
    AlertDialog alertDialog = dialog.getDialog();
    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( alertDialog );
    assertFalse( shadowDialog.isShowing() );

    dialog.run();

    assertTrue( shadowDialog.isShowing() );
    String expectedMessage = activity.getString( R.string.dialog_interrupted_progress_message );
    assertEquals( expectedMessage, shadowDialog.getMessage() );
  }

  @Test
  public void testButtons() {
    Activity activity = UiTestUtil.createActivity();
    AndroidWidgetToolkit awt = mock( AndroidWidgetToolkit.class );

    TestProgressInterruptedDialog dialog = new TestProgressInterruptedDialog( activity, awt );

    verify( dialog.getDialogDelegate( activity ) ).setButton( eq( DialogInterface.BUTTON_NEGATIVE ),
                                                              anyString(),
                                                              isA( ErrorDialog.ActivityFinishListener.class ) );
    verify( dialog.getDialogDelegate( activity ) ).setButton( eq( DialogInterface.BUTTON_NEUTRAL ),
                                                              anyString(),
                                                              isA( ErrorDialog.DialogCancelListener.class ) );
  }

}
