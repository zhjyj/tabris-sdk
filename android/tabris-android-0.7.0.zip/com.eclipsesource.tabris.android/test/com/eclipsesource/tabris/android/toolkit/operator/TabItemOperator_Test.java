/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.toolkit.operator.TabItemOperator;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TabItemOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String TAB_FOLDER_ID = "w3";
  private static final String TAB_ITEM_ID = "w4";

  private TabrisActivity activity;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    FrameLayout parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    rootLayout.addView( parentLayout );
  }

  @Test
  @Ignore("Can not test because Robolectric doesn't provide a TabHost.getTabContentView() implementation which is used by the implementation.")
  public void testCreateTabItem() {
    TabFolder tabHost = ( TabFolder )activity.getLayoutInflater().inflate( R.layout.tabfolder_top,
                                                                           null );
    tabHost.setTag( TAB_FOLDER_ID );
    tabHost.setup();
    ViewGroup root = ( ViewGroup )activity.findViewById( R.id.root_layout );
    root.addView( tabHost );
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( TAB_ITEM_ID );
    CreateProperties properties = new CreateProperties();
    properties.setParent( TAB_FOLDER_ID );
    createOp.setProperties( properties );
    TabItemOperator operator = new TabItemOperator( activity );

    Assert.assertNull( tabHost.getCurrentTabTag() );

    operator.create( createOp );

    Assert.assertEquals( TAB_ITEM_ID, tabHost.getCurrentTabTag() );
  }

  // more tests should be written when a proper robolectric shadow object has
  // been created

}
