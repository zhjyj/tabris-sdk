/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

public class CompositeItemClickListener_Test {

  @Test
  public void testInheritsFromListenerHolder() throws Exception {
    CompositeItemSelectedListener compListener = new CompositeItemSelectedListener();

    assertTrue( compListener instanceof ListenerHolder );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testNotifyOnItemSelected() {
    CompositeItemSelectedListener compListener = new CompositeItemSelectedListener();
    OnItemSelectedListener listener1 = mock( OnItemSelectedListener.class );
    OnItemSelectedListener listener2 = mock( OnItemSelectedListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    AdapterView parent = mock( AdapterView.class );
    View view = mock( View.class );

    compListener.onItemSelected( parent, view, 1, 2 );

    verify( listener1 ).onItemSelected( parent, view, 1, 2 );
    verify( listener2 ).onItemSelected( parent, view, 1, 2 );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testNotifyOnNothingSelected() {
    CompositeItemSelectedListener compListener = new CompositeItemSelectedListener();
    OnItemSelectedListener listener1 = mock( OnItemSelectedListener.class );
    OnItemSelectedListener listener2 = mock( OnItemSelectedListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    AdapterView parent = mock( AdapterView.class );

    compListener.onNothingSelected( parent );

    verify( listener1 ).onNothingSelected( parent );
    verify( listener2 ).onNothingSelected( parent );
  }
}
