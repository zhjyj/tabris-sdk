/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.UiCallback;
import com.eclipsesource.tabris.android.toolkit.operator.UiCallbackOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class UiCallbackOperator_Test {

  private static final String WIDGET_ID = "w4";

  private UiCallbackOperator uicbOperator;
  private TabrisActivity activity;

  private UiCallback uiCallback;

  private SetOperation setOp;

  private CreateOperation createOp;

  private AndroidWidgetToolkit awt;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivity();
    uiCallback = mock( UiCallback.class );
    awt = new AndroidWidgetToolkit( activity );
    awt.getObjectRegistry().put( "uicb", uiCallback );
    activity.getProcessor().setWidgetToolkit( awt );
    uicbOperator = new UiCallbackOperator( activity );
    setOp = new SetOperation();
    setOp.setTarget( "uicb" );
    createOp = new CreateOperation();
    createOp.setTarget( "uicb" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullOp() throws Exception {
    uicbOperator.set( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullTarget() throws Exception {
    SetOperation operation = new SetOperation();
    operation.setProperties( new SetProperties() );
    uicbOperator.set( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateOnNullOp() throws Exception {
    uicbOperator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateOnNullTarget() throws Exception {
    CreateOperation operation = new CreateOperation();
    operation.setProperties( new CreateProperties() );
    uicbOperator.create( operation );
  }

  @Test
  public void testCreateOk() throws Exception {
    uicbOperator.create( createOp );

    assertNotNull( awt.findObjectById( "uicb", UiCallback.class ) );
  }

  @Test
  public void testCreateAndActivateOk() throws Exception {
    CreateProperties props = new CreateProperties();
    props.setActive( true );
    createOp.setProperties( props );

    uicbOperator.create( createOp );

    UiCallback uicb = awt.findObjectById( "uicb", UiCallback.class );
    assertTrue( uicb.callbackIsActive() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullProperties() throws Exception {
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET_ID );
    uicbOperator.set( operation );
  }

  @Test
  public void testSetActiveTrue() {
    SetProperties props = new SetProperties();
    props.setActive( true );
    setOp.setProperties( props );

    uicbOperator.set( setOp );

    verify( uiCallback ).setActive( true );
  }

  @Test
  public void testSetActiveFalse() {
    SetProperties props = new SetProperties();
    props.setActive( false );
    setOp.setProperties( props );

    uicbOperator.set( setOp );

    verify( uiCallback ).setActive( false );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallOnNullOp() throws Exception {
    uicbOperator.call( null );
  }

  @Test
  public void testCallMethodSendUiRequest() throws Exception {
    CallOperation operation = new CallOperation();
    operation.setTarget( "uicb" );
    operation.setMethod( "sendUIRequest" );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );

    uicbOperator.call( operation );

    verify( processor ).processPostRequest( new PostRequest() );
  }
}
