/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.os.Build;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAsyncTask;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapFactory;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowLooper;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class LoadImageTask_Test {

  private static final String IMAGE_PATH = "somePath/toAn/Image";

  class LoadImageTaskUnderTest extends LoadImageTask {

    public LoadImageTaskUnderTest( TabrisActivity activity ) {
      super( activity );
    }

    BitmapDrawable executionResult;
    boolean doInBackgroundCalled;

    @Override
    protected void onPostExecute( BitmapDrawable result ) {
      super.onPostExecute( result );
      this.executionResult = result;
    }

    @Override
    protected BitmapDrawable doInBackground( List<String>... params ) {
      BitmapDrawable result = super.doInBackground( params );
      doInBackgroundCalled = true;
      return result;
    };
  };

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testExecuteImageParamMalformed() throws Throwable {
    LoadImageTask loadBitmapTask = new LoadImageTask( new TabrisActivity() );

    loadBitmapTask.loadBitmap( Arrays.asList( IMAGE_PATH, "256" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testExecuteUrlMissing() throws Throwable {
    LoadImageTask loadBitmapTask = new LoadImageTask( new TabrisActivity() );

    loadBitmapTask.loadBitmap( Arrays.asList( "", "256", "100" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testExecuteEmptyParam() throws Throwable {
    LoadImageTask loadBitmapTask = new LoadImageTask( new TabrisActivity() );

    loadBitmapTask.loadBitmap( new ArrayList<String>() );
  }

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testExecuteNullParam() throws Throwable {
    LoadImageTask loadBitmapTask = new LoadImageTask( new TabrisActivity() );

    loadBitmapTask.loadBitmap( ( List<String> )null );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableFromNetwork() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTask loadBitmapTask = new LoadImageTask( activity );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    when( activity.getProcessor().processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    when( transportResult.getResult() ).thenReturn( inputImage );

    loadBitmapTask.loadBitmap( params );

    assertNotNull( loadBitmapTask.get() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableDirectlyFromCache() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTaskUnderTest loadBitmapTask = new LoadImageTaskUnderTest( activity );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( cache.get( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( toolkit.getBitmapCache() ).thenReturn( cache );

    loadBitmapTask.loadBitmap( params );

    assertEquals( bitmapDrawable, loadBitmapTask.executionResult );
    assertFalse( loadBitmapTask.doInBackgroundCalled );
    verify( cache ).increaseReferenceCount( IMAGE_PATH );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableFromCacheInUiThread() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    Robolectric.bindShadowClass( TabrisShadowLooper.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTaskUnderTest loadBitmapTask = new LoadImageTaskUnderTest( activity );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( cache.get( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( cache.getOrWait( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( toolkit.getBitmapCache() ).thenReturn( cache );

    loadBitmapTask.loadBitmap( params );

    verify( cache ).getOrWait( IMAGE_PATH );
    assertEquals( bitmapDrawable, loadBitmapTask.executionResult );
    assertTrue( loadBitmapTask.doInBackgroundCalled );
    verify( cache ).increaseReferenceCount( IMAGE_PATH );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableFromDelayedCacheInUiThread() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTaskUnderTest loadBitmapTask = new LoadImageTaskUnderTest( activity );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( cache.getOrWait( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( toolkit.getBitmapCache() ).thenReturn( cache );

    loadBitmapTask.loadBitmap( params );

    verify( cache ).getOrWait( IMAGE_PATH );
    verify( cache, never() ).putAndNotify( IMAGE_PATH, bitmapDrawable );
    assertEquals( bitmapDrawable, loadBitmapTask.executionResult );
    assertTrue( loadBitmapTask.doInBackgroundCalled );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableViaInternalCallToExecute() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTaskUnderTest loadBitmapTask = spy( new LoadImageTaskUnderTest( activity ) );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getApiLevel() ).thenReturn( Build.VERSION_CODES.GINGERBREAD );
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( cache.getOrWait( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( toolkit.getBitmapCache() ).thenReturn( cache );

    loadBitmapTask.loadBitmap( params );

    verify( loadBitmapTask ).execute( params );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableViaInternalCallToExecuteOnExecutor() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    LoadImageTaskUnderTest loadBitmapTask = spy( new LoadImageTaskUnderTest( activity ) );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getApiLevel() ).thenReturn( Build.VERSION_CODES.HONEYCOMB );
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( cache.getOrWait( IMAGE_PATH ) ).thenReturn( bitmapDrawable );
    when( toolkit.getBitmapCache() ).thenReturn( cache );

    loadBitmapTask.loadBitmap( params );

    verify( loadBitmapTask ).executeOnExecutor( any( Executor.class ), eq( params ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testLoadDrawableFails() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    BitmapDrawableCache cache = mock( BitmapDrawableCache.class );
    when( toolkit.getBitmapCache() ).thenReturn( cache );
    LoadImageTask loadBitmapTask = new LoadImageTask( activity );
    List<String> params = Arrays.asList( IMAGE_PATH, "256", "256" );
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    when( activity.getProcessor().processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    when( transportResult.hasException() ).thenReturn( true );
    when( transportResult.getResult() ).thenReturn( inputImage );

    loadBitmapTask.loadBitmap( params );

    verify( cache ).unlockWriteLock( IMAGE_PATH );
    assertNull( loadBitmapTask.get() );
  }

  private IWidgetToolkit createMockedWidgetToolkit( TabrisActivity activity ) {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( activity.getProcessor() ).thenReturn( processor );
    return toolkit;
  }
}
