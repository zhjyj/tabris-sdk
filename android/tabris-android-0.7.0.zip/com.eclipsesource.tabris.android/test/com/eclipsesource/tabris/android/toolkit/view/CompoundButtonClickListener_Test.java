/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.CompoundButtonClickListener;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CompoundButtonClickListener_Test {

  private static final String WIDGET_ID = "w2";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new CompoundButtonClickListener( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOnClickNullArg() throws Exception {
    CompoundButtonClickListener listener = new CompoundButtonClickListener( new TabrisActivity() );
    listener.onClick( null );
  }

  @Test
  public void testOnClick() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    CompoundButtonClickListener listener = new CompoundButtonClickListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, WIDGET_ID );
    request.addParam( WIDGET_ID + IProtocolConstants.SELECTION_POSTFIX, Boolean.TRUE.toString() );
    CompoundButton button = mock( CompoundButton.class );
    when( button.getTag() ).thenReturn( WIDGET_ID );
    when( button.isChecked() ).thenReturn( Boolean.TRUE );

    listener.onClick( button );

    verify( processor ).processPostRequest( request );
  }

}
