/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolBarOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String TOOLBAR_ID = "w3";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFields();
    activity.setContentView( R.layout.protocol );
    parentLayout = new FrameLayout( activity );
    toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getSetterManager() ).thenReturn( mock( SetterManager.class ) );
  }

  @Test(expected = NullPointerException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarNoProps() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateToolBarNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TOOLBAR_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateToolBarOk() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    verify( toolkit ).registerObjectById( eq( TOOLBAR_ID ), any( ToolBar.class ) );
    View view = parentLayout.findViewWithTag( TOOLBAR_ID );
    assertTrue( view instanceof ToolBar );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( TOOLBAR_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarWrongBounds() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = createValidCreateOperation();
    when( toolkit.getSetterManager() ).thenReturn( new SetterManager( activity ) );
    op.getProperties().setBounds( Arrays.asList( 10, 20, 30 ) );

    operator.create( op );
  }

  @Test
  public void testGetType() throws Exception {
    ToolBarOperator op = new ToolBarOperator( new TabrisActivity() );
    assertEquals( ToolBarOperator.TYPE, op.getType() );
  }

}