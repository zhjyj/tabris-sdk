/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.text.InputFilter.LengthFilter;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowEditText;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class EditTextSetter_Test {

  @Test
  public void testSetEnabledFalse() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    SetProperties props = new SetProperties();
    props.setEnabled( false );

    setter.execute( editText, props );

    verify( editText ).setEnabled( false );
    verify( editText ).setFocusable( false );
  }

  @Test
  public void testSetEnabledTrue() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    SetProperties props = new SetProperties();
    props.setEnabled( true );

    setter.execute( editText, props );

    verify( editText ).setEnabled( true );
    verify( editText ).setFocusable( true );
  }

  @Test
  public void testSetEditableFalse() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    SetProperties properties = new SetProperties();
    properties.setEditable( false );

    setter.execute( editText, properties );

    verify( editText ).setFocusable( false );
  }

  @Test
  public void testSetEditableTrue() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    SetProperties properties = new SetProperties();
    properties.setEditable( true );

    setter.execute( editText, properties );

    verify( editText ).setFocusable( true );
  }

  @Test
  public void testSetTextLimit() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setTextLimit( 5 );

    setter.execute( editText, properties );

    assertTrue( editText.getFilters()[ 0 ] instanceof LengthFilter );
  }
}
