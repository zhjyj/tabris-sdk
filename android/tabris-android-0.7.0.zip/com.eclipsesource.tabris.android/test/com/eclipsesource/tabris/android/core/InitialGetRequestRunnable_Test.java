/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.org.apache.http.ParseException;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.toolkit.ProgressIndicator;

public class InitialGetRequestRunnable_Test {

  private GetRequest request;
  private ProtocolProcessor processor;
  private ITransportResult response;
  private ITransport transport;
  private IWidgetToolkit toolkit;
  private IProtocolParser parser;
  private ProgressIndicator progressIndicator;

  @Before
  public void setUp() {
    request = mock( GetRequest.class );
    processor = mock( ProtocolProcessor.class );
    response = mock( ITransportResult.class );
    transport = mock( ITransport.class );
    when( transport.get( request ) ).thenReturn( response );
    when( processor.getTransport() ).thenReturn( transport );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    progressIndicator = mock( ProgressIndicator.class );
    when( toolkit.getProgressIndicator() ).thenReturn( progressIndicator );
    parser = mock( IProtocolParser.class );
  }

  @Test
  public void testRunWithFailedGetRequest() {
    when( response.hasException() ).thenReturn( true );
    Exception exception = mock( Exception.class );
    when( response.getException() ).thenReturn( exception );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( processor ).getTransport();
    verify( processor ).getWidgetToolkit();
    verify( toolkit ).showError( eq( response.getException() ) );
    verifyNoMoreInteractions( parser );
  }

  @Test
  public void testRunWithEmptyInitialResponse() throws IOException {
    InputStream responseStream = mock( InputStream.class );
    when( response.getResult() ).thenReturn( responseStream );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( response ).getResult();
    verify( parser ).parse( any( InputStream.class ) );
    verify( responseStream ).close();
    verifyProgressIndication();
    verifyNoMoreInteractions( toolkit );
  }

  private void verifyProgressIndication() {
    verify( toolkit ).getProgressIndicator();
    verify( progressIndicator ).start();
    verify( progressIndicator ).stop();
  }

  @Test
  public void testRunWithNullResponse() {
    when( response.getResult() ).thenReturn( null );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( response ).getResult();
    verify( toolkit ).showError( any( Exception.class ) );
    verifyNoMoreInteractions( parser );
    verifyProgressIndication();
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testRunWithFailingResponse() throws IOException {
    InputStream responseStream = mock( InputStream.class );
    when( responseStream.read() ).thenThrow( new IOException() );
    when( responseStream.read( any( byte[].class ) ) ).thenThrow( new IOException() );
    when( responseStream.read( any( byte[].class ), anyInt(), anyInt() ) ).thenThrow( new IOException() );
    when( response.getResult() ).thenReturn( responseStream );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( response ).getResult();
    verify( toolkit ).showError( any( Exception.class ) );
    verifyNoMoreInteractions( parser );
    verifyProgressIndication();
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testRunWithFailingParser() throws IOException {
    InputStream responseStream = mock( InputStream.class );
    doThrow( new ParseException() ).when( parser ).parse( any( InputStream.class ) );
    when( response.getResult() ).thenReturn( responseStream );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( response ).getResult();
    verify( toolkit ).showError( any( IllegalStateException.class ) );
    verifyProgressIndication();
    verifyNoMoreInteractions( toolkit );
    verify( responseStream ).close();
  }

  @Test
  public void testRunOK() throws IOException {
    InputStream responseStream = new ByteArrayInputStream( "foo".getBytes() );
    InputStream streamSpy = spy( responseStream );
    when( response.getResult() ).thenReturn( streamSpy );
    InitialGetRequestRunnable runnable = new InitialGetRequestRunnable( request, processor, parser );

    runnable.run();

    verify( response ).getResult();
    verify( parser ).parse( any( InputStream.class ) );
    verify( streamSpy ).close();
    verifyProgressIndication();
    verifyNoMoreInteractions( toolkit );
  }
}
