/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class UiCallbackRunnable_Test {

  private static final String CALLBACK_QUERY = "custom_service_handler=org.eclipse.rap.uicallback";

  class ProtocolProcessorUnderTest extends ProtocolProcessor {

    private GetRequest request;
    private final boolean exception;

    public ProtocolProcessorUnderTest( boolean exception ) {
      this.exception = exception;
    }

    @Override
    public ITransportResult processGetRequest( GetRequest request ) {
      this.request = request;
      Thread.currentThread().interrupt();
      ITransportResult result = mock( ITransportResult.class );
      when( result.hasException() ).thenReturn( exception );
      return result;
    }

    public GetRequest getRequest() {
      return request;
    }

    @Override
    public IProtocolParser getParser() {
      return mock( IProtocolParser.class );
    }
  }

  @Test
  public void testRunActive() {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessorUnderTest processor = new ProtocolProcessorUnderTest( false );
    activity.setProcessor( processor );
    UiCallbackRunnable runnable = new UiCallbackRunnable( activity );

    runnable.run();

    GetRequest request = new GetRequest();
    request.setQuery( CALLBACK_QUERY );
    request.setTimeout( 0 );
    request.setSilentRequest( true );
    assertEquals( request, processor.getRequest() );
  }

  @Test
  public void testIsConnectedTrue() throws Exception {
    TabrisActivity activity = createConnectivityAwareActivity( true );

    UiCallbackRunnable runnable = new UiCallbackRunnable( activity );

    assertTrue( runnable.isConnected() );
  }

  @Test
  public void testIsConnectedFalse() throws Exception {
    TabrisActivity activity = createConnectivityAwareActivity( false );

    UiCallbackRunnable runnable = new UiCallbackRunnable( activity );

    assertFalse( runnable.isConnected() );
  }

  private TabrisActivity createConnectivityAwareActivity( boolean connected ) {
    TabrisActivity activity = mock( TabrisActivity.class );
    ConnectivityManager connectivityManager = mock( ConnectivityManager.class );
    NetworkInfo networkInfo = mock( NetworkInfo.class );
    when( networkInfo.isConnected() ).thenReturn( connected );
    when( connectivityManager.getActiveNetworkInfo() ).thenReturn( networkInfo );
    when( activity.getSystemService( Context.CONNECTIVITY_SERVICE ) ).thenReturn( connectivityManager );
    return activity;
  }
}
