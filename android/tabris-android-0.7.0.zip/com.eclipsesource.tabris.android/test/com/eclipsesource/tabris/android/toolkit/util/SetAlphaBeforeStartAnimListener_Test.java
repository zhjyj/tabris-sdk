/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.util.SetAlphaBeforeStartAnimListener;

import android.view.animation.Animation;
import android.widget.ImageView;

public class SetAlphaBeforeStartAnimListener_Test {

  @Test
  public void testOnAnimationStart() {
    ImageView view = mock( ImageView.class );
    SetAlphaBeforeStartAnimListener listener = new SetAlphaBeforeStartAnimListener( view, 12, false );
    Animation animation = mock( Animation.class );

    listener.onAnimationStart( animation );

    verify( view ).setAlpha( 12 );
    verifyNoMoreInteractions( animation );
  }

  @Test
  public void testOnAnimationStartRemove() {
    ImageView view = mock( ImageView.class );
    SetAlphaBeforeStartAnimListener listener = new SetAlphaBeforeStartAnimListener( view, 10, true );
    Animation animation = mock( Animation.class );

    listener.onAnimationStart( animation );

    verify( view ).setAlpha( 10 );
    verify( animation ).setAnimationListener( null );
  }

}
