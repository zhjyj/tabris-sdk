/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListSelectionAdapter;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    setter.execute( mock( List.class ), null );
  }

  @Test
  public void testSetItems() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    SetProperties props = new SetProperties();
    props.setItems( Arrays.asList( "one", "two", "three" ) );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).setItems( props.getItems(), activity );
  }

  @Test
  public void testSetItemsNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setItems( null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetItemsEmpty() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    SetProperties props = new SetProperties();
    props.setItems( new ArrayList<String>() );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).setItems( props.getItems(), activity );
  }

  @Test
  public void testSetBackgroundNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setBackground( null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetSelectionIndices() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setSelectionIndices( Arrays.asList( 2 ) );
    List list = mock( List.class );
    ListSelectionAdapter<?> adapter = mock( ListSelectionAdapter.class );
    when( list.getAdapter() ).thenReturn( adapter );

    setter.execute( list, props );

    verify( adapter ).setSelection( 2 );
  }

  @Test
  public void testSetSelectionIndicesEmpty() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setSelectionIndices( new ArrayList<Integer>() );
    List list = mock( List.class );
    ListSelectionAdapter<?> adapter = mock( ListSelectionAdapter.class );
    when( list.getAdapter() ).thenReturn( adapter );

    setter.execute( list, props );

    verify( adapter ).setSelection( ListSelectionAdapter.NOTHING_SELECTED );
  }

  @Test
  public void testSetSelectionIndicesNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setSelectionIndices( null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetTopIndex() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    SetProperties props = new SetProperties();
    props.setTopIndex( 1 );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).smoothScrollToPosition( 1 );
  }
}
