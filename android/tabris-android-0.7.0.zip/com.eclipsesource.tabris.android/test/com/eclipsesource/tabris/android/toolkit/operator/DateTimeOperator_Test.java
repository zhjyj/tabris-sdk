/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.AlertDialog;
import android.util.SparseArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeDatePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeTimePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeSpinnerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateDateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingDateTimeChangedListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DateTimeOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String DATE_TIME_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    activity.getProcessor().getWidgetToolkit().registerObjectById( PARENT_ID, parentLayout );
  }

  @Test
  public void testGetType() {
    DateTimeOperator op = new DateTimeOperator( activity );

    assertEquals( DateTimeOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    DateTimeOperator operator = new DateTimeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeNoProps() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateDateTimeNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( DATE_TIME_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "unknownParent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithDateOk() throws Exception {
    List<String> style = Arrays.asList( DateTimeOperator.STYLE_DATE );
    RecordingDateTimeChangedListener listener = createAndAssertDateTime( style,
                                                                         DateTimeDatePickerDialog.class );
    assertValidDateValues( listener.getDateValues() );
  }

  @Test
  public void testCreateDateTimeWithTimeOk() throws Exception {
    List<String> style = Arrays.asList( DateTimeOperator.STYLE_TIME );
    RecordingDateTimeChangedListener listener = createAndAssertDateTime( style,
                                                                         DateTimeTimePickerDialog.class );
    assertValidTimeValues( listener.getDateValues() );
  }

  private RecordingDateTimeChangedListener createAndAssertDateTime( List<String> style,
                                                                    Class<? extends AlertDialog> dialog )
  {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( style );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertEquals( DATE_TIME_ID, view.getTag() );
    assertTrue( view instanceof DateTimeSpinner );
    DateTimeSpinner spinner = ( DateTimeSpinner )view;
    assertTrue( spinner.getDialog().getClass().equals( dialog ) );
    RecordingDateTimeChangedListener listener = ( RecordingDateTimeChangedListener )spinner.getListeners()
      .get( 0 );
    assertEquals( RecordingDateTimeChangedListener.class, listener.getClass() );
    return listener;
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testCreateDateTimeWithStyleCalendar() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( "CALENDAR" ) );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithStyleDateShort() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_DATE, STYLE_SHORT, DATE_FORMAT_SHORT );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeWithStyleDateMediumWrong1() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    CreateProperties props = op.getProperties();
    props.setStyle( Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.setDateSeparator( "," );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeWithStyleDateMediumWrong2() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    CreateProperties props = op.getProperties();
    props.setStyle( Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.setDatePattern( "DMY" );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithStyleDateMedium() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    CreateProperties props = op.getProperties();
    String dateSeparator = ",";
    props.setStyle( Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.setDatePattern( "YDM" );
    props.setDateSeparator( dateSeparator );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertTrue( view instanceof DateTimeSpinner );
    String targetFormat = DATE_FORMAT_YEAR
                          + dateSeparator
                          + DATE_FORMAT_DAY
                          + dateSeparator
                          + DATE_FORMAR_MONTH;
    assertEquals( targetFormat, ( ( DateTimeSpinner )view ).getDateFormat() );
  }

  @Test
  public void testCreateDateTimeWithStyleDateLong() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_DATE, STYLE_LONG, DATE_FORMAT_LONG );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeShort() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_SHORT, TIME_FORMAT_SHORT );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeMedium() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_MEDIUM, TIME_FORMAT_MEDIUM_AND_LONG );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeLong() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_LONG, TIME_FORMAT_MEDIUM_AND_LONG );
  }

  private void verifyDateTimeCreatedWithCorrectFormat( String dateTimeStyle,
                                                       String format,
                                                       String referenceformat )
  {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( dateTimeStyle, format ) );

    operator.create( op );
    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertTrue( view instanceof DateTimeSpinner );
    assertEquals( referenceformat, ( ( DateTimeSpinner )view ).getDateFormat() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( DATE_TIME_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testAttachSelectionListenerSpinnerWithDateStyle() throws Exception {
    IDateTimeSpinnerDialog dialog = new DateTimeDatePickerDialog( activity, Calendar.getInstance() );
    DateTimeSpinner spinner = createDateTimeSpinnerAndAttachToParent( dialog );
    ImmediateDateTimeChangedListener listener = executeListenOperationAndVerify( spinner );
    SparseArray<String> dateValues = listener.getDateValues();
    assertValidDateValues( dateValues );
  }

  private void assertValidDateValues( SparseArray<String> dateValues ) {
    assertEquals( IProtocolConstants.DATE_TIME_YEAR, dateValues.get( Calendar.YEAR ) );
    assertEquals( IProtocolConstants.DATE_TIME_MONTH, dateValues.get( Calendar.MONTH ) );
    assertEquals( IProtocolConstants.DATE_TIME_DAY, dateValues.get( Calendar.DAY_OF_MONTH ) );
  }

  @Test
  public void testAttachSelectionListenerSpinnerWithTimeStyle() throws Exception {
    IDateTimeSpinnerDialog dialog = new DateTimeTimePickerDialog( activity, Calendar.getInstance() );
    DateTimeSpinner spinner = createDateTimeSpinnerAndAttachToParent( dialog );
    ImmediateDateTimeChangedListener listener = executeListenOperationAndVerify( spinner );
    SparseArray<String> dateValues = listener.getDateValues();
    assertValidTimeValues( dateValues );
  }

  private void assertValidTimeValues( SparseArray<String> dateValues ) {
    assertEquals( IProtocolConstants.DATE_TIME_HOURS, dateValues.get( Calendar.HOUR_OF_DAY ) );
    assertEquals( IProtocolConstants.DATE_TIME_MINUTES, dateValues.get( Calendar.MINUTE ) );
    assertEquals( IProtocolConstants.DATE_TIME_SECONDS, dateValues.get( Calendar.SECOND ) );
  }

  private ImmediateDateTimeChangedListener executeListenOperationAndVerify( DateTimeSpinner spinner )
  {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( DATE_TIME_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( true );
    op.setProperties( properties );

    ArrayList<IDateTimeChangedListener> listeners = spinner.getListeners();
    assertTrue( listeners.isEmpty() );

    operator.listen( op );

    assertEquals( ImmediateDateTimeChangedListener.class, listeners.get( 0 ).getClass() );
    ImmediateDateTimeChangedListener listener = ( ImmediateDateTimeChangedListener )listeners.get( 0 );
    return listener;
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testRemoveSelectionListener() throws Exception {
    IDateTimeSpinnerDialog dialog = new DateTimeDatePickerDialog( activity, Calendar.getInstance() );
    DateTimeSpinner spinner = createDateTimeSpinnerAndAttachToParent( dialog );
    spinner.addListener( new ImmediateDateTimeChangedListener( mock( ProtocolProcessor.class ),
                                                               mock( SparseArray.class ) ) );
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( DATE_TIME_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( false );
    op.setProperties( properties );

    assertEquals( 1, spinner.getListeners().size() );

    operator.listen( op );

    assertTrue( spinner.getListeners().isEmpty() );
  }

  private DateTimeSpinner createDateTimeSpinnerAndAttachToParent( IDateTimeSpinnerDialog dialog ) {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             android.R.layout.simple_spinner_dropdown_item );
    DateTimeSpinner spinner = new DateTimeSpinner( activity, adapter, dialog, "" );
    spinner.setTag( DATE_TIME_ID );
    activity.getProcessor().getWidgetToolkit().registerObjectById( DATE_TIME_ID, spinner );
    parentLayout.addView( spinner );
    return spinner;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetYearRangeToLow() throws Exception {
    SetProperties props = new SetProperties();
    props.setYear( 1899 );
    executeSetOp( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetYearRangeToHigh() throws Exception {
    SetProperties props = new SetProperties();
    props.setYear( 2101 );
    executeSetOp( props );
  }

  @Test
  public void testSetYearTo1900() throws Exception {
    SetProperties props = new SetProperties();
    props.setYear( 1900 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setYear( 1900 );
  }

  @Test
  public void testSetYearTo2100() throws Exception {
    SetProperties props = new SetProperties();
    props.setYear( 2100 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setYear( 2100 );
  }

  @Test
  public void testSetMonthTo2() throws Exception {
    SetProperties props = new SetProperties();
    props.setMonth( 2 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setMonth( 2 );
  }

  @Test
  public void testSetDayTo3() throws Exception {
    SetProperties props = new SetProperties();
    props.setDay( 3 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setDay( 3 );
  }

  @Test
  public void testSetHoursTo4() throws Exception {
    SetProperties props = new SetProperties();
    props.setHours( 4 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setHours( 4 );
  }

  @Test
  public void testSetMinutesTo5() throws Exception {
    SetProperties props = new SetProperties();
    props.setMinutes( 5 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setMinutes( 5 );
  }

  private IDateTimeSpinnerDialog executeSetOp( SetProperties props ) {
    IDateTimeSpinnerDialog dialog = mock( IDateTimeSpinnerDialog.class );
    createDateTimeSpinnerAndAttachToParent( dialog );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( DATE_TIME_ID );
    setOp.setProperties( props );
    DateTimeOperator operator = new DateTimeOperator( activity );

    operator.set( setOp );
    return dialog;
  }
}
