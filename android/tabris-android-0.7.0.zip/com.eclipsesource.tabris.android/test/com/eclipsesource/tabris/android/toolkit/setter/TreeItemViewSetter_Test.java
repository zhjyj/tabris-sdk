/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAsyncTask;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeItemViewSetter_Test {

  private static final String TEXT_STRING1 = "Hello World!";
  private static final String TEXT_STRING2 = "The world is not enough";

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    setter.execute( mock( TreeItemView.class ), null );
  }

  @Test
  public void testSetTextsNull() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getTexts() );
  }

  @Test
  public void testSetTextsEmptyList() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setTexts( new ArrayList<String>() );

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getTexts() );
  }

  @Test
  public void testSetTextsOk() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    properties.setTexts( Arrays.asList( TEXT_STRING1, TEXT_STRING2 ) );

    setter.execute( treeItemView, properties );

    verify( treeItemView ).setTexts( Arrays.asList( TEXT_STRING1, TEXT_STRING2 ) );
  }

  @Test
  public void testSetColorsNull() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getForegroundCellColors() );
    assertNull( treeItemView.getBackgroundCellColors() );
  }

  @Test
  public void testSetColorsEmptyList() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setCellForegrounds( new ArrayList<List<Integer>>() );
    properties.setCellBackgrounds( new ArrayList<List<Integer>>() );

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getForegroundCellColors() );
    assertNull( treeItemView.getBackgroundCellColors() );
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testSetColorsOk() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    List<Integer> colorTuple = Arrays.asList( 1, 2, 3, 4 );
    int color = SetterManager.colorToupleToInt( colorTuple );
    List<List<Integer>> multipleColorTuples = Arrays.asList( colorTuple,
                                                             colorTuple,
                                                             colorTuple,
                                                             colorTuple );
    properties.setCellForegrounds( multipleColorTuples );
    properties.setCellBackgrounds( multipleColorTuples );

    setter.execute( treeItemView, properties );

    verify( treeItemView ).setForegroundCellColors( Arrays.asList( color, color, color, color ) );
  }

  @Test
  public void testSetImagesNull() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getImage() );
  }

  @Test
  public void testSetImagesEmptyList() {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = new TreeItemView( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setTexts( new ArrayList<String>() );

    setter.execute( treeItemView, properties );

    assertNull( treeItemView.getImage() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testSetImagesOk() throws Exception {
    TabrisActivity activity = getImageCreationMockingUiActivity();
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( activity );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    properties.setImages( Arrays.asList( Arrays.asList( "path", "123", "123" ) ) );

    setter.execute( treeItemView, properties );

    verify( treeItemView ).setImage( any( BitmapDrawable.class ) );
    verify( treeView ).refreshTree();
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    verify( cache ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }

  private TabrisActivity getImageCreationMockingUiActivity() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    when( activity.getProcessor().processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    when( transportResult.getResult() ).thenReturn( inputImage );
    UiTestUtil.mockToolkitMultiply( activity, 123, 123 );
    return activity;
  }

  @Test
  public void testSetExpandedNull() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();

    setter.execute( treeItemView, properties );

    verify( treeView, never() ).setParentTreeItem( any( TreeItemView.class ) );
  }

  @Test
  public void testSetExpandedTrue() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    properties.setExpanded( true );

    setter.execute( treeItemView, properties );

    verify( treeView ).setParentTreeItem( treeItemView );
  }

  @Test
  public void testSetExpandedFalseOnChild() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView2 = mock( TreeItemView.class );
    TreeItemView treeItemView1 = mock( TreeItemView.class );
    when( treeItemView1.getTreeItemParent() ).thenReturn( treeItemView2 );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView1.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    properties.setExpanded( false );

    setter.execute( treeItemView1, properties );

    verify( treeView ).setParentTreeItem( treeItemView2 );
  }

  @Test
  public void testSetExpandedFalseOnRoot() throws Exception {
    TreeItemViewSetter<TreeItemView> setter = new TreeItemViewSetter<TreeItemView>( new TabrisActivity() );
    TreeItemView treeItemView = mock( TreeItemView.class );
    TreeView treeView = mock( TreeView.class );
    when( treeItemView.getTreeView() ).thenReturn( treeView );
    SetProperties properties = new SetProperties();
    properties.setExpanded( false );

    setter.execute( treeItemView, properties );

    verify( treeView, never() ).setParentTreeItem( any( TreeItemView.class ) );
  }
}
