/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.Button;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SetterManager_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    SetterManager setterManager = new SetterManager( new TabrisActivity() );

    setterManager.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    SetterManager setterManager = new SetterManager( new TabrisActivity() );

    setterManager.execute( mock( View.class ), null );
  }

  @Test(expected = IllegalStateException.class)
  public void testExecuteNoSetterFound() {
    View view = mock( Button.class );
    SetProperties props = new SetProperties();
    SetterManager setterManager = new SetterManager( new TabrisActivity() );
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = setterManager.getViewSetter();
    viewSetter.clear();

    setterManager.execute( view, props );
  }

  @Test
  @SuppressWarnings({
    "unchecked", "rawtypes"
  })
  public void testExecuteOk() {
    View view = mock( View.class );
    SetProperties props = new SetProperties();
    SetterManager setterManager = new SetterManager( new TabrisActivity() );
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = setterManager.getViewSetter();
    viewSetter.clear();
    IViewSetter setter = mock( IViewSetter.class );
    viewSetter.put( View.class, setter );

    setterManager.execute( view, props );

    verify( setter ).execute( view, props );
  }

  @Test
  @SuppressWarnings({
    "unchecked", "rawtypes"
  })
  public void testExecuteOnViewHierarchyOk() {
    View view = mock( Button.class );
    SetProperties props = new SetProperties();
    SetterManager setterManager = new SetterManager( new TabrisActivity() );
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = setterManager.getViewSetter();
    viewSetter.clear();
    IViewSetter setter = mock( IViewSetter.class );
    viewSetter.put( View.class, setter );

    setterManager.execute( view, props );

    verify( setter ).execute( view, props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntNullArg() throws Exception {
    SetterManager.colorToupleToInt( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToInt2Values() throws Exception {
    SetterManager.colorToupleToInt( Arrays.asList( 10, 20 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntIllegal5Values() throws Exception {
    SetterManager.colorToupleToInt( Arrays.asList( 10, 20, 30, 40, 50 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntOutOfRange() throws Exception {
    SetterManager.colorToupleToInt( Arrays.asList( -1, 256, Integer.MAX_VALUE, Integer.MIN_VALUE ) );
  }

  @Test
  public void testColorToIntValidThreeTouple() throws Exception {
    int color = SetterManager.colorToupleToInt( Arrays.asList( 1, 255, 128 ) );

    assertEquals( 255, getInt( color, SetterManager.COLOR_COMP_A ) );
    assertEquals( 1, getInt( color, SetterManager.COLOR_COMP_R ) );
    assertEquals( 255, getInt( color, SetterManager.COLOR_COMP_G ) );
    assertEquals( 128, getInt( color, SetterManager.COLOR_COMP_B ) );
  }

  @Test
  public void testColorToIntValidFourTouple() throws Exception {
    int color = SetterManager.colorToupleToInt( Arrays.asList( 1, 255, 128, 0 ) );

    assertEquals( 0, getInt( color, SetterManager.COLOR_COMP_A ) );
    assertEquals( 1, getInt( color, SetterManager.COLOR_COMP_R ) );
    assertEquals( 255, getInt( color, SetterManager.COLOR_COMP_G ) );
    assertEquals( 128, getInt( color, SetterManager.COLOR_COMP_B ) );
  }

  private int getInt( int value, int component ) {
    return value >> component & 0xff;
  }
}
