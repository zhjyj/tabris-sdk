/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.app.AlertDialog;
import android.view.View;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@Implements(AlertDialog.class)
public class TabrisShadowAlertDialog extends ShadowAlertDialog {

  private View customTitleView;

  @Implementation
  public void setCustomTitle( View customTitleView ) {
    this.customTitleView = customTitleView;
  }

  @Override
  public View getCustomTitleView() {
    return customTitleView;
  }
}
