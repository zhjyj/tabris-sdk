/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache;
import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache.CacheEntry;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BitmapDrawableCache_Test {

  private static final String KEY = "key";

  class BitmapDrawableCacheUnderTest extends BitmapDrawableCache {

    private boolean sendNullOnFirstRetrieve;
    private boolean isFirstRetreive = true;

    public BitmapDrawableCacheUnderTest( boolean sendNullOnFirstRetrieve ) {
      super( Integer.MAX_VALUE );
      this.sendNullOnFirstRetrieve = sendNullOnFirstRetrieve;
    }

    public BitmapDrawableCacheUnderTest() {
      super( Integer.MAX_VALUE );
    }

    @Override
    public BitmapDrawable get( String key ) {
      if( sendNullOnFirstRetrieve && isFirstRetreive ) {
        isFirstRetreive = false;
        return null;
      } else {
        return super.get( key );
      }
    }
  }

  @Test
  public void testGetSize() {
    ReferenceAwareLRUCache<String, BitmapDrawable> cache = new BitmapDrawableCache( Integer.MAX_VALUE );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    Bitmap bitmap = mock( Bitmap.class );
    when( bitmap.getRowBytes() ).thenReturn( 10 );
    when( bitmap.getHeight() ).thenReturn( 20 );
    when( bitmapDrawable.getBitmap() ).thenReturn( bitmap );

    int result = cache.sizeOf( KEY, bitmapDrawable );

    assertEquals( 200, result );
  }

  @Test
  public void testPutAndNotify() throws Exception {
    BitmapDrawableCacheUnderTest cache = new BitmapDrawableCacheUnderTest();
    ReentrantReadWriteLock readWriteLock = mock( ReentrantReadWriteLock.class );
    WriteLock writeLock = mock( WriteLock.class );
    when( readWriteLock.writeLock() ).thenReturn( writeLock );
    cache.getLoadingLocks().put( KEY, readWriteLock );
    BitmapDrawable bitmapDrawable = createBitmapDrawableMock( 100 );

    cache.putAndNotify( KEY, bitmapDrawable );

    verify( writeLock ).unlock();
    CacheEntry<BitmapDrawable> cacheEntry = cache.getMap().get( KEY );
    assertEquals( bitmapDrawable, cacheEntry.getValue() );
    assertEquals( 1, cacheEntry.getReferenceCount() );
  }

  @Test
  public void testGetOrWaitWithEmptyCache() throws Exception {
    BitmapDrawableCacheUnderTest cache = new BitmapDrawableCacheUnderTest();
    BitmapDrawable bitmapDrawable = createBitmapDrawableMock( 100 );
    cache.put( KEY, bitmapDrawable );

    BitmapDrawable result = cache.getOrWait( KEY );

    assertEquals( bitmapDrawable, result );
  }

  @Test
  public void testGetOrWaitWithEmptyLocks() throws Exception {
    BitmapDrawableCacheUnderTest cache = new BitmapDrawableCacheUnderTest();
    cache.getMap().put( KEY, null );

    cache.getOrWait( KEY );

    ReentrantReadWriteLock lock = cache.getLoadingLocks().get( KEY );
    assertTrue( lock.writeLock().isHeldByCurrentThread() );
  }

  @Test
  public void testGetOrWaitWithUnlockedWriteLock() throws Exception {
    BitmapDrawableCacheUnderTest cache = new BitmapDrawableCacheUnderTest( true );
    BitmapDrawableCacheUnderTest spyCache = spy( cache );
    ReentrantReadWriteLock readWriteLock = mock( ReentrantReadWriteLock.class );
    when( readWriteLock.isWriteLocked() ).thenReturn( true );
    ReadLock readLock = mock( ReadLock.class );
    when( readWriteLock.readLock() ).thenReturn( readLock );
    WriteLock writeLock = mock( WriteLock.class );
    when( writeLock.isHeldByCurrentThread() ).thenReturn( false );
    when( readWriteLock.writeLock() ).thenReturn( writeLock );
    spyCache.getLoadingLocks().put( KEY, readWriteLock );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    spyCache.getMap().put( KEY, new CacheEntry<BitmapDrawable>( bitmapDrawable ) );

    BitmapDrawable result = spyCache.getOrWait( KEY );

    InOrder inOrder = inOrder( readLock, spyCache );
    inOrder.verify( readLock ).lock();
    inOrder.verify( spyCache ).get( KEY );
    inOrder.verify( readLock ).unlock();
    assertEquals( bitmapDrawable, result );
  }

  @Test
  public void testGetOrWaitWithLockedWriteLock() throws Exception {
    BitmapDrawableCacheUnderTest cache = new BitmapDrawableCacheUnderTest( true );
    BitmapDrawableCacheUnderTest spyCache = spy( cache );
    ReentrantReadWriteLock readWriteLock = mock( ReentrantReadWriteLock.class );
    when( readWriteLock.isWriteLocked() ).thenReturn( false );
    WriteLock writeLock = mock( WriteLock.class );
    when( readWriteLock.writeLock() ).thenReturn( writeLock );
    ReadLock readLock = mock( ReadLock.class );
    when( readWriteLock.readLock() ).thenReturn( readLock );
    spyCache.getLoadingLocks().put( KEY, readWriteLock );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    spyCache.getMap().put( KEY, new CacheEntry<BitmapDrawable>( bitmapDrawable ) );

    BitmapDrawable result = spyCache.getOrWait( KEY );

    InOrder inOrder = inOrder( readLock, spyCache, writeLock );
    inOrder.verify( writeLock ).lock();
    inOrder.verify( readLock ).lock();
    inOrder.verify( spyCache ).get( KEY );
    inOrder.verify( readLock ).unlock();
    assertEquals( bitmapDrawable, result );
  }

  @Test
  public void testPutImageButNoSpaceAndAllDrawablesInUse() throws Exception {
    BitmapDrawableCache cache = new BitmapDrawableCache( 100 );
    BitmapDrawable bitmapDrawableA = createBitmapDrawableMock( 80 );
    BitmapDrawable bitmapDrawableB = createBitmapDrawableMock( 40 );

    cache.putAndReference( "a", bitmapDrawableA );
    cache.putAndReference( "b", bitmapDrawableB );

    assertEquals( bitmapDrawableA, cache.getMap().get( "a" ).getValue() );
    assertEquals( bitmapDrawableB, cache.getMap().get( "b" ).getValue() );
  }

  @Test
  public void testPutImageAndNoSpaceButDrawablesRecyclable() throws Exception {
    BitmapDrawableCache cache = new BitmapDrawableCache( 100 );
    BitmapDrawable bitmapDrawableA = createBitmapDrawableMock( 80 );
    cache.put( "a", bitmapDrawableA );
    BitmapDrawable bitmapDrawableB = createBitmapDrawableMock( 40 );

    cache.put( "b", bitmapDrawableB );

    verify( bitmapDrawableA.getBitmap() ).recycle();
    assertEquals( bitmapDrawableB, cache.getMap().get( "b" ).getValue() );
    assertFalse( cache.getMap().containsKey( "a" ) );
  }

  @Test
  public void testPutImageAndEnoughSpace() throws Exception {
    BitmapDrawableCache cache = new BitmapDrawableCache( 100 );
    BitmapDrawable bitmapDrawableA = createBitmapDrawableMock( 20 );
    cache.put( "a", bitmapDrawableA );
    BitmapDrawable bitmapDrawableB = createBitmapDrawableMock( 40 );
    cache.put( "b", bitmapDrawableB );

    assertEquals( bitmapDrawableA, cache.getMap().get( "a" ).getValue() );
    assertEquals( bitmapDrawableB, cache.getMap().get( "b" ).getValue() );
  }

  private BitmapDrawable createBitmapDrawableMock( int size ) {
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    Bitmap bitmap = mock( Bitmap.class );
    when( bitmap.getRowBytes() ).thenReturn( 2 );
    when( bitmap.getHeight() ).thenReturn( size / 2 );
    when( bitmapDrawable.getBitmap() ).thenReturn( bitmap );
    return bitmapDrawable;
  }

  @Test
  public void testDecreaseReferenceCount() throws Exception {
    BitmapDrawableCache cache = new BitmapDrawableCache( 100 );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    CacheEntry<BitmapDrawable> cacheEntry = new CacheEntry<BitmapDrawable>( bitmapDrawable );
    cache.getMap().put( "a", cacheEntry );
    cacheEntry.increaseReferenceCount();

    assertEquals( 1, cacheEntry.getReferenceCount() );

    cache.decreaseReferenceCount( bitmapDrawable );

    assertEquals( 0, cacheEntry.getReferenceCount() );
  }

}
