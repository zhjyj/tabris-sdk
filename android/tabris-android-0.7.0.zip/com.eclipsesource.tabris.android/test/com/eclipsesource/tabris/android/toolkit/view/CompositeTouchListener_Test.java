
package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CompositeTouchListener_Test {

  @Test
  public void testInheritsFromListenerHolder() throws Exception {
    CompositeTouchListener compListener = new CompositeTouchListener();

    assertTrue( compListener instanceof ListenerHolder );
  }

  @Test
  public void testNotifyOnItemSelected() {
    CompositeTouchListener compListener = new CompositeTouchListener();
    OnTouchListener listener1 = mock( OnTouchListener.class );
    OnTouchListener listener2 = mock( OnTouchListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    View view = mock( View.class );
    MotionEvent motionEvent = MotionEvent.obtain( 123, 123, 123, 123, 123, 123 );

    compListener.onTouch( view, motionEvent );

    verify( listener1 ).onTouch( view, motionEvent );
    verify( listener2 ).onTouch( view, motionEvent );
  }

}
