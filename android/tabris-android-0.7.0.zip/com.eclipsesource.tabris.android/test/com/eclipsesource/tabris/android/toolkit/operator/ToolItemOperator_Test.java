/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.eclipsesource.tabris.android.toolkit.view.SeparatorToolItem;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolItemOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentWidget;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    parentWidget = new FrameLayout( activity );
    activity.getProcessor().getWidgetToolkit().registerObjectById( PARENT_ID, parentWidget );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolItemNoProps() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolItemNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateToolItemNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private ToolItem getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof ToolItem );
    assertEquals( WIDGET_ID, view.getTag() );
    return ( ToolItem )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateWithStylePush() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( "PUSH" ) );

    operator.create( op );

    ToolItem view = getCreatedValidatedView();
    assertTrue( view instanceof PushToolItem );
    assertEquals( parentWidget, view.getParent() );
  }

  @Test
  public void testCreateWithStyleSeparator() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( "SEPARATOR" ) );

    operator.create( op );

    ToolItem view = getCreatedValidatedView();
    assertTrue( view instanceof SeparatorToolItem );
    assertEquals( parentWidget, view.getParent() );
  }

  @Test
  public void testGetType() throws Exception {
    ToolItemOperator op = new ToolItemOperator( new TabrisActivity() );
    assertEquals( ToolItemOperator.TYPE, op.getType() );
  }

  @Test
  public void testAttachSelectionListener() throws Exception {
    ToolItemOperator operator = new ToolItemOperator( activity );
    PushToolItem toolItem = mock( PushToolItem.class );
    when( toolItem.getPaddingLeft() ).thenReturn( 1 );
    when( toolItem.getPaddingTop() ).thenReturn( 2 );
    when( toolItem.getPaddingRight() ).thenReturn( 3 );
    when( toolItem.getPaddingBottom() ).thenReturn( 4 );
    activity.getProcessor().getWidgetToolkit().registerObjectById( WIDGET_ID, toolItem );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setSelection( true );
    op.setProperties( listenProps );

    operator.listen( op );

    verify( toolItem ).setBackgroundResource( R.drawable.item_background_holo_dark );
    verify( toolItem ).setPadding( 1, 2, 3, 4 );
  }

  @Test
  public void testRemoveSelectionListener() throws Exception {
    ToolItemOperator operator = new ToolItemOperator( activity );
    PushToolItem toolItem = mock( PushToolItem.class );
    when( toolItem.getPaddingLeft() ).thenReturn( 1 );
    when( toolItem.getPaddingTop() ).thenReturn( 2 );
    when( toolItem.getPaddingRight() ).thenReturn( 3 );
    when( toolItem.getPaddingBottom() ).thenReturn( 4 );
    activity.getProcessor().getWidgetToolkit().registerObjectById( WIDGET_ID, toolItem );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setSelection( false );
    op.setProperties( listenProps );

    operator.listen( op );

    verify( toolItem ).setBackgroundResource( R.drawable.item_background_holo_dark_no_selection );
    verify( toolItem ).setPadding( 1, 2, 3, 4 );
  }
}
