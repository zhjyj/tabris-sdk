/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.view.animation.TranslateAnimation;

import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowTranslateAnimation;

@Implements(TranslateAnimation.class)
public class TabrisShadowTranslateAnimation extends ShadowTranslateAnimation {

  private float fromXDelta;
  private float toXDelta;
  private float fromYDelta;
  private float toYDelta;

  public void __constructor__( float fromXDelta, float toXDelta, float fromYDelta, float toYDelta )
  {
    this.fromXDelta = fromXDelta;
    this.toXDelta = toXDelta;
    this.fromYDelta = fromYDelta;
    this.toYDelta = toYDelta;
  }

  public float getFromXDelta() {
    return fromXDelta;
  }

  public float getToXDelta() {
    return toXDelta;
  }

  public float getFromYDelta() {
    return fromYDelta;
  }

  public float getToYDelta() {
    return toYDelta;
  }

}
