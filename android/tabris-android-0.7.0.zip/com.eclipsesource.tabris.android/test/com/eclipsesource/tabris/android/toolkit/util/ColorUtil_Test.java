/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.Drawable;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ColorUtil_Test {

  @Test
  public void testApplColorFilter() {
    ColorUtil colorUtil = new ColorUtil();
    Drawable drawable = mock( Drawable.class );

    colorUtil.applyColorFilter( drawable, 1f, 2f, 3f );

    verify( drawable ).setColorFilter( any( ColorMatrixColorFilter.class ) );
  }
}
