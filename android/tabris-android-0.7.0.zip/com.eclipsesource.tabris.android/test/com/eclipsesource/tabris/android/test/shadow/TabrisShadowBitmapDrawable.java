/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowBitmapDrawable;

@Implements(BitmapDrawable.class)
public class TabrisShadowBitmapDrawable extends ShadowBitmapDrawable {

  public void __constructor__( Resources resources, Bitmap bitmap ) {
    __constructor__( bitmap );
  }
}
