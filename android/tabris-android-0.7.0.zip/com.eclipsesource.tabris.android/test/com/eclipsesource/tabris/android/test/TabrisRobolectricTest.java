/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test;

import org.junit.Ignore;

import android.os.Build;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@Ignore
public class TabrisRobolectricTest {

  private static final int SDK_INT = Build.VERSION.SDK_INT;

  protected void switchVersionTo( int version ) {
    RobolectricTestRunner.setStaticValue( Build.VERSION.class, "SDK_INT", version );
  }

  protected void resetVersion() {
    RobolectricTestRunner.setStaticValue( Build.VERSION.class, "SDK_INT", SDK_INT );
  }

}
