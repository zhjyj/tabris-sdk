/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Scale;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ScaleSetter_Test {

  @Test
  public void testSetMinimum() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    SetProperties props = new SetProperties();
    props.setMinimum( 50 );

    setter.execute( scale, props );

    verify( scale ).setMin( 50 );
  }

  @Test
  public void testSetMaximum() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    SetProperties props = new SetProperties();
    props.setMaximum( 50 );

    setter.execute( scale, props );

    verify( scale ).setMax( 50 );
  }

  @Test
  public void testSetSelection() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    SetProperties props = new SetProperties();
    props.setSelection( new GenericObject( new Integer( 50 ) ) );

    setter.execute( scale, props );

    verify( scale ).setProgress( 50 );
  }

  @Test
  public void testApplyBoundsToView() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( activity );
    Scale scale = mock( Scale.class );
    MarginLayoutParams layoutParams = new MarginLayoutParams( 0, 0 );
    when( scale.getLayoutParams() ).thenReturn( layoutParams );
    SetProperties props = new SetProperties();
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    props.setBounds( bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 10, 24, 30, 32 );

    setter.execute( scale, props );

    assertEquals( 10, layoutParams.leftMargin );
    assertEquals( 24, layoutParams.topMargin );
    assertEquals( 30, layoutParams.width );
    assertEquals( 32, layoutParams.height );
  }

}
