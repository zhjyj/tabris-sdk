/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import java.util.ArrayList;
import java.util.List;

import org.mockito.Mockito;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.widget.EditText;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowEditText;

@Implements(EditText.class)
public class TabrisShadowEditText extends ShadowEditText {

  private final List<TextWatcher> watchers = new ArrayList<TextWatcher>();
  private InputFilter[] filters;

  @Override
  public void __constructor__( Context context ) {
    __constructor__( context, null );
    setBackgroundDrawable( Mockito.mock( Drawable.class ) );
  }

  @Override
  @Implementation
  public void addTextChangedListener( TextWatcher watcher ) {
    this.watchers.add( watcher );
  }

  @Override
  @Implementation
  public void removeTextChangedListener( TextWatcher watcher ) {
    this.watchers.remove( watcher );
  }

  @Override
  public List<TextWatcher> getWatchers() {
    return watchers;
  }

  @Implementation
  public void setTextSize( int unit, float size ) {
    setTextSize( size );
  }

  @Implementation
  public void setFilters( InputFilter[] filters ) {
    this.filters = filters;
  }

  @Implementation
  public InputFilter[] getFilters() {
    return filters;
  }
}
