/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.content.DialogInterface;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAlertDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeTimePickerDialog;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
public class DateTimeTimePickerDialog_Test {

  class DialogUnderTest extends DateTimeTimePickerDialog {

    private int hourOfDay;
    private int minutOfHour;
    private int updatedCount;

    public DialogUnderTest( Activity activity, Calendar calendar ) {
      super( activity, calendar );
    }

    public void expected( int hourOfDay, int minutOfHour ) {
      this.hourOfDay = hourOfDay;
      this.minutOfHour = minutOfHour;
    }

    @Override
    public void updateTime( int hourOfDay, int minutOfHour ) {
      super.updateTime( hourOfDay, minutOfHour );
      assertEquals( this.hourOfDay, hourOfDay );
      assertEquals( this.minutOfHour, minutOfHour );
      updatedCount++;
    }

    public int getUpdatedCount() {
      return updatedCount;
    }

  }

  @Test(expected = NullPointerException.class)
  public void testCreateNullActivity() {
    new DateTimeTimePickerDialog( null, Calendar.getInstance() );
  }

  @Test(expected = NullPointerException.class)
  public void testCreateNullCalendar() {
    new DateTimeTimePickerDialog( new Activity(), null );
  }

  @Test
  public void testCreateOk() {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    DateTimeTimePickerDialog dialog = new DateTimeTimePickerDialog( new Activity(),
                                                                    Calendar.getInstance() );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    assertNotNull( shadowDialog.getCustomTitleView().findViewById( R.id.alertTitle ) );
    assertNotNull( shadowDialog.getCustomTitleView().findViewById( R.id.icon ) );
  }

  @Test
  public void testReset() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DateTimeTimePickerDialog dialog = new DateTimeTimePickerDialog( new Activity(), calendar );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.reset();

    verify( spinner ).setDate( calendar.getTime() );
  }

  @Test
  public void testChangeTime() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DateTimeTimePickerDialog dialog = new DateTimeTimePickerDialog( new Activity(), calendar );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );
    Calendar newCalendar = ( Calendar )calendar.clone();
    newCalendar.set( Calendar.HOUR_OF_DAY, calendar.get( Calendar.HOUR_OF_DAY ) + 1 );
    newCalendar.set( Calendar.MINUTE, calendar.get( Calendar.MINUTE ) + 1 );

    verify( spinner ).setDate( calendar.getTime() );
    verify( spinner ).formatDate( calendar.getTime() );

    dialog.onTimeChanged( null,
                          newCalendar.get( Calendar.HOUR_OF_DAY ),
                          newCalendar.get( Calendar.MINUTE ) );
    dialog.onClick( mock( DialogInterface.class ), 0 );

    verify( spinner ).formatDate( newCalendar.getTime() );
    verify( spinner ).setDate( newCalendar.getTime() );
    verifyNoMoreInteractions( spinner );
  }

  @Test
  public void testSetHours() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DialogUnderTest dialog = new DialogUnderTest( new Activity(), calendar );
    dialog.expected( 15, calendar.get( Calendar.MINUTE ) );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.setHours( 15 );

    // we can not exactly assert what date is set on the spinner because there
    // is now Shadow object for the dialog
    verify( spinner, times( 2 ) ).setDate( any( Date.class ) );
    assertEquals( 1, dialog.getUpdatedCount() );
  }

  @Test
  public void testSetMinutes() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    final Calendar calendar = Calendar.getInstance();
    DialogUnderTest dialog = new DialogUnderTest( new Activity(), calendar );
    dialog.expected( calendar.get( Calendar.HOUR_OF_DAY ), 35 );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    dialog.setDateTimeSpinner( spinner );

    dialog.setMinutes( 35 );

    // we can exactly assert what date is set on the spinner because there is
    // now Shadow object for the dialog
    verify( spinner, times( 2 ) ).setDate( any( Date.class ) );
    assertEquals( 1, dialog.getUpdatedCount() );
  }
}
