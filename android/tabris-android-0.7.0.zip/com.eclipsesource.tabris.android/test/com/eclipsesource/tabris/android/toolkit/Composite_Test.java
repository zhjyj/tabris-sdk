/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.view.View;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.RadioButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowFrameLayout;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Composite_Test {

  private TabrisActivity activity;
  private CompositeCheckedChangedListener compListener;
  private ListenerRegistry listenerRegistry;

  public class RadioButtonUnderTest extends RadioButton {

    public RadioButtonUnderTest( Activity activity ) {
      super( activity );
    }

    @Override
    public Object getTag() {
      return "w3";
    }
  };

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithoutOnCreate();
    ProtocolProcessor processor = activity.getProcessor();
    listenerRegistry = mock( ListenerRegistry.class );
    compListener = mock( CompositeCheckedChangedListener.class );
    when( listenerRegistry.findListener( "w2", CompositeCheckedChangedListener.class ) ).thenReturn( compListener );
    when( listenerRegistry.findListener( "w3", CompositeCheckedChangedListener.class ) ).thenReturn( compListener );
    when( processor.getWidgetToolkit().getListenerRegistry() ).thenReturn( listenerRegistry );

  }

  @Test
  public void testAddRadioButton() {
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );
    RadioButtonUnderTest radioButtonUnderTest = new RadioButtonUnderTest( activity );
    assertEquals( 0, compositeLayout.getChildCount() );

    compositeLayout.addView( radioButtonUnderTest );

    assertEquals( 1, compositeLayout.getChildCount() );
    verify( compListener ).addListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveRadioButtonAt() {
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    RadioButtonUnderTest radioButtonUnderTest = new RadioButtonUnderTest( activity );
    assertEquals( 0, compositeLayout.getChildCount() );
    compositeLayout.addView( radioButtonUnderTest );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeViewAt( 0 );
    assertEquals( 0, compositeLayout.getChildCount() );
    verify( compListener ).removeListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveRadioButton() {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    RadioButtonUnderTest radioButtonUnderTest = new RadioButtonUnderTest( activity );
    assertEquals( 0, compositeLayout.getChildCount() );
    compositeLayout.addView( radioButtonUnderTest );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeView( radioButtonUnderTest );
    assertEquals( 0, compositeLayout.getChildCount() );
    verify( compListener ).removeListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveView() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    verifyNoMoreInteractions( listenerRegistry );
    View view = new View( activity );
    compositeLayout.addView( view );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeView( view );
    assertEquals( 0, compositeLayout.getChildCount() );
  }

  @Test
  public void testRadioButtonsToggled() throws Exception {
    activity = UiTestUtil.createActivity();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    CompositeCheckedChangedListener complistenerW2 = new CompositeCheckedChangedListener();
    CompositeCheckedChangedListener complistenerW3 = new CompositeCheckedChangedListener();
    toolkit.getListenerRegistry().registerListener( "w2", complistenerW2 );
    toolkit.getListenerRegistry().registerListener( "w3", complistenerW3 );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );
    RadioButton rb2 = new RadioButton( activity );
    rb2.setTag( "w2" );
    rb2.setOnCheckedChangeListener( complistenerW2 );
    RadioButton rb3 = new RadioButton( activity );
    rb3.setTag( "w3" );
    rb3.setOnCheckedChangeListener( complistenerW3 );
    compositeLayout.addView( rb2 );
    compositeLayout.addView( rb3 );

    assertFalse( rb2.isChecked() );
    assertFalse( rb3.isChecked() );

    rb2.setChecked( true );

    assertTrue( rb2.isChecked() );
    assertFalse( rb3.isChecked() );

    rb3.setChecked( true );

    assertFalse( rb2.isChecked() );
    assertTrue( rb3.isChecked() );

    rb3.setChecked( false );

    assertFalse( rb2.isChecked() );
    assertFalse( rb3.isChecked() );
  }

}
