/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;
import com.eclipsesource.tabris.android.toolkit.view.state.AbstractState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProtocolProcessor_Test {

  @Test
  public void testCreateProcolProcessor() {
    ProtocolProcessor protocolProcessor = new ProtocolProcessor();
    assertNotNull( protocolProcessor );
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionParserNull() throws Exception {
    ITransport transport = mock( ITransport.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setTransport( transport );
    processor.setWidgetToolkit( toolkit );

    processor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionTransportNull() throws Exception {
    IProtocolParser transport = mock( IProtocolParser.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setParser( transport );
    processor.setWidgetToolkit( toolkit );

    processor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionToolkitNull() throws Exception {
    IProtocolParser parser = mock( IProtocolParser.class );
    ITransport transport = mock( ITransport.class );
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setParser( parser );
    processor.setTransport( transport );

    processor.startSession();
  }

  @Test
  public void testSendInitialGetRequest() throws Exception {
    ProtocolProcessor processor = new ProtocolProcessor();
    ExecutorService executerService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executerService );
    processor.setTransport( mock( ITransport.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setWidgetToolkit( toolkit );
    processor.setParser( mock( IProtocolParser.class ) );

    processor.startSession();

    verify( executerService ).execute( any( InitialGetRequestRunnable.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testSendInitialPostRequest() throws Exception {
    ITransport transport = mock( ITransport.class );
    ITransportResult getResult = mock( ITransportResult.class );
    when( getResult.getResult() ).thenReturn( new ByteArrayInputStream( "".getBytes() ) );
    when( transport.get( any( GetRequest.class ) ) ).thenReturn( getResult );
    IProtocolParser parser = mock( IProtocolParser.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    ProtocolProcessor processor = new ProtocolProcessor();
    ExecutorService executerService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executerService );
    processor.setTransport( transport );
    processor.setWidgetToolkit( toolkit );
    processor.setParser( parser );
    ITransportResult result = getResult;
    when( result.hasException() ).thenReturn( false );

    PostRequest request = new PostRequest();
    request.addParam( ITransportRequest.PARAM_RWT_INITIALIZE, "true" );
    request.addParam( ITransportRequest.PARAM_UI_ROOT, "w1" );
    request.addParam( ITransportRequest.PARAM_W1_BOUNDS_HEIGHT, "0" );
    request.addParam( ITransportRequest.PARAM_W1_BOUNDS_WIDTH, "0" );
    request.addParam( ITransportRequest.PARAM_W1_COLOR_DEPTH, "0" );
    request.addParam( ITransportRequest.PARAM_W1_CURSOR_LOCATION_X, "0" );
    request.addParam( ITransportRequest.PARAM_W1_CURSOR_LOCATION_Y, "0" );
    request.addParam( ITransportRequest.PARAM_W1_DPI_X, "0" );
    request.addParam( ITransportRequest.PARAM_W1_DPI_Y, "0" );
    request.addParam( ITransportRequest.PARAM_W4T_HEIGHT, "0" );
    request.addParam( ITransportRequest.PARAM_W4T_WIDTH, "0" );
    when( transport.post( eq( request ) ) ).thenReturn( result );

    processor.sendInitialPostRequest( null );

    verify( executerService ).execute( new PostRequestRunnable( request, processor ) );
  }

  @Test
  public void testProcessGetRequestOk() throws Exception {
    ITransport transport = mock( ITransport.class );
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( false );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( eq( request ) ) ).thenReturn( result );

    ITransportResult transportResult = processor.processGetRequest( request );

    verify( transport ).get( request );
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessGetRequestFail() throws Exception {
    ITransport transport = mock( ITransport.class );
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    when( result.hasException() ).thenReturn( true );
    when( result.getException() ).thenReturn( any( Exception.class ) );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( request ) ).thenReturn( result );

    ITransportResult transportResult = processor.processGetRequest( request );

    verify( transport ).get( request );
    verify( transportResult ).getException();
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessPostRequest() throws Exception {
    ProtocolProcessor processor = new ProtocolProcessor();
    ExecutorService executorService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executorService );

    processor.processPostRequest( any( PostRequest.class ) );

    verify( executorService ).execute( any( PostRequestRunnable.class ) );
  }

  @Test
  public void testSetGetTransport() {
    ProtocolProcessor protocolProcessor = new ProtocolProcessor();
    ITransport transport = mock( ITransport.class );

    protocolProcessor.setTransport( transport );

    assertSame( protocolProcessor.getTransport(), transport );
  }

  @Test
  public void testSetGetParser() {
    ProtocolProcessor protocolProcessor = new ProtocolProcessor();
    IProtocolParser parser = mock( IProtocolParser.class );

    protocolProcessor.setParser( parser );

    assertSame( protocolProcessor.getParser(), parser );
  }

  @Test
  public void testSetGetToolkit() {
    ProtocolProcessor protocolProcessor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );

    protocolProcessor.setWidgetToolkit( toolkit );

    assertSame( protocolProcessor.getWidgetToolkit(), toolkit );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testCreateInitRequest() throws Exception {
    ProtocolProcessor protocolProcessor = new ProtocolProcessor();
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setTransport( transport );
    protocolProcessor.setParser( mock( IProtocolParser.class ) );
    IWidgetToolkit wt = mock( IWidgetToolkit.class );
    when( wt.getSurfaceWidth() ).thenReturn( 480 );
    when( wt.getSurfaceHeight() ).thenReturn( 800 );
    when( wt.getSurfaceDpiX() ).thenReturn( 320 );
    when( wt.getSurfaceDpiY() ).thenReturn( 320 );
    when( wt.getSurfaceColorDepth() ).thenReturn( 24 );
    when( wt.divideByDensityFactor( 800 ) ).thenReturn( 400 );
    when( wt.divideByDensityFactor( 480 ) ).thenReturn( 240 );
    protocolProcessor.setWidgetToolkit( wt );

    PostRequest request = protocolProcessor.createInitialRequest( new HashMap<String, String>() );

    Map<String, String> params = request.getParams();
    assertEquals( "w1", params.get( ITransportRequest.PARAM_UI_ROOT ) );
    assertEquals( "true", params.get( ITransportRequest.PARAM_RWT_INITIALIZE ) );
    assertEquals( "240", params.get( ITransportRequest.PARAM_W1_BOUNDS_WIDTH ) );
    assertEquals( "400", params.get( ITransportRequest.PARAM_W1_BOUNDS_HEIGHT ) );
    assertEquals( "24", params.get( ITransportRequest.PARAM_W1_COLOR_DEPTH ) );
    assertEquals( "0", params.get( ITransportRequest.PARAM_W1_CURSOR_LOCATION_X ) );
    assertEquals( "0", params.get( ITransportRequest.PARAM_W1_CURSOR_LOCATION_Y ) );
    assertEquals( "320", params.get( ITransportRequest.PARAM_W1_DPI_X ) );
    assertEquals( "320", params.get( ITransportRequest.PARAM_W1_DPI_Y ) );
    assertEquals( "240", params.get( ITransportRequest.PARAM_W4T_WIDTH ) );
    assertEquals( "400", params.get( ITransportRequest.PARAM_W4T_HEIGHT ) );
  }

  @Test
  public void testGetSessionTime() throws Exception {
    ProtocolProcessor processor = new ProtocolProcessor();
    ITransport transport = mock( ITransport.class );
    ITransportResult getResult = mock( ITransportResult.class );
    when( getResult.getResult() ).thenReturn( new ByteArrayInputStream( "".getBytes() ) );
    when( transport.get( any( GetRequest.class ) ) ).thenReturn( getResult );
    ITransportResult transportResult = mock( ITransportResult.class );
    when( transportResult.hasException() ).thenReturn( false );
    when( transport.post( any( PostRequest.class ) ) ).thenReturn( transportResult );
    processor.setTransport( transport );
    processor.setParser( mock( IProtocolParser.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setWidgetToolkit( toolkit );

    assertEquals( 0, processor.getSessionTime() );
    processor.startSession();
    Thread.sleep( 1 );

    assertTrue( processor.getSessionTime() > 0 );
  }

  @Test
  public void testOperationFoundNull() {
    ProtocolProcessor processor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( null );

    verify( toolkit ).showError( any( Exception.class ) );
  }

  @Test
  public void testOperationFoundError() {
    ProtocolProcessor processor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).showError( any( Exception.class ) );
  }

  @Test
  public void testOperationFoundOk() {
    ProtocolProcessor processor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).process( any( ArrayList.class ) );
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testMetaSessionTimeoutFoundOk() {
    ProtocolProcessor processor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    Meta meta = mock( Meta.class );
    when( meta.getError() ).thenReturn( Meta.SESSION_TIMEOUT_ERROR );

    processor.metaFound( meta );

    verify( toolkit ).showError( eq( new LocalizableException( LocalizableException.SESSION_TIMEOUT ) ) );
  }

  @Test
  public void testMetaWithUnknownErrorFoundOk() {
    ProtocolProcessor processor = new ProtocolProcessor();
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    Meta meta = mock( Meta.class );
    when( meta.getError() ).thenReturn( "some error" );
    Meta oldMeta = processor.getCurMeta();

    processor.metaFound( meta );

    assertSame( oldMeta, processor.getCurMeta() );
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testStateRecorderPresent() {
    ProtocolProcessor processor = new ProtocolProcessor();

    StateRecorder stateRecorder = processor.getStateRecorder();

    assertNotNull( stateRecorder );
    assertEquals( 0, stateRecorder.getRecording().size() );
  }

  @Test
  public void testRecordedStateIsAttached() {
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setRequestThreadPool( mock( ExecutorService.class ) );
    StateRecorder stateRecorder = processor.getStateRecorder();
    IState stateMock = Mockito.mock( AbstractState.class );
    when( stateMock.generateKey() ).thenReturn( "key" );
    when( stateMock.generateValue() ).thenReturn( "value" );
    stateRecorder.recordState( stateMock );
    PostRequest request = mock( PostRequest.class );

    processor.processPostRequest( request );

    verify( request ).addParam( "key", "value" );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testShutdown() throws Exception {
    ProtocolProcessor processor = new ProtocolProcessor();
    ITransport transport = mock( ITransport.class );
    processor.setTransport( transport );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    ExecutorService threadPool = mock( ExecutorService.class );
    processor.setRequestThreadPool( threadPool );

    processor.shutdown();

    verify( transport ).dispose();
    verify( toolkit ).dispose();
    verify( threadPool ).shutdownNow();
  }
}
