/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.Test;

import android.view.View;
import android.view.animation.Animation;

import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ApplyBoundsOnFinishAnimationListener;

@SuppressWarnings("unchecked")
public class ApplyBoundsOnFinishAnimationListener_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullArgView() {
    new ApplyBoundsOnFinishAnimationListener( null, mock( List.class ), mock( ViewSetter.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullArgBounds() {
    new ApplyBoundsOnFinishAnimationListener( mock( View.class ), null, mock( ViewSetter.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullArgViewSetter() {
    new ApplyBoundsOnFinishAnimationListener( mock( View.class ), mock( List.class ), null );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testOnAnimationEnd() {
    View view = mock( View.class );
    List bounds = mock( List.class );
    ViewSetter viewSetter = mock( ViewSetter.class );
    ApplyBoundsOnFinishAnimationListener listener = new ApplyBoundsOnFinishAnimationListener( view,
                                                                                              bounds,
                                                                                              viewSetter );
    listener.onAnimationEnd( mock( Animation.class ) );

    verify( viewSetter ).applyBoundsToView( view, bounds );
    verify( view ).requestLayout();
  }
}
