/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Separator.Orientation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SeparatorSetter_Test {

  @Test
  public void testSetBoundsOnSeparatorWithoutOrientation() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    SeparatorSetter<Separator> setter = new SeparatorSetter<Separator>( activity );
    Separator separator = new Separator( activity );
    separator.setLayoutParams( new MarginLayoutParams( 0, 0 ) );
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, bounds );
    SetProperties properties = new SetProperties();
    properties.setBounds( bounds );

    setter.execute( separator, properties );

    MarginLayoutParams params = ( MarginLayoutParams )separator.getLayoutParams();
    assertEquals( 10, params.leftMargin );
    assertEquals( 20, params.topMargin );
    assertEquals( 30, params.width );
    assertEquals( 40, params.height );
  }

  @Test
  public void testSetBoundsOnSeparatorWithHorizontalOrientation() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    SeparatorSetter<Separator> setter = new SeparatorSetter<Separator>( activity );
    Separator separator = new Separator( activity );
    separator.setOrientation( Orientation.HORIZONTAL );
    separator.setLayoutParams( new MarginLayoutParams( 0, 0 ) );
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 39, 1 );
    SetProperties properties = new SetProperties();
    properties.setBounds( bounds );

    setter.execute( separator, properties );

    MarginLayoutParams params = ( MarginLayoutParams )separator.getLayoutParams();
    assertEquals( 10, params.leftMargin );
    assertEquals( 39, params.topMargin );
    assertEquals( 30, params.width );
    assertEquals( 1, params.height );
  }

  @Test
  public void testSetBoundsOnSeparatorWithVerticalOrientation() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    SeparatorSetter<Separator> setter = new SeparatorSetter<Separator>( activity );
    Separator separator = new Separator( activity );
    separator.setOrientation( Orientation.VERTICAL );
    separator.setLayoutParams( new MarginLayoutParams( 0, 0 ) );
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 24, 1 );
    SetProperties properties = new SetProperties();
    properties.setBounds( bounds );

    setter.execute( separator, properties );

    MarginLayoutParams params = ( MarginLayoutParams )separator.getLayoutParams();
    assertEquals( 24, params.leftMargin );
    assertEquals( 20, params.topMargin );
    assertEquals( 1, params.width );
    assertEquals( 40, params.height );
  }

}
