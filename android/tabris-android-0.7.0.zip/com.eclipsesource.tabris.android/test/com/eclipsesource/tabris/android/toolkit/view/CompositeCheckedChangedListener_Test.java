/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class CompositeCheckedChangedListener_Test {

  @Test
  public void testNotifyOnItemClick() {
    CompositeCheckedChangedListener compListener = new CompositeCheckedChangedListener();
    OnCheckedChangeListener listener1 = mock( OnCheckedChangeListener.class );
    OnCheckedChangeListener listener2 = mock( OnCheckedChangeListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    CompoundButton button = mock( CompoundButton.class );

    compListener.onCheckedChanged( button, true );

    verify( listener1 ).onCheckedChanged( button, true );
    verify( listener2 ).onCheckedChanged( button, true );
  }

}
