/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache;
import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache.CacheEntry;

public class ReferenceAwareLRUCache_Test {

  private static final String K1 = "k1";
  private static final String K2 = "k2";
  private static final String K3 = "k3";
  private static final String V1 = "v1";
  private static final String V2 = "v2";
  private static final String V3 = "v3";

  @Test(expected = IllegalArgumentException.class)
  public void testPutExistingKeyInCache() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( Integer.MAX_VALUE );

    cache.put( K1, V1 );
    cache.put( K1, V1 );
  }

  @Test
  public void testPutInCache() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( Integer.MAX_VALUE );

    cache.put( K1, V1 );

    assertEquals( V1, cache.getMap().get( K1 ).getValue() );
  }

  @Test
  public void testPutTwoInCache() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( Integer.MAX_VALUE );

    cache.put( K1, V1 );
    cache.put( K2, V2 );

    assertEquals( V1, cache.getMap().get( K1 ).getValue() );
    assertEquals( V2, cache.getMap().get( K2 ).getValue() );
    assertMapIs( cache.getMap(), K1, K2 );
  }

  @Test
  public void testPutAndReferenceInCache() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( Integer.MAX_VALUE );

    cache.putAndReference( K1, V1 );

    CacheEntry<String> cacheEntry = cache.getMap().get( K1 );
    assertEquals( V1, cacheEntry.getValue() );
    assertEquals( 1, cacheEntry.getReferenceCount() );
  }

  @Test
  public void testPutInCacheRemovingTail() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( 1 );

    cache.put( K1, V1 );
    cache.put( K2, V2 );

    assertMapIs( cache.getMap(), K2 );
    assertEquals( V2, cache.getMap().get( K2 ).getValue() );
  }

  @Test
  public void testPutInCacheShuffle() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( Integer.MAX_VALUE );

    cache.put( K1, V1 );
    cache.put( K2, V2 );
    cache.get( K1 );
    cache.put( K3, V3 );

    assertMapIs( cache.getMap(), K2, K1, K3 );
  }

  private <K, V> void assertMapIs( Map<K, CacheEntry<V>> map, K... expectedOrder ) {
    Object[] mapKeys = map.keySet().toArray();
    assertEquals( mapKeys.length, expectedOrder.length );
    for( int i = 0; i < mapKeys.length; i++ ) {
      assertEquals( mapKeys[ i ], expectedOrder[ i ] );
    }
  }

  @Test
  public void testPutInCacheAfterShuffleRemovingTail() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( 2 );

    cache.put( K1, V1 );
    cache.put( K2, V2 );
    cache.get( K1 );
    cache.put( K3, V3 );

    assertMapIs( cache.getMap(), K1, K3 );
  }

  @Test
  public void testPutInCacheWithSpaceButHeldReferences() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( 2 );

    cache.putAndReference( K1, V1 );
    cache.putAndReference( K2, V2 );
    cache.putAndReference( K3, V3 );

    assertMapIs( cache.getMap(), K1, K2, K3 );
  }

  @Test
  public void testPutInCacheWithSpaceAndEverythingIsReferenced() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( 4 );

    cache.putAndReference( K1, V1 );
    cache.putAndReference( K2, V2 );
    cache.putAndReference( K3, V3 );

    assertMapIs( cache.getMap(), K1, K2, K3 );
  }

  @Test
  public void testIncrementAndDecerementReferenceCount() {
    ReferenceAwareLRUCache<String, String> cache = new ReferenceAwareLRUCache<String, String>( 4 );

    cache.put( K1, V1 );

    cache.increaseReferenceCount( K1 );

    assertEquals( 1, cache.getMap().get( K1 ).getReferenceCount() );

    cache.decreaseReferenceCount( K1 );

    assertEquals( 0, cache.getMap().get( K1 ).getReferenceCount() );
  }
}
