/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import java.util.concurrent.Executor;

import android.os.AsyncTask;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowAsyncTask;

@Implements(AsyncTask.class)
public class TabrisShadowAsyncTask<Params, Progress, Result>
  extends ShadowAsyncTask<Params, Progress, Result>
{

  @Implementation
  public final AsyncTask<Params, Progress, Result> executeOnExecutor( Executor exec,
                                                                      Params... params )
  {
    return execute( params );
  }
}
