/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

import junit.framework.Assert;

import org.junit.Ignore;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.eclipsesource.tabris.android.parser.gson.GsonProtocolParser;

public class GsonProtocolParser_Test {

  IProtocolParserCallback nullCallback = new IProtocolParserCallback() {

    public void operationsFound( ArrayList<Operation> operations ) {
      Assert.fail( "operationsFound should not have been called" );
    }

    public void metaFound( Meta meta ) {
      Assert.fail( "metaFound should not have been called" );
    }
  };

  @Test(expected = IllegalArgumentException.class)
  public void testParseNull() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( null );
  }

  @Test(expected = ParseException.class)
  public void testParseEmpty() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseInvalidJson() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "foo".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseEmptyObject() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{}".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseNoMeta() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{\"key\":\"value\"}".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseNoMetaWithEmptyOperations() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{ \"operations:\": []}".getBytes() ) );
  }

  @Test
  public void testParseWithValidMeta() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Meta meta = new Meta();
    meta.setRequestCounter( 123 );

    parser.parse( new ByteArrayInputStream( "{\"meta\": {\"requestCounter\": 123}}".getBytes() ) );

    verify( callback ).metaFound( meta );
  }

  @Test
  public void testParseMetaWithEmptyOperations() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Meta meta = new Meta();
    meta.setRequestCounter( 123 );

    parser.parse( new ByteArrayInputStream( "{ \"meta\": {\"requestCounter\": 123}, \"operations\": []}".getBytes() ) );
    verify( callback ).metaFound( meta );
    verifyNoMoreInteractions( callback );
  }

  @Test
  public void testParseMetaAndCreateOperationWithoutProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Meta meta = new Meta();
    meta.setRequestCounter( 123 );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( "w3" );
    createOp.setType( "Shell" );
    operations.add( createOp );

    parser.parse( new ByteArrayInputStream( "{ \"meta\": {\"requestCounter\": 123}, \"operations\": [ [ \"create\", \"w3\", \"Shell\" ] ] }".getBytes() ) );
    verify( callback ).metaFound( meta );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  public void testParseMetaAndCreateOperationWithProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Meta meta = new Meta();
    meta.setRequestCounter( 123 );
    CreateProperties properties = new CreateProperties();
    properties.setActive( true );
    properties.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    properties.setTabIndex( 5 );
    properties.setBounds( Arrays.asList( 10, 20, 30, 40 ) );
    properties.setStyle( Arrays.asList( "CENTER", "TOGGLE" ) );
    properties.setActiveControl( "someControl" );
    properties.setMinimumSize( Arrays.asList( 200, 300 ) );
    properties.setMode( "modusOperandi" );
    properties.setText( "forHumans" );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    CreateOperation createOp = new CreateOperation();
    operations.add( createOp );
    createOp.setTarget( "w3" );
    createOp.setType( "Shell" );
    createOp.setProperties( properties );

    String content = "{ \"meta\": {\"requestCounter\": 123}, "
                     + "\"operations\": [ "
                     + "[\"create\", "
                     + "\"w3\", "
                     + "\"Shell\", "
                     + "{"
                     + "\"active\": true, "
                     + "\"background\": [10, 20, 30, 40], "
                     + "\"tabIndex\": 5, "
                     + "\"bounds\": [10, 20, 30, 40], "
                     + "\"style\": [\"CENTER\", \"TOGGLE\"], "
                     + "\"activeControl\": \"someControl\", "
                     + "\"minimumSize\": [200, 300], "
                     + "\"mode\": \"modusOperandi\", "
                     + "\"text\": \"forHumans\" "
                     + "} "
                     + "] "
                     + "]}";
    parser.parse( new ByteArrayInputStream( content.getBytes() ) );
    verify( callback ).metaFound( meta );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testParseMetaAndMultipleOpsWithProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Meta meta = new Meta();
    meta.setRequestCounter( -1 );

    parser.parse( new FileInputStream( new File( "../com.eclipsesource.tabris.android.test/test-data/prot.json" ) ) );

    verify( callback ).metaFound( meta );
    verify( callback, times( 1 ) ).operationsFound( any( ArrayList.class ) );
    verifyNoMoreInteractions( callback );
  }

  @Test
  @Ignore("Does not work because of the upgrade to gson-2.1. Primitive type values in List<Object> are converted differently")
  @SuppressWarnings("unchecked")
  public void testParseGarbageAndMetaAndMultipleOpsWithProps() throws Exception {
    // parsing a real life message from server
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );

    Meta meta = new Meta();
    meta.setRequestCounter( 0 );

    CreateOperation create1 = new CreateOperation();
    create1.setTarget( "w2" );
    create1.setType( "org.eclipse.swt.widgets.Shell" );
    CreateProperties createProps = new CreateProperties();
    createProps.setStyle( Arrays.asList( "NO_TRIM" ) );
    createProps.setText( "Snippet" );
    createProps.setActive( true );
    createProps.setMode( "maximized" );
    createProps.setMinimumSize( Arrays.asList( 80, 2 ) );
    createProps.setActiveControl( "w3" );
    createProps.setBounds( Arrays.asList( 0, 0, 320, 460 ) );
    createProps.setTabIndex( -1 );
    createProps.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    create1.setProperties( createProps );

    CreateOperation create2 = new CreateOperation();
    create2.setTarget( "w3" );
    create2.setType( "org.eclipse.swt.widgets.Composite" );
    CreateProperties createProps2 = new CreateProperties();
    createProps2.setParent( "w2" );
    createProps2.setStyle( Arrays.asList( "LEFT_TO_RIGHT" ) );
    createProps2.setBounds( Arrays.asList( 5, 5, 310, 450 ) );
    createProps2.setChildren( Arrays.asList( "w9", "w10", "w11" ) );
    createProps2.setTabIndex( -1 );
    createProps2.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    create2.setProperties( createProps2 );

    ListenOperation listen1 = new ListenOperation();
    listen1.setTarget( "w3" );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setMouse( true );
    listen1.setProperties( listenProps );

    CreateOperation create3 = new CreateOperation();
    create3.setTarget( "w4" );
    create3.setType( "org.eclipse.swt.widgets.Label" );
    CreateProperties createProps3 = new CreateProperties();
    createProps3.setParent( "w3" );
    createProps3.setStyle( Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps3.setBounds( Arrays.asList( 5, 5, 121, 32 ) );
    createProps3.setChildren( Arrays.asList( "w9", "w10", "w11" ) );
    createProps3.setTabIndex( -1 );
    createProps3.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    createProps3.setForeground( Arrays.asList( 10, 20, 30, 40 ) );
    create3.setProperties( createProps3 );

    CreateOperation create4 = new CreateOperation();
    create4.setTarget( "w5" );
    create4.setType( "org.eclipse.swt.widgets.Button" );
    CreateProperties createProps4 = new CreateProperties();
    createProps4.setParent( "w3" );
    createProps4.setStyle( Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps4.setBounds( Arrays.asList( 5, 5, 121, 32 ) );
    createProps4.setChildren( Arrays.asList( "w9", "w10", "w11" ) );
    createProps4.setTabIndex( -1 );
    createProps4.setText( "Hello World!" );
    createProps4.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    createProps4.setForeground( Arrays.asList( 10, 20, 30, 40 ) );
    create4.setProperties( createProps4 );

    CreateOperation create5 = new CreateOperation();
    create5.setTarget( "w6" );
    create5.setType( "org.eclipse.swt.widgets.Label" );
    CreateProperties createProps5 = new CreateProperties();
    createProps5.setParent( "w3" );
    createProps5.setStyle( Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps5.setBounds( Arrays.asList( 5, 5, 121, 32 ) );
    createProps5.setChildren( Arrays.asList( "w9", "w10", "w11" ) );
    createProps5.setTabIndex( -1 );
    createProps5.setText( "Hello Label!" );
    createProps5.setBackground( Arrays.asList( 10, 20, 30, 40 ) );
    createProps5.setForeground( Arrays.asList( 10, 20, 30, 40 ) );
    create5.setProperties( createProps5 );

    ListenOperation listen2 = new ListenOperation();
    listen2.setTarget( "w4" );
    listenProps = new ListenProperties();
    listenProps.setMouse( true );
    listen2.setProperties( listenProps );

    SetOperation set1 = new SetOperation();
    set1.setTarget( "w4" );
    SetProperties setProps = new SetProperties();
    setProps.setText( "Text alskj lakfj lkjf\nLine 2:bla" );
    set1.setProperties( setProps );

    CallOperation callOperation = new CallOperation();
    callOperation.setTarget( "w1" );
    callOperation.setMethod( "measureStrings" );
    CallProperties props = new CallProperties();
    props.put( "strings", Arrays.asList( Arrays.asList( 501642321,
                                                        "Search",
                                                        Arrays.asList( "Verdana" ),
                                                        12,
                                                        false,
                                                        false,
                                                        -1 ) ) );
    callOperation.setProperties( props );

    parser.parse( new FileInputStream( new File( "../com.eclipsesource.tabris.android.test/test-data/prot2.json" ) ) );

    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( create1 );
    operations.add( create2 );
    operations.add( listen1 );
    operations.add( create3 );
    operations.add( create4 );
    operations.add( create5 );
    operations.add( listen2 );
    operations.add( set1 );
    operations.add( callOperation );
    verify( callback ).metaFound( meta );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  public void testToJsonNull() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( null );

    assertEquals( "null", json );
  }

  @Test
  public void testToJsonString() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( "hello" );

    assertEquals( "\"hello\"", json );
  }

  @Test
  public void testToJsonNumber() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( 123 );

    assertEquals( "123", json );
  }

  @Test
  public void testToJsonBoolean() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( Boolean.TRUE );

    assertEquals( "true", json );
  }

  @Test
  public void testToJsonArray() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( new Object[]{
      "abc", 123
    } );

    assertEquals( "[\"abc\",123]", json );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testToJsonList() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( Arrays.asList( "abc", 123 ) );

    assertEquals( "[\"abc\",123]", json );
  }

  @Test
  public void testToJsonMap() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    HashMap<String, Object> map = new LinkedHashMap<String, Object>();
    map.put( "one", "abc" );
    map.put( "two", 123 );

    String json = parser.toJson( map );

    assertEquals( "{\"one\":\"abc\",\"two\":123}", json );
  }
}
