/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.Drawable;
import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProgressBarSetter_Test {

  @Test
  public void testSetStateNormalOnNormalProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( false );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getProgressDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "normal" );

    setter.execute( progressBar, props );

    verify( drawable ).setColorFilter( null );
  }

  @Test
  public void testSetStateNormalOnIndeterminateProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( true );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getIndeterminateDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "normal" );

    setter.execute( progressBar, props );

    verify( drawable ).setColorFilter( null );
  }

  @Test
  public void testSetStateErrorOnNormalProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( false );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getProgressDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "error" );

    setter.execute( progressBar, props );

    verify( colorUtil ).applyColorFilter( drawable, 1f, 0f, 0f );
  }

  @Test
  public void testSetStateErrorOnIndeterminateProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( true );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getIndeterminateDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "error" );

    setter.execute( progressBar, props );

    verify( colorUtil ).applyColorFilter( drawable, 1f, 0f, 0f );
  }

  @Test
  public void testSetStatePausedOnNormalProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( false );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getProgressDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "paused" );

    setter.execute( progressBar, props );

    verify( colorUtil ).applyColorFilter( drawable, 0.7f, 0.7f, 0.7f );
  }

  @Test
  public void testSetStatePausedOnIndeterminateProgressBar() {
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( new TabrisActivity() );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( true );
    Drawable drawable = mock( Drawable.class );
    when( progressBar.getIndeterminateDrawable() ).thenReturn( drawable );
    SetProperties props = new SetProperties();
    props.setState( "paused" );

    setter.execute( progressBar, props );

    verify( colorUtil ).applyColorFilter( drawable, 0.7f, 0.7f, 0.7f );
  }

  @Test
  public void testApplyBoundsToViewOnNormalProgressBar() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( activity );
    ProgressBar progressBar = mock( ProgressBar.class );
    MarginLayoutParams layoutParams = new MarginLayoutParams( 0, 0 );
    when( progressBar.getLayoutParams() ).thenReturn( layoutParams );
    SetProperties props = new SetProperties();
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    props.setBounds( bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 10, 34, 30, 12 );

    setter.execute( progressBar, props );

    assertEquals( 10, layoutParams.leftMargin );
    assertEquals( 34, layoutParams.topMargin );
    assertEquals( 30, layoutParams.width );
    assertEquals( 12, layoutParams.height );
  }

  @Test
  public void testApplyBoundsToViewOnIndeterminateProgressBar() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ProgressBarSetter<ProgressBar> setter = new ProgressBarSetter<ProgressBar>( activity );
    ProgressBar progressBar = mock( ProgressBar.class );
    when( progressBar.isIndeterminate() ).thenReturn( true );
    MarginLayoutParams layoutParams = new MarginLayoutParams( 0, 0 );
    when( progressBar.getLayoutParams() ).thenReturn( layoutParams );
    SetProperties props = new SetProperties();
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    props.setBounds( bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 10, 36, 30, 9 );

    setter.execute( progressBar, props );

    assertEquals( 10, layoutParams.leftMargin );
    assertEquals( 36, layoutParams.topMargin );
    assertEquals( 30, layoutParams.width );
    assertEquals( 9, layoutParams.height );
  }
}
