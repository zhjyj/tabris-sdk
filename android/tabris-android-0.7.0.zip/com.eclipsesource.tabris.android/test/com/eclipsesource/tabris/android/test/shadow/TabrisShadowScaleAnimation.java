/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.view.animation.ScaleAnimation;

import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowAnimation;

@Implements(ScaleAnimation.class)
public class TabrisShadowScaleAnimation extends ShadowAnimation {

  private float fromX;
  private float toX;
  private float fromY;
  private float toY;

  public void __constructor__( float fromX, float toX, float fromY, float toY ) {
    this.fromX = fromX;
    this.toX = toX;
    this.fromY = fromY;
    this.toY = toY;
  }

  public float getFromX() {
    return fromX;
  }

  public float getToX() {
    return toX;
  }

  public float getFromY() {
    return fromY;
  }

  public float getToY() {
    return toY;
  }

}
