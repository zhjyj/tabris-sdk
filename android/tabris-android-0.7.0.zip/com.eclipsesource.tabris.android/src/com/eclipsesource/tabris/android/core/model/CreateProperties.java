/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.util.List;

public class CreateProperties extends SetProperties {

  private List<String> style;
  private String control;

  public List<String> getStyle() {
    return style;
  }

  public void setStyle( List<String> styles ) {
    this.style = styles;
  }

  public String getControl() {
    return control;
  }

  public void setControl( String control ) {
    this.control = control;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( control == null )
                                                   ? 0
                                                   : control.hashCode() );
    result = prime * result + ( ( style == null )
                                                 ? 0
                                                 : style.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( !super.equals( obj ) )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    CreateProperties other = ( CreateProperties )obj;
    if( control == null ) {
      if( other.control != null )
        return false;
    } else if( !control.equals( other.control ) )
      return false;
    if( style == null ) {
      if( other.style != null )
        return false;
    } else if( !style.equals( other.style ) )
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "CreateProperties ["
           + ( style != null
                            ? "style=" + style + ", "
                            : "" )
           + ( control != null
                              ? "control=" + control + ", "
                              : "" )
           + ( super.toString() != null
                                       ? "toString()=" + super.toString()
                                       : "" )
           + "]";
  }

}
