/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;

public class ToolBarOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.ToolBar";

  public ToolBarOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    initiateNewView( operation, new ToolBar( getActivity() ) );
  }

  public String getType() {
    return TYPE;
  }

}
