/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeScaleChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateScaleChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingScaleChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.Scale;

public class ScaleOperator extends AbstractWidgetOperator {

  private static final String TYPE = "rwt.widgets.Scale";

  public ScaleOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Scale scale = new Scale( getActivity() );
    CompositeScaleChangedListener compListener = new CompositeScaleChangedListener();
    compListener.addListener( new RecordingScaleChangeListener( getProcessor().getStateRecorder() ) );
    scale.setOnSeekBarChangeListener( compListener );
    getListenerRegistry().registerListener( operation.getTarget(), compListener );
    initiateNewView( operation, scale );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    CompositeScaleChangedListener compListener = getListenerRegistry().findListener( operation.getTarget(),
                                                                                     CompositeScaleChangedListener.class );
    compListener.addListener( new ImmediateScaleChangeListener( getActivity().getProcessor() ) );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    CompositeScaleChangedListener compListener = getListenerRegistry().findListener( operation.getTarget(),
                                                                                     CompositeScaleChangedListener.class );
    compListener.removeListeners( ImmediateScaleChangeListener.class );
  }

  public String getType() {
    return TYPE;
  }

}
