/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import android.util.SparseArray;
import android.widget.ArrayAdapter;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeDatePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeTimePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeSpinnerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateDateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingDateTimeChangedListener;

public class DateTimeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.DateTime";

  public static final String STYLE_DATE = "DATE";
  public static final String STYLE_CALENDAR = "CALENDAR";
  public static final String STYLE_TIME = "TIME";
  public static final String STYLE_SHORT = "SHORT";
  public static final String STYLE_MEDIUM = "MEDIUM";
  public static final String STYLE_LONG = "LONG";

  public static final String TIME_FORMAT_SHORT = "HH:mm";
  public static final String TIME_FORMAT_MEDIUM_AND_LONG = TIME_FORMAT_SHORT;
  public static final String DATE_FORMAT_DAY = "dd";
  public static final String DATE_FORMAR_MONTH = "MM";
  public static final String DATE_FORMAT_YEAR = "yyyy";
  public static final String DATE_FORMAT_LONG = "EEEE ,  dd MMMMM ,  yyyy";
  public static final String DATE_FORMAT_SHORT = "MMMMM, yyyy";

  private final TabrisActivity activity;

  public DateTimeOperator( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( activity, operation );
    DateTimeSpinner dateTimeSpinner = createDateTimeSpinner( operation );
    attachStateRecordingListener( dateTimeSpinner, operation.getProperties().getStyle() );
    initiateNewView( operation, dateTimeSpinner );
  }

  private DateTimeSpinner createDateTimeSpinner( CreateOperation operation ) {
    List<String> style = operation.getProperties().getStyle();
    if( style.contains( STYLE_CALENDAR ) ) {
      throw new UnsupportedOperationException( "The style CALENDAR is currently not supported for the DateTime widget." );
    }
    IDateTimeSpinnerDialog dialog = null;
    String dateFormat = null;
    Calendar calendar = GregorianCalendar.getInstance();
    if( style.contains( STYLE_DATE ) ) {
      dateFormat = createDateFormat( operation.getProperties() );
      dialog = new DateTimeDatePickerDialog( activity, calendar );
    } else if( style.contains( STYLE_TIME ) ) {
      dateFormat = createTimeFormat( operation.getProperties() );
      dialog = new DateTimeTimePickerDialog( activity, calendar );
    }
    return new DateTimeSpinner( activity, createAdapter(), dialog, dateFormat );
  }

  private String createTimeFormat( CreateProperties properties ) {
    if( properties.getStyle().contains( STYLE_SHORT ) ) {
      return TIME_FORMAT_SHORT;
    }
    return TIME_FORMAT_MEDIUM_AND_LONG;
  }

  private String createDateFormat( CreateProperties properties ) {
    StringBuffer dateFormat = new StringBuffer();
    List<String> style = properties.getStyle();
    if( style.contains( STYLE_SHORT ) ) {
      dateFormat.append( DATE_FORMAT_SHORT );
    } else if( style.contains( STYLE_MEDIUM ) ) {
      createDateFormatMedium( dateFormat, properties );
    } else if( style.contains( STYLE_LONG ) ) {
      dateFormat.append( DATE_FORMAT_LONG );
    }
    return dateFormat.toString();
  }

  private void createDateFormatMedium( StringBuffer dateFormat, CreateProperties properties ) {
    validateDateMediumProperties( properties );
    String datePattern = properties.getDatePattern();
    String dateSeparator = properties.getDateSeparator();
    for( int i = 0; i < datePattern.length(); i++ ) {
      if( datePattern.charAt( i ) == 'Y' ) {
        dateFormat.append( DATE_FORMAT_YEAR );
      } else if( datePattern.charAt( i ) == 'M' ) {
        dateFormat.append( DATE_FORMAR_MONTH );
      } else if( datePattern.charAt( i ) == 'D' ) {
        dateFormat.append( DATE_FORMAT_DAY );
      }
      if( i != datePattern.length() - 1 ) {
        dateFormat.append( dateSeparator );
      }
    }
  }

  private void validateDateMediumProperties( CreateProperties properties ) {
    if( properties.getDatePattern() == null ) {
      throw new IllegalArgumentException( "No date pattern found to create a MEDIUM DATE DateTime widget" );
    }
    if( properties.getDateSeparator() == null ) {
      throw new IllegalArgumentException( "No date separator found to create a MEDIUM DATE DateTime widget" );
    }
  }

  private void attachStateRecordingListener( DateTimeSpinner spinner, List<String> style ) {
    StateRecorder stateRecorder = getProcessor().getStateRecorder();
    SparseArray<String> dateValues = createDateValuesList( style );
    spinner.addListener( new RecordingDateTimeChangedListener( stateRecorder, dateValues ) );
  }

  private ArrayAdapter<String> createAdapter() {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             android.R.layout.simple_spinner_item );
    adapter.setDropDownViewResource( R.layout.spinner_dropdown_item );
    return adapter;
  }

  private SparseArray<String> createDateValuesList( List<String> style ) {
    SparseArray<String> dateValues = new SparseArray<String>();
    if( style.contains( STYLE_DATE ) ) {
      dateValues.put( Calendar.YEAR, IProtocolConstants.DATE_TIME_YEAR );
      dateValues.put( Calendar.MONTH, IProtocolConstants.DATE_TIME_MONTH );
      dateValues.put( Calendar.DAY_OF_MONTH, IProtocolConstants.DATE_TIME_DAY );
    } else if( style.contains( STYLE_TIME ) ) {
      dateValues.put( Calendar.HOUR_OF_DAY, IProtocolConstants.DATE_TIME_HOURS );
      dateValues.put( Calendar.MINUTE, IProtocolConstants.DATE_TIME_MINUTES );
      dateValues.put( Calendar.SECOND, IProtocolConstants.DATE_TIME_SECONDS );
    }
    return dateValues;
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final DateTimeSpinner spinner = ( DateTimeSpinner )findViewByTarget( operation );
    IDateTimeSpinnerDialog dialog = spinner.getDialog();
    SparseArray<String> dateValues = null;
    if( dialog instanceof DateTimeDatePickerDialog ) {
      dateValues = createDateValuesList( Arrays.asList( STYLE_DATE ) );
    } else if( dialog instanceof DateTimeTimePickerDialog ) {
      dateValues = createDateValuesList( Arrays.asList( STYLE_TIME ) );
    }
    spinner.addListener( new ImmediateDateTimeChangedListener( getProcessor(), dateValues ) );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    final DateTimeSpinner spinner = ( DateTimeSpinner )findViewByTarget( operation );
    spinner.removeListeners( ImmediateDateTimeChangedListener.class );
  }

  @Override
  public void set( SetOperation operation ) {
    super.set( operation );
    DateTimeSpinner spinner = ( DateTimeSpinner )findViewByTarget( operation );
    setYear( spinner, operation.getProperties() );
    setMonth( spinner, operation.getProperties() );
    setDay( spinner, operation.getProperties() );
    setHours( spinner, operation.getProperties() );
    setMinutes( spinner, operation.getProperties() );
  }

  private void setYear( DateTimeSpinner spinner, SetProperties props ) {
    Integer year = props.getYear();
    if( year != null ) {
      if( year < 1900 || year > 2100 ) {
        throw new IllegalArgumentException( "The year to set on a DateTime widget can only be in the range 1900 - 2100 (inclusive). Received: "
                                            + year );
      }
      spinner.getDialog().setYear( year );
    }
  }

  private void setMonth( DateTimeSpinner spinner, SetProperties props ) {
    Integer month = props.getMonth();
    if( month != null ) {
      spinner.getDialog().setMonth( month );
    }
  }

  private void setDay( DateTimeSpinner spinner, SetProperties props ) {
    Integer day = props.getDay();
    if( day != null ) {
      spinner.getDialog().setDay( day );
    }
  }

  private void setHours( DateTimeSpinner spinner, SetProperties props ) {
    Integer hours = props.getHours();
    if( hours != null ) {
      spinner.getDialog().setHours( hours );
    }
  }

  private void setMinutes( DateTimeSpinner spinner, SetProperties props ) {
    Integer minutes = props.getMinutes();
    if( minutes != null ) {
      spinner.getDialog().setMinutes( minutes );
    }
  }

}
