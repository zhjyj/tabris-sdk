/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class TabFolderOperator extends AbstractWidgetOperator {

  private static final String STYLE_BOTTOM = "BOTTOM";

  public static final String TYPE = "rwt.widgets.TabFolder";

  private final TabrisActivity activity;

  class TabChangeListener implements OnTabChangeListener {

    private final String widgetId;

    boolean firstTabSetVisible = false;

    public TabChangeListener( String widgetId ) {
      this.widgetId = widgetId;
    }

    public void onTabChanged( String tabId ) {
      if( !firstTabSetVisible ) {
        firstTabSetVisible = true;
      } else {
        PostRequest request = new PostRequest();
        request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED_ITEM, tabId );
        request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, widgetId );
        getProcessor().processPostRequest( request );
      }
    }
  }

  public TabFolderOperator( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  public void create( final CreateOperation operation ) {
    TabHost tabHost = null;
    ValidationUtil.validateCreateOperation( activity, operation );
    CreateProperties properties = operation.getProperties();
    List<String> style = properties.getStyle();
    if( style != null && style.contains( STYLE_BOTTOM ) ) {
      tabHost = ( TabHost )activity.getLayoutInflater().inflate( R.layout.tabfolder_bottom, null );
    } else {
      tabHost = ( TabHost )activity.getLayoutInflater().inflate( R.layout.tabfolder_top, null );
    }
    tabHost.setup();
    tabHost.setOnTabChangedListener( new TabChangeListener( operation.getTarget() ) );
    initiateNewView( operation, tabHost );
  }

  public String getType() {
    return TYPE;
  }

}
