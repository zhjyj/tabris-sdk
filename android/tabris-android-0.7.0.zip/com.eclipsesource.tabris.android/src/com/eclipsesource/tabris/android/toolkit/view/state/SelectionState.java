/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class SelectionState extends AbstractState {

  private final boolean selection;

  public SelectionState( String widgetID, boolean selection ) {
    super( widgetID );
    this.selection = selection;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTION_POSTFIX;
  }

  @Override
  public String generateValue() {
    return Boolean.toString( selection );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( selection
                                         ? 1231
                                         : 1237 );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    SelectionState other = ( SelectionState )obj;
    if( selection != other.selection ) {
      return false;
    }
    return true;
  }

}
