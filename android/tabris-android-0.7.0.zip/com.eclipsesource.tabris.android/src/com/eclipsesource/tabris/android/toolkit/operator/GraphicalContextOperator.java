/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.HashMap;
import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.ClientGraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.AddColorStopGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.AlphaGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.BeginPathGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.CreateLinearGradiantGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.DrawImageGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.EllipseGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillStyleGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillTextGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.FontGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.LineCapGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.LineJoinGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.LineToGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.LineWidthGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.MoveToGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.QuadraticCurveToGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.RectGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.RestoreGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.SaveGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeStyleGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeTextGcOperation;

public class GraphicalContextOperator implements IOperator {

  public static final String TYPE = "rwt.GC";

  private static final String STR_INIT = "init";
  private static final String STR_DRAW = "draw";
  private static final String STR_OPERATIONS = "operations";

  private final TabrisActivity activity;
  private final HashMap<String, IGcOperation> gcOperations;

  public GraphicalContextOperator( TabrisActivity activity ) {
    this.activity = activity;
    gcOperations = new HashMap<String, IGcOperation>();
    // control operations
    registerOperation( new BeginPathGcOperation() );
    registerOperation( new SaveGcOperation() );
    registerOperation( new RestoreGcOperation() );
    registerOperation( new StrokeGcOperation() );
    registerOperation( new FillGcOperation() );
    registerOperation( new CreateLinearGradiantGcOperation( activity ) );
    registerOperation( new AddColorStopGcOperation() );
    // paint operations
    registerOperation( new FillStyleGcOperation() );
    registerOperation( new StrokeStyleGcOperation() );
    registerOperation( new AlphaGcOperation() );
    registerOperation( new LineWidthGcOperation( activity ) );
    registerOperation( new LineCapGcOperation() );
    registerOperation( new LineJoinGcOperation() );
    registerOperation( new FontGcOperation( activity ) );
    // geometry operations
    registerOperation( new RectGcOperation( activity ) );
    registerOperation( new QuadraticCurveToGcOperation( activity ) );
    registerOperation( new EllipseGcOperation( activity ) );
    registerOperation( new MoveToGcOperation( activity ) );
    registerOperation( new LineToGcOperation( activity ) );
    registerOperation( new DrawImageGcOperation( activity ) );
    registerOperation( new FillTextGcOperation( activity ) );
    registerOperation( new StrokeTextGcOperation( activity ) );
  }

  private void registerOperation( IGcOperation op ) {
    gcOperations.put( op.getOperation(), op );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( activity, operation );
    View view = activity.getProcessor()
      .getWidgetToolkit()
      .findObjectById( operation.getProperties().getParent(), View.class );
    if( !( view instanceof Canvas ) ) {
      throw new IllegalStateException( "Can not create GraphicalContext because the parent is not of type "
                                       + Canvas.class.getName()
                                       + ". Instead it is of type "
                                       + view );
    }
    Canvas canvas = ( Canvas )view;
    ClientGraphicalContext gc = new ClientGraphicalContext( activity, canvas );
    canvas.setGc( gc );

    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.registerObjectById( operation.getTarget(), gc );
  }

  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    GraphicalContext gc = toolkit.findObjectById( operation.getTarget(), GraphicalContext.class );
    if( operation.getMethod().equals( STR_INIT ) ) {
      gc.init( operation.getProperties() );
    } else if( operation.getMethod().equals( STR_DRAW ) ) {
      processDrawMethod( operation, gc );
    }
  }

  private void processDrawMethod( CallOperation operation, GraphicalContext gc ) {
    Object ops = operation.getProperties().get( STR_OPERATIONS );
    if( ops instanceof List ) {
      processOperationList( gc, ( List<?> )ops );
      gc.invalidate();
    } else {
      String msg = "The " + STR_OPERATIONS + " paramatere has to be a list. Got: " + ops;
      throw new IllegalArgumentException( msg );
    }
  }

  private void processOperationList( GraphicalContext gc, List<?> opsList ) {
    for( int i = 0; i < opsList.size(); i++ ) {
      Object element = opsList.get( i );
      if( element instanceof List ) {
        List<?> elemList = ( List<?> )element;
        processOperation( gc, elemList );
      } else {
        String msg = "The "
                     + STR_OPERATIONS
                     + " list entries have to be of type list. Got: "
                     + element;
        throw new IllegalArgumentException( msg );
      }
    }
  }

  private void processOperation( GraphicalContext gc, List<?> elemList ) {
    if( elemList.size() > 0 ) {
      IGcOperation operation = gcOperations.get( elemList.get( 0 ) );
      if( operation != null ) {
        operation.execute( gc, elemList );
      }
    }
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.unregisterObjectById( operation.getTarget() );
  }

  /** To be used for testing only. */
  HashMap<String, IGcOperation> getGcOperations() {
    return gcOperations;
  }

  public void set( SetOperation operation ) {
    // Nothing to do here
  }

  public void listen( ListenOperation operation ) {
    // Nothing to do here
  }

}
