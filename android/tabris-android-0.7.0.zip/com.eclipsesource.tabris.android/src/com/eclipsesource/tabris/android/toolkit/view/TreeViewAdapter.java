/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class TreeViewAdapter extends BaseAdapter {

  private static final int TITLE_COLUMN_INDEX = 0;
  private static final int DESCRIPTION_COLUMN_INDEX = 1;

  private final TreeView treeView;
  private final LayoutInflater inflater;
  private TreeViewColorizer colorizer;

  public static class TreeViewColorizer {

    public void colorizeRow( int position, View rowView, List<TreeItemView> currentTreeItems ) {
      if( currentTreeItems.size() > position ) {
        setBackground( position, rowView, currentTreeItems );
      }
    }

    private void setBackground( int position, View rowView, List<TreeItemView> currentTreeItems ) {
      List<Integer> cellBackgrounds = currentTreeItems.get( position ).getBackgroundCellColors();
      if( cellBackgrounds != null && cellBackgrounds.size() > TITLE_COLUMN_INDEX ) {
        rowView.setBackgroundColor( cellBackgrounds.get( TITLE_COLUMN_INDEX ) );
      } else {
        rowView.setBackgroundDrawable( null );
      }
    }

    public void colorizeTitle( ViewHolder viewHolder, TreeItemView treeItemView ) {
      List<Integer> cellForegrounds = treeItemView.getForegroundCellColors();
      if( cellForegrounds != null && cellForegrounds.size() > TITLE_COLUMN_INDEX ) {
        viewHolder.titleText.setTextColor( cellForegrounds.get( TITLE_COLUMN_INDEX ) );
      }
    }

    public void colorizeDescription( ViewHolder viewHolder, TreeItemView treeItemView ) {
      List<Integer> cellForegrounds = treeItemView.getForegroundCellColors();
      if( cellForegrounds != null && cellForegrounds.size() > DESCRIPTION_COLUMN_INDEX ) {
        viewHolder.descriptionText.setTextColor( cellForegrounds.get( DESCRIPTION_COLUMN_INDEX ) );
      }
    }
  }

  static class ViewHolder {

    public ImageView iconImage;
    public TextView titleText;
    public TextView descriptionText;

  }

  public TreeViewAdapter( Activity activity, TreeView treeView ) {
    ValidationUtil.checkNullArg( this, activity, Activity.class );
    ValidationUtil.checkNullArg( this, treeView, TreeView.class );
    this.treeView = treeView;
    inflater = activity.getLayoutInflater();
    colorizer = new TreeViewColorizer();
  }

  public int getCount() {
    if( treeView.hasVirtualTreeSupport() ) {
      return treeView.getParentTreeItem().getItemCount();
    }
    return treeView.getCurrentTreeItems().size();
  }

  public Object getItem( int position ) {
    return treeView.getCurrentTreeItems().get( position );
  }

  public long getItemId( int position ) {
    return position;
  }

  public View getView( int position, View convertView, ViewGroup parent ) {
    ViewHolder viewHolder;
    View rowView = convertView;
    if( rowView == null ) {
      rowView = inflater.inflate( R.layout.tree_item_two_line, null, true );
      viewHolder = createHolder( rowView );
    } else {
      viewHolder = ( ViewHolder )rowView.getTag();
    }
    setupView( position, viewHolder );
    colorizer.colorizeRow( position, rowView, treeView.getCurrentTreeItems() );
    return rowView;
  }

  private void setupView( int position, ViewHolder viewHolder ) {
    ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
    if( currentTreeItems.size() > position ) {
      TreeItemView treeItemView = currentTreeItems.get( position );
      populateView( viewHolder, treeItemView );
    } else if( treeView.hasVirtualTreeSupport() ) {
      viewHolder.titleText.setText( StringUtil.DOT_DOT_DOT );
      viewHolder.descriptionText.setVisibility( View.GONE );
      viewHolder.iconImage.setVisibility( View.GONE );
    }
  }

  private void populateView( ViewHolder viewHolder, TreeItemView treeItemView ) {
    populateTitle( viewHolder, treeItemView );
    colorizer.colorizeTitle( viewHolder, treeItemView );
    populateDescription( viewHolder, treeItemView );
    colorizer.colorizeDescription( viewHolder, treeItemView );
    populateIcon( viewHolder, treeItemView );
  }

  private void populateIcon( ViewHolder viewHolder, TreeItemView treeItemView ) {
    BitmapDrawable image = treeItemView.getImage();
    if( image != null ) {
      viewHolder.iconImage.setVisibility( View.VISIBLE );
      viewHolder.iconImage.setImageDrawable( image );
    } else {
      viewHolder.iconImage.setVisibility( View.GONE );
    }
  }

  private void populateDescription( ViewHolder viewHolder, TreeItemView treeItemView ) {
    List<String> texts = treeItemView.getTexts();
    if( texts != null && texts.size() > DESCRIPTION_COLUMN_INDEX ) {
      viewHolder.descriptionText.setText( texts.get( DESCRIPTION_COLUMN_INDEX ) );
      viewHolder.descriptionText.setVisibility( View.VISIBLE );
      if( texts.get( 1 ).length() == 0 ) {
        viewHolder.descriptionText.setVisibility( View.GONE );
      }
    } else {
      viewHolder.descriptionText.setVisibility( View.GONE );
    }
  }

  private void populateTitle( ViewHolder viewHolder, TreeItemView treeItemView ) {
    List<String> texts = treeItemView.getTexts();
    if( texts != null ) {
      viewHolder.titleText.setText( texts.get( TITLE_COLUMN_INDEX ) );
    }
  }

  private ViewHolder createHolder( View rowView ) {
    ViewHolder holder;
    holder = new ViewHolder();
    holder.titleText = ( TextView )rowView.findViewById( R.id.tree_item_title_text );
    holder.descriptionText = ( TextView )rowView.findViewById( R.id.tree_item_desc_text );
    holder.iconImage = ( ImageView )rowView.findViewById( R.id.tree_item_image_item );
    rowView.setTag( holder );
    return holder;
  }

  /* For testing purposes only */
  void setColorizer( TreeViewColorizer colorizer ) {
    this.colorizer = colorizer;
  }
}
