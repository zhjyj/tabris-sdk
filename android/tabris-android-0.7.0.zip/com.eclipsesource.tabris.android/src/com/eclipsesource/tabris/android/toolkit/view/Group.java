/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class Group extends Composite {

  private final TabrisActivity activity;
  private TextView titleView;
  private View separatorView;

  public Group( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
    createTitleTextView( activity );
    createSeparatorView( activity );
  }

  private void createTitleTextView( TabrisActivity activity ) {
    titleView = new TextView( activity );
    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams( LayoutParams.MATCH_PARENT,
                                                                    LayoutParams.WRAP_CONTENT );
    params.leftMargin = mult( 18 );
    params.topMargin = mult( 14 );
    titleView.setLayoutParams( params );
    titleView.setTypeface( null, Typeface.BOLD );
    titleView.setTextColor( ThemeUtil.getColorValue( activity, R.attr.groupTitleTextColor ) );
    titleView.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.GROUP_TITLE_TEXT_SIZE );
    addView( titleView );
  }

  private void createSeparatorView( TabrisActivity activity ) {
    separatorView = new View( activity );
    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams( LayoutParams.MATCH_PARENT,
                                                                    mult( 1 ) );
    params.leftMargin = mult( 8 );
    params.rightMargin = mult( 8 );
    params.topMargin = mult( 38 );
    separatorView.setLayoutParams( params );
    separatorView.setBackgroundColor( ThemeUtil.getColorValue( activity, R.attr.groupSeparatorColor ) );
    addView( separatorView );
  }

  private int mult( int value ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    return toolkit.multiplyByDensityFactor( value );
  }

  public void setTitle( String text ) {
    titleView.setText( text );
  }

  public void setTitleAndSeparatorColor( int color ) {
    titleView.setTextColor( color );
    separatorView.setBackgroundColor( color );
  }
}
