/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.core.IState;

public abstract class AbstractState implements IState {

  protected String widgetId;

  public AbstractState( String widgetId ) {
    if( widgetId == null ) {
      throw new IllegalArgumentException( "WidgetID can not be null." );
    }
    this.widgetId = widgetId;
  }

  public abstract String generateKey();

  public abstract String generateValue();

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( widgetId == null )
                                                    ? 0
                                                    : widgetId.hashCode() );
    result = prime * result + getClass().hashCode();
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    AbstractState other = ( AbstractState )obj;
    if( widgetId == null ) {
      if( other.widgetId != null ) {
        return false;
      }
    } else if( !widgetId.equals( other.widgetId ) ) {
      return false;
    }
    return true;
  }

}
