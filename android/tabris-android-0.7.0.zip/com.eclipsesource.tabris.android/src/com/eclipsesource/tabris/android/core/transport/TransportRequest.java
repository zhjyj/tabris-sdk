/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

public class TransportRequest implements ITransportRequest {

  private final String path;
  private String query;
  private int timeout = -1;
  private boolean silentRequest;

  public TransportRequest( String path ) {
    this( path, null );
  }

  public TransportRequest( String path, String query ) {
    if( path == null ) {
      throw new IllegalArgumentException( "The path of a transport request can not be null" );
    }
    this.path = path;
    this.query = query;
  }

  public String getPath() {
    return path;
  }

  public String getQuery() {
    return query;
  }

  public void setQuery( String query ) {
    this.query = query;
  }

  public void setTimeout( int timeout ) {
    this.timeout = timeout;

  }

  public int getTimeout() {
    return timeout;
  }

  public void setSilentRequest( boolean silentRequest ) {
    this.silentRequest = silentRequest;
  }

  public boolean isSilentRequest() {
    return silentRequest;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( silentRequest
                                             ? 1231
                                             : 1237 );
    result = prime * result + ( ( path == null )
                                                ? 0
                                                : path.hashCode() );
    result = prime * result + ( ( query == null )
                                                 ? 0
                                                 : query.hashCode() );
    result = prime * result + timeout;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    TransportRequest other = ( TransportRequest )obj;
    if( silentRequest != other.silentRequest ) {
      return false;
    }
    if( path == null ) {
      if( other.path != null ) {
        return false;
      }
    } else if( !path.equals( other.path ) ) {
      return false;
    }
    if( query == null ) {
      if( other.query != null ) {
        return false;
      }
    } else if( !query.equals( other.query ) ) {
      return false;
    }
    if( timeout != other.timeout ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "TransportRequest ["
           + ( path != null
                           ? "path=" + path + ", "
                           : "" )
           + ( query != null
                            ? "query=" + query + ", "
                            : "" )
           + "timeout="
           + timeout
           + ", backgroundRequest="
           + silentRequest
           + "]";
  }

}
