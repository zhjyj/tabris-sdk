/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

public class CompositeItemSelectedListener extends ListenerHolder<OnItemSelectedListener>
  implements OnItemSelectedListener
{

  public void onItemSelected( AdapterView<?> parent, View view, int position, long id ) {
    ArrayList<OnItemSelectedListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onItemSelected( parent, view, position, id );
    }
  }

  public void onNothingSelected( AdapterView<?> parent ) {
    ArrayList<OnItemSelectedListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onNothingSelected( parent );
    }
  }

}
