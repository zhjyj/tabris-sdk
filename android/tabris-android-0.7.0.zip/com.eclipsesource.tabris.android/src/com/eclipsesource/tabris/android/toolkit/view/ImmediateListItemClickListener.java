/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateListItemClickListener implements OnItemClickListener {

  private final ProtocolProcessor processor;

  public ImmediateListItemClickListener( ProtocolProcessor processor ) {
    if( processor == null ) {
      throw new IllegalArgumentException( "The given processor can not be null" );
    }
    this.processor = processor;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    processor.processPostRequest( createRequestParam( ( List )parent, Integer.toString( position ) ) );
  }

  private String transformByDensity( float ordinate ) {
    return String.valueOf( processor.getWidgetToolkit()
      .divideByDensityFactor( Math.round( ordinate ) ) );
  }

  private PostRequest createRequestParam( List list, String selectedIndex ) {
    PostRequest request = new PostRequest();
    String widgetId = ( String )list.getTag();
    TouchPositionBuffer buffer = getTouchPositonBuffer( widgetId );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, widgetId );
    request.addParam( W1_CURSOR_LOCATION_X, transformByDensity( buffer.getX() ) );
    request.addParam( W1_CURSOR_LOCATION_Y, transformByDensity( buffer.getY() ) );
    buffer.clear();
    return request;
  }

  private TouchPositionBuffer getTouchPositonBuffer( String widgetId ) {
    return processor.getWidgetToolkit()
      .getListenerRegistry()
      .findListener( widgetId, TouchPositionBuffer.class );
  }

}
