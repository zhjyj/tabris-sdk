
package com.eclipsesource.tabris.android.transport.http;

import java.util.concurrent.ExecutorService;

import android.util.Log;

import com.eclipsesource.org.apache.http.client.HttpClient;
import com.eclipsesource.tabris.android.BuildConfig;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class HttpShutdownRunnable implements Runnable {

  private final HttpClient httpClient;
  private final ExecutorService executor;

  public HttpShutdownRunnable( HttpClient httpClient, ExecutorService executor ) {
    this.executor = executor;
    ValidationUtil.checkNullArg( this, httpClient, HttpClient.class );
    ValidationUtil.checkNullArg( this, executor, ExecutorService.class );
    this.httpClient = httpClient;
  }

  public void run() {
    try {
      httpClient.getConnectionManager().shutdown();
    } catch( Throwable e ) {
    } finally {
      try {
        executor.shutdown();
      } catch( Throwable e2 ) {
        if( BuildConfig.DEBUG ) {
          Log.e( TabrisActivity.LOG_TAG, e2.getMessage() );
        }
      }
    }
  }

}
