/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

public interface IDateTimeSpinnerDialog {

  void show();

  void setDateTimeSpinner( DateTimeSpinner dateTimeSpinner );

  void reset();

  void setYear( int year );

  void setMonth( int month );

  void setDay( int day );

  void setHours( int hours );

  void setMinutes( int minutes );

}
