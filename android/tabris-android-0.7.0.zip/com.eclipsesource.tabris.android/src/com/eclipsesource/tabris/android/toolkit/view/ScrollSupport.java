/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollXState;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollYState;

public class ScrollSupport {

  private final View view;
  private ScrollSupportDirection direction;
  private final StateRecorder stateRecorder;
  private final ScrollXState scrollXState;
  private final ScrollYState scrollYState;
  private final IWidgetToolkit toolkit;
  private int scrollTargetX;
  private int scrollTargetY;

  public ScrollSupport( TabrisActivity activity, View view ) {
    this.view = view;
    direction = ScrollSupportDirection.X_AND_Y;
    ProtocolProcessor processor = activity.getProcessor();
    stateRecorder = processor.getStateRecorder();
    toolkit = processor.getWidgetToolkit();
    scrollXState = new ScrollXState( StringUtil.EMPTY_STRING );
    scrollYState = new ScrollYState( StringUtil.EMPTY_STRING );
  }

  protected void onScrollChanged( int x, int y, int oldx, int oldy ) {
    if( x != oldx || y != oldy ) {
      if( direction.supportsX() ) {
        handleScrollX( toolkit.divideByDensityFactor( x ) );
      }
      if( direction.supportsY() ) {
        handleScrollY( toolkit.divideByDensityFactor( y ) );
      }
    }
  }

  private void handleScrollY( int y ) {
    scrollTargetY = y;
    scrollYState.setScrollY( y );
    scrollYState.setWidgetId( ( String )view.getTag() );
    stateRecorder.recordState( scrollYState );
  }

  private void handleScrollX( int x ) {
    scrollTargetX = x;
    scrollXState.setScrollX( x );
    scrollXState.setWidgetId( ( String )view.getTag() );
    stateRecorder.recordState( scrollXState );
  }

  public int getScrollTargetX() {
    return scrollTargetX;
  }

  public int getScrollTargetY() {
    return scrollTargetY;
  }

  public void setScrollTargetX( int scrollTargetX ) {
    this.scrollTargetX = scrollTargetX;
  }

  public void setScrollTargetY( int scrollTargetY ) {
    this.scrollTargetY = scrollTargetY;
  }

  public void setDirection( ScrollSupportDirection direction ) {
    this.direction = direction;
  }

  /** To be used for testing only */
  public ScrollSupportDirection getDirection() {
    return direction;
  }
}