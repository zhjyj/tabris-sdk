/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

public interface IDateTimeChangedListener {

  void dateTimeChanged( DateTimeSpinner spinner );

}
