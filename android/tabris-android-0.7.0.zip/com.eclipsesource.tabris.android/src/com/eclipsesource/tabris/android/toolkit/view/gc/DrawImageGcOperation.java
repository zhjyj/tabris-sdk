/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.Arrays;
import java.util.List;

import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class DrawImageGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "drawImage";

  class LoadAndDrawBitmapTask extends LoadImageTask {

    private final Paint paint;
    private final GraphicalContext gc;
    private final List<?> properties;

    public LoadAndDrawBitmapTask( TabrisActivity activity, GraphicalContext gc, List<?> properties ) {
      super( activity );
      this.gc = gc;
      this.properties = properties;
      paint = new Paint( gc.getPaint() );
    }

    @Override
    protected void onPostExecute( BitmapDrawable bitmap ) {
      if( properties.size() == 4 ) {
        drawDirect( gc, paint, properties, bitmap.getBitmap() );
      } else {
        drawScaled( gc, paint, properties, bitmap.getBitmap() );
      }
      gc.invalidate();
      BitmapDrawableCache cache = getActivity().getProcessor().getWidgetToolkit().getBitmapCache();
      cache.decreaseReferenceCount( bitmap );
    }

    private void drawScaled( final GraphicalContext gc,
                             Paint paint,
                             List<?> properties,
                             Bitmap bitmap )
    {
      final int srcX = Math.round( getScaledFloat( properties, 2 ) );
      final int srcY = Math.round( getScaledFloat( properties, 3 ) );
      final int srcWidth = Math.round( getScaledFloat( properties, 4 ) );
      final int srcHeight = Math.round( getScaledFloat( properties, 5 ) );
      final int destX = Math.round( getScaledFloat( properties, 6 ) );
      final int destY = Math.round( getScaledFloat( properties, 7 ) );
      final int destWidth = Math.round( getScaledFloat( properties, 8 ) );
      final int destHeight = Math.round( getScaledFloat( properties, 9 ) );
      Rect srcRect = new Rect( srcX, srcY, srcX + srcWidth, srcY + srcHeight );
      RectF destRect = new RectF( destX, destY, destX + destWidth, destY + destHeight );
      gc.getCanvas().drawBitmap( bitmap, srcRect, destRect, paint );
    }

    private void drawDirect( final GraphicalContext gc,
                             Paint paint,
                             List<?> properties,
                             Bitmap bitmap )
    {
      float x = getScaledFloat( properties, 2 );
      float y = getScaledFloat( properties, 3 );
      gc.getCanvas().drawBitmap( bitmap, x, y, paint );
    }
  }

  public DrawImageGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  @SuppressWarnings("unchecked")
  public void execute( final GraphicalContext gc, final List<?> properties ) {
    if( properties.size() != 4 && properties.size() != 10 ) {
      throw new IllegalArgumentException( "The 'drawImage' operation has to be a 4 or 10 element touple. Got a "
                                          + properties.size()
                                          + " element touple." );
    }
    List<String> params = Arrays.asList( String.valueOf( properties.get( 1 ) ),
                                         String.valueOf( properties.get( 2 ) ),
                                         String.valueOf( properties.get( 3 ) ) );
    LoadImageTask asynchTask = new LoadAndDrawBitmapTask( getActivity(), gc, properties );
    asynchTask.loadBitmap( params );
  }

}
