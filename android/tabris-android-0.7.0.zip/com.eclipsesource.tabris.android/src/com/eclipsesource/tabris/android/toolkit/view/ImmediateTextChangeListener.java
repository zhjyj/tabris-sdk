/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.text.Editable;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateTextChangeListener extends TextChangeListener {

  private ProtocolProcessor processor;

  public ImmediateTextChangeListener( String textWidgetTag, ProtocolProcessor processor ) {
    super( textWidgetTag, processor.getStateRecorder() );
    this.processor = processor;
  }

  @Override
  public void afterTextChanged( Editable s ) {
    super.afterTextChanged( s );
    processor.processPostRequest( createPostRequest( s ) );
  }

  private PostRequest createPostRequest( Editable s ) {
    PostRequest request = new PostRequest();
    request.addParam( tag + IProtocolConstants.TEXT_POSTFIX, s.toString() );
    return request;
  }

  public void beforeTextChanged( CharSequence s, int start, int count, int after ) {
    // not required
  }

  public void onTextChanged( CharSequence s, int start, int before, int count ) {
    // not required
  }

}
