/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.parser;

import java.io.InputStream;

public interface IProtocolParser {

  void addProtocolParserCallback( IProtocolParserCallback callback );

  void parse( InputStream is );

  String toJson( Object obj );

}
