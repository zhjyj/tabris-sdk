/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateSpinnerItemSelectedListener implements OnItemSelectedListener {

  private final ProtocolProcessor processor;

  public ImmediateSpinnerItemSelectedListener( ProtocolProcessor processor ) {
    if( processor == null ) {
      throw new IllegalArgumentException( "The protocol processor can not be null" );
    }
    this.processor = processor;
  }

  public void onItemSelected( AdapterView<?> parent, View view, int position, long id ) {
    if( parent == null ) {
      throw new IllegalArgumentException( "The parent parameter of the selected element can not be null" );
    }
    String widgetId = ( String )parent.getTag();
    PostRequest request = createRequestParam( widgetId, position );
    processor.processPostRequest( request );
  }

  public void onNothingSelected( AdapterView<?> parent ) {
    // nothing to do here. Not selecting anything doesn't change the ui
  }

  protected PostRequest createRequestParam( String widgetId, int position ) {
    PostRequest request = new PostRequest();
    request.addParam( widgetId + IProtocolConstants.LIST_VISIBLE_POSTFIX, Boolean.FALSE.toString() );
    request.addParam( widgetId + IProtocolConstants.SELECTED_ITEM_POSTFIX,
                      String.valueOf( position ) );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, widgetId );
    return request;
  }
}
