/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Group;

public class GroupSetter<T extends Group> extends CompositeSetter<T> {

  public GroupSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T group, SetProperties properties ) {
    super.execute( group, properties );
    setText( group, properties );
    setForeground( group, properties );
  }

  private void setText( T group, SetProperties properties ) {
    String text = properties.getText();
    if( text != null ) {
      group.setTitle( text );
    }
  }

  private void setForeground( T group, SetProperties properties ) {
    List<Integer> foreground = properties.getForeground();
    if( foreground != null ) {
      group.setTitleAndSeparatorColor( SetterManager.colorToupleToInt( foreground ) );
    }
  }

}
