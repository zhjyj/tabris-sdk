/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.view.state.FocusState;

public class RecordingFocusTrackingListener implements OnTouchListener {

  private final TabrisActivity activity;
  private final StateRecorder stateRecorder;
  private InputMethodManager imm;
  private String prevTag;

  public RecordingFocusTrackingListener( TabrisActivity activity ) {
    this.activity = activity;
    this.stateRecorder = activity.getProcessor().getStateRecorder();
    imm = ( InputMethodManager )activity.getSystemService( Context.INPUT_METHOD_SERVICE );
  }

  public boolean onTouch( View v, MotionEvent event ) {
    String tag = ( String )v.getTag();
    if( !tag.equals( prevTag ) ) {
      prevTag = tag;
      stateRecorder.recordState( new FocusState( tag ) );
    }
    if( v instanceof EditText ) {
      notifyImmediateListener( v );
    } else {
      hideKeyboard( v );
    }
    return false;
  }

  private void hideKeyboard( View v ) {
    imm.hideSoftInputFromWindow( v.getWindowToken(), 0 );
  }

  private void notifyImmediateListener( View v ) {
    ListenerRegistry registry = activity.getProcessor().getWidgetToolkit().getListenerRegistry();
    CompositeFocusListener compListener = registry.findListener( ( String )v.getTag(),
                                                                 CompositeFocusListener.class );
    OnFocusChangeListener immediateListener = compListener.findListener( ImmediateFocusChangeListener.class );
    if( immediateListener != null && v.hasFocus() ) {
      immediateListener.onFocusChange( v, true );
    }
  }

  /** To be used for testing only. */
  void setPrevTag( String prevTag ) {
    this.prevTag = prevTag;
  }

  /** To be used for testing only. */
  void setInputMethodManager( InputMethodManager imm ) {
    this.imm = imm;
  }
}
