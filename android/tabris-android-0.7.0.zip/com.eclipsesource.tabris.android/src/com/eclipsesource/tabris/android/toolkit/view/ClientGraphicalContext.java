/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.view.MotionEvent;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ClientGraphicalContext extends GraphicalContext {

  private static final float TOUCH_TOLERANCE = 4;

  private static final String KEY_FOREGROUND = "foreground";
  private static final String KEY_LINE_WIDTH = "lineWidth";
  private static final String KEY_POLYLINE = "polyline";

  private final TabrisActivity activity;
  private final float tolerance;

  private Path linePath;
  private ArrayList<Integer> recordedCoords;
  private float lastY;
  private float lastX;

  public ClientGraphicalContext( TabrisActivity activity, Canvas canvas ) {
    super( activity, canvas );
    this.activity = activity;
    linePath = new Path();
    recordedCoords = new ArrayList<Integer>();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    tolerance = toolkit.multiplyByDensityFactor( TOUCH_TOLERANCE );
  }

  public boolean onTouchEvent( MotionEvent event ) {
    float x = event.getX();
    float y = event.getY();
    switch( event.getAction() ) {
      case MotionEvent.ACTION_DOWN:
        onTouchDown( x, y );
        record( x, y );
      break;
      case MotionEvent.ACTION_MOVE:
        onMove( x, y );
        record( x, y );
      break;
      case MotionEvent.ACTION_UP:
      case MotionEvent.ACTION_CANCEL:
        onTouchUpOrCancel( x, y );
      break;
    }
    return true;
  }

  private void onTouchDown( float x, float y ) {
    linePath.moveTo( x, y );
    lastX = x;
    lastY = y;
  }

  private void onMove( float x, float y ) {
    addMoveTo( x, y );
    float dx = Math.abs( x - lastX );
    float dy = Math.abs( y - lastY );
    if( dx >= tolerance || dy >= tolerance ) {
      initInternal();
      float controlPointX = ( x + lastX ) / 2f;
      float controlPointY = ( y + lastY ) / 2f;
      drawQuadTo( x, y, controlPointX, controlPointY );
    }
  }

  private void addMoveTo( float x, float y ) {
    // if a mouse listener is also registered on the parent canvas we might do
    // not receive the mouse down event so we add a moveTo manually
    if( recordedCoords.isEmpty() ) {
      onTouchDown( x, y );
    }
  }

  private void drawQuadTo( float curX, float curY, float controlPointX, float controlPointY ) {
    linePath.quadTo( controlPointX, controlPointY, curX, curY );
    drawPath();
    invalidateDrawingRegion( curX, curY );
    lastX = curX;
    lastY = curY;
  }

  private void onTouchUpOrCancel( float x, float y ) {
    drawQuadTo( x, y, x, y );
    sendPolylineRequest();
    linePath.rewind();
    recordedCoords.clear();
  }

  private void record( float x, float y ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    recordedCoords.add( Math.round( toolkit.divideByDensityFactor( x ) ) );
    recordedCoords.add( Math.round( toolkit.divideByDensityFactor( y ) ) );
  }

  private Object[][] createPolyLineParam() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    float lineWidth = toolkit.divideByDensityFactor( getPaint().getStrokeWidth() );
    int color = getStrokeColor();
    Object[][] polylineArray = new Object[][]{
      new Object[]{
        KEY_FOREGROUND, new Object[]{
          Color.red( color ), Color.green( color ), Color.blue( color ), getPaint().getAlpha()
        }
      }, new Object[]{
        KEY_LINE_WIDTH, new Object[]{
          lineWidth
        }
      }, new Object[]{
        KEY_POLYLINE, recordedCoords
      },
    };
    return polylineArray;
  }

  private void sendPolylineRequest() {
    if( !recordedCoords.isEmpty() && recordedCoordsArePoint() ) {
      convertCoordsToPoint();
    }
    Object[][] polylineArray = createPolyLineParam();
    ProtocolProcessor processor = activity.getProcessor();
    String param = processor.getParser().toJson( polylineArray );
    PostRequest request = new PostRequest();
    request.addParam( getCanvasView().getTag() + IProtocolConstants.DRAWINGS, param );
    processor.processPostRequest( request );
  }

  private void convertCoordsToPoint() {
    int x = recordedCoords.get( 0 );
    int y = recordedCoords.get( 1 );
    recordedCoords.clear();
    recordedCoords.add( x );
    recordedCoords.add( y );
    recordedCoords.add( x + 1 );
    recordedCoords.add( y );
    recordedCoords.add( x );
    recordedCoords.add( y + 1 );
    recordedCoords.add( x - 1 );
    recordedCoords.add( y );
    recordedCoords.add( x );
    recordedCoords.add( y - 1 );
  }

  private boolean recordedCoordsArePoint() {
    int x = recordedCoords.get( 0 );
    int y = recordedCoords.get( 1 );
    for( int i = 0; i < recordedCoords.size(); i += 2 ) {
      int curX = recordedCoords.get( i );
      int curY = recordedCoords.get( i + 1 );
      if( x != curX || y != curY ) {
        return false;
      }
    }
    return true;
  }

  private void drawPath() {
    Paint paint = getPaint();
    int alpha = paint.getAlpha();
    paint.setStyle( Style.STROKE );
    paint.setColor( getStrokeColor() );
    getCanvas().drawPath( linePath, paint );
    paint.setAlpha( alpha );
  }

  private void initInternal() {
    if( getCanvas() == null || getPaint() == null ) {
      init();
    }
  }

  private void invalidateDrawingRegion( float x, float y ) {
    float halfStrokeWidth = getPaint().getStrokeWidth() / 2f;
    int l = ( int )( Math.min( x, lastX ) - halfStrokeWidth );
    int r = ( int )( Math.max( x, lastX ) + halfStrokeWidth );
    int t = ( int )( Math.min( y, lastY ) - halfStrokeWidth );
    int b = ( int )( Math.max( y, lastY ) + halfStrokeWidth );
    invalidate( l, t, r, b );
  }

  /** To be used for testing only. */
  void setLastX( float lastX ) {
    this.lastX = lastX;
  }

  /** To be used for testing only. */
  void setLastY( float lastY ) {
    this.lastY = lastY;
  }

  /** To be used for testing only. */
  void setRecordedCoords( ArrayList<Integer> recordedCoords ) {
    this.recordedCoords = recordedCoords;
  }

  /** To be used for testing only. */
  void setLinePath( Path linePath ) {
    this.linePath = linePath;
  }

}
