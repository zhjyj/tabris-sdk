/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Display;

public class DisplaySetter<T extends Display> implements IViewSetter<T> {

  private final TabrisActivity activity;

  public DisplaySetter( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void execute( T view, SetProperties properties ) {
    setFocusControl( properties );
  }

  protected void setFocusControl( SetProperties properties ) {
    String focusControl = properties.getFocusControl();
    if( focusControl != null ) {
      IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
      View view = toolkit.findObjectById( properties.getFocusControl(), View.class );
      view.requestFocus();
    }
  }

}
