/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;
import java.util.HashMap;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.RecordingFocusTrackingListener;

public interface IWidgetToolkit {

  void process( ArrayList<Operation> operations );

  void showError( Throwable t );

  int getSurfaceWidth();

  int getSurfaceHeight();

  int getSurfaceDpiX();

  int getSurfaceDpiY();

  int getSurfaceColorDepth();

  float getDensityFactor();

  int getDensityDpi();

  float divideByDensityFactor( float value );

  int divideByDensityFactor( int value );

  int multiplyByDensityFactor( int value );

  float multiplyByDensityFactor( float value );

  void dispose();

  void executeDelayedInUiThread( Runnable runnable, long delay );

  void cancelInUiThread( Runnable runnable );

  IProgressIndicator getProgressIndicator();

  ListenerRegistry getListenerRegistry();

  HashMap<String, String> measureStrings( CallOperation probeOperation );

  Object unregisterObjectById( String id );

  void registerObjectById( String id, Object object );

  <T> T findObjectById( String id, Class<? extends T> clazz );

  BitmapDrawableCache getBitmapCache();

  int getApiLevel();

  RecordingFocusTrackingListener getFocusTrackingListener();

  SetterManager getSetterManager();

}
