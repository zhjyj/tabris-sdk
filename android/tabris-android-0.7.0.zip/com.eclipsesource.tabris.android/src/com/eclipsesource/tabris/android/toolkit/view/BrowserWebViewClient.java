/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.webkit.WebView;
import android.webkit.WebViewClient;

public class BrowserWebViewClient extends WebViewClient {

  private IBrowserProgressListener progressListener;
  private final String widgetId;

  public BrowserWebViewClient( String widgetId ) {
    this.widgetId = widgetId;
  }

  @Override
  public void onPageFinished( WebView view, String url ) {
    if( progressListener != null ) {
      progressListener.pageFinishedLoading( widgetId );
    }
  }

  public void setProgressListener( IBrowserProgressListener progressListener ) {
    this.progressListener = progressListener;
  }
}