/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.MotionEvent;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public abstract class AbstractTouchListener {

  static final String MOUSE_BUTTON_1 = "1";
  static final String MOUSE_BUTTON_3 = "3";

  protected final TabrisActivity activity;

  protected AbstractTouchListener( TabrisActivity activity ) {
    this.activity = activity;
  }

  protected void sendMouseEventRequest( MotionEvent event,
                                        String mouseEvent,
                                        String mouseButton,
                                        String widgetId )
  {
    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = createMouseEventRequest( event,
                                                   mouseEvent,
                                                   mouseButton,
                                                   widgetId,
                                                   processor );
    processor.processPostRequest( request );
  }

  private PostRequest createMouseEventRequest( MotionEvent event,
                                               String mouseEvent,
                                               String mouseButton,
                                               String widgetId,
                                               ProtocolProcessor processor )
  {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    String coordX = String.valueOf( toolkit.divideByDensityFactor( Math.round( event.getRawX() ) ) );
    String coordY = String.valueOf( toolkit.divideByDensityFactor( Math.round( event.getRawY() ) ) );
    String sessionTime = String.valueOf( processor.getSessionTime() );
    PostRequest request = new PostRequest();
    request.addParam( mouseEvent, widgetId );
    request.addParam( mouseEvent + EVENT_MOUSE_BUTTON, mouseButton );
    request.addParam( mouseEvent + EVENT_MOUSE_COORD_X, coordX );
    request.addParam( mouseEvent + EVENT_MOUSE_COORD_Y, coordY );
    request.addParam( mouseEvent + EVENT_MOUSE_TIME, sessionTime );
    request.addParam( W1_CURSOR_LOCATION_X, coordX );
    request.addParam( W1_CURSOR_LOCATION_Y, coordY );
    return request;
  }
}
