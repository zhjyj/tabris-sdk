/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class Dialog extends AlertDialog {

  private final TextView titleView;
  private final ImageView iconView;

  public Dialog( Context context ) {
    super( context, ThemeUtil.getAttrResId( context, R.attr.alertDialogTheme ) );
    LayoutInflater inflater = ( LayoutInflater )getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
    View header = inflater.inflate( R.layout.dialog_header_holo, null );
    titleView = ( TextView )header.findViewById( R.id.alertTitle );
    iconView = ( ImageView )header.findViewById( R.id.icon );
    setCustomTitle( header );
  }

  @Override
  public void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    TextView messageTextView = ( TextView )findViewById( android.R.id.message );
    if( messageTextView != null ) {
      int resId = ThemeUtil.getAttrResId( getContext(), android.R.attr.textAppearance );
      messageTextView.setTextAppearance( getContext(), resId );
    }
  }

  @Override
  public void setTitle( CharSequence title ) {
    titleView.setText( title );
  }

  @Override
  public void setTitle( int titleId ) {
    titleView.setText( titleId );
  }

  @Override
  public void setIcon( Drawable icon ) {
    iconView.setImageDrawable( icon );
  }

  @Override
  public void setIcon( int resId ) {
    iconView.setImageResource( resId );
  }
}
