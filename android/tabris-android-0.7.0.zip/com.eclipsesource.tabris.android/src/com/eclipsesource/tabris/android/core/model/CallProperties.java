/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.util.HashMap;

public class CallProperties extends HashMap<String, Object> implements IProperties {

  private static final long serialVersionUID = 5752509950577875633L;

}
