/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ListItemLongClickListener implements OnItemLongClickListener {

  private final ProtocolProcessor processor;

  public ListItemLongClickListener( ProtocolProcessor processor ) {
    if( processor == null ) {
      throw new IllegalArgumentException( "The protocol processor can not be null" );
    }
    this.processor = processor;
  }

  public boolean onItemLongClick( AdapterView<?> parent, View view, int position, long id ) {
    PostRequest request = createRequestParams( parent );
    ( ( List )parent ).getOnItemClickListener().onItemClick( parent, view, position, id );
    processor.processPostRequest( request );
    return true;
  }

  private PostRequest createRequestParams( View view ) {
    PostRequest request = new PostRequest();
    String widgetId = ( String )view.getTag();
    request.addParam( IProtocolConstants.EVENT_MENU_DETECT, widgetId );
    addTouchPosition( request, widgetId );
    return request;
  }

  private String transformByDensity( float ordinate ) {
    return String.valueOf( processor.getWidgetToolkit()
      .divideByDensityFactor( Math.round( ordinate ) ) );
  }

  private void addTouchPosition( PostRequest request, String widgetId ) {
    TouchPositionBuffer buffer = getTouchPositionBuffer( widgetId );
    request.addParam( EVENT_MENU_DETECT_X, transformByDensity( buffer.getX() ) );
    request.addParam( EVENT_MENU_DETECT_Y, transformByDensity( buffer.getY() ) );
    /*
     * do NOT clear the touchBuffer so the onItemClickListener is still able to
     * use it
     */
  }

  private TouchPositionBuffer getTouchPositionBuffer( String widgetId ) {
    return processor.getWidgetToolkit()
      .getListenerRegistry()
      .findListener( widgetId, TouchPositionBuffer.class );
  }

}
