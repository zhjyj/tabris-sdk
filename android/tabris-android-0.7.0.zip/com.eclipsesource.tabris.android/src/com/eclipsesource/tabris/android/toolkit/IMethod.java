/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import com.eclipsesource.tabris.android.core.model.CallProperties;

public interface IMethod {

  void call( CallProperties params );
}
