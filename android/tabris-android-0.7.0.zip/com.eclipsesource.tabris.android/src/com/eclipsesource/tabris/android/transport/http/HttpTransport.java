/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.transport.http;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.zip.GZIPInputStream;

import com.eclipsesource.org.apache.http.Header;
import com.eclipsesource.org.apache.http.HttpResponse;
import com.eclipsesource.org.apache.http.HttpStatus;
import com.eclipsesource.org.apache.http.HttpVersion;
import com.eclipsesource.org.apache.http.NameValuePair;
import com.eclipsesource.org.apache.http.client.HttpClient;
import com.eclipsesource.org.apache.http.client.entity.UrlEncodedFormEntity;
import com.eclipsesource.org.apache.http.client.methods.HttpGet;
import com.eclipsesource.org.apache.http.client.methods.HttpPost;
import com.eclipsesource.org.apache.http.client.methods.HttpRequestBase;
import com.eclipsesource.org.apache.http.conn.scheme.PlainSocketFactory;
import com.eclipsesource.org.apache.http.conn.scheme.Scheme;
import com.eclipsesource.org.apache.http.conn.scheme.SchemeRegistry;
import com.eclipsesource.org.apache.http.conn.ssl.SSLSocketFactory;
import com.eclipsesource.org.apache.http.impl.client.DefaultHttpClient;
import com.eclipsesource.org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import com.eclipsesource.org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import com.eclipsesource.org.apache.http.message.BasicNameValuePair;
import com.eclipsesource.org.apache.http.params.BasicHttpParams;
import com.eclipsesource.org.apache.http.params.HttpConnectionParams;
import com.eclipsesource.org.apache.http.params.HttpParams;
import com.eclipsesource.org.apache.http.params.HttpProtocolParams;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportRequest;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportException;
import com.eclipsesource.tabris.android.core.util.StringUtil;

public class HttpTransport implements ITransport {

  public static final int DEFAULT_SOCKET_TIMEOUT = 20000;
  public static final String HEADER_USER_AGENT = "User-Agent";
  public static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";
  public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
  public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
  public static final String ENCODING_GZIP = "gzip";
  public static final String ENCODING_DEFLATE = "deflate";
  public static final String SUPPORTED_ENCODING = ENCODING_GZIP + "," + ENCODING_DEFLATE;
  public static final String SESSION_ID_PREFIX = ";jsessionid=";

  private static final String HTTPS = "https";
  private static final String HTTP = "http";

  private HttpClient httpClient;
  private final URL url;
  private final String acceptedLanguage;
  private final String userAgent;
  private final ReentrantReadWriteLock shutdownLock;
  private String sessionId;
  private ExecutorService shutdownExecutor;

  public HttpTransport() {
    this( null, null );
  }

  public HttpTransport( URL url, String userAgent ) {
    this.url = url;
    this.userAgent = userAgent;
    shutdownLock = new ReentrantReadWriteLock();
    acceptedLanguage = createAcceptedLanguage();
    httpClient = createHttpClient();
    shutdownExecutor = Executors.newSingleThreadExecutor();
  }

  private String createAcceptedLanguage() {
    Locale locale = Locale.getDefault();
    String result = locale.getLanguage() + "-" + locale.getCountry();
    return result;
  }

  private HttpClient createHttpClient() {
    HttpParams params = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout( params, DEFAULT_SOCKET_TIMEOUT );
    HttpConnectionParams.setSoTimeout( params, DEFAULT_SOCKET_TIMEOUT );
    HttpProtocolParams.setVersion( params, HttpVersion.HTTP_1_1 );
    HttpProtocolParams.setContentCharset( params, StringUtil.UTF_8 );
    SchemeRegistry schemeRegistry = new SchemeRegistry();
    schemeRegistry.register( new Scheme( HTTP, 80, PlainSocketFactory.getSocketFactory() ) );
    schemeRegistry.register( new Scheme( HTTPS, 443, SSLSocketFactory.getSocketFactory() ) );
    ThreadSafeClientConnManager cm = new ThreadSafeClientConnManager( schemeRegistry );
    cm.setMaxTotal( 10 );
    DefaultHttpClient defaultHttpClient = new DefaultHttpClient( cm, params );
    defaultHttpClient.setHttpRequestRetryHandler( new DefaultHttpRequestRetryHandler( 0, false ) );
    return defaultHttpClient;
  }

  public HttpTransportResult get( GetRequest request ) {
    if( request == null ) {
      throw new IllegalArgumentException( "The transport request to execute can not be null" );
    }
    URI uri = createURI( request, null );
    HttpGet getRequest = createHttpGetRequest( request, uri );
    return executeHttpRequest( getRequest );
  }

  private HttpGet createHttpGetRequest( GetRequest request, URI uri ) {
    HttpGet getRequest = new HttpGet( uri );
    setTimout( request, getRequest );
    return getRequest;
  }

  public HttpTransportResult post( PostRequest request ) {
    if( request == null ) {
      throw new IllegalArgumentException( "The transport request to execute can not be null" );
    }
    URI uri = createURI( request, sessionId );
    HttpPost postRequest = createHttpPostRequest( request, uri );
    return executeHttpRequest( postRequest );
  }

  HttpPost createHttpPostRequest( PostRequest request, URI uri ) {
    HttpPost postRequest = new HttpPost( uri );
    setTimout( request, postRequest );
    Map<String, String> params = request.getParams();
    Set<Entry<String, String>> paramEntries = params.entrySet();
    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>( params.size() );
    for( Entry<String, String> entry : paramEntries ) {
      nameValuePairs.add( new BasicNameValuePair( entry.getKey(), entry.getValue() ) );
    }
    try {
      UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity( nameValuePairs,
                                                                            StringUtil.UTF_8 );
      postRequest.setEntity( urlEncodedFormEntity );
    } catch( UnsupportedEncodingException e ) {
      throw new TransportException( "Can not encoding the post request to UTF-8", e );
    }
    return postRequest;
  }

  private void setTimout( ITransportRequest transportRequest, HttpRequestBase httpRequest ) {
    HttpParams params = httpRequest.getParams();
    if( transportRequest.getTimeout() > -1 ) {
      HttpConnectionParams.setConnectionTimeout( params, transportRequest.getTimeout() );
      HttpConnectionParams.setSoTimeout( params, transportRequest.getTimeout() );
    }
  }

  private URI createURI( ITransportRequest request, String sessionID ) {
    if( url == null ) {
      throw new IllegalStateException( "The end-point url can not be null" );
    }
    URI result;
    try {
      StringBuilder path = new StringBuilder( url.getPath() );
      if( request.getPath() != null ) {
        path.append( request.getPath() );
      }
      if( sessionID != null ) {
        path.append( SESSION_ID_PREFIX );
        path.append( sessionID );
      }
      StringBuilder query = new StringBuilder();
      if( url.getQuery() != null ) {
        query.append( url.getQuery() );
      }
      if( request.getQuery() != null ) {
        query.append( request.getQuery() );
      }
      result = new URI( url.getProtocol(),
                        url.getUserInfo(),
                        url.getHost(),
                        url.getPort(),
                        path.toString(),
                        query.toString(),
                        url.getRef() );
    } catch( URISyntaxException e ) {
      throw new TransportException( "Could not create request uri with " + url + " for " + request,
                                    e );
    }
    return result;
  }

  private HttpTransportResult executeHttpRequest( final HttpRequestBase request ) {
    addDefaultHeaders( request );
    HttpTransportResult result = new HttpTransportResult();
    shutdownLock.readLock().lock();
    try {
      if( httpClient != null ) {
        HttpResponse response = httpClient.execute( request );
        result.setException( createExceptionFromResponseCode( response, result ) );
        if( result.hasParsableContent() ) {
          InputStream is = response.getEntity().getContent();
          Header contentEncoding = response.getFirstHeader( HEADER_CONTENT_ENCODING );
          if( contentEncoding != null
              && contentEncoding.getValue().equalsIgnoreCase( ENCODING_GZIP ) )
          {
            is = new GZIPInputStream( is );
          }
          result.setResult( is );
        }
      }
    } catch( Exception e ) {
      result.setException( new TransportException( "Could not contact " + url, e ) );
    } finally {
      shutdownLock.readLock().unlock();
    }
    return result;
  }

  private TransportException createExceptionFromResponseCode( HttpResponse response,
                                                              HttpTransportResult result )
  {
    int statusCode = response.getStatusLine().getStatusCode();
    if( HttpStatus.SC_OK != statusCode ) {
      return new TransportException( "HTTP response "
                                     + statusCode
                                     + ": "
                                     + response.getStatusLine().getReasonPhrase(), statusCode );
    }
    return null;
  }

  protected void addDefaultHeaders( HttpRequestBase request ) {
    request.setHeader( HEADER_ACCEPT_ENCODING, SUPPORTED_ENCODING );
    request.setHeader( HEADER_ACCEPT_LANGUAGE, acceptedLanguage );
    if( userAgent != null ) {
      request.setHeader( HEADER_USER_AGENT, userAgent );
    }
  }

  public URL getEndPoint() {
    return url;
  }

  public void setSessionId( String sessionId ) {
    this.sessionId = sessionId;
  }

  public void dispose() {
    shutdownLock.writeLock().tryLock();
    try {
      shutdownExecutor.submit( new HttpShutdownRunnable( httpClient, shutdownExecutor ) );
      httpClient = null;
    } finally {
      if( shutdownLock.isWriteLockedByCurrentThread() ) {
        shutdownLock.writeLock().unlock();
      }
    }
  }

  /** To be used for testing only. */
  public void setShutdownExecutor( ExecutorService executor ) {
    this.shutdownExecutor = executor;
  }

  /** To be used for testing only. */
  void setHttpClient( HttpClient httpClient ) {
    this.httpClient = httpClient;
  }

}
