/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.TreeViewAdapter;

public class TreeItemViewSetter<T extends TreeItemView> implements IViewSetter<TreeItemView> {

  private final TabrisActivity activity;

  public TreeItemViewSetter( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void execute( TreeItemView view, SetProperties properties ) {
    if( view == null ) {
      throw new IllegalArgumentException( "The view to set properties on can not be null" );
    }
    if( properties == null ) {
      throw new IllegalArgumentException( "The properties to set properties on a view can not be null" );
    }
    setTexts( view, properties );
    setColors( view, properties );
    setImages( view, properties );
    setExpanded( view, properties );
    setItemCount( view, properties );
  }

  private void setColors( TreeItemView view, SetProperties properties ) {
    List<List<Integer>> cellForegrounds = properties.getCellForegrounds();
    List<List<Integer>> cellBackgrounds = properties.getCellBackgrounds();
    setForegroundColors( view, cellForegrounds );
    setBackgroundColors( view, cellBackgrounds );
  }

  private void setForegroundColors( TreeItemView view, List<List<Integer>> cellForegrounds ) {
    if( cellForegrounds != null ) {
      if( cellForegrounds.size() > 0 ) {
        view.setForegroundCellColors( parseColors( cellForegrounds ) );
      }
    }
  }

  private void setBackgroundColors( TreeItemView view, List<List<Integer>> cellBackgrounds ) {
    if( cellBackgrounds != null ) {
      if( cellBackgrounds.size() > 0 ) {
        view.setBackgroundCellColors( parseColors( cellBackgrounds ) );
      }
    }
  }

  private List<Integer> parseColors( List<List<Integer>> cellTuples ) {
    List<Integer> colors = new ArrayList<Integer>( cellTuples.size() );
    for( List<Integer> colorTuple : cellTuples ) {
      colors.add( SetterManager.colorToupleToInt( colorTuple ) );
    }
    return colors;
  }

  private void setItemCount( TreeItemView view, SetProperties properties ) {
    Integer itemCount = properties.getItemCount();
    if( itemCount != null ) {
      view.setItemCount( itemCount );
    }
  }

  private void setExpanded( TreeItemView treeItemView, SetProperties properties ) {
    Boolean expanded = properties.getExpanded();
    if( expanded != null ) {
      TreeView treeView = treeItemView.getTreeView();
      if( expanded ) {
        expandTree( treeView, treeItemView );
      } else {
        contractTree( treeView, treeItemView );
      }
    }
  }

  private void contractTree( TreeView treeView, TreeItemView treeItemView ) {
    TreeItemView parent = treeItemView.getTreeItemParent();
    if( parent != null ) {
      TreeItemView curParent = treeView.getParentTreeItem();
      treeView.setParentTreeItem( parent );
      treeView.refreshTree();
      treeView.scrollTo( curParent );
    }
  }

  private void expandTree( TreeView treeView, TreeItemView treeItemView ) {
    treeView.setParentTreeItem( treeItemView );
    /*
     * Swapping the adapter in and out is a workaround for scrolling to 0.
     * Scrolling to 0 via adapter.setSelection(0) does not work when we call
     * adapter.notifyDataSetChanged() after setting the adapter.setSelection(0).
     * This happens when we add new tree items after we have expanded a tree
     * node.
     */
    TreeViewAdapter adapter = treeView.getAdapter();
    treeView.setAdapter( null );
    treeView.setAdapter( adapter );
  }

  @SuppressWarnings("unchecked")
  private void setImages( final TreeItemView view, SetProperties properties ) {
    List<List<String>> images = properties.getImages();
    if( images != null ) {
      new LoadImageTask( activity ) {

        @Override
        protected void onPostExecute( BitmapDrawable drawable ) {
          decreaseReferenceCount( activity.getProcessor(), view );
          view.setImage( drawable );
          view.getTreeView().refreshTree();
        }
      }.loadBitmap( images.get( 0 ) );
    }
  }

  private void setTexts( TreeItemView view, SetProperties properties ) {
    List<String> texts = properties.getTexts();
    if( texts != null ) {
      if( texts.size() > 0 ) {
        view.setTexts( texts );
        view.getTreeView().refreshTree();
      }
    }
  }

  public static void decreaseReferenceCount( ProtocolProcessor processor, final TreeItemView view )
  {
    BitmapDrawable prevBitmapDrawable = view.getImage();
    BitmapDrawableCache cache = processor.getWidgetToolkit().getBitmapCache();
    cache.decreaseReferenceCount( prevBitmapDrawable );
  }

}
