/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.LinkedHashMap;
import java.util.Set;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TabHost;

public class TabFolder extends TabHost {

  private final LinkedHashMap<TabSpec, String> tabSpecs = new LinkedHashMap<TabSpec, String>();

  public TabFolder( Context context ) {
    super( context );
  }

  public TabFolder( Context context, AttributeSet attrs ) {
    super( context, attrs );
  }

  @Override
  public void addView( final View child ) {
    Set<TabSpec> keySet = tabSpecs.keySet();
    boolean viewAdded = false;
    int i = 0;
    for( TabSpec tabSpec : keySet ) {
      String controlWidgetId = tabSpecs.get( tabSpec );
      if( controlWidgetId != null && controlWidgetId.equals( child.getTag() ) ) {
        addViewOnContentView( child, i );
        viewAdded = true;
      }
      i++;
    }
    if( !viewAdded ) {
      super.addView( child );
    }
  }

  private void addViewOnContentView( final View view, int i ) {
    FrameLayout tabContentView = getTabContentView();
    LinearLayout parent = ( LinearLayout )tabContentView.getChildAt( i );
    parent.removeAllViews();
    parent.addView( view );
  }

  public void addTab( TabSpec tabSpec, String controlWidgetId ) {
    super.addTab( tabSpec );
    tabSpecs.put( tabSpec, controlWidgetId );
  }

  public LinkedHashMap<TabSpec, String> getTabSpecs() {
    return tabSpecs;
  }

}
