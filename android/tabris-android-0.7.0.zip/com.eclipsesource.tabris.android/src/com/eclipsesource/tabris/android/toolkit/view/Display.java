/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class Display extends FrameLayout {

  private boolean sessionRunning;

  public Display( Context context ) {
    super( context );
  }

  public Display( Context context, AttributeSet attrSet ) {
    super( context, attrSet );
  }

  @Override
  public void onSizeChanged( int w, int h, int oldw, int oldh ) {
    super.onSizeChanged( w, h, oldw, oldh );
    TabrisActivity activity = ( TabrisActivity )getContext();
    ProtocolProcessor processor = activity.getProcessor();
    if( !sessionRunning ) {
      if( getAutoStartSessionFromIntent( activity ) ) {
        try {
          processor.startSession();
        } catch( Throwable t ) {
          activity.closeActivity( t );
        }
        sessionRunning = true;
      }
    } else {
      processDisplaySizeChanged( processor, w, h );
    }
  }

  private void processDisplaySizeChanged( ProtocolProcessor processor, final int w, final int h ) {
    for( int i = 0; i < getChildCount(); i++ ) {
      View view = getChildAt( i );
      if( view instanceof Shell && ( ( Shell )view ).isMaximized() ) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = w;
        params.height = h;
      }
    }

    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    PostRequest postRequest = new PostRequest();
    postRequest.addParam( IProtocolConstants.W1_BOUNDS_WIDTH,
                          String.valueOf( toolkit.divideByDensityFactor( w ) ) );
    postRequest.addParam( IProtocolConstants.W1_BOUNDS_HEIGHT,
                          String.valueOf( toolkit.divideByDensityFactor( h ) ) );
    TabrisActivity activity = ( TabrisActivity )getContext();
    activity.getProcessor().processPostRequest( postRequest );
  }

  private boolean getAutoStartSessionFromIntent( Activity activity ) {
    return activity.getIntent().getBooleanExtra( TabrisActivity.AUTO_START_SESSION, true );
  }

  public boolean isSessionRunning() {
    return sessionRunning;
  }

}
