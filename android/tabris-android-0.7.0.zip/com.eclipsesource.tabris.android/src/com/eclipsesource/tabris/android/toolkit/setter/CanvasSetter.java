/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;

public class CanvasSetter<T extends Canvas> extends ViewSetter<T> {

  public CanvasSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  protected void setCustomVariant( T view, SetProperties properties ) {
    super.setCustomVariant( view, properties );
    String customVariant = properties.getCustomVariant();
    if( customVariant == null ) {
      view.setClientDrawingEnabled( false );
    } else if( customVariant != SetProperties.NOT_MODIFIFED ) {
      if( customVariant.equals( ICustomVariants.CLIENT_CANVAS ) ) {
        view.setClientDrawingEnabled( true );
      }
    }
  }
}
