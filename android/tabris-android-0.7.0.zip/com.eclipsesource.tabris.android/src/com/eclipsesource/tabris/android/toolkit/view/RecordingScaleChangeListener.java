/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.IndexSelectionState;

public class RecordingScaleChangeListener implements OnSeekBarChangeListener {

  private final StateRecorder stateRecorder;

  public RecordingScaleChangeListener( StateRecorder stateRecorder ) {
    this.stateRecorder = stateRecorder;
  }

  public void onStopTrackingTouch( SeekBar seekBar ) {
    if( seekBar instanceof Scale ) {
      Scale scale = ( Scale )seekBar;
      String widgetId = ( String )scale.getTag();
      int curProgress = scale.getProgress() + scale.getMin();
      stateRecorder.recordState( new IndexSelectionState( widgetId, curProgress ) );
    }
  }

  public void onStartTrackingTouch( SeekBar seekBar ) {
    // nothing to do here
  }

  public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {
    // nothing to do here
  }

}
