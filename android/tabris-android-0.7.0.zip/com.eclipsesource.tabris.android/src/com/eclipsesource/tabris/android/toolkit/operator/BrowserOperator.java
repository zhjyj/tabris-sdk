/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.BrowserProgressListener;

public class BrowserOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Browser";

  private static final String STR_SCRIPT = "script";
  private static final String STR_EVALUATE = "evaluate";

  public BrowserOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Browser browser = new Browser( getActivity() );
    initiateNewView( operation, browser );
    browser.init();
  }

  @Override
  protected void attachProgressListener( ListenOperation operation ) {
    Browser browser = findObjectById( operation.getTarget(), Browser.class );
    browser.setProgressListener( new BrowserProgressListener( getActivity() ) );
  }

  @Override
  protected void removeProgressListener( ListenOperation operation ) {
    Browser browser = findObjectById( operation.getTarget(), Browser.class );
    browser.setProgressListener( null );
  }

  @Override
  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    CallProperties properties = operation.getProperties();
    if( STR_EVALUATE.equals( operation.getMethod() ) ) {
      Object scriptObj = properties.get( STR_SCRIPT );
      if( scriptObj != null && scriptObj instanceof String ) {
        Browser browser = findObjectById( operation.getTarget(), Browser.class );
        browser.executeScript( ( String )scriptObj );
      }
    }
  }
}
