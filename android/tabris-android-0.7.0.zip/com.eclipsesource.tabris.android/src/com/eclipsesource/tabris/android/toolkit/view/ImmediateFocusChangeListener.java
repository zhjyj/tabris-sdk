/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.view.View.OnFocusChangeListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;

public class ImmediateFocusChangeListener implements OnFocusChangeListener {

  private final TabrisActivity activity;

  public ImmediateFocusChangeListener( TabrisActivity activity ) {
    if( activity == null ) {
      throw new IllegalArgumentException( "The given activity can not be null" );
    }
    this.activity = activity;
  }

  public void onFocusChange( View view, boolean hasFocus ) {
    if( view == null ) {
      throw new IllegalArgumentException( "The view parameter that has been focused can not be null" );
    }
    activity.getProcessor().processPostRequest( createRequest( view, hasFocus ) );
  }

  protected PostRequest createRequest( View view, boolean hasFocus ) {
    String focusedWidget;
    if( hasFocus ) {
      focusedWidget = ( String )view.getTag();
    } else {
      focusedWidget = AndroidWidgetToolkit.DISPLAY_ID;
    }
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, focusedWidget );
    return request;
  }
}
