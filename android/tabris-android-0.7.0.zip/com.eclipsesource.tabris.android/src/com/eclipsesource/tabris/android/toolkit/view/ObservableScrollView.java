/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.TabrisActivity;

public class ObservableScrollView extends Composite {

  private final TabrisActivity activity;
  private ObservableHorizontalScrollView horizontalScroll;
  private ObservableVerticalScrollView verticalScroll;

  public ObservableScrollView( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  public void createNestedScrollViews() {
    verticalScroll = new ObservableVerticalScrollView( activity );
    verticalScroll.setTag( getTag() );
    verticalScroll.getScrollSupport().setDirection( ScrollSupportDirection.Y );
    super.addView( verticalScroll );
    horizontalScroll = new ObservableHorizontalScrollView( activity );
    horizontalScroll.setTag( getTag() );
    horizontalScroll.getScrollSupport().setDirection( ScrollSupportDirection.X );
    verticalScroll.addView( horizontalScroll );
  }

  public ObservableHorizontalScrollView getHorizontalScroll() {
    return horizontalScroll;
  }

  public ObservableVerticalScrollView getVerticalScroll() {
    return verticalScroll;
  }

  @Override
  public void addView( View child ) {
    horizontalScroll.addView( child );
  }

  @Override
  public void removeViewAt( int index ) {
    horizontalScroll.removeViewAt( index );
  }

  @Override
  public void removeView( View view ) {
    ViewGroup viewGroup = ( ViewGroup )view.getParent();
    viewGroup.removeViewAt( viewGroup.indexOfChild( view ) );
  }

}
