/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.ArrayList;
import java.util.List;

import android.graphics.LinearGradient;
import android.graphics.Shader.TileMode;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.LinearGradiant;

public class FillStyleGcOperation extends PaintColorGcOperation {

  public static final String OPERATION = "fillStyle";

  private static final String LINEAR_GRADIENT = "linearGradient";

  public FillStyleGcOperation() {
    super( OPERATION );
  }

  @Override
  public void execute( GraphicalContext gc, List<?> properties ) {
    if( properties.size() == 2 && properties.get( 1 ).equals( LINEAR_GRADIENT ) ) {
      applyShader( gc );
    } else {
      super.execute( gc, properties );
    }
  }

  private void applyShader( GraphicalContext gc ) {
    LinearGradiant lg = gc.getLinearGradient();
    ArrayList<Integer> colors = lg.getColors();
    int[] colorsArray = new int[ colors.size() ];
    for( int i = 0; i < colors.size(); i++ ) {
      colorsArray[ i ] = colors.get( i );
    }
    float[] positions = new float[]{
      0.0f, 1.0f
    };
    LinearGradient shader = new LinearGradient( lg.getX0(),
                                                lg.getX1(),
                                                lg.getY0(),
                                                lg.getY1(),
                                                colorsArray,
                                                positions,
                                                TileMode.MIRROR );
    gc.getPaint().setShader( shader );
  }

  @Override
  public void setColor( GraphicalContext gc, int color ) {
    gc.setFillColor( color );
  }

}
