/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class SelectedItemState extends AbstractState {

  private final int position;

  public SelectedItemState( String widgetId, int position ) {
    super( widgetId );
    this.position = position;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTED_ITEM_POSTFIX;
  }

  @Override
  public String generateValue() {
    return String.valueOf( position );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + position;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    SelectedItemState other = ( SelectedItemState )obj;
    if( position != other.position ) {
      return false;
    }
    return true;
  }

}
