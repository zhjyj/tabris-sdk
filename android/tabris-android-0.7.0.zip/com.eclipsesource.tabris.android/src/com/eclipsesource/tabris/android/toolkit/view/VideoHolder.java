/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.List;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;

public class VideoHolder extends FrameLayout {

  private List<Integer> bufferedBounds;
  private Drawable bufferedBackground;
  private VideoController videoController;
  private VideoOperationsExecutor videoOperationsExecutor;
  private String videoUrl;
  private boolean isFullscreen = false;
  private View originalParent;
  private SystemUiVisibilityChangeListener systemUiVisibilityChangeListener;

  class SystemUiVisibilityChangeListener implements OnSystemUiVisibilityChangeListener {

    public void onSystemUiVisibilityChange( int visibility ) {
      if( isFullscreen && visibility == 0 ) {
        getVideo().showMediaController();
      }
    }
  };

  public VideoHolder( Context context ) {
    this( context, null );
  }

  public VideoHolder( Context context, AttributeSet attrs ) {
    super( context, attrs );
  }

  @Override
  protected void onFinishInflate() {
    Video video = getVideo();
    videoController = new VideoController( video );
    video.setController( videoController );
    videoOperationsExecutor = new VideoOperationsExecutor( videoController );
    ProtocolProcessor processor = ( ( TabrisActivity )getContext() ).getProcessor();
    videoController.addVideoStateListener( new ImmediateVideoStateListener( processor, this ) );
    videoController.addVideoStateListener( videoOperationsExecutor );
  }

  public VideoOperationsExecutor getVideoOperationsExecutor() {
    return videoOperationsExecutor;
  }

  public Video getVideo() {
    return ( Video )findViewById( R.id.videoView );
  }

  public void bufferBounds( List<Integer> bounds ) {
    bufferedBounds = bounds;
  }

  public List<Integer> getBufferedBounds() {
    return bufferedBounds;
  }

  public View getOriginalParent() {
    return originalParent;
  }

  public void setOriginalParent( View parent ) {
    this.originalParent = parent;
  }

  private Point calculateOriginalParentPosition( View originalParent ) {
    View root = getRootView();
    View parent = originalParent;
    Point positionOnScreen = new Point();
    while( parent != root ) {
      MarginLayoutParams params = ( MarginLayoutParams )parent.getLayoutParams();
      positionOnScreen.x += params.leftMargin;
      positionOnScreen.y += params.topMargin;
      parent = ( View )parent.getParent();
    }

    return positionOnScreen;
  }

  public Point calculateOriginalParentPosition() {
    return calculateOriginalParentPosition( originalParent );
  }

  public void enterFullscreen() {
    isFullscreen = true;
    TabrisActivity activity = ( TabrisActivity )getContext();

    Window window = activity.getWindow();
    WindowManager.LayoutParams attrs = window.getAttributes();
    attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
    window.setAttributes( attrs );

    switchLightsOff();
    bufferedBackground = getBackground();
    setBackgroundColor( getContext().getResources().getColor( R.color.black ) );
    applyFullScreenBounds( activity );
  }

  public void switchLightsOn() {
    if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
      lightsOnApi11();
    }
  }

  @TargetApi(11)
  private void lightsOnApi11() {
    setOnSystemUiVisibilityChangeListener( null );
    setSystemUiVisibility( 0 );
  }

  public void switchLightsOff() {
    if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1 ) {
      lightsOffApi15();
    } else if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
      lightsOffApi11();
    }
    if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ) {
      setVisibiltyListener();
    }
  }

  @TargetApi(11)
  private void setVisibiltyListener() {
    if( systemUiVisibilityChangeListener == null ) {
      systemUiVisibilityChangeListener = new SystemUiVisibilityChangeListener();
    }
    setOnSystemUiVisibilityChangeListener( systemUiVisibilityChangeListener );
  }

  @TargetApi(15)
  private void lightsOffApi15() {
    setSystemUiVisibility( View.SYSTEM_UI_FLAG_HIDE_NAVIGATION );
  }

  @TargetApi(11)
  private void lightsOffApi11() {
    setSystemUiVisibility( View.SYSTEM_UI_FLAG_LOW_PROFILE );
  }

  public void applyFullScreenBounds( TabrisActivity activity ) {
    MarginLayoutParams params = ( MarginLayoutParams )getLayoutParams();
    params.leftMargin = 0;
    params.topMargin = 0;
    params.width = getRootView().getWidth();
    params.height = getRootView().getHeight();
    setLayoutParams( params );
    getVideo().getHolder().setFixedSize( params.width, params.height );
  }

  public void leaveFullscreen() {
    isFullscreen = false;
    TabrisActivity activity = ( TabrisActivity )getContext();

    Window window = activity.getWindow();
    WindowManager.LayoutParams attrs = window.getAttributes();
    attrs.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
    window.setAttributes( attrs );

    switchLightsOn();
    setBackgroundDrawable( bufferedBackground );
    restoreBoundsOfHolder();
  }

  private void restoreBoundsOfHolder() {
    Point originalParentPosition = calculateOriginalParentPosition();
    int x = originalParentPosition.x + bufferedBounds.get( 0 );
    int y = originalParentPosition.y + bufferedBounds.get( 1 );
    MarginLayoutParams params = ( MarginLayoutParams )getLayoutParams();
    params.leftMargin = x;
    params.topMargin = y;
    params.width = bufferedBounds.get( 2 );
    params.height = bufferedBounds.get( 3 );
    setLayoutParams( params );
  }

  public View getAnchorView() {
    return findViewById( R.id.videoLabel );
  }

  public String getUrl() {
    return videoUrl;
  }

  public void setUrl( String videoUrl ) {
    this.videoUrl = videoUrl;
  }

  public boolean isFullscreen() {
    return isFullscreen;
  }

  /**
   * For testing purposes only.
   * 
   * @return
   */
  Drawable getBufferedBackground() {
    return bufferedBackground;
  }

}
