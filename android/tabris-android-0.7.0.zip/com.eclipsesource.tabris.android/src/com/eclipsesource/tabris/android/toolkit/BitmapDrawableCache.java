/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache;

public class BitmapDrawableCache extends ReferenceAwareLRUCache<String, BitmapDrawable> {

  private final HashMap<String, ReentrantReadWriteLock> loadingLocks;

  public BitmapDrawableCache( int cacheSize ) {
    super( cacheSize );
    loadingLocks = new HashMap<String, ReentrantReadWriteLock>();
  }

  @Override
  public int sizeOf( String key, BitmapDrawable bitmapDrawable ) {
    Bitmap bitmap = bitmapDrawable.getBitmap();
    return bitmap.getRowBytes() * bitmap.getHeight();
  }

  @Override
  protected void entryRemoved( String key, BitmapDrawable bitmapDrawable ) {
    bitmapDrawable.getBitmap().recycle();
  }

  public BitmapDrawable getOrWait( String key ) {
    BitmapDrawable bitmapDrawable = get( key );
    if( bitmapDrawable == null ) {
      boolean writeLockCreated = false;
      synchronized( loadingLocks ) {
        ReentrantReadWriteLock loadingLock = loadingLocks.get( key );
        if( loadingLock == null ) {
          ReentrantReadWriteLock newLock = new ReentrantReadWriteLock();
          newLock.writeLock().lock();
          loadingLocks.put( key, newLock );
          writeLockCreated = true;
        } else if( !loadingLock.isWriteLocked() ) {
          loadingLock.writeLock().lock();
        }
      }
      ReentrantReadWriteLock loadingLock = loadingLocks.get( key );
      if( loadingLock != null && !writeLockCreated ) {
        loadingLock.readLock().lock();
        BitmapDrawable result = get( key );
        loadingLock.readLock().unlock();
        return result;
      }
    }
    return bitmapDrawable;
  }

  public void putAndNotify( String key, BitmapDrawable drawable ) {
    synchronized( loadingLocks ) {
      if( drawable != null ) {
        putAndReference( key, drawable );
      }
      unlockWriteLock( key );
    }
  }

  public void unlockWriteLock( String key ) {
    loadingLocks.remove( key ).writeLock().unlock();
  }

  public void decreaseReferenceCount( BitmapDrawable bitmapDrawable ) {
    Collection<CacheEntry<BitmapDrawable>> values = getMap().values();
    for( CacheEntry<BitmapDrawable> cacheEntry : values ) {
      if( cacheEntry.getValue() == bitmapDrawable ) {
        cacheEntry.decreaseReferenceCount();
        return;
      }
    }
  }

  /** To be used for testing only. */
  HashMap<String, ReentrantReadWriteLock> getLoadingLocks() {
    return loadingLocks;
  }

}
