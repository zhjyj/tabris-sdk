/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.core.model.SetProperties;

public interface IViewSetter<T extends View> {

  void execute( T view, SetProperties setProperties );

}
