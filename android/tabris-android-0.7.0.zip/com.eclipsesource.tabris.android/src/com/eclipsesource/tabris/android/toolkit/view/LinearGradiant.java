/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

public class LinearGradiant {

  private float x0;
  private float y0;
  private float x1;
  private float y1;
  private final ArrayList<Integer> colors;

  public LinearGradiant() {
    colors = new ArrayList<Integer>();
  }

  public void setCoords( float x0, float y0, float x1, float y1 ) {
    this.x0 = x0;
    this.y0 = y0;
    this.x1 = x1;
    this.y1 = y1;
  }

  public void addColor( int index, int color ) {
    colors.add( index, color );
  }

  public ArrayList<Integer> getColors() {
    return colors;
  }

  public float getX0() {
    return x0;
  }

  public float getY0() {
    return y0;
  }

  public float getX1() {
    return x1;
  }

  public float getY1() {
    return y1;
  }

}
