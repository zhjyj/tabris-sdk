/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class ButtonSetter<T extends Button> extends TextViewSetter<T> {

  public static final float LUMINOCITY_LIGHT_THEME = 0.2f;
  public static final float LUMINOCITY_DARK_THEME = 0.9f;

  private ColorUtil colorUtil;

  public ButtonSetter( TabrisActivity activity ) {
    super( activity );
    colorUtil = new ColorUtil();
  }

  @Override
  public void execute( T view, SetProperties properties ) {
    super.execute( view, properties );
    if( view == null ) {
      throw new IllegalArgumentException( "The view to set properties on can not be null" );
    }
    if( properties == null ) {
      throw new IllegalArgumentException( "The properties to set properties on a view can not be null" );
    }
  }

  @Override
  protected int getDefaultVerticalAlignment() {
    return Gravity.CENTER_VERTICAL;
  }

  @Override
  protected void setBackground( View view, SetProperties properties ) {
    List<Integer> background = properties.getBackground();
    if( background != null ) {
      Drawable bgDrawable = view.getBackground();
      if( bgDrawable == null ) {
        view.setBackgroundColor( SetterManager.colorToupleToInt( background ) );
      } else {
        float lumiFactor = LUMINOCITY_LIGHT_THEME;
        if( getCurrentButtonStyle() == R.style.Widget_Holo_Button ) {
          lumiFactor = LUMINOCITY_DARK_THEME;
        }
        float r = background.get( 0 ) / 255f + lumiFactor;
        float g = background.get( 1 ) / 255f + lumiFactor;
        float b = background.get( 2 ) / 255f + lumiFactor;
        colorUtil.applyColorFilter( bgDrawable, r, g, b );
      }
    }
  }

  protected int getCurrentButtonStyle() {
    return ThemeUtil.getAttrResId( getActivity(), android.R.attr.buttonStyle );
  }

  @Override
  public BitmapDrawable getBitmapDrawable( TextView textView ) {
    return ( BitmapDrawable )textView.getCompoundDrawables()[ 0 ];
  }

  @Override
  protected void setBitmapDrawable( TextView textView, BitmapDrawable drawable ) {
    textView.setCompoundDrawablesWithIntrinsicBounds( drawable, null, null, null );
  }

  /** To be used for testing only. */
  public void setColorUtil( ColorUtil colorUtil ) {
    this.colorUtil = colorUtil;
  }
}
