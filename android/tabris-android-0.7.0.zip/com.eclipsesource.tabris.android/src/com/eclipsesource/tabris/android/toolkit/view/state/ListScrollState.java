/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class ListScrollState extends AbstractState {

  private final int firstVisibleItem;

  public ListScrollState( String widgetId, int firstVisibleItem ) {
    super( widgetId );
    this.firstVisibleItem = firstVisibleItem;
  }

  @Override
  public String generateValue() {
    return Integer.toString( firstVisibleItem );
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.TOP_INDEX_POSTFIX;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + firstVisibleItem;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    ListScrollState other = ( ListScrollState )obj;
    if( firstVisibleItem != other.firstVisibleItem ) {
      return false;
    }
    return true;
  }
}