/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.HorizontalScrollView;

import com.eclipsesource.tabris.android.TabrisActivity;

public class ObservableHorizontalScrollView extends HorizontalScrollView {

  private final ScrollSupport scrollSupport;

  public ObservableHorizontalScrollView( TabrisActivity activity ) {
    super( activity );
    scrollSupport = new ScrollSupport( activity, this );
  }

  @Override
  protected void onScrollChanged( int x, int y, int oldx, int oldy ) {
    super.onScrollChanged( x, y, oldx, oldy );
    scrollSupport.onScrollChanged( x, y, oldx, oldy );
  }

  public void doSmoothScrollTo( int x, int y ) {
    scrollSupport.setScrollTargetX( x );
    scrollSupport.setScrollTargetY( y );
    smoothScrollTo( x, y );
  }

  public ScrollSupport getScrollSupport() {
    return scrollSupport;
  }
}