/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

import com.eclipsesource.tabris.android.R;

public class ProgressIndicator implements IProgressIndicator {

  private static final long OPEN_DELAY = 2000;
  private static final long CLOSE_DELAY = 1500;

  private final AndroidWidgetToolkit toolkit;

  private ProgressDialog progressDialog;
  private ErrorDialog progressInterruptedDialog;
  private WallClock timer = new WallClock();
  private long openTime;
  private long submitTime;
  protected Runnable openDialogRunnable;
  protected Runnable closeDialogRunnable;

  private final OnCancelListener progressDialogCancelListener = new DialogInterface.OnCancelListener()
  {

    public void onCancel( DialogInterface dialog ) {
      toolkit.executeInUiThread( progressInterruptedDialog );
    }
  };

  static class OpenDialogRunnable implements Runnable {

    private final ProgressIndicator indicator;

    public OpenDialogRunnable( ProgressIndicator indicator ) {
      this.indicator = indicator;
    }

    public void run() {
      if( !indicator.isAnyDialogShowing() ) {
        indicator.openProgressDialog();
      }
    }

  }
  static class CloseDialogRunnable implements Runnable {

    private final ProgressIndicator indicator;

    public CloseDialogRunnable( ProgressIndicator indicator ) {
      this.indicator = indicator;
    }

    public void run() {
      indicator.closeProgressDialog();
    }

  };
  public static class WallClock {

    long getCurrentTime() {
      return System.currentTimeMillis();
    }
  }

  protected ProgressIndicator( Activity activity, AndroidWidgetToolkit toolkit ) {
    this.toolkit = toolkit;
    createDialogs( activity, toolkit );
    openDialogRunnable = new OpenDialogRunnable( this );
    closeDialogRunnable = new CloseDialogRunnable( this );
  }

  private void createDialogs( Activity activity, AndroidWidgetToolkit toolkit ) {
    progressDialog = new ProgressDialog( activity );
    progressDialog.setOnCancelListener( progressDialogCancelListener );
    progressDialog.setIndeterminate( true );
    progressDialog.setMessage( activity.getString( R.string.dialog_progress_message ) );
    progressInterruptedDialog = new ProgressInterruptedDialog( activity, toolkit );
  }

  public void start() {
    submitTime = timer.getCurrentTime();
    toolkit.executeDelayedInUiThread( openDialogRunnable, OPEN_DELAY );
  }

  synchronized void setOpenTime( long currentTime ) {
    openTime = currentTime;
  }

  public synchronized void stop() {
    toolkit.cancelInUiThread( openDialogRunnable );
    long showingTime = timer.getCurrentTime() - openTime;
    if( openTime != 0 && showingTime < CLOSE_DELAY ) {
      toolkit.executeDelayedInUiThread( closeDialogRunnable, CLOSE_DELAY );
    } else {
      toolkit.cancelInUiThread( closeDialogRunnable );
      closeProgressDialog(); // dismiss progress immediately
    }
  }

  void openProgressDialog() {
    progressDialog.show();
    setOpenTime( timer.getCurrentTime() );
  }

  void closeProgressDialog() {
    progressDialog.dismiss();
    openTime = 0;
  }

  boolean isAnyDialogShowing() {
    return progressDialog.isShowing() || progressInterruptedDialog.isShowing();
  }

  /** For testing purposes only. */
  ProgressDialog getProgressDialog() {
    return progressDialog;
  }

  /** For testing purposes only. */
  void setProgressDialog( ProgressDialog progressDialog ) {
    this.progressDialog = progressDialog;
  }

  /** For testing purposes only. */
  void setProgressInterruptedDialog( ErrorDialog progressInterruptedDialog ) {
    this.progressInterruptedDialog = progressInterruptedDialog;
  }

  /** For testing purposes only. */
  void setTimer( WallClock timer ) {
    this.timer = timer;
  }

  /** For testing purposes only. */
  void setCloseDialogRunnable( Runnable closeDialogRunnable ) {
    this.closeDialogRunnable = closeDialogRunnable;
  }

  /** For testing purposes only. */
  void setOpenDialogRunnable( Runnable openDialogRunnable ) {
    this.openDialogRunnable = openDialogRunnable;
  }
}
