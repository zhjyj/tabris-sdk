/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;

public class CompoundButtonSetter<T extends CompoundButton> extends ButtonSetter<T> {

  public CompoundButtonSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T view, SetProperties properties ) {
    super.execute( view, properties );
    if( view == null ) {
      throw new IllegalArgumentException( "The view to set properties on can not be null" );
    }
    if( properties == null ) {
      throw new IllegalArgumentException( "The properties to set properties on a view can not be null" );
    }
    setChecked( view, properties );
  }

  private void setChecked( CompoundButton view, SetProperties properties ) {
    GenericObject selectionProperty = properties.getSelection();
    if( selectionProperty != null ) {
      Boolean selection = selectionProperty.getObjectAs( Boolean.class );
      view.setChecked( selection );
    }
  }

}
