/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.parser;

import java.util.ArrayList;

import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.model.Operation;

public interface IProtocolParserCallback {

  void operationsFound( ArrayList<Operation> ops );

  void metaFound( Meta meta );

}
