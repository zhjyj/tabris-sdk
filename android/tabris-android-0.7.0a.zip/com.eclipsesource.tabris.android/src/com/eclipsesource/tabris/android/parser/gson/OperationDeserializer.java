/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

public class OperationDeserializer implements JsonDeserializer<Operation> {

  public Operation deserialize( JsonElement json, Type typeOfT, JsonDeserializationContext context )
    throws JsonParseException
  {
    Operation operation = null;
    if( json instanceof JsonArray ) {
      JsonArray opArray = ( JsonArray )json;
      String action = opArray.get( 0 ).getAsString();
      operation = createOperationFromJsonArray( action, opArray, context );
    }
    return operation;
  }

  private Operation createOperationFromJsonArray( String action,
                                                  JsonArray opArray,
                                                  JsonDeserializationContext context )
  {
    Operation result = null;
    if( CreateOperation.ACTION.equals( action ) ) {
      result = createCreateOperation( opArray, context );
    } else if( SetOperation.ACTION.equals( action ) ) {
      result = createSetOperation( opArray, context );
    } else if( ListenOperation.ACTION.equals( action ) ) {
      result = createListenOperation( opArray, context );
    } else if( CallOperation.ACTION.equals( action ) ) {
      result = createCallOperation( opArray, context );
    } else if( DestroyOperation.ACTION.equals( action ) ) {
      result = new DestroyOperation();
    } else {
      throw new JsonParseException( "Unknown type of operation " + opArray );
    }
    result.setTarget( getTarget( opArray ) );
    return result;
  }

  private Operation createCallOperation( JsonArray opArray, JsonDeserializationContext context ) {
    CallOperation co = new CallOperation();
    co.setMethod( opArray.get( 2 ).getAsString() );
    if( opArray.size() >= 4 ) {
      co.setProperties( ( CallProperties )context.deserialize( opArray.get( 3 ),
                                                               CallProperties.class ) );
    }
    return co;
  }

  private Operation createListenOperation( JsonArray opArray, JsonDeserializationContext context ) {
    ListenOperation lo = new ListenOperation();
    if( opArray.size() >= 3 ) {
      lo.setProperties( ( ListenProperties )context.deserialize( opArray.get( 2 ),
                                                                 ListenProperties.class ) );
    }
    return lo;
  }

  private Operation createSetOperation( JsonArray opArray, JsonDeserializationContext context ) {
    SetOperation so = new SetOperation();
    so.setProperties( ( SetProperties )context.deserialize( opArray.get( 2 ), SetProperties.class ) );
    return so;
  }

  private Operation createCreateOperation( JsonArray opArray, JsonDeserializationContext context ) {
    CreateOperation co = new CreateOperation();
    co.setType( opArray.get( 2 ).getAsString() );
    if( opArray.size() >= 4 ) {
      co.setProperties( ( CreateProperties )context.deserialize( opArray.get( 3 ),
                                                                 CreateProperties.class ) );
    }
    return co;
  }

  private String getTarget( JsonArray opArray ) {
    String target = opArray.get( 1 ).getAsString();
    if( target == null ) {
      throw new JsonParseException( "Target of operation must not be null " + opArray );
    }
    return target;
  }
}
