/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;


public class StateRecorder {

  private Set<IState> recording;

  StateRecorder() {
    clearRecordedState();
  }

  public void recordState( IState state ) {
    recording.remove( state );
    recording.add( state );
  }

  Collection<IState> getRecording() {
    return recording;
  }

  void clearRecordedState() {
    recording = new HashSet<IState>();
  }

  public boolean contains( IState state ) {
    return recording.contains( state );
  }
}
