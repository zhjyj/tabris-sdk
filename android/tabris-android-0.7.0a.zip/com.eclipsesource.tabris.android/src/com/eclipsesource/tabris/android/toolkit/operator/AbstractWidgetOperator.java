/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateFocusChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.LongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;

public abstract class AbstractWidgetOperator implements IOperator {

  private final TabrisActivity activity;

  public AbstractWidgetOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  private SetterManager getSetterManager() {
    return getWidgetToolkit().getSetterManager();
  }

  public TabrisActivity getActivity() {
    return activity;
  }

  protected ProtocolProcessor getProcessor() {
    return activity.getProcessor();
  }

  protected IWidgetToolkit getWidgetToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }

  protected ListenerRegistry getListenerRegistry() {
    return activity.getProcessor().getWidgetToolkit().getListenerRegistry();
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    View view = findViewByTarget( operation );
    getSetterManager().execute( view, operation.getProperties() );
  }

  protected void initiateNewView( CreateOperation operation, View view ) {
    setInitialLayoutParams( view );
    view.setTag( operation.getTarget() );
    getParentView( operation ).addView( view );
    IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
    toolkit.registerObjectById( operation.getTarget(), view );
    registerDefaultListeners( operation, view, toolkit );
    applyProperties( operation, view );
  }

  private void registerDefaultListeners( CreateOperation operation,
                                         View view,
                                         IWidgetToolkit toolkit )
  {
    CompositeTouchListener listener = new CompositeTouchListener();
    toolkit.getListenerRegistry().registerListener( operation.getTarget(), listener );
    listener.addListener( toolkit.getFocusTrackingListener() );
    view.setOnTouchListener( listener );
  }

  protected void applyProperties( CreateOperation operation, View view ) {
    if( operation.getProperties() != null ) {
      getSetterManager().execute( view, operation.getProperties() );
    }
  }

  private ViewGroup getParentView( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( activity, operation );
    CreateProperties props = operation.getProperties();
    return findObjectById( props.getParent(), ViewGroup.class );
  }

  protected <T> T findObjectById( String id, Class<? extends T> clazz ) {
    return getProcessor().getWidgetToolkit().findObjectById( id, clazz );
  }

  protected void setInitialLayoutParams( View view ) {
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams( 0, 0 );
    layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
    view.setLayoutParams( layoutParams );
  }

  public void listen( ListenOperation operation ) {
    ValidationUtil.validateListenOperation( operation );
    ListenProperties properties = operation.getProperties();
    if( properties.getSelection() != null ) {
      if( properties.getSelection() ) {
        attachSelectionListener( operation );
      } else {
        removeSelectionListener( operation );
      }
    }
    if( properties.getMouse() != null ) {
      if( properties.getMouse() ) {
        attachMouseListener( operation );
      } else {
        removeMouseListener( operation );
      }
    }
    if( properties.getFocus() != null ) {
      if( properties.getFocus() ) {
        attachFocusListener( operation );
      } else {
        removeFocusListener( operation );
      }
    }
    if( properties.getModify() != null ) {
      if( properties.getModify() ) {
        attachModifyListener( operation );
      } else {
        removeModifyListener( operation );
      }
    }
    if( properties.getProgress() != null ) {
      if( properties.getProgress() ) {
        attachProgressListener( operation );
      } else {
        removeProgressListener( operation );
      }
    }
    if( properties.isMenuDetect() != null ) {
      if( properties.isMenuDetect() ) {
        attachMenuDetectListener( operation );
      } else {
        removeMenuDetectListener( operation );
      }
    }
  }

  protected View findViewByTarget( Operation operation ) {
    return findObjectById( operation.getTarget(), View.class );
  }

  protected void attachFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( new ImmediateFocusChangeListener( activity ) );
  }

  protected void removeFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( null );
  }

  protected void attachMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, true, false );
    } else {
      if( !previousTouchListener.isTransmittingUpDown() ) {
        previousTouchListener.setTransmittingUpDown( true );
      }
    }
  }

  public void attachInitialTouchListener( final View view,
                                          boolean transmitUpDownEvents,
                                          boolean transmitMenuDetectEvents )
  {
    String widgetId = ( String )view.getTag();
    MouseEventTouchListener mouseEventTouchListener;
    mouseEventTouchListener = new MouseEventTouchListener( activity, transmitUpDownEvents );
    LongClickListener longClickListener = new LongClickListener( activity,
                                                                 mouseEventTouchListener,
                                                                 mouseEventTouchListener,
                                                                 transmitMenuDetectEvents );
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    compListener.removeListeners( ConsumingTouchListener.class );
    compListener.addListener( mouseEventTouchListener );
    view.setOnLongClickListener( longClickListener );
    getListenerRegistry().registerListener( widgetId, longClickListener );
  }

  protected void attachMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, false, true );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( true );
    }
  }

  private MouseEventTouchListener getPreviousTouchListener( String widgetId ) {
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    return ( MouseEventTouchListener )compListener.findListener( MouseEventTouchListener.class );
  }

  private LongClickListener getPreviousLongClickListener( String widgetId ) {
    return getListenerRegistry().findListener( widgetId, LongClickListener.class );
  }

  protected void removeMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    LongClickListener previousLongClickListener = getPreviousLongClickListener( widgetId );
    if( previousLongClickListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousLongClickListener.isTransmittingMenuDetect() ) {
      removeTouchListenersFinally( view );
      applyConsumingTouchListener( view );
    } else {
      getPreviousTouchListener( widgetId ).setTransmittingUpDown( false );
    }
  }

  protected void applyConsumingTouchListener( View view ) {
    // to be implemented by subclasses
  }

  private void throwNoTouchListenerException( final String widgetId ) {
    throw new NullPointerException( "Widget with id="
                                    + widgetId
                                    + " does not have a touch listener attached." );
  }

  public void removeTouchListenersFinally( final View view ) {
    String widgetId = ( String )view.getTag();
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    compListener.removeListeners( MouseEventTouchListener.class );
    view.setOnLongClickListener( null );
    getListenerRegistry().unregisterListener( widgetId, LongClickListener.class );
  }

  protected void attachSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( new ViewClickListener( activity ) );
  }

  protected void removeSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( null );
  }

  protected void removeMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousTouchListener.isTransmittingUpDown() ) {
      removeTouchListenersFinally( view );
      applyConsumingTouchListener( view );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( false );
    }
  }

  protected void attachModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void attachProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null ) {
      throw new IllegalArgumentException( "Could not find widget "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    ViewSetter.dereferenceBackground( getProcessor(), view );
    // It would be possible to directly call viewGroup.removeView(view) but to
    // support robolectric we use the index based approach. Could be minimized
    // with custom shadow object.
    ViewGroup viewGroup = ( ViewGroup )view.getParent();
    viewGroup.removeViewAt( viewGroup.indexOfChild( view ) );
    getProcessor().getWidgetToolkit().unregisterObjectById( operation.getTarget() );
  }

  public void call( CallOperation operation ) {
    // to be implemented by subclasses
  }

}
