/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.media.MediaPlayer;

public class VideoController {

  private static final List<VideoState> IN_PROGRESS_STATES = Arrays.asList( new VideoState[]{
    VideoState.STOPPING, VideoState.SEEKING, VideoState.PREPARING
  } );

  private final Video video;
  private final List<IVideoStateListener> listeners;
  private VideoState videoState;
  private VideoState previousVideoState;

  public enum VideoState {
    NEW,
    PLAY,
    PAUSE,
    STOP,
    INTERRUPT,
    FAST_FORWARD,
    FAST_BACKWARD,
    READY,
    DONE,
    ERROR,
    SET_URL,
    STOPPING,
    SEEKING,
    PREPARING
  }

  public VideoController( Video video ) {
    this.video = video;
    videoState = VideoState.NEW;
    previousVideoState = VideoState.NEW;
    listeners = new ArrayList<IVideoStateListener>();
  }

  public void addVideoStateListener( IVideoStateListener listener ) {
    listeners.add( listener );
  }

  public void play() {
    videoState = VideoState.PLAY;
    video.doPlay();
    fireVideoStateChanged();
  }

  public void stop() {
    previousVideoState = VideoState.PAUSE;
    videoState = VideoState.STOPPING;
    video.doStop();
  }

  public void pause() {
    videoState = VideoState.PAUSE;
    video.doPause();
    fireVideoStateChanged();
  }

  public void skipForward() {
    previousVideoState = videoState;
    videoState = VideoState.SEEKING;
    video.doSkipForward();
  }

  public void skipBackward() {
    previousVideoState = videoState;
    videoState = VideoState.SEEKING;
    video.doSkipBackward();
  }

  public void setUrl() {
    videoState = VideoState.PREPARING;
    video.setUrl();
  }

  /**
   * Called from Video directly when MediaController was used.
   */
  void setSeeking() {
    if( VideoState.SEEKING != videoState ) {
      // maybe we should consider other in-progress states, too
      previousVideoState = videoState;
    }
    videoState = VideoState.SEEKING;
  }

  void seekCompleted() {
    switch( videoState ) {
      case STOPPING:
        videoState = VideoState.STOP;
      break;
      case SEEKING:
        videoState = previousVideoState;
      break;
      default:
        return;
    }
    fireVideoStateChanged();
  }

  void prepareCompleted() {
    videoState = VideoState.READY;
    fireVideoStateChanged();
  }

  public boolean isInProgress() {
    return IN_PROGRESS_STATES.contains( videoState );
  }

  void done() {
    videoState = VideoState.DONE;
    fireVideoStateChanged();
    if( video.isLooping() ) {
      videoState = VideoState.PLAY;
      fireVideoStateChanged();
    } else {
      videoState = VideoState.PAUSE;
      fireVideoStateChanged();
    }
  }

  boolean error( int what, int extra ) {
    videoState = VideoState.ERROR;
    fireVideoStateChanged();
    return true;
  }

  boolean info( int what, int extra ) {
    if( MediaPlayer.MEDIA_INFO_BUFFERING_END == what ) {
      videoState = VideoState.PLAY;
      fireVideoStateChanged();
    } else {
      videoState = VideoState.INTERRUPT;
      fireVideoStateChanged();
    }
    return true;
  }

  private void fireVideoStateChanged() {
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).videoStateChanged( videoState );
    }
  }

  private String resolveInfoCode( int what ) {
    String message;
    switch( what ) {
      case MediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING:
        message = "Video is lagging.";
      break;
      case MediaPlayer.MEDIA_INFO_BUFFERING_START:
        message = "Buffering video.";
      break;
      case MediaPlayer.MEDIA_INFO_BUFFERING_END:
        message = "Buffer filled. Resuming.";
      break;
      default:
        message = "MediaPlayer info: " + Integer.toString( what );
      break;
    }
    return message;
  }

  private String resolveErrorCode( int what ) {
    String message;
    switch( what ) {
      case MediaPlayer.MEDIA_ERROR_UNKNOWN:
        message = "An unknown error occured in MediaPlayer.";
      break;
      case MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK:
        message = "The video is not valid for progressive playback.";
      break;
      case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
        message = "The video server died.";
      break;
      default:
        message = "Error " + Integer.toString( what ) + " occured in MediaPlayer.";
      break;
    }
    return message;
  }

  /**
   * For testing purposes only.
   */
  protected VideoState getVideoState() {
    return videoState;
  }

  /**
   * For testing purposes only.
   */
  protected VideoState getPreviousVideoState() {
    return previousVideoState;
  }
}
