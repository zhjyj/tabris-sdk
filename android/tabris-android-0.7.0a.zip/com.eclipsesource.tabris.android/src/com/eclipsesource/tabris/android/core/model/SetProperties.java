/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.util.List;

/**
 * When adding a field to the {@link SetProperties} class make sure to
 * update/generate the {@link #hashCode()}, {@link #equals(Object)} and
 * {@link #toString()} methods.
 */
/**
 * @author Moritz Post
 */
public class SetProperties implements IProperties {

  public static final String NOT_MODIFIFED = new String();

  private String text;
  private List<String> texts;
  private Boolean active;
  private String mode = NOT_MODIFIFED;
  private List<Integer> minimumSize;
  private String activeControl;
  private List<Integer> bounds;
  private Integer tabIndex;
  private List<Integer> foreground;
  private List<Integer> background;
  private List<List<Integer>> cellForegrounds;
  private List<List<Integer>> cellBackgrounds;
  private String parent;
  private String content;
  private List<String> backgroundImage;
  private List<String> image;
  private List<List<String>> images;
  private GenericObject selection;
  private Boolean enabled;
  private Boolean editable;
  private Boolean visibility;
  private Font font;
  private List<Integer> origin;
  private List<String> items;
  private Integer selectionIndex;
  private Integer topIndex;
  private List<Integer> selectionIndices;
  private List<String> children;
  private List<String> monthNames;
  private List<String> weekdayNames;
  private List<String> weekdayShortNames;
  private Integer date;
  private String dateSeparator;
  private String datePattern;
  private Integer year;
  private Integer month;
  private Integer day;
  private Integer hours;
  private Integer minutes;
  private Integer seconds;
  private Boolean expanded;
  private String toolTip;
  private Integer itemCount;
  private String message;
  private String customVariant = NOT_MODIFIFED;
  private String alignment;
  private String url;
  private Boolean enableHighAccuracy;
  private Integer maximumAge;
  private Integer frequency;
  private String needsPosition;
  private Integer textLimit;
  private Integer minimum;
  private Integer maximum;
  private String state;
  private String focusControl;
  private String videoURL;
  private Boolean repeat;
  private Boolean controls_visible;
  private String presentation_mode;
  private Boolean autoplay;
  private Float speed;
  private String playback_mode;

  public String getVideoURL() {
    return videoURL;
  }

  public void setVideoURL( String videoURL ) {
    this.videoURL = videoURL;
  }

  public Boolean getRepeat() {
    return repeat;
  }

  public void setRepeat( Boolean repeat ) {
    this.repeat = repeat;
  }

  public Boolean getControls_visible() {
    return controls_visible;
  }

  public void setControls_visible( Boolean controls_visible ) {
    this.controls_visible = controls_visible;
  }

  public String getPresentation_mode() {
    return presentation_mode;
  }

  public void setPresentation_mode( String presentation_mode ) {
    this.presentation_mode = presentation_mode;
  }

  public Boolean getAutoplay() {
    return autoplay;
  }

  public void setAutoplay( Boolean autoplay ) {
    this.autoplay = autoplay;
  }

  public Float getSpeed() {
    return speed;
  }

  public void setSpeed( Float speed ) {
    this.speed = speed;
  }

  public String getPlayback_mode() {
    return playback_mode;
  }

  public void setPlayback_mode( String playback_mode ) {
    this.playback_mode = playback_mode;
  }

  public String getText() {
    return text;
  }

  public void setText( String text ) {
    this.text = text;
  }

  public List<String> getTexts() {
    return texts;
  }

  public void setTexts( List<String> texts ) {
    this.texts = texts;
  }

  public String getMode() {
    return mode;
  }

  public void setMode( String mode ) {
    this.mode = mode;
  }

  public List<Integer> getMinimumSize() {
    return minimumSize;
  }

  public void setMinimumSize( List<Integer> minimumSize ) {
    this.minimumSize = minimumSize;
  }

  public String getActiveControl() {
    return activeControl;
  }

  public void setActiveControl( String activeControl ) {
    this.activeControl = activeControl;
  }

  public List<Integer> getBounds() {
    return bounds;
  }

  public void setBounds( List<Integer> bounds ) {
    this.bounds = bounds;
  }

  public Integer getTabIndex() {
    return tabIndex;
  }

  public void setTabIndex( Integer tabIndex ) {
    this.tabIndex = tabIndex;
  }

  public List<Integer> getBackground() {
    return background;
  }

  public void setBackground( List<Integer> background ) {
    this.background = background;
  }

  public String getParent() {
    return parent;
  }

  public void setParent( String parent ) {
    this.parent = parent;
  }

  public List<Integer> getForeground() {
    return foreground;
  }

  public List<List<Integer>> getCellForegrounds() {
    return cellForegrounds;
  }

  public void setCellForegrounds( List<List<Integer>> cellForegrounds ) {
    this.cellForegrounds = cellForegrounds;
  }

  public void setForeground( List<Integer> foreground ) {
    this.foreground = foreground;
  }

  public List<List<Integer>> getCellBackgrounds() {
    return cellBackgrounds;
  }

  public void setCellBackgrounds( List<List<Integer>> cellBackgrounds ) {
    this.cellBackgrounds = cellBackgrounds;
  }

  public String getContent() {
    return content;
  }

  public void setContent( String content ) {
    this.content = content;
  }

  public List<String> getBackgroundImage() {
    return backgroundImage;
  }

  public void setBackgroundImage( List<String> backgroundImage ) {
    this.backgroundImage = backgroundImage;
  }

  public List<String> getImage() {
    return image;
  }

  public void setImage( List<String> image ) {
    this.image = image;
  }

  public List<List<String>> getImages() {
    return images;
  }

  public void setImages( List<List<String>> images ) {
    this.images = images;
  }

  public Boolean getActive() {
    return active;
  }

  public void setActive( Boolean active ) {
    this.active = active;
  }

  public GenericObject getSelection() {
    return selection;
  }

  public void setSelection( GenericObject selection ) {
    this.selection = selection;
  }

  public Boolean getEnabled() {
    return enabled;
  }

  public void setEnabled( Boolean enabled ) {
    this.enabled = enabled;
  }

  public Boolean getEditable() {
    return editable;
  }

  public void setEditable( Boolean editable ) {
    this.editable = editable;
  }

  public Boolean getVisibility() {
    return visibility;
  }

  public void setVisibility( Boolean visibility ) {
    this.visibility = visibility;
  }

  public Font getFont() {
    return font;
  }

  public void setFont( Font font ) {
    this.font = font;
  }

  public List<Integer> getOrigin() {
    return origin;
  }

  public void setOrigin( List<Integer> origin ) {
    this.origin = origin;
  }

  public List<String> getItems() {
    return items;
  }

  public void setItems( List<String> items ) {
    this.items = items;
  }

  public Integer getSelectionIndex() {
    return selectionIndex;
  }

  public void setSelectionIndex( Integer selectionIndex ) {
    this.selectionIndex = selectionIndex;
  }

  public Integer getTopIndex() {
    return topIndex;
  }

  public void setTopIndex( Integer topIndex ) {
    this.topIndex = topIndex;
  }

  public List<Integer> getSelectionIndices() {
    return selectionIndices;
  }

  public void setSelectionIndices( List<Integer> selectionIndices ) {
    this.selectionIndices = selectionIndices;
  }

  public List<String> getChildren() {
    return children;
  }

  public void setChildren( List<String> children ) {
    this.children = children;
  }

  public List<String> getMonthNames() {
    return monthNames;
  }

  public void setMonthNames( List<String> monthNames ) {
    this.monthNames = monthNames;
  }

  public List<String> getWeekdayNames() {
    return weekdayNames;
  }

  public void setWeekdayNames( List<String> weekdayNames ) {
    this.weekdayNames = weekdayNames;
  }

  public List<String> getWeekdayShortNames() {
    return weekdayShortNames;
  }

  public void setWeekdayShortNames( List<String> weekdayShortNames ) {
    this.weekdayShortNames = weekdayShortNames;
  }

  public String getDateSeparator() {
    return dateSeparator;
  }

  public void setDateSeparator( String dateSeparator ) {
    this.dateSeparator = dateSeparator;
  }

  public String getDatePattern() {
    return datePattern;
  }

  public void setDatePattern( String datePattern ) {
    this.datePattern = datePattern;
  }

  public Integer getYear() {
    return year;
  }

  public void setYear( Integer year ) {
    this.year = year;
  }

  public Integer getMonth() {
    return month;
  }

  public void setMonth( Integer month ) {
    this.month = month;
  }

  public Integer getDate() {
    return date;
  }

  public void setDate( Integer date ) {
    this.date = date;
  }

  public Integer getDay() {
    return day;
  }

  public void setDay( Integer day ) {
    this.day = day;
  }

  public Integer getHours() {
    return hours;
  }

  public void setHours( Integer hours ) {
    this.hours = hours;
  }

  public Integer getMinutes() {
    return minutes;
  }

  public void setMinutes( Integer minutes ) {
    this.minutes = minutes;
  }

  public Integer getSeconds() {
    return seconds;
  }

  public void setSeconds( Integer seconds ) {
    this.seconds = seconds;
  }

  public Boolean getExpanded() {
    return expanded;
  }

  public void setExpanded( Boolean expanded ) {
    this.expanded = expanded;
  }

  public String getToolTip() {
    return toolTip;
  }

  public void setToolTip( String toolTip ) {
    this.toolTip = toolTip;
  }

  public Integer getItemCount() {
    return itemCount;
  }

  public void setItemCount( Integer itemCount ) {
    this.itemCount = itemCount;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage( String message ) {
    this.message = message;
  }

  public String getCustomVariant() {
    return customVariant;
  }

  public void setCustomVariant( String customVariant ) {
    this.customVariant = customVariant;
  }

  public String getAlignment() {
    return alignment;
  }

  public void setAlignment( String alignment ) {
    this.alignment = alignment;
  }

  public Boolean getEnableHighAccuracy() {
    return enableHighAccuracy;
  }

  public void setEnableHighAccuracy( Boolean enableHighAccuracy ) {
    this.enableHighAccuracy = enableHighAccuracy;
  }

  public Integer getMaximumAge() {
    return maximumAge;
  }

  public void setMaximumAge( Integer maximumAge ) {
    this.maximumAge = maximumAge;
  }

  public Integer getFrequency() {
    return frequency;
  }

  public void setFrequency( Integer frequency ) {
    this.frequency = frequency;
  }

  public String getNeedsPosition() {
    return needsPosition;
  }

  public void setNeedsPosition( String needsPosition ) {
    this.needsPosition = needsPosition;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl( String url ) {
    this.url = url;
  }

  public Integer getTextLimit() {
    return textLimit;
  }

  public void setTextLimit( Integer textLimit ) {
    this.textLimit = textLimit;
  }

  public Integer getMinimum() {
    return minimum;
  }

  public void setMinimum( Integer minimum ) {
    this.minimum = minimum;
  }

  public Integer getMaximum() {
    return maximum;
  }

  public void setMaximum( Integer maximum ) {
    this.maximum = maximum;
  }

  public String getState() {
    return state;
  }

  public void setState( String state ) {
    this.state = state;
  }

  public String getFocusControl() {
    return focusControl;
  }

  public void setFocusControl( String focusControl ) {
    this.focusControl = focusControl;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( active == null )
                                                  ? 0
                                                  : active.hashCode() );
    result = prime * result + ( ( activeControl == null )
                                                         ? 0
                                                         : activeControl.hashCode() );
    result = prime * result + ( ( alignment == null )
                                                     ? 0
                                                     : alignment.hashCode() );
    result = prime * result + ( ( autoplay == null )
                                                    ? 0
                                                    : autoplay.hashCode() );
    result = prime * result + ( ( background == null )
                                                      ? 0
                                                      : background.hashCode() );
    result = prime * result + ( ( backgroundImage == null )
                                                           ? 0
                                                           : backgroundImage.hashCode() );
    result = prime * result + ( ( bounds == null )
                                                  ? 0
                                                  : bounds.hashCode() );
    result = prime * result + ( ( cellBackgrounds == null )
                                                           ? 0
                                                           : cellBackgrounds.hashCode() );
    result = prime * result + ( ( cellForegrounds == null )
                                                           ? 0
                                                           : cellForegrounds.hashCode() );
    result = prime * result + ( ( children == null )
                                                    ? 0
                                                    : children.hashCode() );
    result = prime * result + ( ( content == null )
                                                   ? 0
                                                   : content.hashCode() );
    result = prime * result + ( ( controls_visible == null )
                                                            ? 0
                                                            : controls_visible.hashCode() );
    result = prime * result + ( ( customVariant == null )
                                                         ? 0
                                                         : customVariant.hashCode() );
    result = prime * result + ( ( date == null )
                                                ? 0
                                                : date.hashCode() );
    result = prime * result + ( ( datePattern == null )
                                                       ? 0
                                                       : datePattern.hashCode() );
    result = prime * result + ( ( dateSeparator == null )
                                                         ? 0
                                                         : dateSeparator.hashCode() );
    result = prime * result + ( ( day == null )
                                               ? 0
                                               : day.hashCode() );
    result = prime * result + ( ( editable == null )
                                                    ? 0
                                                    : editable.hashCode() );
    result = prime * result + ( ( enableHighAccuracy == null )
                                                              ? 0
                                                              : enableHighAccuracy.hashCode() );
    result = prime * result + ( ( enabled == null )
                                                   ? 0
                                                   : enabled.hashCode() );
    result = prime * result + ( ( expanded == null )
                                                    ? 0
                                                    : expanded.hashCode() );
    result = prime * result + ( ( focusControl == null )
                                                        ? 0
                                                        : focusControl.hashCode() );
    result = prime * result + ( ( font == null )
                                                ? 0
                                                : font.hashCode() );
    result = prime * result + ( ( foreground == null )
                                                      ? 0
                                                      : foreground.hashCode() );
    result = prime * result + ( ( frequency == null )
                                                     ? 0
                                                     : frequency.hashCode() );
    result = prime * result + ( ( hours == null )
                                                 ? 0
                                                 : hours.hashCode() );
    result = prime * result + ( ( image == null )
                                                 ? 0
                                                 : image.hashCode() );
    result = prime * result + ( ( images == null )
                                                  ? 0
                                                  : images.hashCode() );
    result = prime * result + ( ( itemCount == null )
                                                     ? 0
                                                     : itemCount.hashCode() );
    result = prime * result + ( ( items == null )
                                                 ? 0
                                                 : items.hashCode() );
    result = prime * result + ( ( maximum == null )
                                                   ? 0
                                                   : maximum.hashCode() );
    result = prime * result + ( ( maximumAge == null )
                                                      ? 0
                                                      : maximumAge.hashCode() );
    result = prime * result + ( ( message == null )
                                                   ? 0
                                                   : message.hashCode() );
    result = prime * result + ( ( minimum == null )
                                                   ? 0
                                                   : minimum.hashCode() );
    result = prime * result + ( ( minimumSize == null )
                                                       ? 0
                                                       : minimumSize.hashCode() );
    result = prime * result + ( ( minutes == null )
                                                   ? 0
                                                   : minutes.hashCode() );
    result = prime * result + ( ( mode == null )
                                                ? 0
                                                : mode.hashCode() );
    result = prime * result + ( ( month == null )
                                                 ? 0
                                                 : month.hashCode() );
    result = prime * result + ( ( monthNames == null )
                                                      ? 0
                                                      : monthNames.hashCode() );
    result = prime * result + ( ( needsPosition == null )
                                                         ? 0
                                                         : needsPosition.hashCode() );
    result = prime * result + ( ( origin == null )
                                                  ? 0
                                                  : origin.hashCode() );
    result = prime * result + ( ( parent == null )
                                                  ? 0
                                                  : parent.hashCode() );
    result = prime * result + ( ( playback_mode == null )
                                                         ? 0
                                                         : playback_mode.hashCode() );
    result = prime * result + ( ( presentation_mode == null )
                                                             ? 0
                                                             : presentation_mode.hashCode() );
    result = prime * result + ( ( repeat == null )
                                                  ? 0
                                                  : repeat.hashCode() );
    result = prime * result + ( ( seconds == null )
                                                   ? 0
                                                   : seconds.hashCode() );
    result = prime * result + ( ( selection == null )
                                                     ? 0
                                                     : selection.hashCode() );
    result = prime * result + ( ( selectionIndex == null )
                                                          ? 0
                                                          : selectionIndex.hashCode() );
    result = prime * result + ( ( selectionIndices == null )
                                                            ? 0
                                                            : selectionIndices.hashCode() );
    result = prime * result + ( ( speed == null )
                                                 ? 0
                                                 : speed.hashCode() );
    result = prime * result + ( ( state == null )
                                                 ? 0
                                                 : state.hashCode() );
    result = prime * result + ( ( tabIndex == null )
                                                    ? 0
                                                    : tabIndex.hashCode() );
    result = prime * result + ( ( text == null )
                                                ? 0
                                                : text.hashCode() );
    result = prime * result + ( ( textLimit == null )
                                                     ? 0
                                                     : textLimit.hashCode() );
    result = prime * result + ( ( texts == null )
                                                 ? 0
                                                 : texts.hashCode() );
    result = prime * result + ( ( toolTip == null )
                                                   ? 0
                                                   : toolTip.hashCode() );
    result = prime * result + ( ( topIndex == null )
                                                    ? 0
                                                    : topIndex.hashCode() );
    result = prime * result + ( ( url == null )
                                               ? 0
                                               : url.hashCode() );
    result = prime * result + ( ( videoURL == null )
                                                    ? 0
                                                    : videoURL.hashCode() );
    result = prime * result + ( ( visibility == null )
                                                      ? 0
                                                      : visibility.hashCode() );
    result = prime * result + ( ( weekdayNames == null )
                                                        ? 0
                                                        : weekdayNames.hashCode() );
    result = prime * result + ( ( weekdayShortNames == null )
                                                             ? 0
                                                             : weekdayShortNames.hashCode() );
    result = prime * result + ( ( year == null )
                                                ? 0
                                                : year.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    SetProperties other = ( SetProperties )obj;
    if( active == null ) {
      if( other.active != null ) {
        return false;
      }
    } else if( !active.equals( other.active ) ) {
      return false;
    }
    if( activeControl == null ) {
      if( other.activeControl != null ) {
        return false;
      }
    } else if( !activeControl.equals( other.activeControl ) ) {
      return false;
    }
    if( alignment == null ) {
      if( other.alignment != null ) {
        return false;
      }
    } else if( !alignment.equals( other.alignment ) ) {
      return false;
    }
    if( autoplay == null ) {
      if( other.autoplay != null ) {
        return false;
      }
    } else if( !autoplay.equals( other.autoplay ) ) {
      return false;
    }
    if( background == null ) {
      if( other.background != null ) {
        return false;
      }
    } else if( !background.equals( other.background ) ) {
      return false;
    }
    if( backgroundImage == null ) {
      if( other.backgroundImage != null ) {
        return false;
      }
    } else if( !backgroundImage.equals( other.backgroundImage ) ) {
      return false;
    }
    if( bounds == null ) {
      if( other.bounds != null ) {
        return false;
      }
    } else if( !bounds.equals( other.bounds ) ) {
      return false;
    }
    if( cellBackgrounds == null ) {
      if( other.cellBackgrounds != null ) {
        return false;
      }
    } else if( !cellBackgrounds.equals( other.cellBackgrounds ) ) {
      return false;
    }
    if( cellForegrounds == null ) {
      if( other.cellForegrounds != null ) {
        return false;
      }
    } else if( !cellForegrounds.equals( other.cellForegrounds ) ) {
      return false;
    }
    if( children == null ) {
      if( other.children != null ) {
        return false;
      }
    } else if( !children.equals( other.children ) ) {
      return false;
    }
    if( content == null ) {
      if( other.content != null ) {
        return false;
      }
    } else if( !content.equals( other.content ) ) {
      return false;
    }
    if( controls_visible == null ) {
      if( other.controls_visible != null ) {
        return false;
      }
    } else if( !controls_visible.equals( other.controls_visible ) ) {
      return false;
    }
    if( customVariant == null ) {
      if( other.customVariant != null ) {
        return false;
      }
    } else if( !customVariant.equals( other.customVariant ) ) {
      return false;
    }
    if( date == null ) {
      if( other.date != null ) {
        return false;
      }
    } else if( !date.equals( other.date ) ) {
      return false;
    }
    if( datePattern == null ) {
      if( other.datePattern != null ) {
        return false;
      }
    } else if( !datePattern.equals( other.datePattern ) ) {
      return false;
    }
    if( dateSeparator == null ) {
      if( other.dateSeparator != null ) {
        return false;
      }
    } else if( !dateSeparator.equals( other.dateSeparator ) ) {
      return false;
    }
    if( day == null ) {
      if( other.day != null ) {
        return false;
      }
    } else if( !day.equals( other.day ) ) {
      return false;
    }
    if( editable == null ) {
      if( other.editable != null ) {
        return false;
      }
    } else if( !editable.equals( other.editable ) ) {
      return false;
    }
    if( enableHighAccuracy == null ) {
      if( other.enableHighAccuracy != null ) {
        return false;
      }
    } else if( !enableHighAccuracy.equals( other.enableHighAccuracy ) ) {
      return false;
    }
    if( enabled == null ) {
      if( other.enabled != null ) {
        return false;
      }
    } else if( !enabled.equals( other.enabled ) ) {
      return false;
    }
    if( expanded == null ) {
      if( other.expanded != null ) {
        return false;
      }
    } else if( !expanded.equals( other.expanded ) ) {
      return false;
    }
    if( focusControl == null ) {
      if( other.focusControl != null ) {
        return false;
      }
    } else if( !focusControl.equals( other.focusControl ) ) {
      return false;
    }
    if( font == null ) {
      if( other.font != null ) {
        return false;
      }
    } else if( !font.equals( other.font ) ) {
      return false;
    }
    if( foreground == null ) {
      if( other.foreground != null ) {
        return false;
      }
    } else if( !foreground.equals( other.foreground ) ) {
      return false;
    }
    if( frequency == null ) {
      if( other.frequency != null ) {
        return false;
      }
    } else if( !frequency.equals( other.frequency ) ) {
      return false;
    }
    if( hours == null ) {
      if( other.hours != null ) {
        return false;
      }
    } else if( !hours.equals( other.hours ) ) {
      return false;
    }
    if( image == null ) {
      if( other.image != null ) {
        return false;
      }
    } else if( !image.equals( other.image ) ) {
      return false;
    }
    if( images == null ) {
      if( other.images != null ) {
        return false;
      }
    } else if( !images.equals( other.images ) ) {
      return false;
    }
    if( itemCount == null ) {
      if( other.itemCount != null ) {
        return false;
      }
    } else if( !itemCount.equals( other.itemCount ) ) {
      return false;
    }
    if( items == null ) {
      if( other.items != null ) {
        return false;
      }
    } else if( !items.equals( other.items ) ) {
      return false;
    }
    if( maximum == null ) {
      if( other.maximum != null ) {
        return false;
      }
    } else if( !maximum.equals( other.maximum ) ) {
      return false;
    }
    if( maximumAge == null ) {
      if( other.maximumAge != null ) {
        return false;
      }
    } else if( !maximumAge.equals( other.maximumAge ) ) {
      return false;
    }
    if( message == null ) {
      if( other.message != null ) {
        return false;
      }
    } else if( !message.equals( other.message ) ) {
      return false;
    }
    if( minimum == null ) {
      if( other.minimum != null ) {
        return false;
      }
    } else if( !minimum.equals( other.minimum ) ) {
      return false;
    }
    if( minimumSize == null ) {
      if( other.minimumSize != null ) {
        return false;
      }
    } else if( !minimumSize.equals( other.minimumSize ) ) {
      return false;
    }
    if( minutes == null ) {
      if( other.minutes != null ) {
        return false;
      }
    } else if( !minutes.equals( other.minutes ) ) {
      return false;
    }
    if( mode == null ) {
      if( other.mode != null ) {
        return false;
      }
    } else if( !mode.equals( other.mode ) ) {
      return false;
    }
    if( month == null ) {
      if( other.month != null ) {
        return false;
      }
    } else if( !month.equals( other.month ) ) {
      return false;
    }
    if( monthNames == null ) {
      if( other.monthNames != null ) {
        return false;
      }
    } else if( !monthNames.equals( other.monthNames ) ) {
      return false;
    }
    if( needsPosition == null ) {
      if( other.needsPosition != null ) {
        return false;
      }
    } else if( !needsPosition.equals( other.needsPosition ) ) {
      return false;
    }
    if( origin == null ) {
      if( other.origin != null ) {
        return false;
      }
    } else if( !origin.equals( other.origin ) ) {
      return false;
    }
    if( parent == null ) {
      if( other.parent != null ) {
        return false;
      }
    } else if( !parent.equals( other.parent ) ) {
      return false;
    }
    if( playback_mode == null ) {
      if( other.playback_mode != null ) {
        return false;
      }
    } else if( !playback_mode.equals( other.playback_mode ) ) {
      return false;
    }
    if( presentation_mode == null ) {
      if( other.presentation_mode != null ) {
        return false;
      }
    } else if( !presentation_mode.equals( other.presentation_mode ) ) {
      return false;
    }
    if( repeat == null ) {
      if( other.repeat != null ) {
        return false;
      }
    } else if( !repeat.equals( other.repeat ) ) {
      return false;
    }
    if( seconds == null ) {
      if( other.seconds != null ) {
        return false;
      }
    } else if( !seconds.equals( other.seconds ) ) {
      return false;
    }
    if( selection == null ) {
      if( other.selection != null ) {
        return false;
      }
    } else if( !selection.equals( other.selection ) ) {
      return false;
    }
    if( selectionIndex == null ) {
      if( other.selectionIndex != null ) {
        return false;
      }
    } else if( !selectionIndex.equals( other.selectionIndex ) ) {
      return false;
    }
    if( selectionIndices == null ) {
      if( other.selectionIndices != null ) {
        return false;
      }
    } else if( !selectionIndices.equals( other.selectionIndices ) ) {
      return false;
    }
    if( speed == null ) {
      if( other.speed != null ) {
        return false;
      }
    } else if( !speed.equals( other.speed ) ) {
      return false;
    }
    if( state == null ) {
      if( other.state != null ) {
        return false;
      }
    } else if( !state.equals( other.state ) ) {
      return false;
    }
    if( tabIndex == null ) {
      if( other.tabIndex != null ) {
        return false;
      }
    } else if( !tabIndex.equals( other.tabIndex ) ) {
      return false;
    }
    if( text == null ) {
      if( other.text != null ) {
        return false;
      }
    } else if( !text.equals( other.text ) ) {
      return false;
    }
    if( textLimit == null ) {
      if( other.textLimit != null ) {
        return false;
      }
    } else if( !textLimit.equals( other.textLimit ) ) {
      return false;
    }
    if( texts == null ) {
      if( other.texts != null ) {
        return false;
      }
    } else if( !texts.equals( other.texts ) ) {
      return false;
    }
    if( toolTip == null ) {
      if( other.toolTip != null ) {
        return false;
      }
    } else if( !toolTip.equals( other.toolTip ) ) {
      return false;
    }
    if( topIndex == null ) {
      if( other.topIndex != null ) {
        return false;
      }
    } else if( !topIndex.equals( other.topIndex ) ) {
      return false;
    }
    if( url == null ) {
      if( other.url != null ) {
        return false;
      }
    } else if( !url.equals( other.url ) ) {
      return false;
    }
    if( videoURL == null ) {
      if( other.videoURL != null ) {
        return false;
      }
    } else if( !videoURL.equals( other.videoURL ) ) {
      return false;
    }
    if( visibility == null ) {
      if( other.visibility != null ) {
        return false;
      }
    } else if( !visibility.equals( other.visibility ) ) {
      return false;
    }
    if( weekdayNames == null ) {
      if( other.weekdayNames != null ) {
        return false;
      }
    } else if( !weekdayNames.equals( other.weekdayNames ) ) {
      return false;
    }
    if( weekdayShortNames == null ) {
      if( other.weekdayShortNames != null ) {
        return false;
      }
    } else if( !weekdayShortNames.equals( other.weekdayShortNames ) ) {
      return false;
    }
    if( year == null ) {
      if( other.year != null ) {
        return false;
      }
    } else if( !year.equals( other.year ) ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "SetProperties ["
           + ( text != null
                           ? "text=" + text + ", "
                           : "" )
           + ( texts != null
                            ? "texts=" + texts + ", "
                            : "" )
           + ( active != null
                             ? "active=" + active + ", "
                             : "" )
           + ( mode != null
                           ? "mode=" + mode + ", "
                           : "" )
           + ( minimumSize != null
                                  ? "minimumSize=" + minimumSize + ", "
                                  : "" )
           + ( activeControl != null
                                    ? "activeControl=" + activeControl + ", "
                                    : "" )
           + ( bounds != null
                             ? "bounds=" + bounds + ", "
                             : "" )
           + ( tabIndex != null
                               ? "tabIndex=" + tabIndex + ", "
                               : "" )
           + ( foreground != null
                                 ? "foreground=" + foreground + ", "
                                 : "" )
           + ( background != null
                                 ? "background=" + background + ", "
                                 : "" )
           + ( cellForegrounds != null
                                      ? "cellForegrounds=" + cellForegrounds + ", "
                                      : "" )
           + ( cellBackgrounds != null
                                      ? "cellBackgrounds=" + cellBackgrounds + ", "
                                      : "" )
           + ( parent != null
                             ? "parent=" + parent + ", "
                             : "" )
           + ( content != null
                              ? "content=" + content + ", "
                              : "" )
           + ( backgroundImage != null
                                      ? "backgroundImage=" + backgroundImage + ", "
                                      : "" )
           + ( image != null
                            ? "image=" + image + ", "
                            : "" )
           + ( images != null
                             ? "images=" + images + ", "
                             : "" )
           + ( selection != null
                                ? "selection=" + selection + ", "
                                : "" )
           + ( enabled != null
                              ? "enabled=" + enabled + ", "
                              : "" )
           + ( editable != null
                               ? "editable=" + editable + ", "
                               : "" )
           + ( visibility != null
                                 ? "visibility=" + visibility + ", "
                                 : "" )
           + ( font != null
                           ? "font=" + font + ", "
                           : "" )
           + ( origin != null
                             ? "origin=" + origin + ", "
                             : "" )
           + ( items != null
                            ? "items=" + items + ", "
                            : "" )
           + ( selectionIndex != null
                                     ? "selectionIndex=" + selectionIndex + ", "
                                     : "" )
           + ( topIndex != null
                               ? "topIndex=" + topIndex + ", "
                               : "" )
           + ( selectionIndices != null
                                       ? "selectionIndices=" + selectionIndices + ", "
                                       : "" )
           + ( children != null
                               ? "children=" + children + ", "
                               : "" )
           + ( monthNames != null
                                 ? "monthNames=" + monthNames + ", "
                                 : "" )
           + ( weekdayNames != null
                                   ? "weekdayNames=" + weekdayNames + ", "
                                   : "" )
           + ( weekdayShortNames != null
                                        ? "weekdayShortNames=" + weekdayShortNames + ", "
                                        : "" )
           + ( date != null
                           ? "date=" + date + ", "
                           : "" )
           + ( dateSeparator != null
                                    ? "dateSeparator=" + dateSeparator + ", "
                                    : "" )
           + ( datePattern != null
                                  ? "datePattern=" + datePattern + ", "
                                  : "" )
           + ( year != null
                           ? "year=" + year + ", "
                           : "" )
           + ( month != null
                            ? "month=" + month + ", "
                            : "" )
           + ( day != null
                          ? "day=" + day + ", "
                          : "" )
           + ( hours != null
                            ? "hours=" + hours + ", "
                            : "" )
           + ( minutes != null
                              ? "minutes=" + minutes + ", "
                              : "" )
           + ( seconds != null
                              ? "seconds=" + seconds + ", "
                              : "" )
           + ( expanded != null
                               ? "expanded=" + expanded + ", "
                               : "" )
           + ( toolTip != null
                              ? "toolTip=" + toolTip + ", "
                              : "" )
           + ( itemCount != null
                                ? "itemCount=" + itemCount + ", "
                                : "" )
           + ( message != null
                              ? "message=" + message + ", "
                              : "" )
           + ( customVariant != null
                                    ? "customVariant=" + customVariant + ", "
                                    : "" )
           + ( alignment != null
                                ? "alignment=" + alignment + ", "
                                : "" )
           + ( url != null
                          ? "url=" + url + ", "
                          : "" )
           + ( enableHighAccuracy != null
                                         ? "enableHighAccuracy=" + enableHighAccuracy + ", "
                                         : "" )
           + ( maximumAge != null
                                 ? "maximumAge=" + maximumAge + ", "
                                 : "" )
           + ( frequency != null
                                ? "frequency=" + frequency + ", "
                                : "" )
           + ( needsPosition != null
                                    ? "needsPosition=" + needsPosition + ", "
                                    : "" )
           + ( textLimit != null
                                ? "textLimit=" + textLimit + ", "
                                : "" )
           + ( minimum != null
                              ? "minimum=" + minimum + ", "
                              : "" )
           + ( maximum != null
                              ? "maximum=" + maximum + ", "
                              : "" )
           + ( state != null
                            ? "state=" + state + ", "
                            : "" )
           + ( focusControl != null
                                   ? "focusControl=" + focusControl
                                   : "" )
           + "]";
  }

}
