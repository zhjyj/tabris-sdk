/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Group;

public class GroupOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Group";

  public GroupOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Group group = new Group( getActivity() );
    initiateNewView( operation, group );
    applyConsumingTouchListener( group );
  }

  @Override
  protected void applyConsumingTouchListener( View view ) {
    CompositeTouchListener compListener = getListenerRegistry().findListener( ( String )view.getTag(),
                                                                              CompositeTouchListener.class );
    compListener.addListener( new ConsumingTouchListener() );
  }

  public String getType() {
    return TYPE;
  }

}
