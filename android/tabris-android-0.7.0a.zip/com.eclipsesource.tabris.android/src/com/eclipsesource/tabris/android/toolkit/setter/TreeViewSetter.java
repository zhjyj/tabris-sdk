/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class TreeViewSetter<T extends TreeView> extends ViewSetter<TreeView> {

  public TreeViewSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( TreeView treeView, SetProperties properties ) {
    super.execute( treeView, properties );
    setToolTip( treeView, properties );
    setItemCount( treeView, properties );
  }

  private void setItemCount( TreeView treeView, SetProperties properties ) {
    Integer itemCount = properties.getItemCount();
    if( itemCount != null ) {
      treeView.getRootTreeItem().setItemCount( itemCount );
    }
  }

  private void setToolTip( TreeView treeView, SetProperties properties ) {
    String toolTip = properties.getToolTip();
    if( toolTip != null ) {
      treeView.setToolTip( toolTip );
    }
  }

  @Override
  protected void setSelection( View view, SetProperties properties ) {
    // we do not support setting the selection yet
  }
}
