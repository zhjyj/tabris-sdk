/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.util.FloatMath;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Separator.Orientation;

public class SeparatorSetter<T extends Separator> extends ViewSetter<T> {

  public SeparatorSetter( TabrisActivity activity ) {
    super( activity );
  }

  private static final int SEPARATOR_SIZE = 1;
  private static float HALF_SEPARATOR_SIZE = SEPARATOR_SIZE / 2f;

  @Override
  public void applyBoundsToView( View view, List<Integer> bounds ) {
    Separator separator = ( Separator )view;
    Orientation orientation = separator.getOrientation();
    if( orientation == null ) {
      super.applyBoundsToView( view, bounds );
    } else {
      switch( orientation ) {
        case HORIZONTAL:
          super.applyBoundsToView( view, createHorizontalBounds( bounds ) );
        break;
        case VERTICAL:
          super.applyBoundsToView( view, createVerticalBounds( bounds ) );
        break;
      }
    }
  }

  private ArrayList<Integer> createVerticalBounds( List<Integer> bounds ) {
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    Integer x = bounds.get( 0 );
    Integer width = bounds.get( 2 );
    newBounds.add( ( int )FloatMath.floor( x + ( width / 2f ) - HALF_SEPARATOR_SIZE ) );
    newBounds.add( bounds.get( 1 ) );
    newBounds.add( SEPARATOR_SIZE );
    newBounds.add( bounds.get( 3 ) );
    return newBounds;
  }

  private ArrayList<Integer> createHorizontalBounds( List<Integer> bounds ) {
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    Integer y = bounds.get( 1 );
    Integer height = bounds.get( 3 );
    newBounds.add( bounds.get( 0 ) );
    newBounds.add( ( int )FloatMath.floor( y + ( height / 2f ) - HALF_SEPARATOR_SIZE ) );
    newBounds.add( bounds.get( 2 ) );
    newBounds.add( SEPARATOR_SIZE );
    return newBounds;
  }

}
