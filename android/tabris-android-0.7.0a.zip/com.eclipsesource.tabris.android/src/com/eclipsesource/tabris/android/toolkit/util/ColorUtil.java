/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.Drawable;

public class ColorUtil {

  public void applyColorFilter( Drawable drawable, float r, float g, float b ) {
    ColorMatrix cmDesat = new ColorMatrix();
    cmDesat.setSaturation( 0 );
    ColorMatrix cm = new ColorMatrix();
    // @formatter:off
    cm.set( new float[]{
      r, 0, 0, 0, 0, 
      0, g, 0, 0, 0, 
      0, 0, b, 0, 0, 
      0, 0, 0, 1, 0
    } );
    // @formatter:on
    cmDesat.postConcat( cm );
    drawable.setColorFilter( new ColorMatrixColorFilter( cmDesat ) );
  }
}
