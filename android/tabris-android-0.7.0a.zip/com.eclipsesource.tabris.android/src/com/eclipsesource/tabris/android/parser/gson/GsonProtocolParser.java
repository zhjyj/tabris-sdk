/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.eclipsesource.tabris.android.core.model.Action;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

public class GsonProtocolParser implements IProtocolParser {

  private static final String FIELD_META = "meta";
  private static final String FIELD_OPERATIONS = "operations";

  private final Set<IProtocolParserCallback> callbacks;
  private final Gson gson;

  public GsonProtocolParser() {
    callbacks = new HashSet<IProtocolParserCallback>();
    gson = createGson();
  }

  public void parse( InputStream is ) {
    if( is == null ) {
      throw new IllegalArgumentException( "Can not parse null input steam" );
    }
    parseDocument( is );
  }

  private void parseDocument( InputStream is ) {
    // is = new LoggingInputStream( is );
    JsonReader reader = null;
    try {
      reader = new JsonReader( new InputStreamReader( is ) );
      reader.setLenient( true );
      reader.beginObject();
      processMeta( gson, reader );
      processOperations( gson, reader );
      reader.endObject();
    } catch( Exception e ) {
      throw new ParseException( "Could not read/parse json document", e );
    } finally {
      if( reader != null ) {
        try {
          reader.close();
        } catch( IOException e ) {
          throw new ParseException( "Could not close input stream from http response", e );
        }
      }
    }
  }

  private void processOperations( Gson gson, JsonReader reader ) throws IOException {
    ArrayList<Operation> operations = new ArrayList<Operation>();
    if( reader.hasNext() ) {
      String operationsField = reader.nextName();
      if( !operationsField.equals( FIELD_OPERATIONS ) ) {
        throw new ParseException( "No operations field in the protocol message." );
      }
      reader.beginArray();
      while( reader.hasNext() ) {
        Operation op = gson.fromJson( reader, Operation.class );
        operations.add( op );
      }
      reader.endArray();
    }
    if( !operations.isEmpty() ) {
      fireOperationsFound( operations );
    }
  }

  private void processMeta( Gson gson, JsonReader reader ) throws IOException {
    String metaField = reader.nextName();
    if( !metaField.equals( FIELD_META ) ) {
      throw new ParseException( "No meta field in the protocol message." );
    }
    Meta meta = gson.fromJson( reader, Meta.class );
    fireMetaFound( meta );
  }

  private Gson createGson() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( Operation.class, new OperationDeserializer() );
    gsonBuilder.registerTypeAdapter( CallProperties.class, new CallPropertiesDeserializer() );
    gsonBuilder.registerTypeAdapter( Action.class, new ActionDeserializer() );
    gsonBuilder.registerTypeAdapter( Font.class, new FontDeserializer() );
    gsonBuilder.registerTypeAdapter( GenericObject.class, new GenericObjectDeserializer() );
    return gsonBuilder.create();
  }

  private void fireMetaFound( Meta meta ) {
    for( IProtocolParserCallback callback : callbacks ) {
      callback.metaFound( meta );
    }
  }

  private void fireOperationsFound( ArrayList<Operation> ops ) {
    for( IProtocolParserCallback callback : callbacks ) {
      callback.operationsFound( ops );
    }
  }

  public void addProtocolParserCallback( IProtocolParserCallback callback ) {
    callbacks.add( callback );
  }

  public void removeProtocolParserCallback( IProtocolParserCallback callback ) {
    callbacks.remove( callback );
  }

  public String toJson( Object obj ) {
    return gson.toJson( obj );
  }
}
