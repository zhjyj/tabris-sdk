/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;

public class UiCallbackRunnable implements Runnable {

  private static final int RETRY_DELAY = 2000;
  private static final String CALLBACK_QUERY = "custom_service_handler=org.eclipse.rap.uicallback";

  private final TabrisActivity activity;

  public UiCallbackRunnable( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void run() {
    try {
      ProtocolProcessor processor = activity.getProcessor();
      while( !Thread.interrupted() ) {
        GetRequest request = createUiCallbackRequest();
        ITransportResult result = processor.processGetRequest( request );
        if( result.hasException() ) {
          do {
            Thread.sleep( RETRY_DELAY );
          } while( !isConnected() );
        } else {
          parseResult( processor, result );
        }
      }
    } catch( InterruptedException e ) {
      // Interruption is intended when callback is deactivated
    }
  }

  private GetRequest createUiCallbackRequest() {
    GetRequest request = new GetRequest();
    request.setQuery( CALLBACK_QUERY );
    request.setTimeout( 0 );
    request.setSilentRequest( true );
    return request;
  }

  private void parseResult( ProtocolProcessor processor, ITransportResult result ) {
    try {
      processor.getParser().parse( result.getResult() );
    } catch( Throwable t ) {
      processor.getWidgetToolkit().showError( t );
    }
  }

  public boolean isConnected() {
    ConnectivityManager cm = ( ConnectivityManager )activity.getSystemService( Context.CONNECTIVITY_SERVICE );
    NetworkInfo netInfo = cm.getActiveNetworkInfo();
    if( netInfo != null && netInfo.isConnected() ) {
      return true;
    }
    return false;
  }
}
