/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Paint.Style;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class FillGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "fill";

  public FillGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    gc.setStyle( Style.FILL );
    gc.drawCurrentPath();
  }
}
