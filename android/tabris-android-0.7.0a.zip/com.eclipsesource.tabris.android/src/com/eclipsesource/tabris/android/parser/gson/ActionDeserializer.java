/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;

import com.eclipsesource.tabris.android.core.model.Action;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;

public class ActionDeserializer implements JsonDeserializer<Action> {

  public Action deserialize( JsonElement json, Type typeOfT, JsonDeserializationContext context )
    throws JsonParseException
  {
    Action result = null;
    if( json instanceof JsonPrimitive ) {
      JsonPrimitive primitive = ( JsonPrimitive )json;
      result = Action.findAction( primitive.getAsString() );
    }
    return result;
  }
}
