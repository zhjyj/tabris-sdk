/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class IndexSelectionState extends AbstractState {

  private final int selection;

  public IndexSelectionState( String widgetID, int selection ) {
    super( widgetID );
    this.selection = selection;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTION_POSTFIX;
  }

  @Override
  public String generateValue() {
    return Integer.toString( selection );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + selection;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    IndexSelectionState other = ( IndexSelectionState )obj;
    if( selection != other.selection ) {
      return false;
    }
    return true;
  }

}
