/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Scale;

public class ScaleSetter<T extends Scale> extends ViewSetter<T> {

  public ScaleSetter( TabrisActivity activity ) {
    super( activity );
  }

  private final int FIXED_HEIGHT = 32;

  @Override
  public void execute( T scale, SetProperties properties ) {
    super.execute( scale, properties );
    setMinimum( scale, properties );
    setMaximum( scale, properties );
  }

  private void setMinimum( T scale, SetProperties properties ) {
    Integer minimum = properties.getMinimum();
    if( minimum != null ) {
      scale.setMin( minimum );
    }
  }

  private void setMaximum( T scale, SetProperties properties ) {
    Integer maximum = properties.getMaximum();
    if( maximum != null ) {
      scale.setMax( maximum );
    }
  }

  @Override
  protected void setSelection( View view, SetProperties properties ) {
    GenericObject selection = properties.getSelection();
    if( selection != null ) {
      ( ( Scale )view ).setProgress( selection.getObjectAs( Number.class ).intValue() );
    }
  }

  @Override
  protected List<Integer> adjustBounds( View view, List<Integer> bounds ) {
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    newBounds.add( bounds.get( 0 ) );
    newBounds.add( bounds.get( 1 ) + bounds.get( 3 ) / 2 - FIXED_HEIGHT / 2 );
    newBounds.add( bounds.get( 2 ) );
    newBounds.add( FIXED_HEIGHT );
    return newBounds;
  }

}