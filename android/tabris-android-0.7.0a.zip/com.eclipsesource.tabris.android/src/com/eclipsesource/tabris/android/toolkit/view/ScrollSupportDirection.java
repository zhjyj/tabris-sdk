/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

public enum ScrollSupportDirection {
  X(true, false),
  Y(false, true),
  X_AND_Y(true, true);

  private final boolean x;
  private final boolean y;

  private ScrollSupportDirection( boolean x, boolean y ) {
    this.x = x;
    this.y = y;
  }

  public boolean supportsX() {
    return x;
  }

  public boolean supportsY() {
    return y;
  }

}