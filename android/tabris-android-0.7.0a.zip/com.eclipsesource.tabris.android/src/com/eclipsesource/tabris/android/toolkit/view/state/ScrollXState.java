/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class ScrollXState extends AbstractState {

  private int scrollX;

  public ScrollXState( String widgetID ) {
    super( widgetID );
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SCROLL_X_POSTFIX;
  }

  @Override
  public String generateValue() {
    return String.valueOf( scrollX );
  }

  public void setScrollX( int scrollX ) {
    this.scrollX = scrollX;
  }

  public void setWidgetId( String widgetId ) {
    if( widgetId == null ) {
      throw new IllegalArgumentException( "The widgetId can not be set to null" );
    }
    super.widgetId = widgetId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + scrollX;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    ScrollXState other = ( ScrollXState )obj;
    if( scrollX != other.scrollX ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "ScrollXState [scrollX=" + scrollX + ", " + ( widgetId != null
                                                                         ? "widgetId=" + widgetId
                                                                         : "" ) + "]";
  }

}
