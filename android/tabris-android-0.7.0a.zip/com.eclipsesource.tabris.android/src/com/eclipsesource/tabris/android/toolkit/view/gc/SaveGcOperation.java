/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class SaveGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "save";

  public SaveGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    gc.savePaint();
  }

}
