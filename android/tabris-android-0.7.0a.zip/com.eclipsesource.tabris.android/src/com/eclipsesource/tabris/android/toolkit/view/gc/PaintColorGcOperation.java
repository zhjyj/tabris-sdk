/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.ArrayList;
import java.util.List;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public abstract class PaintColorGcOperation extends AbstractGcOperation {

  public PaintColorGcOperation( String operation ) {
    super( operation );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    Object object = properties.get( 1 );
    if( !( object instanceof List<?> ) ) {
      throw new IllegalArgumentException( "The '"
                                          + getOperation()
                                          + "' parameter is not a touple. Got: "
                                          + object );
    }
    List<?> objectList = ( List<?> )object;
    ArrayList<Integer> intList = listToIntegerList( getOperation(), objectList );
    setColor( gc, SetterManager.colorToupleToInt( intList ) );
  }

  public static ArrayList<Integer> listToIntegerList( String opName, List<?> objectList ) {
    ArrayList<Integer> intList = new ArrayList<Integer>();
    for( int i = 0; i < objectList.size(); i++ ) {
      Object elem = objectList.get( i );
      if( elem instanceof Number ) {
        intList.add( ( ( Number )elem ).intValue() );
      } else {
        throw new IllegalArgumentException( "The color element for the '"
                                            + opName
                                            + "' is not of type Number. Got: "
                                            + elem.getClass().getName() );
      }
    }
    return intList;
  }

  public abstract void setColor( GraphicalContext gc, int color );
}
