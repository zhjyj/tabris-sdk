/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.util.StringUtil;

public class BrowserProgressListener implements IBrowserProgressListener {

  private final TabrisActivity activity;

  public BrowserProgressListener( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void pageFinishedLoading( String widgetId ) {
    PostRequest request = new PostRequest();
    request.addParam( widgetId + IProtocolConstants.PROGRESS_COMPLETED_POSTFIX, StringUtil.TRUE );
    activity.getProcessor().processPostRequest( request );
  }

}
