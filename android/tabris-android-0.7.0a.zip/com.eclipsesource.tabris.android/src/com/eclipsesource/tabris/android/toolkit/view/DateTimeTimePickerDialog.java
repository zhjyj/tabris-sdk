/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Calendar;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.TimePicker;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class DateTimeTimePickerDialog extends TimePickerDialog implements IDateTimeSpinnerDialog {

  private DateTimeSpinner dateTimeSpinner;
  private final Calendar calendar;
  private final DialogHeader dialogHeader;
  private Calendar initialCalendar;

  public DateTimeTimePickerDialog( Activity activity, Calendar calendar ) {
    super( activity,
           ThemeUtil.getAttrResId( activity, R.attr.alertDialogTheme ),
           null,
           calendar.get( Calendar.HOUR_OF_DAY ),
           calendar.get( Calendar.MINUTE ),
           true );
    this.calendar = calendar;
    initialCalendar = ( Calendar )calendar.clone();
    // we wrap the context in our own theme manually because robolectric does
    // not support shadowing the DatePickerDialog
    int themeResId = ThemeUtil.getAttrResId( activity, R.attr.alertDialogTheme );
    dialogHeader = new DialogHeader( new ContextThemeWrapper( activity, themeResId ) );
    dialogHeader.getIcon().setVisibility( View.GONE );
    setCustomTitle( dialogHeader.getHeader() );
  }

  @Override
  public void onClick( DialogInterface dialog, int which ) {
    super.onClick( dialog, which );
    updateInitialTimeAndSpinner();
  }

  private void updateInitialTimeAndSpinner() {
    initialCalendar = ( Calendar )calendar.clone();
    updateDateTimeSpinner();
  }

  @Override
  public void onTimeChanged( TimePicker view, int hourOfDay, int minute ) {
    calendar.set( Calendar.HOUR_OF_DAY, hourOfDay );
    calendar.set( Calendar.MINUTE, minute );
    updateDialogTitle();
  }

  private void updateDialogTitle() {
    dialogHeader.setTitleText( dateTimeSpinner.formatDate( calendar.getTime() ) );
  }

  public void setDateTimeSpinner( DateTimeSpinner dateTimeSpinner ) {
    this.dateTimeSpinner = dateTimeSpinner;
    updateDateTimeSpinner();
    updateDialogTitle();
  }

  private void updateDateTimeSpinner() {
    dateTimeSpinner.setDate( calendar.getTime() );
  }

  public void reset() {
    updateTime( initialCalendar.get( Calendar.HOUR_OF_DAY ), initialCalendar.get( Calendar.MINUTE ) );
  }

  public void setHours( int hours ) {
    updateTime( hours, calendar.get( Calendar.MINUTE ) );
    updateInitialTimeAndSpinner();
  }

  public void setMinutes( int minutes ) {
    updateTime( calendar.get( Calendar.HOUR_OF_DAY ), minutes );
    updateInitialTimeAndSpinner();
  }

  public void setYear( int year ) {
    // years are not supported
  }

  public void setMonth( int month ) {
    // months are not supported
  }

  public void setDay( int day ) {
    // days are not supported
  }
}
