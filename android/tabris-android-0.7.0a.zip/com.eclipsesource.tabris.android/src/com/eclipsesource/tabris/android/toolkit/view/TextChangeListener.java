/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.text.Editable;
import android.text.TextWatcher;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.TextState;

public class TextChangeListener implements TextWatcher {

  protected String tag;
  private StateRecorder stateRecorder;

  public TextChangeListener( String editTextTag, StateRecorder stateRecorder ) {
    if( editTextTag == null ) {
      throw new IllegalArgumentException( "The widget's tag can not be null!" );
    }
    if( stateRecorder == null ) {
      throw new IllegalArgumentException( "StateRecorder can not be null!" );
    }
    this.tag = editTextTag;
    this.stateRecorder = stateRecorder;
  }

  public void beforeTextChanged( CharSequence s, int start, int count, int after ) {
    // ignore
  }

  public void onTextChanged( CharSequence s, int start, int before, int count ) {
    // ignore
  }

  public void afterTextChanged( Editable s ) {
    String textValue = s.toString();
    stateRecorder.recordState( new TextState( tag, textValue ) );
  }
}
