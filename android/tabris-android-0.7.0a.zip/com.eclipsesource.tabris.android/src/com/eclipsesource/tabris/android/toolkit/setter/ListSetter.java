/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListSelectionAdapter;

public class ListSetter<T extends List> extends ViewSetter<List> {

  public ListSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( List list, SetProperties properties ) {
    super.execute( list, properties );
    setItems( list, properties );
    setSelectionIndices( list, properties );
    setTopIndex( list, properties );
  }

  private void setItems( List list, SetProperties properties ) {
    java.util.List<String> items = properties.getItems();
    if( items != null ) {
      list.setItems( properties.getItems(), getActivity() );
    }
  }

  private void setSelectionIndices( List list, SetProperties properties ) {
    java.util.List<Integer> selectionIndices = properties.getSelectionIndices();
    if( selectionIndices != null ) {
      ListSelectionAdapter<?> adapter = ( ListSelectionAdapter<?> )list.getAdapter();
      if( selectionIndices.isEmpty() ) {
        adapter.setSelection( ListSelectionAdapter.NOTHING_SELECTED );
      } else {
        adapter.setSelection( selectionIndices.get( 0 ) );
      }
    }
  }

  private void setTopIndex( List list, SetProperties properties ) {
    Integer topIndex = properties.getTopIndex();
    if( topIndex != null ) {
      list.smoothScrollToPosition( topIndex );
    }
  }

  @Override
  protected void setBackground( View view, SetProperties properties ) {
    super.setBackground( view, properties );
    java.util.List<Integer> background = properties.getBackground();
    if( background != null ) {
      ( ( List )view ).setCacheColorHint( SetterManager.colorToupleToInt( background ) );
    }
  }

}
