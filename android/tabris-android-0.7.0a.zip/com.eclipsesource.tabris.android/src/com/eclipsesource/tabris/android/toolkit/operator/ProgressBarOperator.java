/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.graphics.drawable.Drawable;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;

public class ProgressBarOperator extends AbstractWidgetOperator {

  private static final String TYPE = "rwt.widgets.ProgressBar";

  private static final String STYLE_INDETERMINATE = "INDETERMINATE";

  public ProgressBarOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    ProgressBar progressBar = new ProgressBar( getActivity() );
    List<String> styles = operation.getProperties().getStyle();
    if( styles != null && styles.contains( STYLE_INDETERMINATE ) ) {
      progressBar.setIndeterminate( true );
      Drawable drawable = getActivity().getResources()
        .getDrawable( R.drawable.progress_indeterminate_horizontal_holo );
      progressBar.setIndeterminateDrawable( drawable );
    }
    initiateNewView( operation, progressBar );
  }

  public String getType() {
    return TYPE;
  }

}
