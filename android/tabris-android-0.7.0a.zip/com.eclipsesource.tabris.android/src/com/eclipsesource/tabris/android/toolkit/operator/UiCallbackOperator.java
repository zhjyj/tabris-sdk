/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.UiCallback;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class UiCallbackOperator implements IOperator {

  public static final String UI_CALLBACK_ID = "uicb";

  private static final String TYPE = "rwt.UICallBack";
  private static final String METHOD_SEND_UI_REQUEST = "sendUIRequest";

  private final TabrisActivity activity;

  public UiCallbackOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateOperation( operation );
    UiCallback uicb = new UiCallback( activity );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.registerObjectById( operation.getTarget(), uicb );
    CreateProperties properties = operation.getProperties();
    if( properties != null ) {
      applyProperties( operation.getTarget(), properties );
    }
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    SetProperties properties = operation.getProperties();
    applyProperties( operation.getTarget(), properties );
  }

  private void applyProperties( String target, SetProperties properties ) {
    Boolean active = properties.getActive();
    if( active != null ) {
      IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
      UiCallback callback = widgetToolkit.findObjectById( target, UiCallback.class );
      callback.setActive( active );
    }
  }

  public void listen( ListenOperation operation ) {
    // The ui callback does not support listening
  }

  public void call( CallOperation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "The call operation to invoke can not be null" );
    }
    String method = operation.getMethod();
    if( METHOD_SEND_UI_REQUEST.equals( method ) ) {
      activity.getProcessor().processPostRequest( new PostRequest() );
    }
  }

  public void destroy( DestroyOperation operation ) {
    // the ui callback is not destroyed by client code. it always exists.
  }

}
