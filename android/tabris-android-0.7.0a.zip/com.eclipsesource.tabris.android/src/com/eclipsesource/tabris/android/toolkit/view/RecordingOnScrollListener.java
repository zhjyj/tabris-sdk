/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.ListScrollState;

public class RecordingOnScrollListener implements OnScrollListener {

  private final StateRecorder stateRecorder;
  private int firstVisibleItem;

  public RecordingOnScrollListener( StateRecorder recorder ) {
    if( recorder == null ) {
      throw new IllegalArgumentException( "The stateRecorder can not be null" );
    }
    this.stateRecorder = recorder;
  }

  public void onScrollStateChanged( AbsListView view, int scrollState ) {
    if( scrollState == SCROLL_STATE_IDLE ) {
      stateRecorder.recordState( new ListScrollState( ( String )view.getTag(), firstVisibleItem ) );
    }
  }

  public void onScroll( AbsListView view,
                        int firstVisibleItem,
                        int visibleItemCount,
                        int totalItemCount )
  {
    this.firstVisibleItem = firstVisibleItem;
  }
}
