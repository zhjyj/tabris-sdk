/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Separator.Orientation;

public class SeparatorOperator extends AbstractWidgetOperator {

  private static final String TYPE = "rwt.widgets.Separator";

  private static final String STYLE_HORIZONTAL = "HORIZONTAL";

  public SeparatorOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Separator separator = new Separator( getActivity() );
    List<String> style = operation.getProperties().getStyle();
    if( style != null && style.contains( STYLE_HORIZONTAL ) ) {
      separator.setOrientation( Orientation.HORIZONTAL );
    } else {
      separator.setOrientation( Orientation.VERTICAL );
    }
    initiateNewView( operation, separator );
  }

  public String getType() {
    return TYPE;
  }

}
