/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class Separator extends View {

  private Orientation orientation;

  public static enum Orientation {
    HORIZONTAL,
    VERTICAL;
  }

  public Separator( TabrisActivity activity ) {
    super( activity );
    setBackgroundColor( ThemeUtil.getColorValue( activity, R.attr.groupSeparatorColor ) );
  }

  public Orientation getOrientation() {
    return orientation;
  }

  public void setOrientation( Orientation orientation ) {
    this.orientation = orientation;
  }

}
