/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.IndexSelectionState;

public class RecordingListItemClickListener implements OnItemClickListener {

  private final StateRecorder stateRecorder;

  public RecordingListItemClickListener( StateRecorder stateRecorder ) {
    this.stateRecorder = stateRecorder;
    if( stateRecorder == null ) {
      throw new IllegalArgumentException( "The state recorder can not be null" );
    }
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    IndexSelectionState state = new IndexSelectionState( ( String )parent.getTag(), position );
    stateRecorder.recordState( state );
    setSelection( parent, position );
  }

  private void setSelection( AdapterView<?> parent, int position ) {
    ListSelectionAdapter<?> adapter = ( ListSelectionAdapter<?> )parent.getAdapter();
    if( adapter != null && !adapter.isEmpty() ) {
      adapter.setSelection( position );
    }
  }

}
