/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Geolocation;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator.NeedsPositionFlavor;
import com.xtremelabs.robolectric.RobolectricTestRunner;


@RunWith( RobolectricTestRunner.class )
public class GeolocationOperator_Test {
  
  private TabrisActivity activity;
  private GeolocationOperator operator;
  private AndroidWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mockProcessor();
    activity.setProcessor( processor );
    mockToolkit( processor );
    operator = new GeolocationOperator( activity );
  }

  private ProtocolProcessor mockProcessor() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getStateRecorder() ).thenReturn( mock( StateRecorder.class ) );
    return processor;
  }
  
  private void mockToolkit( ProtocolProcessor processor ) {
    AndroidWidgetToolkit original = new AndroidWidgetToolkit( activity );
    toolkit = spy( original );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
  }

  @Test
  public void testType() {
    assertEquals( "rap.mobile.Geolocation", operator.getType() );
  }
  
  @Test
  public void testRegistersNewOne() {
    CreateOperation operation = mock( CreateOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );
    
    operator.create( operation );
    
    verify( toolkit ).registerObjectById( eq( "foo" ), any( Geolocation.class ) );
  }
  
  @Test
  public void testUnregistersOnDestroy() {
    mockGeolocation();
    DestroyOperation operation = mock( DestroyOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );
    
    operator.destroy( operation );
    
    verify( toolkit ).unregisterObjectById( eq( "foo" ) );
  }
  
  @Test
  public void testDestroy() {
    Geolocation geolocation = mockGeolocation();
    DestroyOperation operation = mock( DestroyOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );
    
    operator.destroy( operation );
    
    verify( geolocation ).destroy();
  }
  
  @Test
  public void testSetsNothingWhenEmpty() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    createProperties( operation );
    
    operator.set( operation );
    
    verify( geolocation, never() ).setNeedsPosition( any( NeedsPositionFlavor.class ) );
    verify( geolocation, never() ).setFrequency( anyInt() );
    verify( geolocation, never() ).setMaximumAge( anyInt() );
  }
  
  @Test
  public void testSetsNeedPositionNever() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setNeedsPosition( NeedsPositionFlavor.NEVER.toString() );
    
    operator.set( operation );
    
    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.NEVER );
  }
  
  @Test( expected = IllegalStateException.class )
  public void testAvoidsNullValues() {
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setNeedsPosition( NeedsPositionFlavor.NEVER.toString() );
    
    operator.set( operation );
  }
  
  @Test
  public void testSetsNeedPositionOnce() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setNeedsPosition( NeedsPositionFlavor.ONCE.toString() );
    
    operator.set( operation );
    
    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.ONCE );
  }
  
  @Test
  public void testSetsNeedPositionContinous() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setNeedsPosition( NeedsPositionFlavor.CONTINUOUS.toString() );
    
    operator.set( operation );
    
    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.CONTINUOUS );
  }
  
  @Test( expected = IllegalArgumentException.class )
  public void testSetsNeedPositionUnknown() {
    mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setNeedsPosition( "foo" );
    
    operator.set( operation );
  }
  
  @Test
  public void testSetsEnableHighAccuracyWithTrue() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setEnableHighAccuracy( true );
    
    operator.set( operation );
    
    verify( geolocation ).setEnableHighAccuracy( true );
  }
  
  @Test
  public void testSetsEnableHighAccuracyWithFalse() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setEnableHighAccuracy( false );
    
    operator.set( operation );
    
    verify( geolocation ).setEnableHighAccuracy( false );
  }
  
  @Test
  public void testSetsFrequency() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setFrequency( Integer.valueOf( 10 ) );
    
    operator.set( operation );
    
    verify( geolocation ).setFrequency( 10 );
  }
  
  @Test
  public void testSetsMaximumAge() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    SetProperties properties = createProperties( operation );
    properties.setMaximumAge( Integer.valueOf( 10 ) );
    
    operator.set( operation );
    
    verify( geolocation ).setMaximumAge( 10 );
  }
  
  @Test
  public void testNeedsPositionflavor() {
    assertEquals( NeedsPositionFlavor.ONCE, NeedsPositionFlavor.valueOf( "ONCE" ) );
    assertEquals( NeedsPositionFlavor.NEVER, NeedsPositionFlavor.valueOf( "NEVER" ) );
    assertEquals( NeedsPositionFlavor.CONTINUOUS, NeedsPositionFlavor.valueOf( "CONTINUOUS" ) );
  }

  private Geolocation mockGeolocation() {
    Geolocation geolocation = mock( Geolocation.class );
    when( toolkit.findObjectById( "foo", Geolocation.class ) ).thenReturn( geolocation );
    return geolocation;
  }

  private SetProperties createProperties( SetOperation operation ) {
    operation.setTarget( "foo" );
    SetProperties properties = new SetProperties();
    operation.setProperties( properties );
    return properties;
  }
  

}
