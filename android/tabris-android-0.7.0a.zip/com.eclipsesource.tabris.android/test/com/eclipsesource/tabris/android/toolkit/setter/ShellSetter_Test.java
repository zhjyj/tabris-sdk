/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapFactory;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ShellSetter_Test {

  private static final String MODE_VALUE = "modeValue";
  private TabrisActivity activity;
  private Shell shell;

  @Before
  public void setUp() {
    activity = mock( TabrisActivity.class );
    shell = mock( Shell.class );
  }

  @Test
  public void testSetterFound() {
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = new SetterManager( new TabrisActivity() ).getViewSetter();

    Assert.assertTrue( "ShellSetter not found in SetterUtil's list of setters.",
                       viewSetter.containsKey( Shell.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    setter.execute( mock( Shell.class ), null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test
  public void testSetModeToValue() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setMode( MODE_VALUE );

    setter.execute( shell, props );

    verify( shell ).setMode( MODE_VALUE );
  }

  @Test
  public void testShouldApplyModeBeforeVisibility() throws Exception {
    SetProperties properties = new SetProperties();
    properties.setVisibility( true );
    properties.setMode( MODE_VALUE );
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Shell shell = mock( Shell.class );

    setter.execute( shell, properties );

    InOrder inOrder = inOrder( shell );
    inOrder.verify( shell ).setMode( MODE_VALUE );
    inOrder.verify( shell ).playShowAnimation( activity );
  }

  @Test
  public void testSetModeToNull() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setMode( null );

    setter.execute( shell, props );

    verify( shell ).setMode( null );
  }

  @Test
  public void testSetModeNotSet() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    SetProperties props = new SetProperties();

    setter.execute( shell, props );

    verify( shell, never() ).setMode( any( String.class ) );
  }

  @Test
  public void testAnimatedIfSetVisible() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    SetProperties props = new SetProperties();
    props.setVisibility( true );

    setter.execute( shell, props );

    verify( shell ).playShowAnimation( eq( activity ) );
  }

  @Test
  public void testAnimatedIfSetInvisible() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    SetProperties props = new SetProperties();
    props.setVisibility( false );

    setter.execute( shell, props );

    verify( shell ).playHideAnimation( eq( activity ) );
  }

  @Test
  public void testSetText() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setText( "foo" );

    setter.execute( shell, props );

    verify( shell ).setText( eq( "foo" ) );
  }

  @Test
  public void testSetNullText() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setText( null );

    setter.execute( shell, props );

    verifyNoMoreInteractions( shell );
  }

  @Test
  public void testSetIcon() {
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    SetProperties props = new SetProperties();
    props.setImage( Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    when( cache.get( props.getImage().get( 0 ) ) ).thenReturn( mock( BitmapDrawable.class ) );
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Shell shell = new Shell( activity, mock( ShellAnimationSupport.class ) );
    DialogHeader dialogHeader = new DialogHeader( activity );
    BitmapDrawable drawable = mock( BitmapDrawable.class );
    dialogHeader.setIcon( drawable );
    shell.setHeader( dialogHeader );

    setter.execute( shell, props );

    assertNotSame( drawable, shell.getHeader().getIcon().getDrawable() );
    verify( cache ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }

}
