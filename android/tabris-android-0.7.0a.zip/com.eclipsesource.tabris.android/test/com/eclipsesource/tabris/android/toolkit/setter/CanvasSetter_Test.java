/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CanvasSetter_Test {

  @Test
  public void testSetCustomVariantNull() {
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( null );
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas ).setClientDrawingEnabled( false );
  }

  @Test
  public void testSetCustomVariantDefault() {
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( SetProperties.NOT_MODIFIFED );
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas, never() ).setClientDrawingEnabled( anyBoolean() );
  }

  @Test
  public void testSetCustomVariantClientCanvas() {
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( ICustomVariants.CLIENT_CANVAS );
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas ).setClientDrawingEnabled( true );
  }
}
