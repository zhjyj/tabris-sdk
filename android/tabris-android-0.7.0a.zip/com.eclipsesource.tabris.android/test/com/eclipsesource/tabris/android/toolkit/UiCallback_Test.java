/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.UiCallback;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class UiCallback_Test {

  class UiCallbackUnderTest extends UiCallback {

    public UiCallbackUnderTest( TabrisActivity activity ) {
      super( activity );
    }

    @Override
    protected Thread createNewThread() {
      return mock( Thread.class );
    }

    @Override
    public boolean callbackIsActive() {
      return getThread() != null;
    }
  }

  @Test
  public void testSetActiveTrue() {
    TabrisActivity activity = mock( TabrisActivity.class );
    UiCallback uiCallback = new UiCallbackUnderTest( activity );

    uiCallback.setActive( true );

    verify( uiCallback.getThread() ).start();
    verify( activity ).registerReceiver( eq( uiCallback ), any( IntentFilter.class ) );
    verifyNoMoreInteractions( activity );
  }

  @Test
  public void testSetActiveFalse() {
    TabrisActivity activity = mock( TabrisActivity.class );
    UiCallback uiCallback = new UiCallbackUnderTest( activity );

    uiCallback.setActive( true );
    uiCallback.setActive( false );

    verify( activity ).registerReceiver( eq( uiCallback ), any( IntentFilter.class ) );
    verify( uiCallback.getThread() ).interrupt();
    verify( activity ).unregisterReceiver( eq( uiCallback ) );
    verifyNoMoreInteractions( activity );
  }

  @Test
  public void testOnReceiveStartsCallback() throws Exception {
    TabrisActivity activity = mock( TabrisActivity.class );
    UiCallback uiCallback = new UiCallbackUnderTest( activity );

    Intent intent = new Intent( ConnectivityManager.CONNECTIVITY_ACTION );
    intent.putExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY, false );
    uiCallback.onReceive( activity, intent );

    verify( uiCallback.getThread() ).start();
  }

  @Test
  public void testOnReceiveStopsCallback() throws Exception {
    TabrisActivity activity = mock( TabrisActivity.class );
    UiCallback uiCallback = new UiCallbackUnderTest( activity );
    uiCallback.setActive( true );

    Intent intent = new Intent( ConnectivityManager.CONNECTIVITY_ACTION );
    intent.putExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY, true );
    uiCallback.onReceive( activity, intent );

    verify( uiCallback.getThread() ).interrupt();
  }
}
