/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.*;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.parser.gson.GenericObjectDeserializer;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

public class GenericObjectDeserializer_Test {

  private Type type;
  private JsonDeserializationContext context;
  private GenericObjectDeserializer deserializer;

  @Before
  public void setUp() {
    type = Mockito.mock( Type.class );
    context = Mockito.mock( JsonDeserializationContext.class );
    deserializer = new GenericObjectDeserializer();
  }

  @Test
  public void testDeserializeNoneJsonArray() {
    GenericObject result = deserializer.deserialize( null, type, context );

    assertNull( result );
  }

  @Test
  public void testPrimitiveBoolean() {
    GenericObject go = deserializer.deserialize( new JsonPrimitive( true ), type, context );

    assertNotNull( go.getObjectAs( Boolean.class ) );
  }

  @Test
  public void testPrimitiveInteger() {
    int expectedValue = 42;

    assertNotNull( deserializer.deserialize( new JsonPrimitive( expectedValue ), type, context ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPrimitiveBooleanAsInt() {
    GenericObject go = deserializer.deserialize( new JsonPrimitive( true ), type, context );

    go.getObjectAs( Integer.class );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testArrayAsList() {
    JsonArray array = createJsonArray();
    GenericObject go = deserializer.deserialize( array, type, context );

    List<String> listFromArray = go.getObjectAs( List.class );

    assertNotNull( listFromArray );
    assertEquals( 3, listFromArray.size() );
  }

  private JsonArray createJsonArray() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "1" ) );
    array.add( new JsonPrimitive( "2" ) );
    array.add( new JsonPrimitive( "3" ) );
    return array;
  }

  private JsonObject createJsonObject() {
    JsonObject object = new JsonObject();
    object.addProperty( "booleanField", false );
    object.addProperty( "stringField", "test" );
    object.addProperty( "intField", 42 );
    return object;
  }

  @Test
  public void testEmptyObjectAsHashMap() {
    JsonObject object = new JsonObject();
    GenericObject go = deserializer.deserialize( object, type, context );

    @SuppressWarnings("unchecked")
    Map<String, Object> mapFromEmptyObject = go.getObjectAs( Map.class );

    assertNotNull( mapFromEmptyObject );
    assertTrue( mapFromEmptyObject.isEmpty() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testObjectAsHashMap() {
    JsonObject object = createJsonObject();
    GenericObject go = deserializer.deserialize( object, type, context );

    Map<String, Object> mapFromObject = go.getObjectAs( Map.class );

    assertNotNull( mapFromObject );
    assertEquals( 3, mapFromObject.size() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testNestedObjectsAndArraysAsHashMap() {
    JsonObject object = createJsonObject();
    object.add( "objectField", createJsonObject() );
    object.add( "arrayField", createJsonArray() );
    GenericObject go = deserializer.deserialize( object, type, context );

    Map<String, Object> mapFromNestedObjects = go.getObjectAs( Map.class );

    assertNotNull( mapFromNestedObjects );
    assertEquals( 5, mapFromNestedObjects.size() );
  }

}
