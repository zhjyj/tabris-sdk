/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CompoundButtonSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    CompoundButtonSetter<CompoundButton> setter = new CompoundButtonSetter<CompoundButton>( new TabrisActivity() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    CompoundButtonSetter<CompoundButton> setter = new CompoundButtonSetter<CompoundButton>( new TabrisActivity() );
    setter.execute( mock( CompoundButton.class ), null );
  }

  @Test
  public void testSetSelectionTrue() throws Exception {
    CompoundButtonSetter<CompoundButton> setter = new CompoundButtonSetter<CompoundButton>( new TabrisActivity() );
    CompoundButton view = mock( CompoundButton.class );
    SetProperties props = new SetProperties();
    props.setSelection( new GenericObject( true ) );

    setter.execute( view, props );

    verify( view ).setChecked( true );
  }

  @Test
  public void testSetSelectionFalse() throws Exception {
    CompoundButtonSetter<CompoundButton> setter = new CompoundButtonSetter<CompoundButton>( new TabrisActivity() );
    CompoundButton view = mock( CompoundButton.class );
    SetProperties props = new SetProperties();
    props.setSelection( new GenericObject( false ) );

    setter.execute( view, props );

    verify( view ).setChecked( false );
  }

  @Test
  public void testSetSelectionNull() throws Exception {
    CompoundButtonSetter<CompoundButton> setter = new CompoundButtonSetter<CompoundButton>( new TabrisActivity() );
    CompoundButton view = mock( CompoundButton.class );
    SetProperties props = new SetProperties();

    setter.execute( view, props );

    verifyNoMoreInteractions( view );
  }
}
