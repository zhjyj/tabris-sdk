/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.MotionEvent;
import android.view.View;

import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ConsumingTouchListener_Test {

  @Test
  public void testOnTouch() {
    ConsumingTouchListener listener = new ConsumingTouchListener();

    boolean consumes = listener.onTouch( mock( View.class ), MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertTrue( consumes );
  }
}
