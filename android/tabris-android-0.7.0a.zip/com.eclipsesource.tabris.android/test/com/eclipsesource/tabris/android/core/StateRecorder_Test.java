/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Collection;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.AbstractState;
import com.eclipsesource.tabris.android.toolkit.view.state.SimpleTestState;

public class StateRecorder_Test {

  final String paramX = "x";
  final String paramY = "y";

  private class TestState extends AbstractState {

    public TestState( String widgetID ) {
      super( widgetID );
    }

    @Override
    public String generateKey() {
      return null;
    }

    @Override
    public String generateValue() {
      return null;
    }

  }

  private IState createStateMock() {
    return createStateMock( paramX, paramY );
  }

  private IState createStateMock( String param1, String param2 ) {
    IState stateMock = mock( AbstractState.class );
    when( stateMock.generateKey() ).thenReturn( param1 );
    when( stateMock.generateValue() ).thenReturn( param2 );
    return stateMock;
  }

  @Test
  public void testRecordState() {
    StateRecorder recorder = new StateRecorder();
    IState stateMock = createStateMock();

    recorder.recordState( stateMock );

    Collection<IState> recording = recorder.getRecording();
    assertFalse( recording.isEmpty() );
    boolean stateFound = false;
    for( IState state : recording ) {
      if( state.generateKey() == paramX && state.generateValue() == paramY ) {
        stateFound = true;
      }
    }
    assertTrue( stateFound );
  }

  @Test
  public void testClearRecordedState() {
    StateRecorder recorder = new StateRecorder();
    IState stateMock = createStateMock();
    recorder.recordState( stateMock );
    Collection<IState> recording = recorder.getRecording();
    assertFalse( recording.isEmpty() );

    recorder.clearRecordedState();

    assertTrue( recorder.getRecording().isEmpty() );
  }

  @Test
  public void testRecordModifiedState() {
    StateRecorder recorder = new StateRecorder();
    IState state = new SimpleTestState( "w1", paramX, paramY );
    IState otherState = new SimpleTestState( "w1", "A", "B" );
    assertEquals( state, otherState );

    recorder.recordState( state );
    recorder.recordState( otherState );

    Collection<IState> recording = recorder.getRecording();
    assertFalse( recording.isEmpty() );
    assertEquals( 1, recording.size() );
    assertFalse( recording.iterator().next() == state );
    assertTrue( recording.iterator().next() == otherState );
    assertTrue( recording.contains( otherState ) );
    // beware that the following is also true!
    assertTrue( recording.contains( state ) );
  }

  @Test
  public void testRecordDifferentStates() {
    StateRecorder recorder = new StateRecorder();
    IState state = new SimpleTestState( "w1", paramX, paramY );
    IState otherState = new TestState( "w1" );
    assertFalse( state.hashCode() == otherState.hashCode() );

    recorder.recordState( state );
    recorder.recordState( otherState );

    Collection<IState> recording = recorder.getRecording();
    assertFalse( recording.isEmpty() );
    assertEquals( 2, recording.size() );
    assertTrue( recording.contains( otherState ) );
    assertTrue( recording.contains( state ) );
  }
}
