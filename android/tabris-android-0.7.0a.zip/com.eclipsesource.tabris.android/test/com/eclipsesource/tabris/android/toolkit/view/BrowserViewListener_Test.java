/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.MotionEvent;
import android.view.View;

import com.eclipsesource.tabris.android.toolkit.view.BrowserViewListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BrowserViewListener_Test {

  @Test
  public void testRequestFocusOnTouchUp() {
    testRequestFocusOnTouch( MotionEvent.ACTION_UP );
  }

  @Test
  public void testRequestFocusOnTouchDown() {
    testRequestFocusOnTouch( MotionEvent.ACTION_DOWN );
  }

  private void testRequestFocusOnTouch( int action ) {
    BrowserViewListener listener = new BrowserViewListener();
    View view = mock( View.class );
    when( view.hasFocus() ).thenReturn( false );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, action, 10f, 30f, 0 );

    listener.onTouch( view, motionEvent );

    verify( view ).requestFocus();
  }

  @Test
  public void testNoRequestFocusOnTouchUp() {
    testNoRequestFocusOnTouch( MotionEvent.ACTION_UP );
  }

  @Test
  public void testNoRequestFocusOnTouchDown() {
    testNoRequestFocusOnTouch( MotionEvent.ACTION_DOWN );
  }

  private void testNoRequestFocusOnTouch( int action ) {
    BrowserViewListener listener = new BrowserViewListener();
    View view = mock( View.class );
    when( view.hasFocus() ).thenReturn( true );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, action, 10f, 30f, 0 );

    listener.onTouch( view, motionEvent );

    verify( view, never() ).requestFocus();
  }

  @Test
  public void testRequestFocusOnTouchMove() {
    BrowserViewListener listener = new BrowserViewListener();
    View view = mock( View.class );
    when( view.hasFocus() ).thenReturn( false );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, MotionEvent.ACTION_MOVE, 10f, 30f, 0 );

    listener.onTouch( view, motionEvent );

    verify( view, never() ).requestFocus();
  }

}
