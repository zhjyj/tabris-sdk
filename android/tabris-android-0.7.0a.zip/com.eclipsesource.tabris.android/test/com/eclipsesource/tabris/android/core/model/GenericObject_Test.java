/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.GenericObject;

public class GenericObject_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testCreationFromNull() {
    new GenericObject( null );
  }

  @Test
  public void testGetObjectAsString() {
    GenericObject o = new GenericObject( new String( "hello world" ) );

    String s = o.getObjectAs( String.class );

    assertNotNull( s );
    assertTrue( s.equals( "hello world" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetObjectAsWrongType() {
    GenericObject o = new GenericObject( new String( "hello world" ) );

    o.getObjectAs( Integer.class );
  }
}
