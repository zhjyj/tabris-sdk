/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.eclipsesource.tabris.android.parser.gson.RequiredFieldsDeserializer;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

public class RequiredFieldsDeserializer_Test {

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("rawtypes")
  public void testDeserializeNullConstructor() {
    new RequiredFieldsDeserializer( ( String[] )null );
  }

  @Test
  public void testDeserializeEmptyArrayConstructor() {
    RequiredFieldsDeserializer<Meta> deserializer = new RequiredFieldsDeserializer<Meta>( new String[]{} );

    Meta meta = deserializer.deserialize( new JsonObject(),
                                          Meta.class,
                                          mock( JsonDeserializationContext.class ) );

    assertNotNull( meta );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDeserializenNullJson() {
    RequiredFieldsDeserializer<Meta> deserializer = new RequiredFieldsDeserializer<Meta>( new String[]{} );

    deserializer.deserialize( null, Meta.class, mock( JsonDeserializationContext.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDeserializeNullType() {
    RequiredFieldsDeserializer<Meta> deserializer = new RequiredFieldsDeserializer<Meta>( new String[]{} );

    deserializer.deserialize( new JsonObject(), null, mock( JsonDeserializationContext.class ) );
  }

  @Test
  public void testDeserializeOk() {
    RequiredFieldsDeserializer<Meta> deserializer = new RequiredFieldsDeserializer<Meta>( new String[]{} );

    JsonObject obj = new JsonObject();
    obj.addProperty( "requestCounter", 123 );
    Meta meta = deserializer.deserialize( obj, Meta.class, mock( JsonDeserializationContext.class ) );

    assertEquals( 123, meta.getRequestCounter() );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeWithActiveFilter() {
    RequiredFieldsDeserializer<Meta> deserializer = new RequiredFieldsDeserializer<Meta>( new String[]{
      "requestCounter"
    } );

    deserializer.deserialize( new JsonObject(), Meta.class, mock( JsonDeserializationContext.class ) );
  }
}
