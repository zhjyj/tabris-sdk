/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
public class ErrorDialog_Test {

  class TestErrorDialog extends ErrorDialog {

    private Dialog delegate;

    public TestErrorDialog( final Activity activity, AndroidWidgetToolkit awt ) {
      super( activity, awt );
    }

    @Override
    protected Dialog getDialogDelegate( Activity activity ) {
      if( delegate == null ) {
        delegate = mock( Dialog.class );
      }
      return delegate;
    }
  }

  @Test
  public void testShowFirstTime() {
    AndroidWidgetToolkit awt = mock( AndroidWidgetToolkit.class );
    ErrorDialog errorDialog = new ErrorDialog( new Activity(), awt );
    Exception exception = new Exception( "Message" );

    errorDialog.show( exception );
    errorDialog.run();

    AlertDialog dialog = errorDialog.getDialog();
    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    assertEquals( "Message", shadowDialog.getMessage() );
    verify( awt ).executeInUiThread( errorDialog );
  }

  @Test
  public void testShowSecondTime() {
    AndroidWidgetToolkit awt = mock( AndroidWidgetToolkit.class );
    ErrorDialog errorDialog = new ErrorDialog( new Activity(), awt );
    Exception exception = new Exception( "Message" );

    errorDialog.show( exception );
    errorDialog.run();
    errorDialog.show( exception );
    errorDialog.run();

    verify( awt ).executeInUiThread( errorDialog );
    verifyNoMoreInteractions( awt );
  }

  @Test
  public void testButtons() {
    AndroidWidgetToolkit awt = mock( AndroidWidgetToolkit.class );
    Activity activity = new Activity();

    TestErrorDialog errorDialog = new TestErrorDialog( activity, awt );

    verify( errorDialog.getDialogDelegate( activity ) ).setButton( eq( DialogInterface.BUTTON_NEGATIVE ),
                                                                   anyString(),
                                                                   isA( ErrorDialog.ActivityFinishListener.class ) );
    verify( errorDialog.getDialogDelegate( activity ) ).setButton( eq( DialogInterface.BUTTON_POSITIVE ),
                                                                   anyString(),
                                                                   isA( ErrorDialog.ActivityRestartListener.class ) );
    verify( errorDialog.getDialogDelegate( activity ) ).setButton( eq( DialogInterface.BUTTON_NEUTRAL ),
                                                                   anyString(),
                                                                   isA( ErrorDialog.DialogCancelListener.class ) );
  }

  @Test
  public void testActivityFinishListener() {
    Activity activity = spy( UiTestUtil.createActivityWithMockedFields() );
    ErrorDialog.ActivityFinishListener listener = new ErrorDialog.ActivityFinishListener( activity );

    listener.onClick( mock( Dialog.class ), 23 );

    verify( activity ).finish();
  }

  @Test
  public void testActivityRestartListener() {
    Activity activity = spy( UiTestUtil.createActivityWithMockedFields() );
    ErrorDialog.ActivityRestartListener listener = new ErrorDialog.ActivityRestartListener( activity );

    listener.onClick( mock( Dialog.class ), 23 );

    verify( activity ).finish();
    verify( activity ).startActivity( activity.getIntent() );
  }

  @Test
  public void testDialogCaListener() {
    Dialog dialogToCancel = mock( Dialog.class );
    ErrorDialog.DialogCancelListener listener = new ErrorDialog.DialogCancelListener();

    listener.onClick( dialogToCancel, 23 );

    verify( dialogToCancel ).cancel();
  }
}
