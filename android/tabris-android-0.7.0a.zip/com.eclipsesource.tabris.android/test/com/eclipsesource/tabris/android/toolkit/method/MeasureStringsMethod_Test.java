/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.method;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.toolkit.method.MeasureStringsMethod;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class MeasureStringsMethod_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithMissingParam() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = new CallProperties();
    props.put( "someKey", "someValue" );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithNullStringsParam() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = new CallProperties();
    props.put( MeasureStringsMethod.PARAM_STRINGS, null );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithOneDimensionalStringsParam() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = new CallProperties();
    props.put( MeasureStringsMethod.PARAM_STRINGS, new ArrayList<Object>() );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigParam() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = new CallProperties();
    ArrayList<Object> value = new ArrayList<Object>();
    value.add( 123 );
    props.put( MeasureStringsMethod.PARAM_STRINGS, value );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigId() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = createProps( Arrays.asList( "123456" ) );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigText() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = createProps( Arrays.asList( 123456, 123 ) );

    method.call( props );
  }

  @SuppressWarnings("unchecked")
  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigFont() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = createProps( Arrays.asList( 123456, "123", "font" ) );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigSize() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = createProps( Arrays.asList( 123456, "123", Arrays.asList(), "12" ) );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigBold() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( mock( IWidgetToolkit.class ) );
    MeasureStringsMethod method = new MeasureStringsMethod( processor );
    CallProperties props = createProps( Arrays.asList( 123456, "123", Arrays.asList(), 12, "true" ) );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigItalic() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( mock( IWidgetToolkit.class ) );
    MeasureStringsMethod method = new MeasureStringsMethod( processor );
    List<Object> input = Arrays.asList( 123456, "123", Arrays.asList(), 12, true, "false" );
    CallProperties props = createProps( input );

    method.call( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithIllegalStringConfigBadFont() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( mock( IWidgetToolkit.class ) );
    MeasureStringsMethod method = new MeasureStringsMethod( processor );
    List<Object> input = Arrays.asList( 123456, "123", Arrays.asList( 123 ), 12, true, false );
    CallProperties props = createProps( input );

    method.call( props );
  }

  @Ignore("Can not properly get the Typface for the font while not running on physical devive. Maybe create ShadowTypeface object.")
  @Test
  public void testCallOk() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    List<String> fonts = Arrays.asList( "Verdana",
                                        "Lucida Sans",
                                        "Arial",
                                        "Helvetica",
                                        "sans-serif" );
    CallProperties props = createProps( Arrays.asList( 123456, "123", fonts, 12, true, false ) );

    method.call( props );
  }

  @SuppressWarnings("rawtypes")
  private CallProperties createProps( List config ) {
    CallProperties props = new CallProperties();
    ArrayList<Object> value = new ArrayList<Object>();
    value.add( config );
    props.put( MeasureStringsMethod.PARAM_STRINGS, value );
    return props;
  }

  @Ignore("Can not properly get the Typface for the font while not running on physical devive. Maybe create ShadowTypeface object.")
  @Test
  public void testCallIndirectlyOk() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    List<String> fonts = Arrays.asList( "Verdana",
                                        "Lucida Sans",
                                        "Arial",
                                        "Helvetica",
                                        "sans-serif" );
    CallProperties props = createProps( Arrays.asList( 123456, "123", fonts, 12, true, false ) );

    method.callIndirectly( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallIndirectlyWithMissingParam() {
    MeasureStringsMethod method = new MeasureStringsMethod( mock( ProtocolProcessor.class ) );
    CallProperties props = new CallProperties();
    props.put( "someKey", "someValue" );

    method.callIndirectly( props );
  }

}
