/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;

public class ObservableHorizontalScrollViewSetter<T extends ObservableHorizontalScrollView>
  extends ViewSetter<T>
{

  public ObservableHorizontalScrollViewSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T view, Properties properties ) {
    super.execute( view, properties );
    setOrigin( view, properties );
  }

  private void setOrigin( ObservableHorizontalScrollView view, Properties properties ) {
    List<Integer> origin = properties.getList( ProtocolConstants.PROP_ORIGIN, Integer.class );
    if( origin != null ) {
      if( origin.size() < 2 ) {
        throw new IllegalArgumentException( "The origin property for scrolling has to have two params (x and y coords)" );
      }
      IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
      int x = toolkit.multiplyByDensityFactor( origin.get( 0 ) );
      int y = toolkit.multiplyByDensityFactor( origin.get( 1 ) );
      view.doSmoothScrollTo( x, y );
    }
  }

}