
package com.eclipsesource.tabris.android.toolkit.view;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.ColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.eclipsesource.tabris.android.TabrisActivity;

public class ShowTouchListener implements OnTouchListener {

  private final android.graphics.Canvas canvas;
  private final ColorFilter colorFilter;
  private ImageView imageView;
  private Bitmap bitmap;

  public ShowTouchListener( TabrisActivity activity ) {
    imageView = new ImageView( activity );
    canvas = new android.graphics.Canvas();
    colorFilter = new LightingColorFilter( 0xff666666, 0x00000000 );
  }

  public boolean onTouch( View view, MotionEvent event ) {
    int action = event.getAction();
    if( action == MotionEvent.ACTION_DOWN ) {
      showTouch( view );
    } else if( action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL ) {
      hideTouch();
    }
    return true;
  }

  private void showTouch( View view ) {
    bitmap = renderViewToBitmap( view );
    BitmapDrawable drawable = createBitmapDrawable( view, bitmap, colorFilter );
    imageView.setImageDrawable( drawable );
    imageView.setLayoutParams( view.getLayoutParams() );
    addViewOnTop( imageView, view );
  }

  private Bitmap renderViewToBitmap( View view ) {
    Bitmap bitmap = Bitmap.createBitmap( view.getWidth(), view.getHeight(), Config.ARGB_8888 );
    canvas.setBitmap( bitmap );
    view.draw( canvas );
    return bitmap;
  }

  private static BitmapDrawable createBitmapDrawable( View view, Bitmap bitmap, ColorFilter filter )
  {
    BitmapDrawable drawable = new BitmapDrawable( view.getContext().getResources(), bitmap );
    drawable.setColorFilter( filter );
    return drawable;
  }

  private static void addViewOnTop( View topView, View bottomView ) {
    ViewGroup viewParent = ( ViewGroup )bottomView.getParent();
    viewParent.addView( topView );
    topView.bringToFront();
  }

  private void hideTouch() {
    ( ( ViewGroup )imageView.getParent() ).removeView( imageView );
    bitmap.recycle();
  }

  /** To be used for testing only. */
  void setImageView( ImageView imageView ) {
    this.imageView = imageView;
  }

  /** To be used for testing only. */
  void setBitmap( Bitmap bitmap ) {
    this.bitmap = bitmap;
  }

}