/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ListSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DelegatingItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListItemLongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ScrollListener;
import com.eclipsesource.tabris.android.toolkit.view.TouchPositionBuffer;

public class ListOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.List";

  private final IViewSetter<? extends View> setter;

  public ListOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ListSetter<List>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List list = new List( getActivity() );
    initiateNewView( operation, list );
    registerDefaultListeners( list );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    String target = operation.getTarget();
    ListenerRegistry registry = getListenerRegistry();
    List list = findObjectById( target, List.class );
    list.setOnScrollListener( null );
    registry.unregisterListener( target, ScrollListener.class );
    registry.unregisterListener( target, TouchPositionBuffer.class );
    super.destroy( operation );
  }

  private void registerDefaultListeners( final List list ) {
    String widgetId = getObjectId( list );
    IWidgetToolkit toolkit = getActivity().getProcessor().getWidgetToolkit();
    registerTouchPositionBuffer( widgetId, toolkit );
    final OnItemClickListener compositeListItemClickListener = registerRecordingListItemClickListener( list );
    list.setOnItemSelectedListener( new DelegatingItemSelectedListener( compositeListItemClickListener ) );
    registerScrollListener( list );
  }

  private OnItemClickListener registerRecordingListItemClickListener( final List list ) {
    CompositeItemClickListener compositeListener = new CompositeItemClickListener();
    list.setOnItemClickListener( compositeListener );
    final ListItemClickListener recordingListItemClickListener;
    recordingListItemClickListener = new ListItemClickListener( getActivity() );
    compositeListener.addListener( recordingListItemClickListener );
    return compositeListener;
  }
  
  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    // Do nothing
  }
  
  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    // Do nothing
  }

  private void registerTouchPositionBuffer( String widgetId, IWidgetToolkit toolkit ) {
    TouchPositionBuffer touchPositionBuffer = new TouchPositionBuffer( toolkit );
    getListenerRegistry().registerListener( widgetId, touchPositionBuffer );
    getCompositeTouchListener( widgetId ).addListener( touchPositionBuffer );
  }

  private CompositeTouchListener getCompositeTouchListener( String widgetId ) {
    return getListenerRegistry().findListener( widgetId, CompositeTouchListener.class );
  }

  @Override
  protected void attachMenuDetectListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    list.setOnItemLongClickListener( new ListItemLongClickListener( getActivity() ) );
  }

  @Override
  protected void removeMenuDetectListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    list.setOnItemLongClickListener( null );
    list.setLongClickable( false );
  }

  private void registerScrollListener( final List list ) {
    ScrollListener scrollListener = new ScrollListener( getActivity() );
    list.setOnScrollListener( scrollListener );
  }

}
