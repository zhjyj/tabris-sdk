/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class TreeItemViewSetter<T extends TreeItemView> implements IViewSetter<TreeItemView> {

  private final TabrisActivity activity;

  public TreeItemViewSetter( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void execute( TreeItemView view, Properties properties ) {
    notNull( view, "View" );
    notNull( properties, "Properties" );
    setTexts( view, properties );
    setColors( view, properties );
    setImages( view, properties );
    setExpanded( view, properties );
    setItemCount( view, properties );
  }

  private void setColors( TreeItemView view, Properties properties ) {
    List<List<Integer>> cellForegrounds = properties.getMatrix( ProtocolConstants.PROP_CELL_FOREGROUNDS,
                                                                Integer.class );
    List<List<Integer>> cellBackgrounds = properties.getMatrix( ProtocolConstants.PROP_CELL_BACKGROUNDS,
                                                                Integer.class );
    setForegroundColors( view, cellForegrounds );
    setBackgroundColors( view, cellBackgrounds );
  }

  private void setForegroundColors( TreeItemView view, List<List<Integer>> cellForegrounds ) {
    if( cellForegrounds != null ) {
      if( cellForegrounds.size() > 0 ) {
        view.setForegroundCellColors( parseColors( cellForegrounds ) );
      }
    }
  }

  private void setBackgroundColors( TreeItemView view, List<List<Integer>> cellBackgrounds ) {
    if( cellBackgrounds != null ) {
      if( cellBackgrounds.size() > 0 ) {
        view.setBackgroundCellColors( parseColors( cellBackgrounds ) );
      }
    }
  }

  private List<Integer> parseColors( List<List<Integer>> cellTuples ) {
    List<Integer> colors = new ArrayList<Integer>( cellTuples.size() );
    for( List<Integer> colorTuple : cellTuples ) {
      if( colorTuple == null ) {
        colors.add( null );
      } else {
        colors.add( ColorUtil.colorToupleToInt( colorTuple ) );
      }
    }
    return colors;
  }

  private void setItemCount( TreeItemView view, Properties properties ) {
    Integer itemCount = properties.getInteger( ProtocolConstants.PROP_ITEM_COUNT );
    if( itemCount != null ) {
      view.setItemCount( itemCount );
    }
  }

  private void setExpanded( TreeItemView treeItemView, Properties properties ) {
    Boolean expanded = properties.getBoolean( ProtocolConstants.PROP_EXPANDED );
    if( expanded != null ) {
      TreeView treeView = treeItemView.getTreeView();
      if( expanded ) {
        treeView.expandTree( treeItemView );
      } else {
        treeView.contractTree( treeItemView );
      }
    }
  }

  @SuppressWarnings("unchecked")
  private void setImages( final TreeItemView view, Properties properties ) {
    List<List<Object>> images = properties.getMatrix( ProtocolConstants.PROP_IMAGES, Object.class );
    if( images != null ) {
      new LoadImageTask( activity ) {

        @Override
        protected void onPostExecute( BitmapDrawable drawable ) {
          decreaseReferenceCount( activity.getProcessor(), view );
          view.setImage( drawable );
          view.getTreeView().refreshTree();
        }
      }.loadBitmap( images.get( 0 ) );
    }
  }

  private void setTexts( TreeItemView view, Properties properties ) {
    List<String> texts = properties.getList( ProtocolConstants.PROP_TEXTS, String.class );
    if( texts != null ) {
      if( texts.size() > 0 ) {
        view.setTexts( texts );
        view.getTreeView().refreshTree();
      }
    }
  }

  public static void decreaseReferenceCount( ProtocolProcessor processor, final TreeItemView view )
  {
    BitmapDrawable prevBitmapDrawable = view.getImage();
    BitmapDrawableCache cache = processor.getWidgetToolkit().getBitmapCache();
    cache.decreaseReferenceCount( prevBitmapDrawable );
  }

}
