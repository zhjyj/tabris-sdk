/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

class RequiredFieldsDeserializer<T> implements JsonDeserializer<T> {

  private final List<String> requiredFields;

  public RequiredFieldsDeserializer( String... fields ) {
    if( fields == null ) {
      throw new IllegalArgumentException( "The required fields can not be null" );
    }
    requiredFields = Arrays.asList( fields );
  }

  public T deserialize( JsonElement json, Type typeOfT, JsonDeserializationContext context )
    throws JsonParseException
  {
    validateInput( json, typeOfT );
    JsonObject jsonObject = ( JsonObject )json;

    for( String fieldName : requiredFields ) {
      if( jsonObject.get( fieldName ) == null ) {
        throw new ParseException( "Required field not found: " + fieldName );
      }
    }
    return createDeserializerGson().<T> fromJson( jsonObject, typeOfT );
  }

  private void validateInput( JsonElement json, Type typeOfT ) {
    if( json == null ) {
      throw new IllegalArgumentException( "The json element can not be null" );
    }
    if( typeOfT == null ) {
      throw new IllegalArgumentException( "The type of the target class can not be null" );
    }
    if( !( json instanceof JsonObject ) ) {
      throw new ParseException( "Only json objects can have required fields. Can't validate: "
                                + json.getClass().getName() );
    }
  }

  private Gson createDeserializerGson() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( Head.class, new HeadDeserializer() );
    return gsonBuilder.create();
  }
}