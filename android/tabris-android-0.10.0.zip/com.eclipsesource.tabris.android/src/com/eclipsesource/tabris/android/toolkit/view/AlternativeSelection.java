
package com.eclipsesource.tabris.android.toolkit.view;

public enum AlternativeSelection {
  ALL,
  LEAF,
  BRANCH
}
