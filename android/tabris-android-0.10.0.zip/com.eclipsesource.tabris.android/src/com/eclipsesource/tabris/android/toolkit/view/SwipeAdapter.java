
package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;

public class SwipeAdapter extends PagerAdapter {

  public static final int UNLOCKED = -1;

  private final TabrisActivity activity;
  private final Swipe swipe;
  private final List<SwipeItem> items;
  private final SwipeItemChangeListener listener;
  private int activeItemIndex;
  private int lockLeftIndex;
  private int lockRightIndex;

  class SwipeItemChangeListener implements OnPageChangeListener {

    private int currentIndex;

    public void onPageSelected( int position ) {
      int newIndex = getItemsWithinLocks().get( position ).getIndex();
      if( newIndex != currentIndex && newIndex != activeItemIndex ) {
        currentIndex = newIndex;
        HashMap<String, Object> properties = new HashMap<String, Object>();
        properties.put( "item", currentIndex );
        activity.getRemoteObject( SwipeAdapter.this ).notify( EVENT_SWIPED_TO_ITEM, properties );
      }
    }

    public void onPageScrolled( int position, float positionOffset, int positionOffsetPixels ) {
      // nothing to do here
    }

    public void onPageScrollStateChanged( int state ) {
      // nothing to do here
    }
  }

  static class SwipeItem implements Comparable<SwipeItem> {

    private final int index;
    private final View view;

    public SwipeItem( int index, View view ) {
      this.index = index;
      this.view = view;
    }

    public View getView() {
      return view;
    }

    public int getIndex() {
      return index;
    }

    public int compareTo( SwipeItem another ) {
      if( index < another.index ) {
        return -1;
      } else if( index > another.index ) {
        return 1;
      }
      return 0;
    }

  }

  public SwipeAdapter( final TabrisActivity activity, Swipe swipe ) {
    this.activity = activity;
    this.swipe = swipe;
    items = new ArrayList<SwipeItem>();
    listener = new SwipeItemChangeListener();
    lockLeftIndex = UNLOCKED;
    lockRightIndex = UNLOCKED;
    swipe.setOnPageChangeListener( listener );
  }

  @Override
  public int getCount() {
    return getItemsWithinLocks().size();
  }

  @Override
  public int getItemPosition( Object object ) {
    List<SwipeItem> itemsWithinLock = getItemsWithinLocks();
    for( int i = 0; i < itemsWithinLock.size(); i++ ) {
      SwipeItem swipeItem = itemsWithinLock.get( i );
      if( swipeItem.getView() == object ) {
        return i;
      }
    }
    return POSITION_NONE;
  }

  @Override
  public Object instantiateItem( ViewGroup container, int position ) {
    View view = getItemsWithinLocks().get( position ).getView();
    if( container.getChildAt( position ) != view ) {
      ( ( Swipe )container ).doAddView( view );
    }
    return view;
  }

  @Override
  public void destroyItem( ViewGroup container, int position, Object object ) {
    ( ( Swipe )container ).doRemoveView( ( View )object );
  }

  @Override
  public boolean isViewFromObject( View view, Object object ) {
    return view == object;
  }

  public void addItemAt( int index, String id ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    items.add( new SwipeItem( index, objectRegistry.getObject( id, View.class ) ) );
    applyChangedItemList();
  }

  public void removeItemsAt( List<Integer> indexList ) {
    for( int i = 0; i < indexList.size(); i++ ) {
      int position = getPositionForIndex( indexList.get( i ) );
      items.remove( position );
    }
    applyChangedItemList();
  }

  public void setActiveItem( int activeItemIndex ) {
    this.activeItemIndex = activeItemIndex;
    swipe.setCurrentItem( getPositionForIndex( activeItemIndex ), true );
  }

  public void lockLeft( int lockLeftIndex ) {
    this.lockLeftIndex = lockLeftIndex;
    applyChangedItemList();
  }

  public void lockRight( int lockRightIndex ) {
    this.lockRightIndex = lockRightIndex;
    applyChangedItemList();
  }

  void applyChangedItemList() {
    Collections.sort( items );
    swipe.setOnPageChangeListener( null );
    notifyDataSetChanged();
    swipe.setOffscreenPageLimit( getOffscreenPageLimit() );
    swipe.setOnPageChangeListener( listener );
  }

  private int getOffscreenPageLimit() {
    int curPos = swipe.getCurrentItem();
    int distanceToRight = getItemsWithinLocks().size() - curPos - 1;
    int distanceToLeft = curPos;
    return Math.max( distanceToLeft, distanceToRight );
  }

  private int getPositionForIndex( int index ) {
    for( int i = 0; i < items.size(); i++ ) {
      if( items.get( i ).getIndex() == index ) {
        return i;
      }
    }
    throw new IllegalStateException( "Could not get position for index " + index );
  }

  private List<SwipeItem> getItemsWithinLocks() {
    if( lockLeftIndex == UNLOCKED && lockRightIndex == UNLOCKED ) {
      return items;
    }
    ArrayList<SwipeItem> itemsWithinLocks = new ArrayList<SwipeItem>();
    for( int i = 0; i < items.size(); i++ ) {
      SwipeItem swipeItem = items.get( i );
      if( itemWithinLocks( swipeItem ) ) {
        itemsWithinLocks.add( swipeItem );
      }
    }
    return itemsWithinLocks;
  }

  private boolean itemWithinLocks( SwipeItem swipeItem ) {
    int index = swipeItem.getIndex();
    return index >= lockLeftIndex && ( index <= lockRightIndex || lockRightIndex == UNLOCKED );
  }

  /** To be used for testing only. */
  List<SwipeItem> getItems() {
    return items;
  }

}
