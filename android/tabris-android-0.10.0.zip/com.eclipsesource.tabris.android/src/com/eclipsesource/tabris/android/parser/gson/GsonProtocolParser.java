/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.eclipsesource.tabris.android.core.model.Action;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

public class GsonProtocolParser implements IProtocolParser {

  private static final String FIELD_HEAD = "head";
  private static final String FIELD_OPERATIONS = "operations";

  private final Set<IProtocolParserCallback> callbacks;
  private final Gson deserializer;
  private final Gson serializer;

  public GsonProtocolParser() {
    callbacks = new HashSet<IProtocolParserCallback>();
    deserializer = createDeserializerGson();
    serializer = createSerializerGson();
  }

  private Gson createDeserializerGson() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( Head.class, new HeadDeserializer() );
    gsonBuilder.registerTypeAdapter( Operation.class, new OperationDeserializer() );
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesDeserializer() );
    gsonBuilder.registerTypeAdapter( Action.class, new ActionDeserializer() );
    gsonBuilder.registerTypeAdapter( Font.class, new FontDeserializer() );
    gsonBuilder.registerTypeAdapter( GenericObject.class, new GenericObjectDeserializer() );
    return gsonBuilder.create();
  }

  private Gson createSerializerGson() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    OperationSerializer operationSerializer = new OperationSerializer();
    gsonBuilder.registerTypeAdapter( SetOperation.class, operationSerializer );
    gsonBuilder.registerTypeAdapter( CallOperation.class, operationSerializer );
    gsonBuilder.registerTypeAdapter( NotifyOperation.class, operationSerializer );
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesSerializer() );
    return gsonBuilder.create();
  }

  public void parse( InputStream is ) {
    if( is == null ) {
      throw new IllegalArgumentException( "Can not parse null input steam" );
    }
    parseDocument( is );
  }

  private void parseDocument( InputStream is ) {
    // is = new LoggingInputStream( is );
    JsonReader reader = null;
    try {
      reader = new JsonReader( new InputStreamReader( is ) );
      reader.setLenient( true );
      reader.beginObject();
      processHead( deserializer, reader );
      processOperations( deserializer, reader );
      reader.endObject();
    } catch( Exception e ) {
      throw new ParseException( "Could not read/parse json document", e );
    } finally {
      if( reader != null ) {
        try {
          reader.close();
        } catch( IOException e ) {
          throw new ParseException( "Could not close input stream from http response", e );
        }
      }
    }
  }

  private void processOperations( Gson gson, JsonReader reader ) throws IOException {
    ArrayList<Operation> operations = new ArrayList<Operation>();
    if( reader.hasNext() ) {
      String operationsField = reader.nextName();
      if( !operationsField.equals( FIELD_OPERATIONS ) ) {
        throw new ParseException( "No operations field in the protocol message." );
      }
      reader.beginArray();
      while( reader.hasNext() ) {
        Operation op = gson.fromJson( reader, Operation.class );
        operations.add( op );
      }
      reader.endArray();
    }
    fireOperationsFound( operations );
  }

  private void processHead( Gson gson, JsonReader reader ) throws IOException {
    String headField = reader.nextName();
    if( !headField.equals( FIELD_HEAD ) ) {
      throw new ParseException( "No head field in the protocol message." );
    }
    Head head = gson.fromJson( reader, Head.class );
    fireHeadFound( head );
  }

  private void fireHeadFound( Head head ) {
    for( IProtocolParserCallback callback : callbacks ) {
      callback.headFound( head );
    }
  }

  private void fireOperationsFound( ArrayList<Operation> ops ) {
    for( IProtocolParserCallback callback : callbacks ) {
      callback.operationsFound( ops );
    }
  }

  public void addProtocolParserCallback( IProtocolParserCallback callback ) {
    callbacks.add( callback );
  }

  public void removeProtocolParserCallback( IProtocolParserCallback callback ) {
    callbacks.remove( callback );
  }

  public String toJson( Object obj ) {
    return deserializer.toJson( obj );
  }

  public String createMessage( List<Operation> operations, Map<String, Object> headers ) {
    // need to be a sorted map because this parser implementation relies that
    // 'head' comes first
    Map<String, Object> message = new TreeMap<String, Object>();
    if( headers != null ) {
      message.put( FIELD_HEAD, headers );
    }
    message.put( FIELD_OPERATIONS, operations );
    return serializer.toJson( message );
  }

}
