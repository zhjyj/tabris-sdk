/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

public class SetAlphaBeforeStartAnimListener implements AnimationListener {

  private final ImageView viewToAnimate;
  private final int alpha;
  private final boolean remove;

  public SetAlphaBeforeStartAnimListener( ImageView viewToAnimate, int alpha, boolean remove ) {
    this.viewToAnimate = viewToAnimate;
    this.alpha = alpha;
    this.remove = remove;
  }

  public void onAnimationStart( Animation animation ) {
    viewToAnimate.setAlpha( alpha );
    if( remove ) {
      animation.setAnimationListener( null );
    }
  }

  public void onAnimationRepeat( Animation animation ) {
    // nothing to do here
  }

  public void onAnimationEnd( Animation animation ) {
    // nothing to do here
  }
}