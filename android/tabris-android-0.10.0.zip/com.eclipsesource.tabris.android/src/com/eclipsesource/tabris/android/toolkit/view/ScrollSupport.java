/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_HORIZONTAL_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_VERTICAL_SELECTION;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.Parent;

public class ScrollSupport {

  private final View view;
  private ScrollSupportDirection direction;
  private final IWidgetToolkit toolkit;
  private int scrollTargetX;
  private int scrollTargetY;
  private final TabrisActivity activity;

  public ScrollSupport( TabrisActivity activity, View view ) {
    this.activity = activity;
    this.view = view;
    direction = ScrollSupportDirection.X_AND_Y;
    ProtocolProcessor processor = activity.getProcessor();
    toolkit = processor.getWidgetToolkit();
  }

  protected void onScrollChanged( int x, int y, int oldx, int oldy ) {
    if( x != oldx || y != oldy ) {
      if( direction.supportsX() ) {
        handleScrollX( toolkit.divideByDensityFactor( x ) );
      }
      if( direction.supportsY() ) {
        handleScrollY( toolkit.divideByDensityFactor( y ) );
      }
      notifyScrollBars();
    }
  }

  private void handleScrollY( int y ) {
    scrollTargetY = y;
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.set( PROP_VERTICAL_SELECTION, scrollTargetY );
  }

  private void handleScrollX( int x ) {
    scrollTargetX = x;
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.set( PROP_HORIZONTAL_SELECTION, scrollTargetX );
  }

  private void notifyScrollBars() {
    if( view instanceof Parent ) {
      List<Object> children = ( ( Parent )view ).getChildren();
      for( int i = 0; i < children.size(); i++ ) {
        Object child = children.get( i );
        if( child instanceof ScrollBar ) {
          ( ( ScrollBar )child ).scrollChanged();
        }
      }
    }
  }

  public int getScrollTargetX() {
    return scrollTargetX;
  }

  public int getScrollTargetY() {
    return scrollTargetY;
  }

  public void setScrollTargetX( int scrollTargetX ) {
    this.scrollTargetX = scrollTargetX;
  }

  public void setScrollTargetY( int scrollTargetY ) {
    this.scrollTargetY = scrollTargetY;
  }

  public void setDirection( ScrollSupportDirection direction ) {
    this.direction = direction;
  }

  /** To be used for testing only */
  public ScrollSupportDirection getDirection() {
    return direction;
  }
}