
package com.eclipsesource.tabris.android.toolkit.setter;

import static android.view.KeyEvent.*;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;

import java.util.HashMap;
import java.util.Map;

import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.IKeyEventListener;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;

public class TreeBackKeyEventListener implements IKeyEventListener {

  private final TabrisActivity activity;
  private TreeView treeView;

  public TreeBackKeyEventListener( TabrisActivity activity ) {
    notNull( activity, "activity" );
    this.activity = activity;
  }

  public boolean onKeyEvent( KeyEvent keyEvent ) {
    boolean keyHandled = false;
    if( treeView == null ) {
      keyHandled = false;
    } else if( hasShellOnTop( treeView ) ) {
      keyHandled = false;
    } else if( isBackKey( keyEvent ) && treeView.isShowingRootTreeItem() ) {
      keyHandled = false;
    } else if( isBackKey( keyEvent ) ) {
      contractTree();
      keyHandled = true;
    }
    return keyHandled;
  }

  private boolean isBackKey( KeyEvent keyEvent ) {
    return keyEvent.getKeyCode() == KEYCODE_BACK;
  }

  private void contractTree() {
    TreeItemView treeItem = treeView.getParentTreeItem();
    setVirtualTreeTopItemIndex( treeItem );
    notifyRemoteObjects( treeItem );
    treeView.contractTree( treeItem );
  }

  private boolean hasShellOnTop( View view ) {
    Shell parentShell = getParentShell( view );
    if( parentShell != null ) {
      FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
      int childCount = rootLayout.getChildCount();
      for( int i = 0; i < childCount; i++ ) {
        View child = rootLayout.getChildAt( i );
        if( child instanceof Shell ) {
          Shell shell = ( Shell )child;
          if( shell == parentShell && childCount - 1 > i ) {
            return true;
          }
        }
      }
    }
    return false;
  }

  private Shell getParentShell( View view ) {
    if( view instanceof Shell ) {
      return ( Shell )view;
    } else if( view != null ) {
      return getParentShell( ( View )view.getParent() );
    }
    return null;
  }

  private void notifyRemoteObjects( TreeItemView selecteItem ) {
    RemoteObject treeRemoteObject = activity.getRemoteObject( treeView );
    RemoteObject selectedItemRemoteObject = activity.getRemoteObject( selecteItem );
    selectedItemRemoteObject.set( ProtocolConstants.PROP_EXPANDED, false );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, selectedItemRemoteObject.getId() );
    treeRemoteObject.notify( EVENT_COLLAPSE, properties );
  }

  private void setVirtualTreeTopItemIndex( TreeItemView selectedItem ) {
    if( treeView.hasVirtualTreeSupport() ) {
      VirtualTreeSupport virtualTreeSupport = treeView.getVirtualTreeSupport();
      virtualTreeSupport.reset();
      virtualTreeSupport.setTopItemIndex( treeView, selectedItem );
    }
  }

  public void setTreeView( TreeView treeView ) {
    this.treeView = treeView;
  }

  public TreeView getTreeView() {
    return treeView;
  }

}
