
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;

import java.util.Map;
import java.util.Map.Entry;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;

public abstract class AbstractOperator implements IOperator {

  private final TabrisActivity activity;

  public AbstractOperator( TabrisActivity activity ) {
    notNull( activity, "activity" );
    this.activity = activity;
  }

  protected TabrisActivity getActivity() {
    return activity;
  }

  protected ProtocolProcessor getProcessor() {
    return activity.getProcessor();
  }

  protected IWidgetToolkit getWidgetToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }

  protected ListenerRegistry getListenerRegistry() {
    return activity.getProcessor().getWidgetToolkit().getListenerRegistry();
  }

  protected ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

  protected <T> T findObjectById( String id, Class<? extends T> clazz ) {
    return getObjectRegistry().getObject( id, clazz );
  }

  protected String getObjectId( Object object ) {
    return getObjectRegistry().getRemoteObjectForObject( object ).getId();
  }

  protected void updateListenerOnRemoteObject( ListenOperation operation ) {
    RemoteObject remoteObject = getObjectRegistry().getRemoteObject( operation.getTarget() );
    Map<String, Object> properties = operation.getProperties().getAll();
    for( Entry<String, Object> entry : properties.entrySet() ) {
      if( entry.getValue() instanceof Boolean ) {
        Boolean shouldListen = ( Boolean )entry.getValue();
        if( shouldListen.booleanValue() ) {
          remoteObject.addListen( entry.getKey() );
        } else {
          remoteObject.removeListen( entry.getKey() );
        }
      }
    }
  }

  public void create( CreateOperation operation ) {
    // to be implemented by subclasses
  }

  public void set( SetOperation operation ) {
    // to be implemented by subclasses
  }

  public void listen( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  public void call( CallOperation operation ) {
    // to be implemented by subclasses
  }

  public void destroy( DestroyOperation operation ) {
    // to be implemented by subclasses
  }
}
