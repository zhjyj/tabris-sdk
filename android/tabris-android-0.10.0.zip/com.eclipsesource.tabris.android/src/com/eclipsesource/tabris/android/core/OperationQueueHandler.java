/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class OperationQueueHandler {

  private static final String BOUNDS = "bounds";

  private static final String ROOT_WIDGET_ID = "w1";

  private final ProtocolProcessor processor;
  private final List<List<Operation>> operationsBuffer;

  OperationQueueHandler( ProtocolProcessor processor ) {
    ParamCheck.notNull( processor, "ProtocollProcessor is reqired." );
    this.processor = processor;
    operationsBuffer = new ArrayList<List<Operation>>();
  }

  List<Operation> considerBuffer( List<Operation> operationsQueue ) {
    List<Operation> operationsToSend;
    if( operationsBuffer.isEmpty() ) {
      operationsToSend = fillBufferWithTailOfQueue( operationsQueue );
    } else {
      operationsToSend = operationsBuffer.remove( 0 );
      processor.send();
    }
    return operationsToSend;
  }

  private List<Operation> fillBufferWithTailOfQueue( List<Operation> operationsQueue ) {
    List<List<Operation>> queueParts = split( operationsQueue );
    List<Operation> operationsToSend = queueParts.remove( 0 );
    if( !queueParts.isEmpty() ) {
      operationsBuffer.addAll( queueParts );
      processor.send();
    }
    return operationsToSend;
  }

  /*
   * Split operations in two parts if set bounds on display is proceeded by
   * other operations. Workaround for RAP bug
   * https://bugs.eclipse.org/bugs/show_bug.cgi?id=397746
   */
  List<List<Operation>> split( List<Operation> operations ) {
    List<List<Operation>> result = new ArrayList<List<Operation>>();
    if( operations.size() > 1 ) {
      separateIntoHeadAndTail( operations, result );
    }
    if( result.isEmpty() ) {
      result.add( operations );
    }
    return result;
  }

  private void separateIntoHeadAndTail( List<Operation> operations, List<List<Operation>> result ) {
    int splitAtIndex = indexOfSetBoundsOnRootWidget( operations );
    if( splitAtIndex > 0 ) {
      List<Operation> remainder = operations.subList( splitAtIndex, operations.size() );
      List<Operation> tail = new ArrayList<Operation>( remainder );
      remainder.clear();
      result.add( operations );
      result.add( tail );
    }
  }

  private int indexOfSetBoundsOnRootWidget( List<Operation> operations ) {
    int result = -1;
    for( int i = 0; i < operations.size(); i++ ) {
      Operation operation = operations.get( i );
      if( operation instanceof SetOperation
          && operation.getTarget().equals( ROOT_WIDGET_ID )
          && ( ( SetOperation )operation ).getProperties().hasProperty( BOUNDS ) )
      {
        result = i;
        break;
      }
    }
    return result;
  }

  List<Operation> optimizeSetOperations( List<Operation> operations ) {
    List<Operation> result = new ArrayList<Operation>();
    SetOperation lastSetOperation = null;
    for( Operation operation : operations ) {
      if( operation instanceof SetOperation ) {
        lastSetOperation = mergeProperties( result, lastSetOperation, ( SetOperation )operation );
      } else {
        if( lastSetOperation != null ) {
          result.add( lastSetOperation );
          lastSetOperation = null;
        }
        result.add( operation );
      }
    }
    if( lastSetOperation != null ) {
      result.add( lastSetOperation );
    }
    return result;
  }

  private SetOperation mergeProperties( List<Operation> result,
                                        SetOperation lastSetOperation,
                                        SetOperation setOperation )
  {
    SetOperation currentSetOperation = setOperation;
    if( lastSetOperation == null ) {
      lastSetOperation = currentSetOperation;
    } else if( lastSetOperation.getTarget().equals( currentSetOperation.getTarget() ) ) {
      Map<String, Object> properties = currentSetOperation.getProperties().getAll();
      lastSetOperation.getProperties().add( properties );
    } else {
      result.add( lastSetOperation );
      lastSetOperation = currentSetOperation;
    }
    return lastSetOperation;
  }

  public List<Operation> handleQueue( List<Operation> operationsQueue ) {
    return optimizeSetOperations( considerBuffer( operationsQueue ) );
  }

  /** For testing purposes only. */
  List<List<Operation>> getOperationsBuffer() {
    return operationsBuffer;
  }

}
