/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ModalShellSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ShellSetter;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.Shell;

public class ShellOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Shell";

  private static final String APPLICATION_MODAL = "APPLICATION_MODAL";
  private static final String TITLE = "TITLE";

  private final IViewSetter<? extends View> setter;
  private final IViewSetter<? extends View> modalSetter;
  private ShellAnimationSupport animSupport;

  public ShellOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ShellSetter<Shell>( activity );
    modalSetter = new ModalShellSetter<ModalShell>( activity );
    animSupport = new ShellAnimationSupport();
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    IViewSetter<View> result = ( IViewSetter<View> )setter;
    if( view instanceof ModalShell ) {
      result = ( IViewSetter<View> )modalSetter;
    }
    return result;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateOperation( operation );
    Properties Properties = operation.getProperties();
    Shell shell;
    if( isDialog( Properties ) ) {
      shell = createModalShell();
    } else {
      shell = new Shell( getActivity(), animSupport );
    }
    shell.setVisibility( View.GONE );
    initializeShell( operation, Properties, shell );
  }

  private void initializeShell( CreateOperation operation, Properties Properties, Shell shell ) {
    setTitle( getActivity(), shell, Properties );
    setBackgroundColor( shell );
    setInitialLayoutParams( shell );
    getRootLayout().addView( shell );
    getObjectRegistry().register( operation.getTarget(), shell, TYPE );
    registerListeners( operation, shell );
    applyProperties( operation, shell );
    initializeFocus( shell );
  }

  @Override
  protected void applyConsumingTouchListener( View view ) {
    CompositeTouchListener compListener = getListenerRegistry().findListener( getObjectId( view ),
                                                                              CompositeTouchListener.class );
    compListener.addListener( new ConsumingTouchListener( getActivity() ) );
  }

  protected void registerListeners( CreateOperation operation, View view ) {
    CompositeTouchListener listener = new CompositeTouchListener();
    listener.addListener( getWidgetToolkit().getFocusTrackingListener() );
    listener.addListener( new ConsumingTouchListener( getActivity() ) );
    view.setOnTouchListener( listener );
    getWidgetToolkit().getListenerRegistry().registerListener( operation.getTarget(), listener );
  }

  private ModalShell createModalShell() {
    ModalShell modalShell = new ModalShell( getActivity(), animSupport );
    modalShell.dimBackground( getActivity(), getRootLayout() );
    return modalShell;
  }

  private void initializeFocus( Shell shell ) {
    shell.setFocusable( true );
    shell.requestFocus();
  }

  private void setTitle( Context context, Shell shell, Properties properties ) {
    if( hasTitel( properties ) ) {
      DialogHeader dialogHeader = createTitle( context,
                                               properties.getString( ProtocolConstants.PROP_TEXT ) );
      dialogHeader.getIcon().setVisibility( View.GONE );
      shell.setHeader( dialogHeader );
    }
  }

  private DialogHeader createTitle( Context context, String customTitle ) {
    int themeResId = ThemeUtil.getAttrResId( context, R.attr.alertDialogTheme );
    DialogHeader dialogHeader = new DialogHeader( new ContextThemeWrapper( context, themeResId ) );
    dialogHeader.setTitleText( customTitle );
    return dialogHeader;
  }

  private ViewGroup getRootLayout() {
    return ( ViewGroup )getActivity().findViewById( R.id.root_layout );
  }

  private boolean isDialog( Properties properties ) {
    if( properties == null ) {
      return false;
    }
    List<String> style = properties.getList( ProtocolConstants.PROP_STYLE, String.class );
    return style != null && style.contains( APPLICATION_MODAL );
  }

  private boolean hasTitel( Properties properties ) {
    if( properties == null ) {
      return false;
    }
    List<String> style = properties.getList( ProtocolConstants.PROP_STYLE, String.class );
    return style != null && style.contains( TITLE );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    Shell shell = ( Shell )findViewByTarget( operation );
    if( shell == null ) {
      throw new IllegalArgumentException( "Could not find shell "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    shell.playHideAnimation( getActivity() );
    if( shell instanceof ModalShell ) {
      ( ( ModalShell )shell ).undimBackground( getRootLayout() );
    }
    ShellSetter.dereferenceIcon( getProcessor(), shell );
    super.destroy( operation );
  }

  /**
   * Only used for testing with robolectric so that we can control the way the
   * color is set.
   * 
   * @param shellLayout The {@link View} to set the background color on
   */
  protected void setBackgroundColor( Shell shellLayout ) {
    int color = ThemeUtil.getColorValue( getActivity(), android.R.attr.windowBackground );
    shellLayout.setBackgroundColor( color );
  }

  /**
   * Only used for testing so that we can verify animations were triggered.
   * 
   * @param animSupport The {@link ShellAnimationSupport} to be used by this
   *          object
   */
  public void setShellAnimationSupport( ShellAnimationSupport animSupport ) {
    this.animSupport = animSupport;
  }

}
