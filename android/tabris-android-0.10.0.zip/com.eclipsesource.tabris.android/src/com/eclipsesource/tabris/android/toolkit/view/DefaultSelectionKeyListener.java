/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;

import java.util.HashMap;
import java.util.Map;

import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class DefaultSelectionKeyListener implements OnEditorActionListener {

  private static final Map<String, Object> DEFAULT_PARAMETERS = new HashMap<String, Object>();

  static {
    DEFAULT_PARAMETERS.put( "x", 0 );
    DEFAULT_PARAMETERS.put( "y", 0 );
    DEFAULT_PARAMETERS.put( "width", 0 );
    DEFAULT_PARAMETERS.put( "height", 0 );
    DEFAULT_PARAMETERS.put( "shiftKey", false );
    DEFAULT_PARAMETERS.put( "ctrlKey", false );
    DEFAULT_PARAMETERS.put( "altKey", false );
  }

  private final TabrisActivity activity;

  public DefaultSelectionKeyListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public boolean onEditorAction( TextView view, int actionId, KeyEvent event ) {
    if( actionId == EditorInfo.IME_NULL ) {
      RemoteObject remoteObject = activity.getRemoteObject( view );
      remoteObject.notify( EVENT_DEFAULT_SELECTION, DEFAULT_PARAMETERS );
    }
    return false;
  }

}
