/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.util.TypedValue;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;

public class ErrorDialog implements Runnable {

  protected final AndroidWidgetToolkit awt;
  protected Dialog dialog;
  private final Activity activity;

  protected static class ActivityFinishListener implements OnClickListener {

    private final Activity activity;

    public ActivityFinishListener( Activity activity ) {
      this.activity = activity;
    }

    public void onClick( DialogInterface dialog, int which ) {
      activity.finish();
    }
  }
  protected static class ActivityRestartListener implements OnClickListener {

    private final Activity activity;

    public ActivityRestartListener( Activity activity ) {
      this.activity = activity;
    }

    public void onClick( DialogInterface dialog, int which ) {
      activity.finish();
      activity.startActivity( activity.getIntent() );
    }
  };

  protected static class DialogCancelListener implements OnClickListener {

    public void onClick( DialogInterface dialog, int which ) {
      dialog.cancel();
    }
  }

  public ErrorDialog( final Activity activity, AndroidWidgetToolkit awt ) {
    this.activity = activity;
    this.awt = awt;
    createDialog( activity );
  }

  private void createDialog( final Activity activity ) {
    String appName = activity.getString( R.string.app_name );
    dialog = getDialogDelegate( activity );
    dialog.setTitle( appName );
    dialog.setIcon( getIcon( activity ) );
    createButtons( activity );
  }

  protected Dialog getDialogDelegate( Activity activity ) {
    return new Dialog( activity );
  }

  protected void createButtons( final Activity activity ) {
    dialog.setButton( DialogInterface.BUTTON_NEGATIVE,
                      activity.getString( R.string.dialog_error_button_close ),
                      new ActivityFinishListener( activity ) );

    dialog.setButton( DialogInterface.BUTTON_NEUTRAL,
                      activity.getString( R.string.dialog_error_button_ignore ),
                      new DialogCancelListener() );
  }

  private static int getIcon( Context context ) {
    TypedValue outValue = new TypedValue();
    context.getTheme().resolveAttribute( R.attr.alertDialogIcon, outValue, true );
    return outValue.resourceId;
  }

  public void show( Throwable t, TransportRequest request ) {
    if( !dialog.isShowing() ) {
      setButtonRegardingConnectionError( request );
      dialog.setMessage( getMessage( t ) );
      awt.executeInUiThread( this );
    }
  }

  private void setButtonRegardingConnectionError( TransportRequest request ) {
    if( request == null ) {
      dialog.setButton( DialogInterface.BUTTON_POSITIVE,
                        activity.getString( R.string.dialog_restart_button_restart ),
                        new ActivityRestartListener( activity ) );
    }
  }

  public boolean isShowing() {
    return dialog.isShowing();
  }

  private String getMessage( Throwable t ) {
    String message = t.getMessage();
    if( message == null ) {
      message = dialog.getContext().getString( R.string.dialog_unexpected_error_occured )
                + t.getClass().getSimpleName();
    }
    return message;

  }

  public void run() {
    dialog.show();
  }

  /** To be used for testing only. */
  Dialog getDialog() {
    return dialog;
  }

}