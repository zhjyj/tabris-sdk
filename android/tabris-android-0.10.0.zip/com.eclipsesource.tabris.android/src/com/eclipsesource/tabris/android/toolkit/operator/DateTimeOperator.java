/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import android.util.SparseArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.SpinnerSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeDatePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeTimePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeSpinnerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeChangedListener;

public class DateTimeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.DateTime";

  public static final String STYLE_DATE = "DATE";
  public static final String STYLE_CALENDAR = "CALENDAR";
  public static final String STYLE_TIME = "TIME";
  public static final String STYLE_SHORT = "SHORT";
  public static final String STYLE_MEDIUM = "MEDIUM";
  public static final String STYLE_LONG = "LONG";

  public static final String TIME_FORMAT_SHORT = "HH:mm";
  public static final String TIME_FORMAT_MEDIUM_AND_LONG = TIME_FORMAT_SHORT;
  public static final String DATE_FORMAT_DAY = "dd";
  public static final String DATE_FORMAR_MONTH = "MM";
  public static final String DATE_FORMAT_YEAR = "yyyy";
  public static final String DATE_FORMAT_LONG = "EEEE ,  dd MMMMM ,  yyyy";
  public static final String DATE_FORMAT_SHORT = "MMMMM, yyyy";

  private final IViewSetter<? extends View> setter;

  public DateTimeOperator( TabrisActivity activity ) {
    super( activity );
    setter = new SpinnerSetter<Spinner>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    DateTimeSpinner dateTimeSpinner = createDateTimeSpinner( operation );
    attachDateChangeListener( dateTimeSpinner, operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class ) );
    initiateNewView( operation, dateTimeSpinner );
  }

  private DateTimeSpinner createDateTimeSpinner( CreateOperation operation ) {
    List<String> style = operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class );
    if( style.contains( STYLE_CALENDAR ) ) {
      throw new UnsupportedOperationException( "The style CALENDAR is currently not supported for the DateTime widget." );
    }
    IDateTimeSpinnerDialog dialog = null;
    String dateFormat = null;
    Calendar calendar = GregorianCalendar.getInstance();
    TabrisActivity activity = getActivity();
    if( style.contains( STYLE_DATE ) ) {
      dateFormat = createDateFormat( operation.getProperties() );
      dialog = new DateTimeDatePickerDialog( activity, calendar );
    } else if( style.contains( STYLE_TIME ) ) {
      dateFormat = createTimeFormat( operation.getProperties() );
      dialog = new DateTimeTimePickerDialog( activity, calendar );
    }
    return new DateTimeSpinner( activity, createAdapter(), dialog, dateFormat );
  }

  private String createTimeFormat( Properties properties ) {
    if( properties.getList( ProtocolConstants.PROP_STYLE, String.class ).contains( STYLE_SHORT ) ) {
      return TIME_FORMAT_SHORT;
    }
    return TIME_FORMAT_MEDIUM_AND_LONG;
  }

  private String createDateFormat( Properties properties ) {
    StringBuffer dateFormat = new StringBuffer();
    List<String> style = properties.getList( ProtocolConstants.PROP_STYLE, String.class );
    if( style.contains( STYLE_SHORT ) ) {
      dateFormat.append( DATE_FORMAT_SHORT );
    } else if( style.contains( STYLE_MEDIUM ) ) {
      createDateFormatMedium( dateFormat, properties );
    } else if( style.contains( STYLE_LONG ) ) {
      dateFormat.append( DATE_FORMAT_LONG );
    }
    return dateFormat.toString();
  }

  private void createDateFormatMedium( StringBuffer dateFormat, Properties properties ) {
    validateDateMediumProperties( properties );
    String datePattern = properties.getString( ProtocolConstants.PROP_DATE_PATTERN );
    String dateSeparator = properties.getString( ProtocolConstants.PROP_DATE_SEPARATOR );
    for( int i = 0; i < datePattern.length(); i++ ) {
      if( datePattern.charAt( i ) == 'Y' ) {
        dateFormat.append( DATE_FORMAT_YEAR );
      } else if( datePattern.charAt( i ) == 'M' ) {
        dateFormat.append( DATE_FORMAR_MONTH );
      } else if( datePattern.charAt( i ) == 'D' ) {
        dateFormat.append( DATE_FORMAT_DAY );
      }
      if( i != datePattern.length() - 1 ) {
        dateFormat.append( dateSeparator );
      }
    }
  }

  private void validateDateMediumProperties( Properties properties ) {
    if( !properties.hasProperty( ProtocolConstants.PROP_DATE_PATTERN ) ) {
      throw new IllegalArgumentException( "No date pattern found to create a MEDIUM DATE DateTime widget" );
    }
    if( !properties.hasProperty( ProtocolConstants.PROP_DATE_SEPARATOR ) ) {
      throw new IllegalArgumentException( "No date separator found to create a MEDIUM DATE DateTime widget" );
    }
  }

  private void attachDateChangeListener( DateTimeSpinner spinner, List<String> style ) {
    SparseArray<String> dateValues = createDateValuesList( style );
    spinner.addListener( new DateTimeChangedListener( getActivity(), dateValues ) );
  }

  private ArrayAdapter<String> createAdapter() {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( getActivity(),
                                                             android.R.layout.simple_spinner_item );
    adapter.setDropDownViewResource( R.layout.spinner_dropdown_item );
    return adapter;
  }

  private SparseArray<String> createDateValuesList( List<String> style ) {
    SparseArray<String> dateValues = new SparseArray<String>();
    if( style.contains( STYLE_DATE ) ) {
      dateValues.put( Calendar.YEAR, "year" );
      dateValues.put( Calendar.MONTH, "month" );
      dateValues.put( Calendar.DAY_OF_MONTH, "day" );
    } else if( style.contains( STYLE_TIME ) ) {
      dateValues.put( Calendar.HOUR_OF_DAY, "hours" );
      dateValues.put( Calendar.MINUTE, "minutes" );
      dateValues.put( Calendar.SECOND, "seconds" );
    }
    return dateValues;
  }

  @Override
  public void set( SetOperation operation ) {
    super.set( operation );
    DateTimeSpinner spinner = ( DateTimeSpinner )findViewByTarget( operation );
    setYear( spinner, operation.getProperties() );
    setMonth( spinner, operation.getProperties() );
    setDay( spinner, operation.getProperties() );
    setHours( spinner, operation.getProperties() );
    setMinutes( spinner, operation.getProperties() );
  }

  private void setYear( DateTimeSpinner spinner, Properties props ) {
    Integer year = props.getInteger( ProtocolConstants.PROP_YEAR );
    if( year != null ) {
      if( year < 1900 || year > 2100 ) {
        throw new IllegalArgumentException( "The year to set on a DateTime widget can only be in the range 1900 - 2100 (inclusive). Received: "
                                            + year );
      }
      spinner.getDialog().setYear( year );
    }
  }
  
  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    // Nothing to do here, events will be sended in the DateChangeListener
  }
  
  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    // Nothing to do here, events will be sended in the DateChangeListener
  }

  private void setMonth( DateTimeSpinner spinner, Properties props ) {
    Integer month = props.getInteger( ProtocolConstants.PROP_MONTH );
    if( month != null ) {
      spinner.getDialog().setMonth( month );
    }
  }

  private void setDay( DateTimeSpinner spinner, Properties props ) {
    Integer day = props.getInteger( ProtocolConstants.PROP_DAY );
    if( day != null ) {
      spinner.getDialog().setDay( day );
    }
  }

  private void setHours( DateTimeSpinner spinner, Properties props ) {
    Integer hours = props.getInteger( ProtocolConstants.PROP_HOURS );
    if( hours != null ) {
      spinner.getDialog().setHours( hours );
    }
  }

  private void setMinutes( DateTimeSpinner spinner, Properties props ) {
    Integer minutes = props.getInteger( ProtocolConstants.PROP_MINUTES );
    if( minutes != null ) {
      spinner.getDialog().setMinutes( minutes );
    }
  }

}
