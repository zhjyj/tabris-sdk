/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

public class Text extends EditText {

  private TextSelectionChangeListener selectionChangeListener;

  public Text( Context context ) {
    super( context );
    selectionChangeListener = null;
    setImeOptions( EditorInfo.IME_ACTION_NEXT );
  }

  public void setSelectionChangeListener( TextSelectionChangeListener listener ) {
    this.selectionChangeListener = listener;
  }

  @Override
  protected void onSelectionChanged( int selStart, int selEnd ) {
    super.onSelectionChanged( selStart, selEnd );
    if( selectionChangeListener != null ) {
      selectionChangeListener.afterSelectionChanged( selStart, selEnd - selStart );
    }
  }

}
