
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.view.Swipe;
import com.eclipsesource.tabris.android.toolkit.view.SwipeAdapter;

public class SwipeOperator extends AbstractOperator {

  public static final String TYPE = "tabris.Swipe";

  public SwipeOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    String parentId = operation.getProperties().getString( PROP_PARENT );
    Swipe swipe = findObjectById( parentId, Swipe.class );
    SwipeAdapter swipeAdapter = new SwipeAdapter( getActivity(), swipe );
    swipe.setAdapter( swipeAdapter );
    getObjectRegistry().register( operation.getTarget(), swipeAdapter, operation.getType() );
    getActivity().getRemoteObject( swipeAdapter ).addListen( EVENT_SWIPED_TO_ITEM );
  }

  @Override
  public void call( CallOperation operation ) {
    validateCallOperation( operation );
    SwipeAdapter swipeAdapter = findObjectById( operation.getTarget(), SwipeAdapter.class );
    Properties properties = operation.getProperties();
    if( hasMethod( operation, "itemLoaded" ) ) {
      swipeAdapter.addItemAt( properties.getInteger( "index" ), properties.getString( "content" ) );
    } else if( hasMethod( operation, "removeItems" ) ) {
      swipeAdapter.removeItemsAt( properties.getList( "items", Integer.class ) );
    } else if( hasMethod( operation, "lockLeft" ) ) {
      swipeAdapter.lockLeft( properties.getInteger( "index" ) );
    } else if( hasMethod( operation, "lockRight" ) ) {
      swipeAdapter.lockRight( properties.getInteger( "index" ) );
    } else if( hasMethod( operation, "unlockLeft" ) ) {
      swipeAdapter.lockLeft( SwipeAdapter.UNLOCKED );
    } else if( hasMethod( operation, "unlockRight" ) ) {
      swipeAdapter.lockRight( SwipeAdapter.UNLOCKED );
    }
  }

  private boolean hasMethod( CallOperation operation, String method ) {
    return operation.getMethod().equals( method );
  }

  @Override
  public void set( SetOperation operation ) {
    setActiveItem( operation );
  }

  private void setActiveItem( SetOperation operation ) {
    Integer activeItem = operation.getProperties().getInteger( "activeItem" );
    if( activeItem != null ) {
      SwipeAdapter swipeAdapter = findObjectById( operation.getTarget(), SwipeAdapter.class );
      swipeAdapter.setActiveItem( activeItem );
    }
  }
}
