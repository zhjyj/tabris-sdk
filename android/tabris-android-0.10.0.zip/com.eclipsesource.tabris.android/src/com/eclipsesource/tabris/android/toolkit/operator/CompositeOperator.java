/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Swipe;

public class CompositeOperator extends AbstractWidgetOperator {

  private static final String CUSTOM_VARIANT_SWIPE = "variant_swipe";

  public static final String TYPE = "rwt.widgets.Composite";

  private final IViewSetter<? extends View> compositeSetter;
  private final IViewSetter<? extends View> swipeCompositeSetter;

  public CompositeOperator( TabrisActivity activity ) {
    super( activity );
    compositeSetter = new CompositeSetter<Composite>( activity );
    swipeCompositeSetter = new ViewSetter<View>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    if( view instanceof Swipe ) {
      return ( IViewSetter<View> )swipeCompositeSetter;
    }
    return ( IViewSetter<View> )compositeSetter;
  }

  @Override
  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    String customVariant = operation.getProperties().getString( PROP_CUSTOM_VARIANT );
    if( customVariant != null && customVariant.equals( CUSTOM_VARIANT_SWIPE ) ) {
      createSwipe( operation );
    } else {
      createComposite( operation );
    }
  }

  private void createComposite( CreateOperation operation ) {
    View view = new Composite( getActivity() );
    initiateNewView( operation, view );
    applyConsumingTouchListener( view );
  }

  private void createSwipe( CreateOperation operation ) {
    View view = new Swipe( getActivity() );
    initiateNewView( operation, view );
  }

  @Override
  protected void applyConsumingTouchListener( View view ) {
    if( view instanceof Composite ) {
      CompositeTouchListener compListener = getListenerRegistry().findListener( getObjectId( view ),
                                                                                CompositeTouchListener.class );
      compListener.addListener( new ConsumingTouchListener( getActivity() ) );
    }
  }

}
