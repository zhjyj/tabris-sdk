/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import java.io.InputStream;

public interface ITransportResult {

  InputStream getResult();

  void setResult( InputStream result );

  boolean hasException();

  Exception getException();

  void setException( Exception exception );

  boolean hasParsableContent();
}
