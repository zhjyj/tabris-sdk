/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

public class LocalizableException extends Exception {

  private static final long serialVersionUID = -7622869026723914141L;

  public static final String SESSION_TIMEOUT = "sessionTimeout";

  private final String messageKey;

  public LocalizableException( String messageKey ) {
    this.messageKey = messageKey;
  }

  public String getKey() {
    return messageKey;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( messageKey == null )
                                                      ? 0
                                                      : messageKey.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    LocalizableException other = ( LocalizableException )obj;
    if( messageKey == null ) {
      if( other.messageKey != null ) {
        return false;
      }
    } else if( !messageKey.equals( other.messageKey ) ) {
      return false;
    }
    return true;
  }

}
