/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.util.List;

public class Font {

  private List<String> family;
  private Integer size;
  private Boolean bold;
  private Boolean italic;

  public List<String> getFamily() {
    return family;
  }

  public void setFamily( List<String> family ) {
    this.family = family;
  }

  public Integer getSize() {
    return size;
  }

  public void setSize( Integer size ) {
    this.size = size;
  }

  public Boolean getBold() {
    return bold;
  }

  public void setBold( Boolean bold ) {
    this.bold = bold;
  }

  public Boolean getItalic() {
    return italic;
  }

  public void setItalic( Boolean italic ) {
    this.italic = italic;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( bold == null )
                                                ? 0
                                                : bold.hashCode() );
    result = prime * result + ( ( family == null )
                                                  ? 0
                                                  : family.hashCode() );
    result = prime * result + ( ( italic == null )
                                                  ? 0
                                                  : italic.hashCode() );
    result = prime * result + ( ( size == null )
                                                ? 0
                                                : size.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    Font other = ( Font )obj;
    if( bold == null ) {
      if( other.bold != null ) {
        return false;
      }
    } else if( !bold.equals( other.bold ) ) {
      return false;
    }
    if( family == null ) {
      if( other.family != null ) {
        return false;
      }
    } else if( !family.equals( other.family ) ) {
      return false;
    }
    if( italic == null ) {
      if( other.italic != null ) {
        return false;
      }
    } else if( !italic.equals( other.italic ) ) {
      return false;
    }
    if( size == null ) {
      if( other.size != null ) {
        return false;
      }
    } else if( !size.equals( other.size ) ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "Font ["
           + ( family != null
                             ? "family=" + family + ", "
                             : "" )
           + ( size != null
                           ? "size=" + size + ", "
                           : "" )
           + ( bold != null
                           ? "bold=" + bold + ", "
                           : "" )
           + ( italic != null
                             ? "italic=" + italic
                             : "" )
           + "]";
  }

}
