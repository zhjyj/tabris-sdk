
package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.view.View;

public class Swipe extends ViewPager {

  public Swipe( Context context ) {
    super( context );
  }

  @Override
  public void addView( View child ) {
    // do nothing
  }

  @Override
  public void removeViewAt( int index ) {
    // do nothing
  }

  @Override
  public void removeView( View view ) {
    // do nothing
  }

  public void doAddView( View child ) {
    super.addView( child );
  }

  public void doRemoveViewAt( int index ) {
    super.removeViewAt( index );
  }

  public void doRemoveView( View view ) {
    super.removeView( view );
  }

}
