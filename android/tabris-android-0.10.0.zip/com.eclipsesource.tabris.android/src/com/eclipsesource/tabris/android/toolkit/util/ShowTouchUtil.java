
package com.eclipsesource.tabris.android.toolkit.util;

import android.view.MotionEvent;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ShowTouchListener;

public class ShowTouchUtil {

  private final TabrisActivity activity;

  public ShowTouchUtil( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void dispatchEventToShowTouchListener( ViewParent viewParent, MotionEvent event ) {
    if( viewParent instanceof ViewGroup ) {
      CompositeTouchListener compListener = getCompositeTouchListener( viewParent );
      if( compListener != null ) {
        OnTouchListener listener = compListener.findListener( ShowTouchListener.class );
        if( listener == null ) {
          dispatchEventToShowTouchListener( viewParent.getParent(), event );
        } else {
          listener.onTouch( ( ViewGroup )viewParent, event );
        }
      }
    }
  }

  private CompositeTouchListener getCompositeTouchListener( ViewParent viewParent ) {
    RemoteObject remoteObject = null;
    try {
      remoteObject = activity.getRemoteObject( viewParent );
    } catch( IllegalStateException remoteObjectNotFoundException ) {
      // can happen for Views not directly created via protocol messages
      return null;
    }
    String id = remoteObject.getId();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = toolkit.getListenerRegistry();
    return listenerRegistry.findListener( id, CompositeTouchListener.class );
  }

}
