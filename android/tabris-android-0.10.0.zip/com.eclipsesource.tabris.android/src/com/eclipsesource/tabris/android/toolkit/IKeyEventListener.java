
package com.eclipsesource.tabris.android.toolkit;

import android.view.KeyEvent;

public interface IKeyEventListener {

  boolean onKeyEvent( KeyEvent keyEvent );

}
