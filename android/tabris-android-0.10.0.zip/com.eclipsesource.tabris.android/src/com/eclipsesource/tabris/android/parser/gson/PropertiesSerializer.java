package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;
import java.util.Map;

import com.eclipsesource.tabris.android.core.model.Properties;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;


public class PropertiesSerializer implements JsonSerializer<Properties> {

  public JsonElement serialize( Properties properties, Type typeOfSrc, JsonSerializationContext context ) {
    Map<String, Object> props = properties.getAll();
    if( props != null ) {
      return context.serialize( props );
    } else {
      return JsonNull.INSTANCE;
    }
  }

}
