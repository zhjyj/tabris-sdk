/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class SelectionTreeItemClickListener implements OnItemClickListener {

  private final TabrisActivity activity;

  public SelectionTreeItemClickListener( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    if( parent instanceof TreeView ) {
      TreeView treeView = ( TreeView )parent;
      ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
      if( currentTreeItems.size() > position ) {
        TreeItemView selectedItem = treeView.getCurrentTreeItems().get( position );
        updateRemoteObject( treeView, selectedItem );
      }
    }
  }

  private void updateRemoteObject( TreeView treeView, TreeItemView treeItemView ) {
    RemoteObject remoteObject = activity.getRemoteObject( treeView );
    String treeItemId = activity.getRemoteObject( treeItemView ).getId();
    remoteObject.set( PROP_SELECTION, new String[]{ treeItemId } );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, treeItemId );
    remoteObject.notify( EVENT_SELECTION, properties );
  }
}