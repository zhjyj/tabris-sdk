/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static android.view.MotionEvent.*;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;

public class FocusTrackingListener implements OnTouchListener {

  private final TabrisActivity activity;
  private InputMethodManager imm;
  private String prevId;

  public FocusTrackingListener( TabrisActivity activity ) {
    this.activity = activity;
    imm = ( InputMethodManager )activity.getSystemService( Context.INPUT_METHOD_SERVICE );
  }

  public boolean onTouch( View view, MotionEvent event ) {
    String id = activity.getRemoteObject( view ).getId();
    if( !id.equals( prevId ) ) {
      prevId = id;
      activity.getDisplayRemoteObject().set( "focusControl", id );
    }
    if( view instanceof EditText ) {
      notifyImmediateListener( view );
    } else if( event.getAction() == ACTION_UP || event.getAction() == ACTION_CANCEL ) {
      hideKeyboard( view );
    }
    return false;
  }

  private void hideKeyboard( View view ) {
    imm.hideSoftInputFromWindow( view.getWindowToken(), 0 );
  }

  private void notifyImmediateListener( View view ) {
    ListenerRegistry registry = activity.getProcessor().getWidgetToolkit().getListenerRegistry();
    String id = activity.getRemoteObject( view ).getId();
    CompositeFocusListener compListener = registry.findListener( id, CompositeFocusListener.class );
    OnFocusChangeListener immediateListener = compListener.findListener( FocusChangeListener.class );
    if( immediateListener != null && view.hasFocus() ) {
      immediateListener.onFocusChange( view, true );
    }
  }

  /** To be used for testing only. */
  void setPrevTag( String prevTag ) {
    this.prevId = prevTag;
  }

  /** To be used for testing only. */
  void setInputMethodManager( InputMethodManager imm ) {
    this.imm = imm;
  }
}
