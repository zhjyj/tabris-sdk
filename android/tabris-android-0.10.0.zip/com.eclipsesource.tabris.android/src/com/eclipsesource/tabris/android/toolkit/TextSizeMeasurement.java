/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.graphics.Typeface;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.FloatMath;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;


public class TextSizeMeasurement {

  private static final String METHOD_STORE_MEASUREMENTS = "storeMeasurements";
  private static final String PROP_RESULTS = "results";

  private static final float MEASURE_FACTOR = 20f;
  private static final float TOLERANCE_FACTOR = 1.02f;

  private final TabrisActivity activity;

  public TextSizeMeasurement( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void measureItems( List<List<Object>> items ) {
    sendResults( measure( items ) );
  }

  @SuppressWarnings("rawtypes")
  private Map<String, int[]> measure( List<List<Object>> items ) {
    ParamCheck.notNull( items, "items" );
    Map<String, int[]> result = new HashMap<String, int[]>();
    IWidgetToolkit toolkit = getToolkit();
    for( List<Object> list : items ) {
      try {
        String id = ( String )list.get( 0 );
        String text = ( String )list.get( 1 );
        List fonts = ( List )list.get( 2 );
        float fontSize = toolkit.multiplyByDensityFactor( getNumberAsInt( list.get( 3 ) ) );
        boolean bold = ( Boolean )list.get( 4 );
        boolean italic = ( Boolean )list.get( 5 );
        int wrapWidth = 0;
        if( list.size() >= 7 ) {
          wrapWidth = toolkit.multiplyByDensityFactor( getNumberAsInt( list.get( 6 ) ) );
        }

        Typeface typeface = getTypeface( fonts, bold, italic );
        if( typeface == null ) {
          throw new IllegalStateException( "Could not obtain any font for measuring the text size" );
        }
        TextPaint textPaint = getTextPaint( typeface, fontSize );
        StaticLayout layout = measure( textPaint, text, wrapWidth );
        appendToResult( result, id, layout );
      } catch( ClassCastException exception ) {
        throw new IllegalArgumentException( "A string config was not in the right format", exception );
      } catch( ArrayIndexOutOfBoundsException exception) {
        throw new IllegalArgumentException( "A string config was not in the right format", exception );
      }
    }
    return result;
  }

  private StaticLayout measure( TextPaint textPaint, String text, int wrapWidth ) {
    int boundedWidth = Integer.MAX_VALUE;
    if( wrapWidth > 0 ) {
      boundedWidth = ( int )( wrapWidth * MEASURE_FACTOR );
    }
    return new StaticLayout( text,
                             textPaint,
                             boundedWidth,
                             Alignment.ALIGN_NORMAL,
                             1.0f,
                             0.0f,
                             false );
  }

  private int getNumberAsInt( Object obj ) {
    return ( ( Number )obj ).intValue();
  }

  private TextPaint getTextPaint( Typeface typeface, float fontSize ) {
    TextPaint textPaint = new TextPaint();
    textPaint.setTypeface( typeface );
    textPaint.setTextSize( fontSize * MEASURE_FACTOR );
    return textPaint;
  }

  @SuppressWarnings("rawtypes")
  public static Typeface getTypeface( List fonts, boolean bold, boolean italic ) {
    int style = createStyle( bold, italic );
    Typeface defaultTypeface = Typeface.defaultFromStyle( style );

    for( Object font : fonts ) {
      if( font instanceof String ) {
        String fontName = ( String )font;
        Typeface typeface = Typeface.create( fontName, style );
        if( !defaultTypeface.equals( typeface ) ) {
          return typeface;
        }
      } else {
        throw new IllegalArgumentException( "The given font name is not a string" );
      }
    }
    return defaultTypeface;
  }

  private static int createStyle( boolean bold, boolean italic ) {
    int style = Typeface.NORMAL;
    if( bold ) {
      style |= Typeface.BOLD;
    }
    if( italic ) {
      style |= Typeface.ITALIC;
    }
    return style;
  }

  private void appendToResult( Map<String, int[]> results, String id, StaticLayout layout ) {
    IWidgetToolkit toolkit = getToolkit();
    float measuredWidth = getMaxLineWidth( layout ) / MEASURE_FACTOR * TOLERANCE_FACTOR;
    float measuredHeight = layout.getHeight() / MEASURE_FACTOR;
    int width = ( int )FloatMath.ceil( toolkit.divideByDensityFactor( measuredWidth ) );
    int height = ( int )FloatMath.ceil( toolkit.divideByDensityFactor( measuredHeight ) );
    results.put( id, new int[] { width, height } );
  }

  private float getMaxLineWidth( StaticLayout layout ) {
    float maxLine = 0.0f;
    int lineCount = layout.getLineCount();
    for( int i = 0; i < lineCount; i++ ) {
      float lineLength = layout.getLineRight( i );
      if( lineLength > maxLine ) {
        maxLine = lineLength;
      }
    }
    return maxLine;
  }

  private void sendResults( Map<String, int[]> results ) {
    RemoteObject remoteObject = activity.getRemoteObject( this );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_RESULTS, results );
    remoteObject.call( METHOD_STORE_MEASUREMENTS, properties );
  }

  private IWidgetToolkit getToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }
}
