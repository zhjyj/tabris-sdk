
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_IMAGE_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_IMAGE_SELECTION_ERROR;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_SOURCE_TYPE;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera.SourceType;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class CameraOperator implements IOperator {

  public static final String TYPE = "tabris.Camera";

  private static final String SOURCE_TYPE_CAMERA = "camera";
  private static final String SOURCE_TYPE_PHOTO_LIBRARY = "photo_library";
  private static final String SOURCE_TYPE_SAVED_PHOTO_ALBUM = "saved_photo_album";
  private static final String METHOD_OPEN = "open";

  private final TabrisActivity activity;

  public CameraOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateOperation( operation );
    Camera camera = new Camera( activity, new DateFactory() );
    getObjectRegistry().register( operation.getTarget(), camera, TYPE );
    addDefaultListeners( getObjectRegistry().getRemoteObject( operation.getTarget() ) );
    Properties properties = operation.getProperties();
    if( properties != null ) {
      applyProperties( operation.getTarget(), properties );
    }
  }

  private void addDefaultListeners( RemoteObject remoteObject ) {
    remoteObject.addListen( EVENT_IMAGE_SELECTION );
    remoteObject.addListen( EVENT_IMAGE_SELECTION_ERROR );
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    Properties properties = operation.getProperties();
    applyProperties( operation.getTarget(), properties );
  }

  protected void applyProperties( String target, Properties properties ) {
    applySourceType( target, properties );
    applyResolution( target, properties );
  }

  private void applySourceType( String target, Properties properties ) {
    String sourceType = properties.getString( PROP_SOURCE_TYPE );
    if( sourceType != null ) {
      Camera camera = getObjectRegistry().getObject( target, Camera.class );
      if( sourceType.equals( SOURCE_TYPE_SAVED_PHOTO_ALBUM )
          || sourceType.equals( SOURCE_TYPE_PHOTO_LIBRARY ) )
      {
        camera.setSourceType( SourceType.GALLERY );
      } else if( sourceType.equals( SOURCE_TYPE_CAMERA ) ) {
        camera.setSourceType( SourceType.CAMERA );
      }
    }
  }

  private void applyResolution( String target, Properties properties ) {
    List<Integer> resolution = properties.getList( ProtocolConstants.PROP_RESOLUTION, Integer.class );
    if( resolution != null ) {
      if( resolution.size() == 2 ) {
        Integer width = resolution.get( 0 );
        Integer height = resolution.get( 1 );
        if( width != null && height != null ) {
          Camera camera = getObjectRegistry().getObject( target, Camera.class );
          camera.setResolution( width, height );
        } else {
          throw new IllegalArgumentException( "Resolution touple contains null elements. Received: "
                                              + resolution );
        }
      } else {
        throw new IllegalArgumentException( "Resolution touple does not have 2 elements. Received: "
                                            + resolution );
      }
    }
  }

  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    String method = operation.getMethod();
    if( method.equals( METHOD_OPEN ) ) {
      Camera camera = getObjectRegistry().getObject( operation.getTarget(), Camera.class );
      camera.requestImage();
    }
  }

  public void listen( ListenOperation operation ) {
    // nothing to do here
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    getObjectRegistry().unregister( operation.getTarget() );
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }
}
