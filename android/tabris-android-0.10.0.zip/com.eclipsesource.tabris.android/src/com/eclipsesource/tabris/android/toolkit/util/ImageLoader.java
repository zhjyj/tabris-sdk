
package com.eclipsesource.tabris.android.toolkit.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;

public class ImageLoader {

  public byte[] loadImage( File imageFile, int width, int height ) throws IOException {
    if( width == 0 && height == 0 ) {
      return getFileAsBytes( imageFile );
    }
    return compress( loadResized( imageFile, width, height ) );
  }

  private Bitmap loadResized( File imageFile, int targetWidth, int targetHeight )
    throws FileNotFoundException, IOException
  {
    Options options = getDecodedBounds( imageFile );
    Bitmap sampledBitmap = decodeAsSubsampledBitmap( imageFile, options, targetWidth, targetHeight );
    Bitmap scaledBitmap = resize( sampledBitmap, targetWidth, targetHeight );
    if( scaledBitmap != sampledBitmap ) {
      sampledBitmap.recycle();
    }
    return scaledBitmap;
  }

  private byte[] compress( Bitmap scaledBitmap ) {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    scaledBitmap.compress( CompressFormat.PNG, 80, bos );
    scaledBitmap.recycle();
    return bos.toByteArray();
  }

  private Bitmap resize( Bitmap bitmap, int targetWidth, int targetHeight ) {
    float bitmapWidth = bitmap.getWidth();
    float bitmapHeight = bitmap.getHeight();
    float width = 0;
    float height = 0;
    int minSize = Math.min( targetWidth, targetHeight );
    if( bitmapWidth == bitmapHeight ) {
      if( minSize > bitmapWidth ) {
        width = bitmapWidth;
        height = bitmapWidth;
      } else {
        width = minSize;
        height = minSize;
      }
    } else if( bitmapWidth > bitmapHeight ) {
      if( minSize > bitmapWidth ) {
        width = bitmapWidth;
        height = bitmapHeight;
      } else {
        width = targetWidth;
        height = bitmapHeight / ( bitmapWidth / targetWidth );
      }
    } else {
      if( minSize > bitmapHeight ) {
        width = bitmapWidth;
        height = bitmapHeight;
      } else {
        width = bitmapWidth / ( bitmapHeight / targetHeight );
        height = targetHeight;
      }
    }
    return Bitmap.createScaledBitmap( bitmap, ( int )width, ( int )height, true );
  }

  private int calculateInSampleSize( Options options, int targetWidth, int targetHeight ) {
    final int outWidth = options.outWidth;
    final int outHeight = options.outHeight;
    int inSampleSize = 1;
    if( outHeight > targetHeight || outWidth > targetWidth ) {
      if( outWidth > outHeight ) {
        inSampleSize = Math.round( outHeight / ( float )targetHeight );
      } else {
        inSampleSize = Math.round( outWidth / ( float )targetWidth );
      }
    }
    return inSampleSize;
  }

  private Bitmap decodeAsSubsampledBitmap( File imageFile,
                                           Options options,
                                           int targetWidth,
                                           int targetHeight ) throws IOException
  {
    options.inSampleSize = calculateInSampleSize( options, targetWidth, targetHeight );
    options.inJustDecodeBounds = false;
    FileInputStream is = new FileInputStream( imageFile );
    try {
      return BitmapFactory.decodeStream( is, null, options );
    } finally {
      is.close();
    }
  }

  private Options getDecodedBounds( File imageFile ) throws FileNotFoundException, IOException {
    Options options = new Options();
    options.inJustDecodeBounds = true;
    FileInputStream is = new FileInputStream( imageFile );
    try {
      BitmapFactory.decodeStream( is, null, options );
    } finally {
      is.close();
    }
    return options;
  }

  private byte[] getFileAsBytes( File file ) throws IOException {
    FileInputStream fin = new FileInputStream( file );
    byte buffer[] = new byte[ 8192 ];
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    int pos = fin.read( buffer );
    while( 0 < pos ) {
      bout.write( buffer, 0, pos );
      pos = fin.read( buffer );
    }
    fin.close();
    return bout.toByteArray();
  }
}
