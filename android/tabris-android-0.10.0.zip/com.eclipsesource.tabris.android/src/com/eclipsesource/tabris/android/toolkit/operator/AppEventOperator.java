
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.AppEvent;

public class AppEventOperator extends AbstractOperator {

  public static final String TYPE = "tabris.App";

  public AppEventOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  public void listen( ListenOperation operation ) {
    validateListenOperation( operation );
    initAppEvent();
    updateListenerOnRemoteObject( operation );
  }

  private void initAppEvent() {
    ObjectRegistry objectRegistry = getObjectRegistry();
    if( objectRegistry.getObject( TYPE, AppEvent.class ) == null ) {
      AppEvent appEvent = new AppEvent( getActivity() );
      getWidgetToolkit().addAppStateListener( appEvent );
      objectRegistry.register( TYPE, appEvent, TYPE );
    }
  }

}
