/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.content.DialogInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class BrowserWebChromeClient extends WebChromeClient {

  private static final String HTTP = "http://";

  private final Context context;

  public BrowserWebChromeClient( Context context ) {
    this.context = context;
  }

  @Override
  public boolean onJsAlert( WebView view, String url, String message, JsResult result ) {
    createNeutralDialog( url, message, result ).show();
    return true;
  }

  @Override
  public boolean onJsConfirm( WebView view, String url, String message, final JsResult result ) {
    Dialog dialog = createNeutralDialog( url, message, result );
    dialog.setButton( DialogInterface.BUTTON_NEGATIVE,
                      context.getResources().getString( android.R.string.cancel ),
                      new DialogInterface.OnClickListener() {

                        public void onClick( DialogInterface dialog, int which ) {
                          result.cancel();
                        }
                      } );
    dialog.show();
    return true;
  }

  private Dialog createNeutralDialog( String url, String message, final JsResult result ) {
    Dialog dialog = createNewDialog();
    if( url.startsWith( HTTP ) ) {
      url = url.substring( 7, url.length() );
    }
    dialog.setTitle( url );
    dialog.setMessage( message );
    dialog.setButton( DialogInterface.BUTTON_NEUTRAL,
                      context.getResources().getString( android.R.string.ok ),
                      new DialogInterface.OnClickListener() {

                        public void onClick( DialogInterface dialog, int which ) {
                          result.confirm();
                        }
                      } );
    return dialog;
  }

  Dialog createNewDialog() {
    return new Dialog( context );
  }
}