/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class VirtualTreeSupport implements OnScrollListener {

  private final TabrisActivity activity;
  private int curTopItem;
  private int lastRequestIndex;

  public VirtualTreeSupport( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
    reset();
  }

  public void onScrollStateChanged( AbsListView view, int scrollState ) {
    // nothing to do here
  }

  public void onScroll( AbsListView view,
                        int firstVisibleItem,
                        int visibleItemCount,
                        int totalItemCount )
  {
    if( !itemAlreadyConsidered( curTopItem, firstVisibleItem )
        || firstVisibleItem + visibleItemCount > lastRequestIndex )
    {
      curTopItem = firstVisibleItem;
      if( view instanceof TreeView ) {
        TreeView treeView = ( TreeView )view;
        TreeItemView parentTreeItem = treeView.getParentTreeItem();
        int itemCount = parentTreeItem.getItemCount();
        if( itemCount == 0 ) {
          reset();
          return;
        }
        int posInParentChain = getPosInParentChain( treeView, parentTreeItem );
        int requestIndex = firstVisibleItem + visibleItemCount + posInParentChain;
        if( !allTreeItemsLoaded( treeView, itemCount )
            && !loadedToHeadPosition( visibleItemCount, totalItemCount, posInParentChain )
            && !itemAlreadyLoaded( treeView, requestIndex + visibleItemCount )
            && sufficientGapToLastRequest( lastRequestIndex, visibleItemCount, requestIndex ) )
        {
          lastRequestIndex = requestIndex;
          doSetTopItemIndex( treeView, lastRequestIndex );
          notifySetData( treeView );
        }
      }
    }
  }

  private void notifySetData( TreeView treeView ) {
    RemoteObject remoteObject = activity.getRemoteObject( treeView );
    remoteObject.notify( EVENT_SET_DATA, null );
  }

  private boolean loadedToHeadPosition( int visibleItemCount,
                                        int totalItemCount,
                                        int posInParentChain )
  {
    return lastRequestIndex + visibleItemCount > totalItemCount + posInParentChain;
  }

  private static boolean itemAlreadyLoaded( TreeView treeView, int index ) {
    return index < treeView.getCurrentTreeItems().size();
  }

  static int getPosInParentChain( TreeView treeView, TreeItemView treeItem ) {
    if( treeItem == treeView.getRootTreeItem() ) {
      return 0;
    }
    return calculatePositionInParent( treeView, treeItem );
  }

  private static int calculatePositionInParent( TreeView treeView, TreeItemView treeItem ) {
    TreeItemView parent = treeItem.getTreeItemParent();
    if( parent == null ) {
      throw new IllegalArgumentException( "Tree item is not attached to tree view " + treeView );
    }
    int itemPos = parent.getChildren().indexOf( treeItem );
    if( parent == treeView.getRootTreeItem() ) {
      return itemPos;
    } else {
      return getPosInParentChain( treeView, parent ) + itemPos + 1;
    }
  }

  private static boolean sufficientGapToLastRequest( int lastRequestIndex,
                                                     int visibleItemCount,
                                                     int requestIndex )
  {
    return requestIndex > lastRequestIndex + visibleItemCount / 2;
  }

  private static boolean allTreeItemsLoaded( TreeView treeView, int itemCount ) {
    return treeView.getCurrentTreeItems().size() > itemCount;
  }

  private static boolean itemAlreadyConsidered( int curTopItem, int firstVisibleItem ) {
    return curTopItem == firstVisibleItem;
  }

  public void reset() {
    curTopItem = -1;
    lastRequestIndex = 0;
  }

  public void setTopItemIndex( TreeView treeView, TreeItemView currentItem ) {
    doSetTopItemIndex( treeView, getPosInParentChain( treeView, currentItem ) );
  }

  private void doSetTopItemIndex( TreeView treeView, int topItemIndex ) {
    RemoteObject remoteObject = activity.getRemoteObject( treeView );
    remoteObject.set( PROP_TOP_ITEM_INDEX, topItemIndex );
  }

}
