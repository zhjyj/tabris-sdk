/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;

public class ServerPushRunnable implements Runnable {

  private static final int RETRY_DELAY = 2000;
  private static final String SERVER_PUSH_QUERY = "servicehandler=org.eclipse.rap.serverpush";

  private final TabrisActivity activity;

  public ServerPushRunnable( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void run() {
    try {
      ProtocolProcessor processor = activity.getProcessor();
      do {
        ITransportResult result = processor.processGetRequest( createServerPushCallbackRequest() );
        if( !result.hasException() ) {
          processor.send();
          return;
        }
        Thread.sleep( RETRY_DELAY );
      } while( isConnected() );
    } catch( InterruptedException e ) {
      // Interruption is intended when callback is deactivated
    }
  }

  private GetRequest createServerPushCallbackRequest() {
    GetRequest request = new GetRequest();
    request.setQuery( SERVER_PUSH_QUERY );
    request.setTimeout( 0 );
    request.setSilentRequest( true );
    return request;
  }

  public boolean isConnected() {
    ConnectivityManager cm = ( ConnectivityManager )activity.getSystemService( Context.CONNECTIVITY_SERVICE );
    NetworkInfo netInfo = cm.getActiveNetworkInfo();
    if( netInfo != null && netInfo.isConnected() ) {
      return true;
    }
    return false;
  }
}
