/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.Parent;

public class TreeView extends ListView implements Parent {

  private final TabrisActivity activity;
  private TreeItemView rootTreeItem;
  private TreeItemView parentTreeItem;
  private VirtualTreeSupport virtualTreeSupport;
  private final List<Object> children;

  public TreeView( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
    this.children = new ArrayList<Object>();
    createRootTreeItem();
  }

  private void createRootTreeItem() {
    rootTreeItem = new TreeItemView( activity );
    rootTreeItem.setTexts( Arrays.asList( StringUtil.EMPTY_STRING ) );
    rootTreeItem.setTreeView( this );
    parentTreeItem = rootTreeItem;
  }

  @Override
  public void addView( View view ) {
    rootTreeItem.addView( view );
  }

  public void refreshTree() {
    final TreeViewAdapter treeAdapter = getTreeViewAdapter();
    if( treeAdapter != null ) {
      treeAdapter.notifyDataSetChanged();
    }
  }

  /**
   * Gets the currently shown tree items.
   * 
   * @return the {@link TreeItemView}s currently shown
   * @see #getParentTreeItem()
   */
  public ArrayList<TreeItemView> getCurrentTreeItems() {
    return parentTreeItem.getChildren();
  }

  @Override
  public void removeViewAt( int index ) {
    parentTreeItem.removeViewAt( index );
  }

  @Override
  public int indexOfChild( View child ) {
    return parentTreeItem.indexOfChild( child );
  }

  /**
   * Technically this method overrides the findViewWithTagTraversal(Object tag)
   * in View.class. The parent class "[at]hides" the protected method though. If
   * the underlying implementation changes this might break.
   * 
   * @param tag the tag to search for
   * @return the found view or <code>null</code> if no view could be found
   */
  // @Override
  @Override
  protected View findViewWithTagTraversal( Object tag ) {
    if( tag == null ) {
      throw new IllegalArgumentException( "Can not searh for null tag in "
                                          + TreeView.class.getSimpleName() );
    } else if( getTag().equals( tag ) ) {
      return this;
    }
    return rootTreeItem.findViewWithTagTraversal( tag );
  }

  public void setParentTreeItem( TreeItemView curItem ) {
    this.parentTreeItem = curItem;
  }

  public TreeItemView getRootTreeItem() {
    return rootTreeItem;
  }

  /**
   * Gets the {@link TreeItemView} that contains the currently shown items as
   * children.
   * 
   * @return the parent of the currently show items
   */
  public TreeItemView getParentTreeItem() {
    return parentTreeItem;
  }

  public void setVirtualTreeSupport( VirtualTreeSupport virtualTreeSupport ) {
    this.virtualTreeSupport = virtualTreeSupport;
    setOnScrollListener( virtualTreeSupport );
  }

  public VirtualTreeSupport getVirtualTreeSupport() {
    return virtualTreeSupport;
  }

  public boolean hasVirtualTreeSupport() {
    return virtualTreeSupport != null;
  }

  public void scrollTo( TreeItemView item ) {
    int itemIndex = parentTreeItem.getChildren().indexOf( item );
    if( itemIndex == -1 ) {
      throw new IllegalArgumentException( "Could not find the item to scroll to. Got: " + item );
    }
    setSelection( itemIndex );
  }

  public void contractTree( TreeItemView treeItemView ) {
    TreeItemView parent = treeItemView.getTreeItemParent();
    if( parent != null ) {
      TreeItemView curParent = getParentTreeItem();
      setParentTreeItem( parent );
      refreshTree();
      scrollTo( curParent );
    }
  }

  public void expandTree( TreeItemView treeItemView ) {
    setParentTreeItem( treeItemView );
    /*
     * Swapping the adapter in and out is a workaround for scrolling to 0.
     * Scrolling to 0 via adapter.setSelection(0) does not work when we call
     * adapter.notifyDataSetChanged() after setting the adapter.setSelection(0).
     * This happens when we add new tree items after we have expanded a tree
     * node.
     */
    ListAdapter adapter = getAdapter();
    setAdapter( null );
    setAdapter( adapter );
  }

  public void addChild( Object child ) {
    children.add( child );
  }

  public List<Object> getChildren() {
    return children;
  }

  public void setAlternativeSelection( AlternativeSelection altSelection ) {
    getTreeViewAdapter().setAlternativeSelection( altSelection );
  }

  private TreeViewAdapter getTreeViewAdapter() {
    return ( TreeViewAdapter )getAdapter();
  }

  public boolean isShowingRootTreeItem() {
    return parentTreeItem == rootTreeItem;
  }

}
