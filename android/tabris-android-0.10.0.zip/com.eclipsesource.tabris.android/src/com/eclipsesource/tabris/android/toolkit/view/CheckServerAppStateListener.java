
package com.eclipsesource.tabris.android.toolkit.view;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.toolkit.AppState;
import com.eclipsesource.tabris.android.toolkit.IAppStateListener;

public class CheckServerAppStateListener implements IAppStateListener {

  private final ProtocolProcessor processor;

  public CheckServerAppStateListener( ProtocolProcessor processor ) {
    this.processor = processor;
  }

  public void stateChanged( AppState state ) {
    if( state.equals( AppState.RESUME ) ) {
      processor.send();
    }
  }

}
