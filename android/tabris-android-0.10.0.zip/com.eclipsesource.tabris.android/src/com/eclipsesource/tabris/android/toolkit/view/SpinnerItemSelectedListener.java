/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;

public class SpinnerItemSelectedListener implements OnItemSelectedListener {

  private final TabrisActivity activity;

  public SpinnerItemSelectedListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onItemSelected( AdapterView<?> parent, View view, int position, long id ) {
    RemoteObject remoteObject = activity.getRemoteObject( parent );
    remoteObject.set( ProtocolConstants.PROP_SELECTION_INDEX, position );
    remoteObject.notify( ProtocolConstants.EVENT_SELECTION, null );
  }

  public void onNothingSelected( AdapterView<?> parent ) {
    // nothing to do here. There is always something selected
  }

}
