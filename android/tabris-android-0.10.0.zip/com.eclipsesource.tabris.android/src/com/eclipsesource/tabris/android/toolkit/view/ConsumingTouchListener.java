/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.util.ShowTouchUtil;

public class ConsumingTouchListener implements OnTouchListener {

  private ShowTouchUtil showTouchUtil;

  public ConsumingTouchListener( TabrisActivity activity ) {
    showTouchUtil = new ShowTouchUtil( activity );
  }

  public boolean onTouch( View view, MotionEvent event ) {
    showTouchUtil.dispatchEventToShowTouchListener( view.getParent(), event );
    // intercept all touch events
    return true;
  }

  /** To be used for testing only. */
  public void setShowTouchUtil( ShowTouchUtil showTouchUtil ) {
    this.showTouchUtil = showTouchUtil;
  }

}