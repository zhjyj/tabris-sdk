/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.widget.ListView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.Parent;

public class List extends ListView implements Parent {

  private final ArrayList<Object> children;

  public List( TabrisActivity activity ) {
    super( activity, null );
    this.children = new ArrayList<Object>();
    setVerticalFadingEdgeEnabled( false );
    setAdapter( new ListSelectionAdapter( activity, this ) );
  }

  public void setItems( java.util.List<String> itemsToSet, TabrisActivity activity ) {
    if( itemsToSet == null ) {
      return;
    }
    ListSelectionAdapter adapter = ( ListSelectionAdapter )getAdapter();
    adapter.clear();
    for( String item : itemsToSet ) {
      adapter.addItem( item );
    }
    adapter.notifyDataSetChanged();
  }

  public void addChild( Object child ) {
    children.add( child );
  }

  public java.util.List<Object> getChildren() {
    return children;
  }

  public void setAlternativeSelection( AlternativeSelection altSelection ) {
    ( ( ListSelectionAdapter )getAdapter() ).setAlternativeSelection( altSelection );
  }

}