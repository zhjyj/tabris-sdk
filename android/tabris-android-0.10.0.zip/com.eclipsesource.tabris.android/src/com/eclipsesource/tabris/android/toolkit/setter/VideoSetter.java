/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Point;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoController;
import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;
import com.eclipsesource.tabris.android.toolkit.view.VideoOperationsExecutor;

public class VideoSetter<T extends VideoHolder> extends ViewSetter<T> {

  private static final String PRESENTATION_MODE_EMBEDDED = "embedded";
  private static final String PRESENTATION_MODE_FULL_SCREEN = "full_screen";

  public VideoSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T view, Properties properties ) {
    super.execute( view, properties );
    setControlls( view, properties );
    setFullscreen( view, properties );
    setRepeating( view, properties );
    // order is important, because playbackmode and setURL make up
    // the initial play back state
    setPlaybackMode( view, properties );
    setUrl( view, properties );
  }

  @Override
  public void applyBoundsToView( View view, List<Integer> bounds ) {
    List<Integer> scaledBounds = scaleBounds( bounds );
    VideoHolder holder = ( VideoHolder )view;
    if( holder.isFullscreen() ) {
      holder.applyFullScreenBounds( getActivity() );
    } else {
      super.applyBoundsToView( view, bounds );
      applyBoundsToVideoSurface( scaledBounds, holder );
    }
    holder.bufferBounds( scaledBounds );
  }

  @Override
  protected List<Integer> adjustBounds( View view, List<Integer> bounds ) {
    VideoHolder videoHolder = ( VideoHolder )view;
    /*
     * Because we are a floating widget (i.e. not encapsulated inside the view
     * hierarchy but a top element), we have to take our parent's position into
     * account manually.
     */
    Point parentPos = videoHolder.calculateOriginalParentPosition();
    IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
    bounds.set( 0, bounds.get( 0 ) + toolkit.divideByDensityFactor( parentPos.x ) );
    bounds.set( 1, bounds.get( 1 ) + toolkit.divideByDensityFactor( parentPos.y ) );
    return bounds;
  }

  private void applyBoundsToVideoSurface( List<Integer> scaledBounds, VideoHolder holder ) {
    Video video = holder.getVideo();
    Integer scaledWidth = scaledBounds.get( 2 );
    Integer scaledHeight = scaledBounds.get( 3 );
    video.getHolder().setFixedSize( scaledWidth, scaledHeight );
  }

  private List<Integer> scaleBounds( List<Integer> bounds ) {
    List<Integer> scaledBounds = new ArrayList<Integer>( 4 );
    for( int i = 0; i < 4; i++ ) {
      scaledBounds.add( scaleBoundValue( bounds.get( i ) ) );
    }
    return scaledBounds;
  }

  private void setUrl( T view, Properties properties ) {
    String videoUrl = properties.getString( ProtocolConstants.PROP_VIDEO_URL );
    if( videoUrl != null ) {
      view.setUrl( videoUrl );
      applyVideoState( view, VideoState.SET_URL );
    }
  }

  private void setRepeating( T view, Properties properties ) {
    Boolean isRepeating = properties.getBoolean( ProtocolConstants.PROP_REPEAT );
    if( isRepeating != null ) {
      view.getVideo().setLooping( isRepeating );
    }
  }

  private void setPlaybackMode( T video, Properties properties ) {
    String playbackModeProperty = properties.getString( ProtocolConstants.PROP_PLAYBACK_MODE );
    if( playbackModeProperty != null ) {
      VideoController.VideoState videoState = convertToVideoState( playbackModeProperty );
      applyVideoState( video, videoState );
    }
  }

  private void setFullscreen( T view, Properties properties ) {
    String presentationMode = properties.getString( ProtocolConstants.PROP_PRESENTATION_MODE );
    if( presentationMode != null ) {
      if( PRESENTATION_MODE_EMBEDDED.equals( presentationMode ) ) {
        view.leaveFullscreen();
      } else if( PRESENTATION_MODE_FULL_SCREEN.equals( presentationMode ) ) {
        view.enterFullscreen();
      } else {
        throw new IllegalArgumentException( "Unknown presentation mode: " + presentationMode );
      }
    }
  }

  private void setControlls( T view, Properties properties ) {
    Boolean controllsVisible = properties.getBoolean( ProtocolConstants.PROP_CONTROLS_VISIBLE );
    if( controllsVisible != null ) {
      Video video = view.getVideo();
      video.shouldHaveMediaController( controllsVisible );
      if( controllsVisible ) {
        video.registerMediaController();
      } else {
        video.setMediaController( null );
      }
    }
  }

  private void applyVideoState( T view, VideoController.VideoState videoState ) {
    VideoOperationsExecutor videoOperationsExecutor = view.getVideoOperationsExecutor();
    videoOperationsExecutor.execute( videoState );
  }

  private VideoController.VideoState convertToVideoState( String playbackMode ) {
    return VideoController.VideoState.valueOf( playbackMode.toUpperCase() );
  }
}
