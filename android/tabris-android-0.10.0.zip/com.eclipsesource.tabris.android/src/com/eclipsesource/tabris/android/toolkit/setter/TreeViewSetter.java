/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.AlternativeSelection;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class TreeViewSetter<T extends TreeView> extends ViewSetter<TreeView> {

  private static final String CUSTOM_VARIANT_ALT_SELECTION = "variant_ALT_SELECTION";
  private static final String CUSTOM_VARIANT_ALT_SELECTION_LEAF = "variant_ALT_SELECTION_LEAF";
  private static final String CUSTOM_VARIANT_ALT_SELECTION_BRANCH = "variant_ALT_SELECTION_BRANCH";
  private static final String CUSTOM_VARIANT_BACK_FOCUS = "variant_BACK_FOCUS";

  private TreeBackKeyEventListener backListener;

  public TreeViewSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( TreeView treeView, Properties properties ) {
    super.execute( treeView, properties );
    setItemCount( treeView, properties );
    setAlternativeSelection( treeView, properties );
    setBackFocus( treeView, properties );
  }

  private void setItemCount( TreeView treeView, Properties properties ) {
    Integer itemCount = properties.getInteger( ProtocolConstants.PROP_ITEM_COUNT );
    if( itemCount != null ) {
      treeView.getRootTreeItem().setItemCount( itemCount );
    }
  }

  private void setAlternativeSelection( TreeView treeView, Properties properties ) {
    String customeVariant = properties.getString( PROP_CUSTOM_VARIANT );
    if( customeVariant != null ) {
      if( customeVariant.equals( CUSTOM_VARIANT_ALT_SELECTION ) ) {
        treeView.setAlternativeSelection( AlternativeSelection.ALL );
      } else if( customeVariant.equals( CUSTOM_VARIANT_ALT_SELECTION_LEAF ) ) {
        treeView.setAlternativeSelection( AlternativeSelection.LEAF );
      } else if( customeVariant.equals( CUSTOM_VARIANT_ALT_SELECTION_BRANCH ) ) {
        treeView.setAlternativeSelection( AlternativeSelection.BRANCH );
      }
    }
  }

  private void setBackFocus( TreeView treeView, Properties properties ) {
    String customeVariant = properties.getString( PROP_CUSTOM_VARIANT );
    if( customeVariant != null && customeVariant.equals( CUSTOM_VARIANT_BACK_FOCUS ) ) {
      initBackListener();
      backListener.setTreeView( treeView );
    }
  }

  private void initBackListener() {
    if( backListener == null ) {
      backListener = new TreeBackKeyEventListener( getActivity() );
      getProcessor().getWidgetToolkit().addKeyEventListener( backListener );
    }
  }

  @Override
  protected void setSelection( View view, Properties properties ) {
    // we do not support setting the selection yet
  }

  /** To be used for testing only. */
  void setBackListener( TreeBackKeyEventListener backListener ) {
    this.backListener = backListener;
  }

  public TreeBackKeyEventListener getBackListener() {
    return backListener;
  }
}
