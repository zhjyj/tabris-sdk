/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.view.View.OnFocusChangeListener;

public class CompositeFocusListener extends ListenerHolder<OnFocusChangeListener>
  implements OnFocusChangeListener
{

  public void onFocusChange( View view, boolean hasFocus ) {
    ArrayList<OnFocusChangeListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onFocusChange( view, hasFocus );
    }
  }

}
