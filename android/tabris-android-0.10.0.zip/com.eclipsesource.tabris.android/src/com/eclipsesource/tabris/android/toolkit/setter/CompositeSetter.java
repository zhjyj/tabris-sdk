/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Composite;

public class CompositeSetter<T extends Composite> extends ViewSetter<T> {

  public CompositeSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T composite, Properties Properties ) {
    super.execute( composite, Properties );
    setChildren( composite, Properties );
  }

  private void setChildren( Composite composite, Properties properties ) {
    List<String> children = properties.getList( ProtocolConstants.PROP_CHILDREN, String.class );
    if( children != null ) {
      for( int index = children.size() - 1; index >= 0; index-- ) {
        View child = composite.findViewWithTag( children.get( index ) );
        if( child != null ) {
          composite.bringChildToFront( child );
        }
      }
      composite.invalidate();
    }
  }
}
