/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_PLAYBACK_CHANGED;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_PRESENTATION_CHANGED;
import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.VideoSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;

public class VideoOperator extends AbstractWidgetOperator {

  public static final String TYPE = "tabris.widgets.Video";

  private final IViewSetter<? extends View> setter;

  public VideoOperator( TabrisActivity activity ) {
    super( activity );
    setter = new VideoSetter<VideoHolder>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    TabrisActivity activity = getActivity();
    ValidationUtil.validateCreateOperation( activity, operation );
    VideoHolder videoHolder = ( VideoHolder )activity.getLayoutInflater()
      .inflate( R.layout.video_holder, null );
    Video video = ( Video )videoHolder.findViewById( R.id.videoView );
    video.setHolder( videoHolder );
    videoHolder.setOriginalParent( getParentFromOperation( operation ) );
    initiateAsToplevelWidget( operation, videoHolder );
    getWidgetToolkit().addAppStateListener( videoHolder );
  }

  private View getParentFromOperation( CreateOperation operation ) {
    Properties props = operation.getProperties();
    return findObjectById( props.getString( ProtocolConstants.PROP_PARENT ), ViewGroup.class );
  }

  private void initiateAsToplevelWidget( CreateOperation operation, View view ) {
    setInitialLayoutParams( view );
    registerAsToplevelWidget( operation.getTarget(), view );
    RemoteObject remoteObject = getObjectRegistry().getRemoteObject( operation.getTarget() );
    remoteObject.addListen( EVENT_PRESENTATION_CHANGED );
    remoteObject.addListen( EVENT_PLAYBACK_CHANGED );
    applyProperties( operation, view );
  }

  private void registerAsToplevelWidget( String target, View view ) {
    ObjectRegistry objectRegistry = getObjectRegistry();
    objectRegistry.register( target, view, TYPE );
    ViewGroup display = objectRegistry.getObject( DisplayOperator.DISPLAY_ID, ViewGroup.class );
    display.addView( view );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    VideoHolder videoHolder = getObjectRegistry().getObject( operation.getTarget(), VideoHolder.class );
    getWidgetToolkit().removeAppStateListener( videoHolder );
    super.destroy( operation );
  }
}
