/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class DateTimeSpinner extends Spinner {

  private final IDateTimeSpinnerDialog dialog;
  private final SimpleDateFormat dateFormatter;
  private final ArrayAdapter<String> adapter;
  private final String dateFormat;
  private Date date;
  private final ListenerHolder<DateTimeChangedListener> holder;

  public DateTimeSpinner( final Context context,
                          ArrayAdapter<String> adapter,
                          IDateTimeSpinnerDialog dialog,
                          String dateFormat )
  {
    super( context );
    assertNotNull( context, "context" );
    assertNotNull( adapter, "adapter" );
    assertNotNull( dialog, "dialog" );
    assertNotNull( dateFormat, "dateFormat" );
    this.adapter = adapter;
    this.dialog = dialog;
    this.dateFormat = dateFormat;
    dateFormatter = new SimpleDateFormat( dateFormat );
    holder = new ListenerHolder<DateTimeChangedListener>();
    setAdapter( adapter );
    dialog.setDateTimeSpinner( this );
  }

  private void assertNotNull( Object obj, String field ) {
    if( obj == null ) {
      String msg = "The " + field + " of a " + getClass().getSimpleName() + " can not be null";
      throw new IllegalArgumentException( msg );
    }
  }

  @Override
  public boolean performClick() {
    dialog.reset();
    dialog.show();
    return true;
  }

  void setDate( Date date ) {
    this.date = date;
    adapter.clear();
    adapter.add( formatDate( date ) );
  }

  void fireDateTimeChanged() {
    ArrayList<DateTimeChangedListener> listeners = holder.getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).dateTimeChanged( this );
    }
  }

  public void addListener( DateTimeChangedListener listener ) {
    holder.addListener( listener );
  }

  public void removeListeners( Class<? extends DateTimeChangedListener> listenerClass ) {
    holder.removeListeners( listenerClass );
  }

  public Date getDate() {
    return date;
  }

  String formatDate( Date date ) {
    return dateFormatter.format( date );
  }

  public IDateTimeSpinnerDialog getDialog() {
    return dialog;
  }

  /** To be used for testing only. */
  public ArrayList<DateTimeChangedListener> getListeners() {
    return holder.getListeners();
  }

  /** To be used for testing only. */
  public String getDateFormat() {
    return dateFormat;
  }
}
