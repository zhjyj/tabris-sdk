/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class BeginPathGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "beginPath";

  public BeginPathGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    gc.createNewPath();
  }

}
