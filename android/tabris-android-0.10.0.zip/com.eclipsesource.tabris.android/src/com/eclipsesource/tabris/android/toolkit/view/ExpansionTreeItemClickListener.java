/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ExpansionTreeItemClickListener implements OnItemClickListener {

  private final TabrisActivity activity;

  public ExpansionTreeItemClickListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    if( parent instanceof TreeView ) {
      TreeView treeView = ( TreeView )parent;
      ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
      if( currentTreeItems.size() > position ) {
        TreeItemView selectedItem = currentTreeItems.get( position );
        if( selectedItem.hasChildren() ) {
          updateRemoteObject( treeView, selectedItem );
          treeView.expandTree( selectedItem );
        }
      }
    }
  }

  private void updateRemoteObject( TreeView treeView, TreeItemView selectedItem ) {
    RemoteObject itemRemoteObject = activity.getRemoteObject( selectedItem );
    itemRemoteObject.set( PROP_EXPANDED, true );
    RemoteObject remoteObject = activity.getRemoteObject( treeView );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, itemRemoteObject.getId() );
    remoteObject.notify( EVENT_EXPAND, properties );
    addVirtualTreeParameter( treeView, selectedItem );
  }

  private void addVirtualTreeParameter( TreeView treeView, TreeItemView selectedItem ) {
    if( treeView.hasVirtualTreeSupport() ) {
      VirtualTreeSupport virtualTreeSupport = treeView.getVirtualTreeSupport();
      virtualTreeSupport.reset();
      virtualTreeSupport.setTopItemIndex( treeView, selectedItem );
    }
  }

}