/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_TEXT;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class TextChangeListener implements TextWatcher {

  private final TabrisActivity activity;
  private final View view;

  public TextChangeListener( TabrisActivity activity, View view ) {
    notNull( activity, "Activity" );
    notNull( view, "View" );
    this.activity = activity;
    this.view = view;
  }

  public void beforeTextChanged( CharSequence s, int start, int count, int after ) {
    // ignore
  }

  public void onTextChanged( CharSequence s, int start, int before, int count ) {
    // ignore
  }

  public void afterTextChanged( Editable s ) {
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.set( PROP_TEXT, s.toString() );
  }
}
