
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.AppState;
import com.eclipsesource.tabris.android.toolkit.IAppStateListener;

public class AppEvent implements IAppStateListener {

  private final TabrisActivity activity;

  public AppEvent( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void stateChanged( AppState state ) {
    RemoteObject remoteObject = activity.getRemoteObject( this );
    switch( state ) {
      case PAUSE:
        remoteObject.notify( EVENT_PAUSE );
      break;
      case RESUME:
        remoteObject.notify( EVENT_RESUME );
      break;
      default:
      break;
    }
  }

}
