/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_MENU_DETECT;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_MOUSE_DOWN;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_X;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_Y;

import java.util.HashMap;
import java.util.Map;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class LongClickListener extends BaseMotionListener implements OnLongClickListener {

  private final IMotionBuffer motionBuffer;
  private final MouseEventTouchListener mouseEventTouchListener;
  private boolean isTransmittingMenuDetect;

  public LongClickListener( TabrisActivity activity,
                            IMotionBuffer motionBuffer,
                            MouseEventTouchListener mouseEventTouchListener,
                            boolean isTransmittingMenuDetect )
  {
    super( activity );
    this.motionBuffer = motionBuffer;
    this.mouseEventTouchListener = mouseEventTouchListener;
    this.isTransmittingMenuDetect = isTransmittingMenuDetect;
  }

  public boolean isTransmittingMenuDetect() {
    return isTransmittingMenuDetect;
  }

  public void setTransmittingMenuDetect( boolean isTransmittingMenuDetect ) {
    this.isTransmittingMenuDetect = isTransmittingMenuDetect;
  }

  public boolean onLongClick( View view ) {
    if( mouseEventTouchListener.isTransmittingUpDown() ) {
      sendMouseEvent( motionBuffer.getLastMotion(), EVENT_MOUSE_DOWN, MOUSE_BUTTON_3, view );
      mouseEventTouchListener.longPressDetected();
    }
    if( isTransmittingMenuDetect ) {
      sendMenuDetectEvent( motionBuffer.getLastMotion(), view );
    }
    motionBuffer.clear();
    return true;
  }

  private void sendMenuDetectEvent( MotionEvent event, View view ) {
    int[] coordinates = getMouseCoordinates( event );
    updateDisplayCursorLocation( coordinates );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_X, coordinates[ 0 ] );
    properties.put( PROP_Y, coordinates[ 1 ] );
    remoteObject.notify( EVENT_MENU_DETECT, properties );
  }
  
}
