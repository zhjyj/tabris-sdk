/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.SpinnerSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.SpinnerItemSelectedListener;

public class ComboOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Combo";

  private final IViewSetter<? extends View> setter;

  public ComboOperator( TabrisActivity activity ) {
    super( activity );
    setter = new SpinnerSetter<Spinner>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  @SuppressWarnings("unchecked")
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Spinner spinner = new Spinner( getActivity() );
    attachAdapter( spinner, operation );
    spinner.setOnItemSelectedListener( new SpinnerItemSelectedListener( getActivity() ) );
    initiateNewView( operation, spinner );
  }

  private void attachAdapter( Spinner spinner, CreateOperation operation ) {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( getActivity(),
                                                             android.R.layout.simple_spinner_item );
    adapter.setDropDownViewResource( R.layout.spinner_dropdown_item );
    spinner.setAdapter( adapter );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    // no action required
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    // no action required
  }
}
