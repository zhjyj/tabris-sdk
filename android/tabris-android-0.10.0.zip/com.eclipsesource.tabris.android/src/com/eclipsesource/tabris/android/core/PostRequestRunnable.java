/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;

final class PostRequestRunnable implements Runnable {

  private final ProtocolProcessor processor;

  public PostRequestRunnable( ProtocolProcessor processor ) {
    this.processor = processor;
  }

  public void run() {
    PostRequest request = processor.getNextRequest();
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    IProgressIndicator progressIndicator = toolkit.getProgressIndicator();
    startProgressOnNonSilentRequests( progressIndicator, request );
    ITransportResult transportResult = processor.getTransport().post( request );
    progressIndicator.stop();
    processTransportResult( toolkit, transportResult );
  }

  private void startProgressOnNonSilentRequests( IProgressIndicator progressIndicator,
                                                 PostRequest request )
  {
    if( !request.isSilentRequest() ) {
      progressIndicator.start();
    }
  }

  private void processTransportResult( IWidgetToolkit toolkit, ITransportResult transportResult ) {
    if( transportResult.hasParsableContent() ) {
      parse( toolkit, transportResult );
    } else {
      toolkit.showError( transportResult.getException(), null );
    }
  }

  private void parse( IWidgetToolkit toolkit, ITransportResult transportResult ) {
    try {
      processor.getParser().parse( transportResult.getResult() );
    } catch( Exception e ) {
      toolkit.showError( e, null );
    }
  }

}