
package com.eclipsesource.tabris.android.toolkit;

public interface IOperationsListProcessedListener {

  void listProcessed();

}
