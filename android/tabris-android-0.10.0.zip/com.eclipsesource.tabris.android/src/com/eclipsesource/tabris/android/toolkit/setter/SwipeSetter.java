
package com.eclipsesource.tabris.android.toolkit.setter;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.Swipe;

public class SwipeSetter<T extends Swipe> extends ViewSetter<T> {

  public SwipeSetter( TabrisActivity activity ) {
    super( activity );
  }

}
