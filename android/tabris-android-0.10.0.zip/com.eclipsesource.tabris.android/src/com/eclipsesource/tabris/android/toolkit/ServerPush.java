/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;

public class ServerPush extends BroadcastReceiver implements IOperationsListProcessedListener {

  private final TabrisActivity activity;
  private Thread thread;
  private boolean active;

  public ServerPush( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void activate( boolean active ) {
    this.active = active;
    if( active ) {
      activity.registerReceiver( this, new IntentFilter( ConnectivityManager.CONNECTIVITY_ACTION ) );
      getWidgetToolkit().addOperationsListProcessedListener( this );
      activateServerPushThread( active );
    } else {
      activateServerPushThread( active );
      try {
        activity.unregisterReceiver( this );
      } catch( Exception e ) {
        // unregistering throws an exception when the receiver is not
        // registered. Can be ignored.
      }
      getWidgetToolkit().removeOperationsListProcessedListener( this );
    }
  }

  private IWidgetToolkit getWidgetToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }

  private void activateServerPushThread( boolean active ) {
    interruptThread();
    if( active ) {
      startThread();
    }
  }

  private void startThread() {
    thread = createNewThread();
    thread.start();
  }

  protected Thread createNewThread() {
    return new Thread( new ServerPushRunnable( activity ) );
  }

  private void interruptThread() {
    if( isServerPushActive() ) {
      thread.interrupt();
    }
  }

  public boolean isServerPushActive() {
    return thread != null && thread.isAlive() && !thread.isInterrupted();
  }

  /** To be used for testing only. */
  public Thread getThread() {
    return thread;
  }

  @Override
  public void onReceive( Context context, Intent intent ) {
    String action = intent.getAction();
    if( ConnectivityManager.CONNECTIVITY_ACTION.equals( action ) ) {
      boolean isConnected = !intent.getBooleanExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY,
                                                     false );
      if( isServerPushActive() && !isConnected ) {
        activateServerPushThread( false );
      } else if( !isServerPushActive() && isConnected ) {
        activateServerPushThread( true );
      }
    }
  }

  public void listProcessed() {
    if( active && !isServerPushActive() ) {
      startThread();
    }
  }

}