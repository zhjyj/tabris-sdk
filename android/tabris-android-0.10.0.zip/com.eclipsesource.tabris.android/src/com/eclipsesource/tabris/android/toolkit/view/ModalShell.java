/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.app.Activity;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class ModalShell extends Shell {

  private View dim;
  protected Composite content;

  public ModalShell( TabrisActivity activity, ShellAnimationSupport animSupport ) {
    super( activity, animSupport );
    int styleResId = ThemeUtil.getAttrResId( activity, android.R.attr.alertDialogStyle );
    TypedArray backgroundArray = activity.obtainStyledAttributes( styleResId,
                                                                  new int[]{ android.R.attr.fullBright } );
    super.setBackgroundDrawable( backgroundArray.getDrawable( 0 ) );
    content = new Composite( activity );
    super.addView( content );
  }

  public void dimBackground( TabrisActivity activity, ViewGroup rootLayout ) {
    dim = new View( activity );
    dim.setBackgroundDrawable( getDimBackround( activity ) );
    dim.setMinimumWidth( rootLayout.getWidth() );
    dim.setMinimumHeight( rootLayout.getHeight() );
    dim.setOnTouchListener( new ConsumingTouchListener( activity ) );
    rootLayout.addView( dim );
  }

  private Drawable getDimBackround( Activity activity ) {
    return activity.getResources()
      .getDrawable( android.R.drawable.screen_background_dark_transparent );
  }

  public void undimBackground( ViewGroup rootLayout ) {
    rootLayout.removeView( dim );
  }

  @Override
  public void playShowAnimation( TabrisActivity activity ) {
    animSupport.playModalShellAnimation( this, android.R.attr.windowEnterAnimation, activity );
    animSupport.playDimAnimation( dim, android.R.attr.windowEnterAnimation, activity );
  }

  @Override
  public void playHideAnimation( TabrisActivity activity ) {
    animSupport.playModalShellAnimation( this, android.R.attr.windowExitAnimation, activity );
    animSupport.playDimAnimation( dim, android.R.attr.windowExitAnimation, activity );
  }

  @Override
  public void addView( View view ) {
    content.addView( view );
  }

  @Override
  public void removeView( View view ) {
    removeViewAt( content.indexOfChild( view ) );
  }

  @Override
  public void removeViewAt( int index ) {
    content.removeViewAt( index );
  }

  @Override
  public int indexOfChild( View child ) {
    return content.indexOfChild( child );
  }

  @Override
  public void setBackgroundDrawable( Drawable d ) {
    content.setBackgroundDrawable( d );
  }

  @Override
  public void bringChildToFront( View child ) {
    content.bringChildToFront( child );
  }

  @Override
  public void setBackgroundColor( int color ) {
    /*
     * ignored until a mechanism to color the background 9 patch has been found
     */
  }
}
