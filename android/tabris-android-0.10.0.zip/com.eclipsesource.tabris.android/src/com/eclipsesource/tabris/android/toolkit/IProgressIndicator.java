/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

public interface IProgressIndicator {

  public void start();

  public void stop();
}
