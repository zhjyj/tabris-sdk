/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.checkNullArg;
import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ViewClickListener implements OnClickListener {

  private final TabrisActivity activity;

  public ViewClickListener( TabrisActivity activity ) {
    checkNullArg( this, activity, TabrisActivity.class );
    this.activity = activity;
  }

  public void onClick( View view ) {
    notNull( view, "View" );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.notify( EVENT_SELECTION, null );
  }
}