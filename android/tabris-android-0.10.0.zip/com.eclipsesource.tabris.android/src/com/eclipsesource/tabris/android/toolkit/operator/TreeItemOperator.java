/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.validateCreateOperation;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.TreeItemViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;

public class TreeItemOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.GridItem";

  private final IViewSetter<? extends View> setter;

  public TreeItemOperator( TabrisActivity activity ) {
    super( activity );
    setter = new TreeItemViewSetter<TreeItemView>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    TreeItemView treeItemView = new TreeItemView( getActivity() );
    initiateNewView( operation, treeItemView );
  }
  
  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( !( view instanceof TreeItemView ) ) {
      throw new IllegalArgumentException( "Could not find TreeItemView "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    TreeItemView treeItemView = ( TreeItemView )view;
    treeItemView.getTreeItemParent().removeView( view );
    TreeItemViewSetter.decreaseReferenceCount( getProcessor(), treeItemView );
    getWidgetToolkit().getListenerRegistry().unregisterAllListeners( operation.getTarget() );
  }
}
