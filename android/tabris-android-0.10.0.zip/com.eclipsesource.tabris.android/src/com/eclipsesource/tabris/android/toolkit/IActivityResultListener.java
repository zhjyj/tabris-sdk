
package com.eclipsesource.tabris.android.toolkit;

import android.content.Intent;

public interface IActivityResultListener {

  void receivedActivityResult( int requestCode, int resultCode, Intent intent );

}
