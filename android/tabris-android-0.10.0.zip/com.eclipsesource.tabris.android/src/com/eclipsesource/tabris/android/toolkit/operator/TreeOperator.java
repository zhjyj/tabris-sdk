/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.TreeBackKeyEventListener;
import com.eclipsesource.tabris.android.toolkit.setter.TreeViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ExpansionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.SelectionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.TreeViewAdapter;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;

public class TreeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Grid";
  public static final String STYLE_VIRTUAL = "VIRTUAL";

  private final IViewSetter<? extends View> setter;

  public TreeOperator( TabrisActivity activity ) {
    super( activity );
    setter = new TreeViewSetter<TreeView>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  @SuppressWarnings("unchecked")
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  @Override
  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    TreeView treeView = new TreeView( getActivity() );
    treeView.setAdapter( new TreeViewAdapter( getActivity(), treeView ) );
    attachDefaultListeners( treeView );
    attachVirtualListener( treeView, operation );
    initiateNewView( operation, treeView );
    activateTreeEventListeners( treeView );
  }

  private void activateTreeEventListeners( TreeView view ) {
    RemoteObject remoteObject = getActivity().getRemoteObject( view );
    remoteObject.addListen( EVENT_COLLAPSE );
    remoteObject.addListen( EVENT_EXPAND );
  }

  private void attachDefaultListeners( TreeView treeView ) {
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    ExpansionTreeItemClickListener expansionTreeItemClickListener = new ExpansionTreeItemClickListener( getActivity() );
    compListener.addListener( expansionTreeItemClickListener );
    treeView.setOnItemClickListener( compListener );
  }

  private void attachVirtualListener( TreeView treeView, CreateOperation operation ) {
    List<String> style = operation.getProperties().getList( ProtocolConstants.PROP_STYLE,
                                                            String.class );
    if( style != null && style.contains( STYLE_VIRTUAL ) ) {
      treeView.setVirtualTreeSupport( new VirtualTreeSupport( getActivity() ) );
    }
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final TreeView treeView = findObjectById( operation.getTarget(), TreeView.class );
    CompositeItemClickListener compListener = ( CompositeItemClickListener )treeView.getOnItemClickListener();
    compListener.addListener( new SelectionTreeItemClickListener( getActivity() ) );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    final TreeView treeView = findObjectById( operation.getTarget(), TreeView.class );
    CompositeItemClickListener compListener = ( CompositeItemClickListener )treeView.getOnItemClickListener();
    compListener.removeListeners( SelectionTreeItemClickListener.class );
  }

  @Override
  @SuppressWarnings("rawtypes")
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null ) {
      throw new IllegalArgumentException( "Could not find widget "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    TreeBackKeyEventListener backListener = ( ( TreeViewSetter )setter ).getBackListener();
    if( backListener != null ) {
      TreeView treeView = backListener.getTreeView();
      if( treeView == view ) {
        getWidgetToolkit().removeKeyEventListener( backListener );
      }
    }
  }
}
