/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static android.text.InputType.*;

import java.util.List;

import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener;
import com.eclipsesource.tabris.android.toolkit.view.DefaultSelectionKeyListener;
import com.eclipsesource.tabris.android.toolkit.view.ModifyListener;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.TextChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.TextSelectionChangeListener;

public class TextOperator extends LabelOperator {

  public static final String TYPE = "rwt.widgets.Text";

  private static final String STYLE_BORDER = "BORDER";
  private static final String STYLE_SINGLE = "SINGLE";
  private static final String STYLE_PASSWORD = "PASSWORD";
  private static final String STYLE_MULTI = "MULTI";

  private final IViewSetter<? extends View> setter;

  public TextOperator( TabrisActivity activity ) {
    super( activity );
    setter = new EditTextSetter<EditText>( activity );
  }

  @Override
  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  @Override
  public void create( CreateOperation operation ) {
    EditText editText = new Text( getActivity() );
    editText.setGravity( Gravity.TOP );
    setTextProperties( editText, operation.getProperties() );
    initiateNewView( operation, editText );
    initiateTextChangeListener( editText );
    initiateSelectionListener( editText );
    initiateCompositeFocusListener( editText );
  }

  @Override
  protected void attachDefaultSelectionListener( ListenOperation operation ) {
    EditText view = ( EditText )findViewByTarget( operation );
    int inputType = view.getInputType();
    if( ( inputType & TYPE_TEXT_FLAG_MULTI_LINE ) != TYPE_TEXT_FLAG_MULTI_LINE ) {
      view.setOnEditorActionListener( new DefaultSelectionKeyListener( getActivity() ) );
    }
  }

  @Override
  protected void removeDefaultSelectionListener( ListenOperation operation ) {
    EditText view = ( EditText )findViewByTarget( operation );
    int inputType = view.getInputType();
    if( ( inputType & TYPE_TEXT_FLAG_MULTI_LINE ) != TYPE_TEXT_FLAG_MULTI_LINE ) {
      view.setOnEditorActionListener( null );
    }
  }

  private void initiateCompositeFocusListener( EditText editText ) {
    CompositeFocusListener compositeListener = new CompositeFocusListener();
    getListenerRegistry().registerListener( getObjectId( editText ), compositeListener );
    editText.setOnFocusChangeListener( compositeListener );
  }

  private void setTextProperties( EditText text, Properties props ) {
    text.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.TEXT_TEXT_SIZE );

    List<String> styles = props.getList( ProtocolConstants.PROP_STYLE, String.class );

    if( styles != null ) {
      if( !styles.contains( STYLE_BORDER ) ) {
        text.setBackgroundDrawable( null );
      }
      if( styles.contains( STYLE_SINGLE ) ) {
        // has to precede any PASSWORD style that may follow!
        text.setSingleLine( true );
      }
      if( styles.contains( STYLE_MULTI ) ) {
        text.setInputType( TYPE_TEXT_FLAG_MULTI_LINE | TYPE_CLASS_TEXT );
      }
      if( styles.contains( STYLE_PASSWORD ) ) {
        text.setTransformationMethod( new PasswordTransformationMethod() );
        text.setInputType( TYPE_TEXT_FLAG_NO_SUGGESTIONS );
      }
    }
  }

  private void initiateTextChangeListener( EditText view ) {
    TextChangeListener listener = new TextChangeListener( getActivity(), view );
    view.addTextChangedListener( listener );
  }

  private void initiateSelectionListener( EditText view ) {
    TextSelectionChangeListener listener = new TextSelectionChangeListener( getActivity(), view );
    ( ( Text )view ).setSelectionChangeListener( listener );
  }

  @Override
  protected void attachModifyListener( ListenOperation operation ) {
    final EditText view = ( EditText )findViewByTarget( operation );
    String widgetId = getObjectId( view );
    ModifyListener listener = new ModifyListener( getActivity(), view );
    view.addTextChangedListener( listener );
    getListenerRegistry().registerListener( widgetId, listener );
  }

  @Override
  protected void removeModifyListener( ListenOperation operation ) {
    String tag = operation.getTarget();
    final EditText view = ( EditText )findViewByTarget( operation );
    TextWatcher listenerToRemove = getListenerRegistry().unregisterListener( tag, TextWatcher.class );
    if( listenerToRemove != null ) {
      view.removeTextChangedListener( listenerToRemove );
    }
  }

}
