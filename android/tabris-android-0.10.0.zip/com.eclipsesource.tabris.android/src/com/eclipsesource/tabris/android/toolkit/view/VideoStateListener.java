/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_PLAYBACK_CHANGED;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_MODE;

import java.util.HashMap;
import java.util.Map;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;

public class VideoStateListener implements IVideoStateListener {

  private final VideoHolder holder;
  private final TabrisActivity activity;

  public VideoStateListener( TabrisActivity activity, VideoHolder holder ) {
    this.activity = activity;
    this.holder = holder;
  }

  public void videoStateChanged( VideoState videoState ) {
    RemoteObject remoteObject = activity.getRemoteObject( holder );
    Map<String, Object> properties= new HashMap<String, Object>();
    properties.put( PROP_MODE, videoState.name().toLowerCase() );
    remoteObject.notify( EVENT_PLAYBACK_CHANGED, properties );
  }

}
