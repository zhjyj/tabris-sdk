/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.text.TextWatcher;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListenerRegistry_Test {

  private static final String WIDGET_ID = "w3";
  private static final String OTHER_WIDGET_ID = "w2";

  @Test
  public void testCreation() {
    ListenerRegistry registry = new ListenerRegistry();

    assertNotNull( registry );
  }

  @Test
  public void testUnregisterFromEmpty() {
    ListenerRegistry registry = new ListenerRegistry();

    Object removedListener = registry.unregisterListener( WIDGET_ID, TextWatcher.class );

    assertNull( removedListener );
  }

  @Test
  public void testRegisterAtEmpty() {
    ListenerRegistry registry = new ListenerRegistry();
    String listener = new String( "123" );

    registry.registerListener( WIDGET_ID, listener );
    Object removedListener = registry.unregisterListener( WIDGET_ID, String.class );
    Object removedListener2 = registry.unregisterListener( WIDGET_ID, String.class );

    assertNotNull( removedListener );
    assertEquals( listener, removedListener );
    assertNull( removedListener2 );
  }

  @Test
  public void testRegisterMultipleListeners() {
    ListenerRegistry registry = new ListenerRegistry();
    TextWatcher listener1 = Mockito.mock( TextWatcher.class );
    TextWatcher listener2 = Mockito.mock( TextWatcher.class );

    registry.registerListener( WIDGET_ID, listener1 );
    registry.registerListener( WIDGET_ID, listener2 );

    assertEquals( 1, registry.getBackingStore().size() );
  }

  @Test
  public void testRemoveListenerFromMultipleListeners() {
    ListenerRegistry registry = new ListenerRegistry();
    Integer listener1 = new Integer( 123 );
    String listener2 = new String();

    registry.registerListener( WIDGET_ID, listener1 );
    registry.registerListener( WIDGET_ID, listener2 );

    registry.unregisterListener( WIDGET_ID, String.class );

    Map<String, Set<Object>> backingStore = registry.getBackingStore();
    assertEquals( 1, backingStore.size() );
    assertTrue( backingStore.get( WIDGET_ID ).contains( listener1 ) );
    assertEquals( 1, backingStore.get( WIDGET_ID ).size() );
  }

  @Test
  public void testUnregisterOtherWidgetAtEmpty() {
    ListenerRegistry registry = new ListenerRegistry();
    TextWatcher listener = Mockito.mock( TextWatcher.class );

    registry.registerListener( WIDGET_ID, listener );
    Object removedListener = registry.unregisterListener( OTHER_WIDGET_ID, TextWatcher.class );

    assertNull( removedListener );
  }

  @Test
  public void testIsTotalyEmptyAfterLastListenerWasUnregistered() {
    ListenerRegistry registry = new ListenerRegistry();
    String listener = new String( "213" );
    registry.registerListener( WIDGET_ID, listener );
    assertEquals( 1, registry.getBackingStore().size() );
    assertTrue( registry.getBackingStore().containsKey( WIDGET_ID ) );

    Object removedListener = registry.unregisterListener( WIDGET_ID, String.class );

    assertNotNull( removedListener );
    assertFalse( registry.getBackingStore().containsKey( WIDGET_ID ) );
  }

  @Test
  public void testGetListenerNullArg() throws Exception {
    ListenerRegistry registry = new ListenerRegistry();

    assertNull( registry.findListener( null, null ) );
  }

  @Test
  public void testGetListenerNotExistent() throws Exception {
    ListenerRegistry registry = new ListenerRegistry();
    Object listener = new Object();

    assertNull( registry.findListener( WIDGET_ID, listener.getClass() ) );
  }

  @Test
  public void testGetListenerOk() throws Exception {
    ListenerRegistry registry = new ListenerRegistry();
    Object listener = new Object();
    registry.registerListener( WIDGET_ID, listener );

    assertSame( listener, registry.findListener( WIDGET_ID, listener.getClass() ) );
    assertSame( listener, registry.findListener( WIDGET_ID, listener.getClass() ) );
  }

  @Test
  public void testRemoveAllListenersOnNonExistentWidget() throws Exception {
    ListenerRegistry registry = new ListenerRegistry();
    Object listener = new Object();
    registry.registerListener( WIDGET_ID, listener );

    registry.unregisterAllListeners( OTHER_WIDGET_ID );

    assertEquals( 1, registry.getBackingStore().size() );
  }

  @Test
  public void testRemoveAllListenersOk() throws Exception {
    ListenerRegistry registry = new ListenerRegistry();
    Object listener = new Object();
    registry.registerListener( WIDGET_ID, listener );
    String otherListener = new String();
    registry.registerListener( WIDGET_ID, otherListener );
    Object otherWidgetsListener = new Object();
    registry.registerListener( OTHER_WIDGET_ID, otherWidgetsListener );

    registry.unregisterAllListeners( WIDGET_ID );

    assertEquals( 1, registry.getBackingStore().size() );
    assertEquals( 0, registry.getNumberOfListenersForWidget( WIDGET_ID ) );
    assertEquals( 1, registry.getNumberOfListenersForWidget( OTHER_WIDGET_ID ) );
  }
}
