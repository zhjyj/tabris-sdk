/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.view.AlternativeSelection;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListSelectionAdapter;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    setter.execute( null, mock( Properties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    setter.execute( mock( List.class ), null );
  }

  @Test
  public void testSetItems() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    Properties props = new Properties();
    props.add( "items", Arrays.asList( "one", "two", "three" ) );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).setItems( props.getList( "items", String.class ), activity );
  }

  @Test
  public void testSetItemsNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "items", null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetItemsEmpty() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    Properties props = new Properties();
    props.add( "items", new ArrayList<String>() );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).setItems( props.getList( "items", String.class ), activity );
  }

  @Test
  public void testSetBackgroundNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "background", null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetSelectionIndices() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "selectionIndices", Arrays.asList( 2 ) );
    List list = mock( List.class );
    ListSelectionAdapter adapter = mock( ListSelectionAdapter.class );
    when( list.getAdapter() ).thenReturn( adapter );

    setter.execute( list, props );

    verify( adapter ).setSelectionIndex( 2 );
  }

  @Test
  public void testSetSelectionIndicesEmpty() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "selectionIndices", new ArrayList<Integer>() );
    List list = mock( List.class );
    ListSelectionAdapter adapter = mock( ListSelectionAdapter.class );
    when( list.getAdapter() ).thenReturn( adapter );

    setter.execute( list, props );

    verify( adapter ).setSelectionIndex( ListSelectionAdapter.NOTHING_SELECTED );
  }

  @Test
  public void testSetSelectionIndicesNull() throws Exception {
    ListSetter<List> setter = new ListSetter<List>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "selectionIndices", null );
    List list = mock( List.class );

    setter.execute( list, props );

    verifyNoMoreInteractions( list );
  }

  @Test
  public void testSetTopIndex() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    Properties props = new Properties();
    props.add( "topIndex", 1 );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).smoothScrollToPosition( 1 );
  }

  @Test
  public void testNullCustomVariantShouldNotChangeAlternativeSelection() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    Properties props = new Properties();
    props.add( "customVariant", null );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list, never() ).setAlternativeSelection( any( AlternativeSelection.class ) );
  }

  @Test
  public void testShouldSetAlternativeSelectionOnList() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ListSetter<List> setter = new ListSetter<List>( activity );
    Properties props = new Properties();
    props.add( "customVariant", "variant_ALT_SELECTION" );
    List list = mock( List.class );

    setter.execute( list, props );

    verify( list ).setAlternativeSelection( AlternativeSelection.ALL );
  }
}
