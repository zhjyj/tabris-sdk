/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test;

import java.io.File;
import java.lang.reflect.Method;

import org.junit.runners.model.InitializationError;

import com.eclipsesource.tabris.android.test.shadow.TabrisShadowLooper;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

public class TabrisTestRunner extends RobolectricTestRunner {

  public TabrisTestRunner( final Class<?> testClass ) throws InitializationError {
    super( testClass );
  }

  public TabrisTestRunner( final Class<?> testClass, final File androidProjectRoot )
    throws InitializationError
  {
    super( testClass, androidProjectRoot );
  }

  @Override
  public void beforeTest( Method method ) {
    super.beforeTest( method );
    Robolectric.bindShadowClass( TabrisShadowLooper.class );
  }
}
