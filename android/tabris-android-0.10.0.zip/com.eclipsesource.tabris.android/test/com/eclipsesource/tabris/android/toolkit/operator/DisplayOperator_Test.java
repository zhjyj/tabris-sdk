/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.DisplaySetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DisplayOperator_Test {

  private TabrisActivity activity;
  private DisplayOperator operator;
  private ObjectRegistry objectRegistry;
  private Display display;

  @Before
  public void setUp() {
    activity = UiTestUtil.createMockedActivity();
    display = mock( Display.class );
    when( activity.findViewById( R.id.root_layout ) ).thenReturn( display );
    objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    operator = new DisplayOperator( activity );
  }

  @Test
  public void testViewSetter() throws Exception {
    IViewSetter<View> viewSetter = operator.getViewSetter( mock( Display.class ) );

    assertTrue( viewSetter instanceof DisplaySetter );
  }

  @Test
  public void testGetType() throws Exception {
    assertEquals( DisplayOperator.TYPE, operator.getType() );
  }

  @Test
  public void testCreateDisplayOK() throws Exception {
    CreateOperation op = new CreateOperation();
    op.setTarget( "w1" );
    op.setType( "rwt.widgets.Display" );

    operator.create( op );

    verify( objectRegistry ).register( "w1", display, "rwt.widgets.Display" );
    verify( display ).sendInitialPostRequest();
  }

}
