/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

public class DefaultFonts_Test {

  @Test
  public void testNumberOfFonts() {
    assertEquals( 5, DefaultFonts.getFonts().size() );
  }

  @Test
  public void testDifferentHashes() {
    List<?> fonts = DefaultFonts.getFonts();
    Set<Integer> keys = new HashSet<Integer>();
    for( Object entry : fonts ) {
      keys.add( ( Integer )( ( List<?> )entry ).get( 0 ) );
    }

    assertEquals( 5, keys.size() );
  }

}
