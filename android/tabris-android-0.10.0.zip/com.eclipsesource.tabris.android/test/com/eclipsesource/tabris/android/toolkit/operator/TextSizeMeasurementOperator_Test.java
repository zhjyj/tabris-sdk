package com.eclipsesource.tabris.android.toolkit.operator;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.TextSizeMeasurement;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;


@RunWith(RobolectricTestRunner.class)
public class TextSizeMeasurementOperator_Test {

  private TabrisActivity activity;
  private ObjectRegistry objectRegistry;
  private TextSizeMeasurementOperator operator;
  private TextSizeMeasurement measurement;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFields();
    operator = new TextSizeMeasurementOperator( activity );
    objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    measurement = mock( TextSizeMeasurement.class );
  }

  @Test
  public void testCall_MeasurementNotCreated() throws Exception {
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
    String type = "rwt.client.TextSizeMeasurement";
    when( objectRegistry.getObject( type, TextSizeMeasurement.class ) ).thenReturn( null );

    operator.call( createCallOperation() );

    verify( objectRegistry ).register( eq( type ), any( TextSizeMeasurement.class ), eq( type ) );
  }

  @Test
  public void testCall_MeasurementAlreadyCreated() throws Exception {
    String type = "rwt.client.TextSizeMeasurement";
    when( objectRegistry.getObject( type, TextSizeMeasurement.class ) ).thenReturn( measurement );

    operator.call( createCallOperation() );

    verify( measurement ).measureItems( new ArrayList<List<Object>>() );
  }

  private CallOperation createCallOperation() {
    CallOperation result = new CallOperation();
    result.setTarget( "rwt.client.TextSizeMeasurement" );
    result.setMethod( "measureItems" );
    Properties properties = new Properties();
    properties.add( "items", new ArrayList<List<Object>>() );
    result.setProperties( properties  );
    return result;
  }

}
