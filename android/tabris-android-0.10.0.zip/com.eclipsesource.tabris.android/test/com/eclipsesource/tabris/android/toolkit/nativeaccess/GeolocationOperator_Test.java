/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator.NeedsPositionFlavor;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class GeolocationOperator_Test {

  private TabrisActivity activity;
  private GeolocationOperator operator;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFields();
    toolkit = activity.getProcessor().getWidgetToolkit();
    operator = new GeolocationOperator( activity );
  }

  @Test
  public void testType() {
    assertEquals( "tabris.Geolocation", operator.getType() );
  }

  @Test
  public void testRegistersNewOne() {
    ObjectRegistry objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
    CreateOperation operation = mock( CreateOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );

    operator.create( operation );

    verify( objectRegistry ).register( eq( "foo" ), any( Geolocation.class ), eq( GeolocationOperator.TYPE ) );
  }
  
  @Test
  public void testCreateAddsDefaultListnersListensToEvents() {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( remoteObject );
    CreateOperation operation = mock( CreateOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );

    operator.create( operation );
    
    verify( remoteObject ).addListen( "LocationUpdate" );
    verify( remoteObject ).addListen( "LocationUpdateError" );
  }

  @Test
  public void testUnregistersOnDestroy() {
    mockGeolocation();
    DestroyOperation operation = mock( DestroyOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );

    operator.destroy( operation );

    assertNull( toolkit.getObjectRegistry().getObject( "foo" ) );
  }

  @Test
  public void testDestroy() {
    Geolocation geolocation = mockGeolocation();
    DestroyOperation operation = mock( DestroyOperation.class );
    when( operation.getTarget() ).thenReturn( "foo" );

    operator.destroy( operation );

    verify( geolocation ).destroy();
  }

  @Test
  public void testSetsNothingWhenEmpty() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties( operation );

    operator.set( operation );

    verify( geolocation, never() ).setNeedsPosition( any( NeedsPositionFlavor.class ) );
    verify( geolocation, never() ).setFrequency( anyInt() );
    verify( geolocation, never() ).setMaximumAge( anyInt() );
  }

  @Test
  public void testSetsNeedPositionNever() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "needsPosition", NeedsPositionFlavor.NEVER.toString() );

    operator.set( operation );

    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.NEVER );
  }

  @Test(expected = IllegalStateException.class)
  public void testAvoidsNullValues() {
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "needsPosition", NeedsPositionFlavor.NEVER.toString() );

    operator.set( operation );
  }

  @Test
  public void testSetsNeedPositionOnce() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "needsPosition", NeedsPositionFlavor.ONCE.toString() );

    operator.set( operation );

    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.ONCE );
  }

  @Test
  public void testSetsNeedPositionContinous() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "needsPosition", NeedsPositionFlavor.CONTINUOUS.toString() );

    operator.set( operation );

    verify( geolocation ).setNeedsPosition( NeedsPositionFlavor.CONTINUOUS );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetsNeedPositionUnknown() {
    mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "needsPosition", "foo" );

    operator.set( operation );
  }

  @Test
  public void testSetsEnableHighAccuracyWithTrue() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "enableHighAccuracy", true );

    operator.set( operation );

    verify( geolocation ).setEnableHighAccuracy( true );
  }

  @Test
  public void testSetsEnableHighAccuracyWithFalse() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "enableHighAccuracy", false );

    operator.set( operation );

    verify( geolocation ).setEnableHighAccuracy( false );
  }

  @Test
  public void testSetsFrequency() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "frequency", Integer.valueOf( 10 ) );

    operator.set( operation );

    verify( geolocation ).setFrequency( 10 );
  }

  @Test
  public void testSetsMaximumAge() {
    Geolocation geolocation = mockGeolocation();
    SetOperation operation = new SetOperation();
    Properties properties = Properties( operation );
    properties.add( "maximumAge", Integer.valueOf( 10 ) );

    operator.set( operation );

    verify( geolocation ).setMaximumAge( 10 );
  }

  @Test
  public void testNeedsPositionflavor() {
    assertEquals( NeedsPositionFlavor.ONCE, NeedsPositionFlavor.valueOf( "ONCE" ) );
    assertEquals( NeedsPositionFlavor.NEVER, NeedsPositionFlavor.valueOf( "NEVER" ) );
    assertEquals( NeedsPositionFlavor.CONTINUOUS, NeedsPositionFlavor.valueOf( "CONTINUOUS" ) );
  }

  private Geolocation mockGeolocation() {
    Geolocation geolocation = mock( Geolocation.class );
    ObjectRegistry objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getObject( "foo", Geolocation.class ) ).thenReturn( geolocation );
    return geolocation;
  }

  private Properties Properties( SetOperation operation ) {
    operation.setTarget( "foo" );
    Properties properties = new Properties();
    operation.setProperties( properties );
    return properties;
  }

}
