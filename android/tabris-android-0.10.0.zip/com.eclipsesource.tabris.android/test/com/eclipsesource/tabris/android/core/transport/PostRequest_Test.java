/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.Test;

public class PostRequest_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testPathConstructorNullArg() throws Exception {
    new PostRequest( ( String )null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParamsConstructorNullArg() throws Exception {
    new PostRequest( ( HashMap<String, String> )null );
  }

  @Test
  public void testParamsConstructor() throws Exception {
    HashMap<String, String> params = new HashMap<String, String>();
    params.put( "key", "value" );
    PostRequest request = new PostRequest( params );

    request.addParams( params );

    assertEquals( "value", request.getParams().get( "key" ) );
  }

  @Test
  public void testAddParam() {
    PostRequest request = new PostRequest( "path" );
    HashMap<String, String> params = new HashMap<String, String>();
    params.put( "key", "value" );
    params.put( "key1", "value1" );
    Set<Entry<String, String>> entrySet = params.entrySet();

    for( Entry<String, String> entry : entrySet ) {
      request.addParam( entry.getKey(), entry.getValue() );
    }

    assertEquals( params, request.getParams() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddParamKey() {
    PostRequest request = new PostRequest( "path" );

    request.addParam( null, "value" );
  }

  @Test
  public void testAddParamOverridesPrevParam() {
    PostRequest request = new PostRequest( "path" );

    request.addParam( "key", "value1" );
    request.addParam( "key", "value2" );

    assertEquals( "value2", request.getParams().get( "key" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddNullParamsMap() throws Exception {
    PostRequest request = new PostRequest();

    request.addParams( null );
  }

  @Test
  public void testAddParamsMap() throws Exception {
    PostRequest request = new PostRequest();
    HashMap<String, String> params = new HashMap<String, String>();
    params.put( "key", "value" );

    request.addParams( params );

    assertEquals( "value", request.getParams().get( "key" ) );
  }

  @Test
  public void testMergeIntoDisjoint() throws Exception {
    PostRequest request1 = new PostRequest();
    request1.addParam( "a", "b" );
    PostRequest request2 = new PostRequest();
    request2.addParam( "c", "d" );

    request1.mergeInto( request2 );

    Map<String, String> params1 = request1.getParams();
    assertEquals( 2, params1.size() );
    assertEquals( params1.get( "a" ), "b" );
    assertEquals( params1.get( "c" ), "d" );
    Map<String, String> params2 = request2.getParams();
    assertEquals( 1, params2.size() );
    assertEquals( params2.get( "c" ), "d" );
  }

  @Test
  public void testMergeIntoOverlapping() throws Exception {
    PostRequest request1 = new PostRequest();
    request1.addParam( "a", "b" );
    request1.addParam( "c", "d" );
    PostRequest request2 = new PostRequest();
    request2.addParam( "c", "e" );

    request1.mergeInto( request2 );

    Map<String, String> params1 = request1.getParams();
    assertEquals( 2, params1.size() );
    assertEquals( params1.get( "a" ), "b" );
    assertEquals( params1.get( "c" ), "e" );
    Map<String, String> params2 = request2.getParams();
    assertEquals( 1, params2.size() );
    assertEquals( params2.get( "c" ), "e" );
  }

  @Test
  public void testContent() throws Exception {
    PostRequest request = new PostRequest();

    request.setContent( "foo" );

    assertEquals( "foo", request.getContent() );
  }

}
