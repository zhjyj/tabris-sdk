/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.eclipsesource.tabris.android.toolkit.view.TabItemView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TabItemOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String TAB_FOLDER_ID = "w3";
  private static final String TAB_ITEM_ID = "w4";

  private TabrisActivity activity;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    FrameLayout parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( parentLayout );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new TabItemOperator( activity );

    assertTrue( operator.getViewSetter( mock( TabItemView.class ) ) instanceof ViewSetter );
  }

  @Test
  @Ignore("Can not test because Robolectric doesn't provide a TabHost.getTabContentView() implementation which is used by the implementation.")
  public void testCreateTabItem() {
    TabFolder tabHost = ( TabFolder )activity.getLayoutInflater().inflate( R.layout.tabfolder_top,
                                                                           null );
    tabHost.setTag( new RemoteObject( TAB_FOLDER_ID, mock( ProtocolProcessor.class ) ) );
    tabHost.setup();
    ViewGroup root = ( ViewGroup )activity.findViewById( R.id.root_layout );
    root.addView( tabHost );
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( TAB_ITEM_ID );
    Properties properties = new Properties();
    properties.add( "parent", TAB_FOLDER_ID );
    createOp.setProperties( properties );
    TabItemOperator operator = new TabItemOperator( activity );

    Assert.assertNull( tabHost.getCurrentTabTag() );

    operator.create( createOp );

    Assert.assertEquals( TAB_ITEM_ID, tabHost.getCurrentTabTag() );
  }

  // more tests should be written when a proper robolectric shadow object has
  // been created

}
