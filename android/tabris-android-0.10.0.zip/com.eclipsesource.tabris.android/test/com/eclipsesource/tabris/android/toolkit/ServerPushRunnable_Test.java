/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ServerPushRunnable_Test {

  private static final String SERVER_PUSH_QUERY = "servicehandler=org.eclipse.rap.serverpush";

  class ProtocolProcessorUnderTest extends ProtocolProcessor {

    private GetRequest request;
    private final boolean exception;

    public ProtocolProcessorUnderTest( boolean exception ) {
      this.exception = exception;
    }

    @Override
    public ITransportResult processGetRequest( GetRequest request ) {
      this.request = request;
      Thread.currentThread().interrupt();
      ITransportResult result = mock( ITransportResult.class );
      when( result.hasException() ).thenReturn( exception );
      return result;
    }

    public GetRequest getRequest() {
      return request;
    }

    @Override
    public IProtocolParser getParser() {
      return mock( IProtocolParser.class );
    }
  }

  @Test
  public void testRunActiveAndMakePostRequest() {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    GetRequest request = new GetRequest();
    request.setQuery( SERVER_PUSH_QUERY );
    request.setTimeout( 0 );
    request.setSilentRequest( true );
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( false );
    when( processor.processGetRequest( request ) ).thenReturn( result );
    activity.setProcessor( processor );
    ServerPushRunnable runnable = new ServerPushRunnable( activity );

    runnable.run();

    verify( processor ).processGetRequest( request );
    verify( processor ).send();
  }

  @Test
  public void testIsConnectedTrue() throws Exception {
    TabrisActivity activity = createConnectivityAwareActivity( true );

    ServerPushRunnable runnable = new ServerPushRunnable( activity );

    assertTrue( runnable.isConnected() );
  }

  @Test
  public void testIsConnectedFalse() throws Exception {
    TabrisActivity activity = createConnectivityAwareActivity( false );

    ServerPushRunnable runnable = new ServerPushRunnable( activity );

    assertFalse( runnable.isConnected() );
  }

  private TabrisActivity createConnectivityAwareActivity( boolean connected ) {
    TabrisActivity activity = mock( TabrisActivity.class );
    ConnectivityManager connectivityManager = mock( ConnectivityManager.class );
    NetworkInfo networkInfo = mock( NetworkInfo.class );
    when( networkInfo.isConnected() ).thenReturn( connected );
    when( connectivityManager.getActiveNetworkInfo() ).thenReturn( networkInfo );
    when( activity.getSystemService( Context.CONNECTIVITY_SERVICE ) ).thenReturn( connectivityManager );
    return activity;
  }
}
