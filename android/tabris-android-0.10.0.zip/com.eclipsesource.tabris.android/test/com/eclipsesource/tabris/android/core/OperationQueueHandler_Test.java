/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;

public class OperationQueueHandler_Test {

  private OperationQueueHandler operationQueueHandler;

  @Before
  public void setUp() {
    operationQueueHandler = new OperationQueueHandler( mock( ProtocolProcessor.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateWithNullShouldFail() {
    OperationQueueHandler handler = new OperationQueueHandler( null );

    fail( "Create with null should throw exception" );
  }

  @Test
  public void testCreate() {
    OperationQueueHandler handler = new OperationQueueHandler( mock( ProtocolProcessor.class ) );

    assertNotNull( handler.getOperationsBuffer() );
    assertTrue( handler.getOperationsBuffer().isEmpty() );
  }

  @Test
  public void testConsiderBufferShouldBufferTail() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    OperationQueueHandler handler = new OperationQueueHandler( processor );
    List<Operation> head = createHead();
    List<Operation> tail = createTail();
    List<Operation> queue = new ArrayList<Operation>( head );
    queue.addAll( tail );
    assertTrue( handler.getOperationsBuffer().isEmpty() );

    List<Operation> operationsToSend = handler.considerBuffer( queue );

    List<List<Operation>> buffer = handler.getOperationsBuffer();
    assertEquals( 1, buffer.size() );
    assertEquals( tail, buffer.get( 0 ) );
    assertEquals( operationsToSend, head );
    verify( processor ).send();
  }

  @Test
  public void testConsiderBufferShouldSendBufferOnSecondCall() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    OperationQueueHandler handler = new OperationQueueHandler( processor );
    List<Operation> head = createHead();
    List<Operation> tail = createTail();
    List<Operation> queue = new ArrayList<Operation>( head );
    queue.addAll( tail );
    assertTrue( handler.getOperationsBuffer().isEmpty() );

    List<Operation> operationsToSend = handler.considerBuffer( queue );

    List<List<Operation>> buffer = handler.getOperationsBuffer();
    assertEquals( 1, buffer.size() );
    verify( processor ).send();

    operationsToSend = handler.considerBuffer( new ArrayList<Operation>() );

    buffer = handler.getOperationsBuffer();
    assertTrue( buffer.isEmpty() );
    assertEquals( operationsToSend, tail );
    verify( processor, times( 2 ) ).send();
  }

  private List<Operation> createHead() {
    List<Operation> head = new ArrayList<Operation>();
    head.add( createSetOperation( "w2", "p1", "1" ) );
    head.add( createSetOperation( "w3", "p2", "2" ) );
    return head;
  }

  private List<Operation> createTail() {
    List<Operation> tail = new ArrayList<Operation>();
    tail.add( createSetOperation( "w1", "bounds", "1" ) );
    tail.add( createSetOperation( "w11", "p11", "11" ) );
    return tail;
  }

  @Test
  public void testSplit_NoSplitPoint() throws Exception {
    List<Operation> operations = createHead();
    operations.add( createSetOperation( "w11", "p11", "11" ) );

    List<List<Operation>> splitOpertations = operationQueueHandler.split( operations );

    assertEquals( 1, splitOpertations.size() );
    assertEquals( operations, splitOpertations.get( 0 ) );
  }

  @Test
  public void testSplit_IntoTwoParts() throws Exception {
    List<Operation> head = createHead();
    List<Operation> tail = createTail();
    List<Operation> operations = new ArrayList<Operation>();
    operations.addAll( head );
    operations.addAll( tail );

    List<List<Operation>> splitOpertations = operationQueueHandler.split( operations );

    assertEquals( 2, splitOpertations.size() );
    assertEquals( head, splitOpertations.get( 0 ) );
    assertEquals( tail, splitOpertations.get( 1 ) );
  }

  @Test
  public void testSplit_IntoTwoParts_smallTail() throws Exception {
    List<Operation> head = createHead();
    head.add( createSetOperation( "w11", "p11", "11" ) );
    List<Operation> tail = new ArrayList<Operation>();
    tail.add( createSetOperation( "w1", "bounds", "1" ) );
    List<Operation> operations = new ArrayList<Operation>();
    operations.addAll( head );
    operations.addAll( tail );

    List<List<Operation>> splitOpertations = operationQueueHandler.split( operations );

    assertEquals( 2, splitOpertations.size() );
    assertEquals( head, splitOpertations.get( 0 ) );
    assertEquals( tail, splitOpertations.get( 1 ) );
  }

  @Test
  public void testSplit_IntoTwoParts_smallHead() throws Exception {
    List<Operation> head = new ArrayList<Operation>();
    head.add( createSetOperation( "w2", "p1", "1" ) );
    List<Operation> tail = new ArrayList<Operation>();
    tail.add( createSetOperation( "w1", "bounds", "1" ) );
    tail.add( createSetOperation( "w3", "p2", "2" ) );
    tail.add( createSetOperation( "w11", "p11", "11" ) );
    List<Operation> operations = new ArrayList<Operation>();
    operations.addAll( head );
    operations.addAll( tail );

    List<List<Operation>> splitOpertations = operationQueueHandler.split( operations );

    assertEquals( 2, splitOpertations.size() );
    assertEquals( head, splitOpertations.get( 0 ) );
    assertEquals( tail, splitOpertations.get( 1 ) );
  }

  @Test
  public void testSplit_IntoTwoParts_twoSplitPoints() throws Exception {
    List<Operation> head = new ArrayList<Operation>();
    head.add( createSetOperation( "w2", "p1", "1" ) );
    List<Operation> tail = new ArrayList<Operation>();
    tail.add( createSetOperation( "w1", "bounds", "1" ) );
    tail.add( createSetOperation( "w3", "p2", "2" ) );
    tail.add( createSetOperation( "w1", "bounds", "2" ) );
    tail.add( createSetOperation( "w11", "p11", "11" ) );
    List<Operation> operations = new ArrayList<Operation>();
    operations.addAll( head );
    operations.addAll( tail );

    List<List<Operation>> splitOpertations = operationQueueHandler.split( operations );

    assertEquals( 2, splitOpertations.size() );
    assertEquals( head, splitOpertations.get( 0 ) );
    assertEquals( tail, splitOpertations.get( 1 ) );
  }

  @Test
  public void testOptimizeSetOperations_WithoutOptimizations() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = operationQueueHandler.optimizeSetOperations( operations );

    assertEquals( operations, optimizedOpertations );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Start() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = operationQueueHandler.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 0 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Middle() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = operationQueueHandler.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 1 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_End() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );

    List<Operation> optimizedOpertations = operationQueueHandler.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 3 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  private SetOperation createSetOperation( String target, String propertyName, String propertyValue )
  {
    SetOperation result = new SetOperation();
    result.setTarget( target );
    Properties properties = new Properties();
    properties.add( propertyName, propertyValue );
    result.setProperties( properties );
    return result;
  }

  private NotifyOperation createNotifyOperation( String target, String eventType ) {
    NotifyOperation result = new NotifyOperation();
    result.setTarget( target );
    result.setEventType( eventType );
    return result;
  }
}
