/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TextSizeMeasurement_Test {

  private TabrisActivity activity;
  private TextSizeMeasurement measurement;
  private RemoteObject remoteObject;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFields();
    remoteObject = new RemoteObject( "rwt.client.TextSizeMeasurement", activity.getProcessor() );
    when( activity.getRemoteObject( "rwt.client.TextSizeMeasurement" ) ).thenReturn( remoteObject );
    measurement = new TextSizeMeasurement( activity );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_NullArgument() throws Exception {
    measurement.measureItems( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalId() {
    List<List<Object>> items = createItem( Arrays.asList( 123456 ) );

    measurement.measureItems( items );
  }

  @SuppressWarnings("unchecked")
  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalText() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", 123 ) );

    measurement.measureItems( items );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalFont() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", "font" ) );

    measurement.measureItems( items );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalSize() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", Arrays.asList(), "12" ) );

    measurement.measureItems( items );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalBold() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", Arrays.asList(), 12, "true" ) );

    measurement.measureItems( items );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_IllegalItalic() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", Arrays.asList(), 12, true, "false"  ) );

    measurement.measureItems( items );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMeasureItems_BadFont() {
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", Arrays.asList( 123 ), 12, true, false ) );

    measurement.measureItems( items );
  }

  @Ignore("Can not properly get the Typface for the font while not running on physical devive. Maybe create ShadowTypeface object.")
  @Test
  public void testMeasureItems_OK() {
    List<String> fonts = Arrays.asList( "Verdana",
                                        "Lucida Sans",
                                        "Arial",
                                        "Helvetica",
                                        "sans-serif" );
    List<List<Object>> items = createItem( Arrays.asList( "123456", "123", fonts, 12, true, false ) );

    measurement.measureItems( items );
  }

  @SuppressWarnings({
    "unchecked", "rawtypes"
  })
  private List<List<Object>> createItem( List item ) {
    List<List<Object>> result = new ArrayList<List<Object>>();
    result.add( item );
    return result;
  }

}
