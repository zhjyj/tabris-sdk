/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.remote;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;

public class RemoteObject_Test {

  private ProtocolProcessor processor;
  private RemoteObject remoteObject;

  @Before
  public void setUp() {
    processor = mock( ProtocolProcessor.class );
    remoteObject = new RemoteObject( "w3", processor );
  }

  @Test
  public void testId() throws Exception {
    assertEquals( "w3", remoteObject.getId() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreate_NullId() throws Exception {
    new RemoteObject( null, processor );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreate_NullProcessor() throws Exception {
    new RemoteObject( "bar", null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreate_NullIdAndProcessor() throws Exception {
    new RemoteObject( null, null );
  }

  @Test
  public void testSet_OK() throws Exception {
    remoteObject.set( "foo", "bar" );

    ArgumentCaptor<Operation> captor = ArgumentCaptor.forClass( Operation.class );
    verify( processor ).appendOperation( captor.capture() );
    assertTrue( captor.getValue() instanceof SetOperation );
    SetOperation operation = ( SetOperation )captor.getValue();
    assertEquals( "w3", operation.getTarget() );
    assertEquals( "bar", operation.getProperties().getString( "foo" ) );
  }

  @Test
  public void testSet_DoesNotSend() throws Exception {
    remoteObject.set( "foo", "bar" );

    verify( processor, never() ).send();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSet_NullPropertyName() throws Exception {
    remoteObject.set( null, "bar" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSet_NullEmptyName() throws Exception {
    remoteObject.set( "", "bar" );
  }

  @Test
  public void testShouldHaveProcessor() throws Exception {
    assertEquals( processor, remoteObject.getProcessor() );
  }

  @Test
  public void testNotify_ForwardsToNotifyWithProperties() throws Exception {
    RemoteObject remoteObjectSpy = spy( remoteObject );

    remoteObjectSpy.notify( "Selection" );

    verify( remoteObjectSpy ).notify( "Selection", null );
  }

  @Test
  public void testNotify_OKWhenListenSet() throws Exception {
    remoteObject.addListen( "Selection" );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.notify( "Selection", properties );

    ArgumentCaptor<Operation> captor = ArgumentCaptor.forClass( Operation.class );
    verify( processor ).appendOperation( captor.capture() );
    assertTrue( captor.getValue() instanceof NotifyOperation );
    NotifyOperation operation = ( NotifyOperation )captor.getValue();
    assertEquals( "w3", operation.getTarget() );
    assertEquals( "Selection", operation.getEventType() );
    assertEquals( "bar", operation.getProperties().getString( "foo" ) );
  }

  @Test
  public void testNotify_FailWhenNoListenSet() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.notify( "Selection", properties );

    verify( processor, never() ).appendOperation( any( Operation.class ) );
  }

  @Test
  public void testNotify_FailWhenListenRemoved() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.addListen( "Selection" );
    remoteObject.removeListen( "Selection" );
    remoteObject.notify( "Selection", properties );

    verify( processor, never() ).appendOperation( any( Operation.class ) );
  }

  @Test
  public void testNotify_SendWhenListenSet() throws Exception {
    remoteObject.addListen( "Selection" );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.notify( "Selection", properties );

    verify( processor ).send();
  }

  @Test
  public void testNotify_SendFailWithoutListen() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.notify( "Selection", properties );

    verify( processor, never() ).send();
  }

  @Test
  public void testNotify_SendFailWhenListenRemoved() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.addListen( "Selection" );
    remoteObject.removeListen( "Selection" );
    remoteObject.notify( "Selection", properties );

    verify( processor, never() ).send();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNotify_NullEventType() throws Exception {
    remoteObject.notify( null, new HashMap<String, Object>() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNotify_EmptyEventType() throws Exception {
    remoteObject.notify( "", new HashMap<String, Object>() );
  }

  @Test
  public void testNotify_NullProperties() throws Exception {
    remoteObject.addListen( "Selection" );
    remoteObject.notify( "Selection", null );

    ArgumentCaptor<Operation> captor = ArgumentCaptor.forClass( Operation.class );
    verify( processor ).appendOperation( captor.capture() );
    NotifyOperation operation = ( NotifyOperation )captor.getValue();
    assertEquals( new Properties(), operation.getProperties() );
  }

  @Test
  public void testListensTo() throws Exception {
    remoteObject.addListen( "Selection" );

    assertTrue( remoteObject.isListeningToEvent( "Selection" ) );
    assertFalse( remoteObject.isListeningToEvent( "Foo" ) );
  }

  @Test
  public void testCall_OK() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.call( "close", properties );

    ArgumentCaptor<Operation> captor = ArgumentCaptor.forClass( Operation.class );
    verify( processor ).appendOperation( captor.capture() );
    assertTrue( captor.getValue() instanceof CallOperation );
    CallOperation operation = ( CallOperation )captor.getValue();
    assertEquals( "w3", operation.getTarget() );
    assertEquals( "close", operation.getMethod() );
    assertEquals( "bar", operation.getProperties().getString( "foo" ) );
  }

  @Test
  public void testCall_Send() throws Exception {
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( "foo", "bar" );

    remoteObject.call( "close", properties );

    verify( processor ).send();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCall_NullMethod() throws Exception {
    remoteObject.call( null, new HashMap<String, Object>() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCall_EmptyMethod() throws Exception {
    remoteObject.call( "", new HashMap<String, Object>() );
  }

  @Test
  public void testCall_NullProperties() throws Exception {
    remoteObject.call( "close", null );

    ArgumentCaptor<Operation> captor = ArgumentCaptor.forClass( Operation.class );
    verify( processor ).appendOperation( captor.capture() );
    CallOperation operation = ( CallOperation )captor.getValue();
    assertEquals( new Properties(), operation.getProperties() );
  }

  @Test
  public void testEquals() throws Exception {
    RemoteObject remoteObject1 = new RemoteObject( "w1", processor );
    RemoteObject remoteObject2 = new RemoteObject( "w1", processor );

    assertEquals( remoteObject1, remoteObject2 );
    assertEquals( remoteObject1.hashCode(), remoteObject2.hashCode() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailAddingWithNullListen() throws Exception {
    remoteObject.addListen( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailAddingWithEmptyListen() throws Exception {
    remoteObject.addListen( "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailRemovingWithNullListen() throws Exception {
    remoteObject.removeListen( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailRemovingWithEmptyListen() throws Exception {
    remoteObject.removeListen( "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailIsListeningWithEmptyListen() throws Exception {
    remoteObject.isListeningToEvent( "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldFailIsListeningWithoutListen() throws Exception {
    remoteObject.isListeningToEvent( null );
  }

}
