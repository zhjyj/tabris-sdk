/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ExecuteOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ExecuteOperationsRunnable_Test {

  @Test
  public void testShowErrorOnUnsupportedType() {
    CreateOperation op = new CreateOperation();
    op.setType( "foo" );
    op.setTarget( "bar" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verify( toolkit ).showError( any( Throwable.class ), any( TransportRequest.class ) );
  }

  @Test
  public void testShowErrorOnFailingOperator() {
    SetOperation op = new SetOperation();
    op.setTarget( "foo" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    AbstractWidgetOperator operator = mock( AbstractWidgetOperator.class );
    doThrow( Exception.class ).when( operator ).set( eq( op ) );
    when( toolkit.getOperator( eq( op ) ) ).thenReturn( operator );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verify( toolkit ).showError( any( Throwable.class ), any( TransportRequest.class ) );
  }

  @Test
  public void executeSetOperationShouldInvokeSet() {
    SetOperation op = new SetOperation();
    op.setTarget( "foo" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    AbstractWidgetOperator operator = mock( AbstractWidgetOperator.class );
    when( toolkit.getOperator( eq( op ) ) ).thenReturn( operator );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verify( operator ).set( eq( op ) );
  }

  @Test
  public void executeCallOperationShouldInvokeCall() {
    CallOperation op = new CallOperation();
    op.setTarget( "foo" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    AbstractWidgetOperator operator = mock( AbstractWidgetOperator.class );
    when( toolkit.getOperator( eq( op ) ) ).thenReturn( operator );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verify( operator ).call( eq( op ) );
  }

  class UnkownOperation extends Operation {

    public UnkownOperation() {
    }
  }

  @Test
  public void executeUnkownOperationShouldNotInteractWithOperator() {
    UnkownOperation op = new UnkownOperation();
    op.setTarget( "foo" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    AbstractWidgetOperator operator = mock( AbstractWidgetOperator.class );
    when( toolkit.getOperator( eq( op ) ) ).thenReturn( operator );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verifyNoMoreInteractions( operator );
  }

  @Test
  public void testProcessingOperationsShouldNotifyOperationsListProcessedListeners()
    throws Exception
  {
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    Runnable runnable = new ExecuteOperationsRunnable( toolkit, new ArrayList<Operation>() );

    runnable.run();

    verify( toolkit ).fireOperationsListProcessed();
  }

  @Test
  public void testOperationFoundJsexFilter() {
    ExecuteOperation op = new ExecuteOperation();
    op.setTarget( "jsex" );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, op );

    runnable.run();

    verify( toolkit ).fireOperationsListProcessed();
    verifyNoMoreInteractions( toolkit );
  }

}
