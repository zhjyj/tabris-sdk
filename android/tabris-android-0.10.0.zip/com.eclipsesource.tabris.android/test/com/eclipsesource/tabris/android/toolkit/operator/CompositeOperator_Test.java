/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Swipe;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;

@RunWith(TabrisTestRunner.class)
public class CompositeOperator_Test {

  private static final String WIDGET_ID = "w3";

  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    FrameLayout parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, mock( ProtocolProcessor.class ) ) );
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( PARENT_ID, parentLayout, "FrameLayout" );
  }

  @Test
  public void testGetViewSetterShouldReturnCompositeSetterForComposite() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );

    assertTrue( operator.getViewSetter( mock( Composite.class ) ) instanceof CompositeSetter );
  }

  @Test
  public void testGetViewSetterShouldReturnViewSetterForSwipe() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );

    assertTrue( operator.getViewSetter( mock( Swipe.class ) ) instanceof ViewSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new CompositeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    CompositeOperator operator = new CompositeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoProps() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Composite comp = getCreatedValidatedView();
    ShadowFrameLayout shadowComp = Robolectric.shadowOf( comp );
    CompositeTouchListener listener = ( CompositeTouchListener )shadowComp.getOnTouchListener();
    assertEquals( CompositeTouchListener.class, listener.getClass() );
    assertEquals( ConsumingTouchListener.class,
                  listener.findListener( ConsumingTouchListener.class ).getClass() );
  }

  @Test
  public void testCreateCompositeWithVariantSwipeOk() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( PROP_CUSTOM_VARIANT, "variant_swipe" );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertEquals( Swipe.class, view.getClass() );
    assertEquals( WIDGET_ID, activity.getRemoteObject( view ).getId() );
  }

  private Composite getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof Composite );
    assertEquals( WIDGET_ID, activity.getRemoteObject( view ).getId() );
    return ( Composite )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    op.setType( "rwt.widgets.Composite" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeWrongBounds() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "bounds", Arrays.asList( 10, 20, 30 ) );

    operator.create( op );
  }

  @Test
  public void testCreateAndInitiateView() throws Exception {
    AbstractWidgetOperator operator = new CompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    FrameLayout layout = getCreatedValidatedView();
    FrameLayout parent = ( FrameLayout )layout.getParent();
    assertEquals( PARENT_ID, activity.getRemoteObject( parent ).getId() );
  }

  @Test
  public void testGetType() throws Exception {
    CompositeOperator op = new CompositeOperator( new TabrisActivity() );
    assertEquals( CompositeOperator.TYPE, op.getType() );
  }
}
