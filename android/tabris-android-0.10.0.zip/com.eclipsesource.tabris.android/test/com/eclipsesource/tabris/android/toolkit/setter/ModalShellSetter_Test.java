/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ModalShellSetter_Test {

  private ModalShell shellMock;

  @Before
  public void setUp() {
    shellMock = mock( ModalShell.class );
  }

  @Test
  public void testSetTranslatedBounds() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    ModalShellSetter<ModalShell> setter = new ModalShellSetter<ModalShell>( activity );
    Properties props = new Properties();
    props.add( "bounds", Arrays.asList( 10, 20, 30, 40 ) );
    when( shellMock.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( toolkit.multiplyByDensityFactor( 10 - IThemeConstants.DIALOG_SHADOW_SIZE ) ).thenReturn( 15 );
    when( toolkit.multiplyByDensityFactor( 20 - IThemeConstants.DIALOG_SHADOW_SIZE ) ).thenReturn( 25 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 35 );
    when( toolkit.multiplyByDensityFactor( 40 ) ).thenReturn( 45 );

    setter.execute( shellMock, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )shellMock.getLayoutParams();
    assertEquals( 15, layoutParams.leftMargin );
    assertEquals( 25, layoutParams.topMargin );
    assertEquals( 35, layoutParams.width );
    assertEquals( 45, layoutParams.height );
  }
}
