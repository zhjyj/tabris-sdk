/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.IOperator;


public class OperatorRegistry_Test {

  private OperatorRegistry operatorRegistry;

  @Before
  public void setUp() {
    operatorRegistry = new OperatorRegistry();
  }

  @Test
  public void testRegister_OK() throws Exception {
    IOperator operator = mock( IOperator.class );
    operatorRegistry.register( "my.Operator", operator );

    assertSame( operator, operatorRegistry.get( "my.Operator" ) );
  }

  @Test
  public void testRegister_UnknownType() throws Exception {
    operatorRegistry.register( "my.Operator", mock( IOperator.class ) );

    assertNull( operatorRegistry.get( "your.Operator" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegister_NullType() throws Exception {
    operatorRegistry.register( null, mock( IOperator.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegister_NullOperator() throws Exception {
    operatorRegistry.register( "my.Operator", null );
  }

  @Test
  public void testUnegister_OK() throws Exception {
    operatorRegistry.register( "my.Operator", mock( IOperator.class ) );

    operatorRegistry.unregister( "my.Operator" );

    assertNull( operatorRegistry.get( "my.Operator" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUnregister_NullType() throws Exception {
    operatorRegistry.unregister( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGet_NullType() throws Exception {
    operatorRegistry.get( null );
  }

  @Test
  public void testGetAll() throws Exception {
    IOperator operator1 = mock( IOperator.class );
    operatorRegistry.register( "my.Operator1", operator1 );
    IOperator operator2 = mock( IOperator.class );
    operatorRegistry.register( "my.Operator2", operator2 );

    Collection<IOperator> operators = operatorRegistry.getAll();

    assertEquals( 2, operators.size() );
    assertTrue( operators.contains( operator1 ) );
    assertTrue( operators.contains( operator2 ) );
  }
}
