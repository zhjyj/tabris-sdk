/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test;

import android.os.Build;

import com.xtremelabs.robolectric.RobolectricTestRunner;

public class ApiLevelUtil {

  /**
   * We hold a special constant for JELLY_BEAN because robolectric does not yet
   * work with android 4.1.
   */
  public static final int API_LEVEL_JELLY_BEAN = 16;

  private static final String SDK_INT_STR = "SDK_INT";

  private ApiLevelUtil() {
  }

  private static final int SDK_INT = Build.VERSION.SDK_INT;

  public static void switchVersionTo( int version ) {
    RobolectricTestRunner.setStaticValue( Build.VERSION.class, SDK_INT_STR, version );
  }

  public static void resetVersion() {
    RobolectricTestRunner.setStaticValue( Build.VERSION.class, SDK_INT_STR, SDK_INT );
  }

}
