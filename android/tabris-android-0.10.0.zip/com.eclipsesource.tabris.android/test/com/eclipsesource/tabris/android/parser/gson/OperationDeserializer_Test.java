/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.lang.reflect.Type;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

public class OperationDeserializer_Test {

  private Type type;
  private JsonDeserializationContext context;
  private OperationDeserializer deserializer;

  @Before
  public void setUp() {
    type = Mockito.mock( Type.class );
    context = Mockito.mock( JsonDeserializationContext.class );
    deserializer = new OperationDeserializer();
  }

  private JsonArray setupCallOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "call" ) );
    array.add( new JsonPrimitive( "w2" ) );
    array.add( new JsonPrimitive( "rwt.widgets.Shell" ) );
    return array;
  }
  
  @Test
  public void testCreateCallOperation() {
    JsonArray array = setupCallOperation();

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof CallOperation );
    CallOperation co = ( CallOperation )op;
    assertEquals( "rwt.widgets.Shell", co.getMethod() );
  }

  @Test
  public void testCreateCallOperationWithProperties() {
    JsonArray array = setupCallOperation();
    Properties cp = new Properties();
    cp.add( "foo", "bar" );
    JsonObject jo = new JsonObject();
    jo.addProperty( "foo", cp.getString( "foo" ) );
    array.add( jo );
    when( context.deserialize( eq( jo ), any( Type.class ) ) ).thenReturn( cp );

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof CallOperation );
    CallOperation co = ( CallOperation )op;
    assertEquals( "rwt.widgets.Shell", co.getMethod() );
    Properties cpResult = co.getProperties();
    assertNotNull( cpResult );
    assertEquals( cp, cpResult );
  }
  
  @Test
  public void testCreateNotifyOperation() {
    JsonArray array = setupNotifyOperation();
    
    Operation op = deserializer.deserialize( array, type, context );
    
    assertNotNull( op );
    assertTrue( op instanceof NotifyOperation );
    NotifyOperation co = ( NotifyOperation )op;
    assertEquals( "foo", co.getEventType() );
  }
  
  @Test
  public void testCreateNotifyOperationWithProperties() {
    JsonArray array = setupNotifyOperation();
    Properties cp = new Properties();
    cp.add( "foo", "bar" );
    JsonObject jo = new JsonObject();
    jo.addProperty( "foo", cp.getString( "foo" ) );
    array.add( jo );
    when( context.deserialize( eq( jo ), any( Type.class ) ) ).thenReturn( cp );
    
    Operation op = deserializer.deserialize( array, type, context );
    
    assertNotNull( op );
    assertTrue( op instanceof NotifyOperation );
    NotifyOperation co = ( NotifyOperation )op;
    assertEquals( "foo", co.getEventType() );
    Properties cpResult = co.getProperties();
    assertNotNull( cpResult );
    assertEquals( cp, cpResult );
  }

  private JsonArray setupNotifyOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "notify" ) );
    array.add( new JsonPrimitive( "w2" ) );
    array.add( new JsonPrimitive( "foo" ) );
    return array;
  }

  private JsonArray setupCreateOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "create" ) );
    array.add( new JsonPrimitive( "w2" ) );
    array.add( new JsonPrimitive( "rwt.widgets.Shell" ) );
    return array;
  }

  @Test
  public void testCreateCreateOperation() {
    JsonArray array = setupCreateOperation();

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof CreateOperation );
    CreateOperation co = ( CreateOperation )op;
    assertEquals( "w2", co.getTarget() );
    assertEquals( "rwt.widgets.Shell", co.getType() );
  }

  @Test
  public void testCreateCreateOperationWithProperties() {
    JsonArray array = setupCreateOperation();
    Properties cp = ( Properties )prepareProperties( new Properties() );
    JsonObject jo = prepareJsonProperties( cp );
    array.add( jo );
    when( context.deserialize( eq( jo ), any( Type.class ) ) ).thenReturn( cp );

    Operation op = deserializer.deserialize( array, type, context );

    assertTrue( op instanceof CreateOperation );
    CreateOperation co = ( CreateOperation )op;
    assertEquals( "w2", co.getTarget() );
    assertEquals( "rwt.widgets.Shell", co.getType() );
    Properties cpResult = co.getProperties();
    assertNotNull( cpResult );
    assertEquals( cp, cpResult );
  }

  @Test
  public void testCreateDestroyOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "destroy" ) );
    array.add( new JsonPrimitive( "w2" ) );

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof DestroyOperation );
    DestroyOperation co = ( DestroyOperation )op;
    assertEquals( "w2", co.getTarget() );
  }

  private JsonArray setupSetOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "set" ) );
    array.add( new JsonPrimitive( "w2" ) );
    return array;
  }

  @Test
  public void testCreateSetOperation() {
    JsonArray array = setupSetOperation();
    Properties sp = prepareProperties( new Properties() );
    JsonObject jo = prepareJsonProperties( sp );
    array.add( jo );
    when( context.deserialize( eq( jo ), any( Type.class ) ) ).thenReturn( sp );

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof SetOperation );
    SetOperation so = ( SetOperation )op;
    assertEquals( "w2", so.getTarget() );
    assertEquals( sp, so.getProperties() );
  }

  private JsonArray setupListenOperation() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "listen" ) );
    array.add( new JsonPrimitive( "w2" ) );
    return array;
  }

  @Test
  public void testCreateListenOperation() {
    JsonArray array = setupListenOperation();

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof ListenOperation );
    ListenOperation lo = ( ListenOperation )op;
    assertEquals( "w2", lo.getTarget() );
  }

  @Test
  public void testCreateListenOperationWithProperties() {
    JsonArray array = setupListenOperation();
    Properties lp = new Properties();
    lp.add( "mouse", true );
    JsonObject jo = new JsonObject();
    jo.addProperty( "mouse", lp.getBoolean( "mouse" ) );
    array.add( jo );
    when( context.deserialize( eq( jo ), any( Type.class ) ) ).thenReturn( lp );

    Operation op = deserializer.deserialize( array, type, context );

    assertNotNull( op );
    assertTrue( op instanceof ListenOperation );
    ListenOperation lo = ( ListenOperation )op;
    assertEquals( "w2", lo.getTarget() );
    assertEquals( lp, lo.getProperties() );
  }

  private Properties prepareProperties( Properties properties ) {
    properties.add(  "active", true );
    properties.add( "mode", "modus" );
    return properties;
  }

  private JsonObject prepareJsonProperties( Properties cp ) {
    JsonObject jo = new JsonObject();
    jo.addProperty( "active", cp.getBoolean( "active" ) );
    jo.addProperty( "mode", cp.getString( "mode" ) );
    return jo;
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDeserializeArrayWithNull() {
    JsonArray array = new JsonArray();
    array.add( JsonNull.INSTANCE );

    deserializer.deserialize( array, type, context );
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testDeserializeArrayWithNullTarget() {
    JsonArray array = new JsonArray();
    array.add( new JsonPrimitive( "create" ) );
    array.add( JsonNull.INSTANCE );
    array.add( new JsonPrimitive( "rwt.widgets.Shell" ) );

    deserializer.deserialize( array, type, context );
  }

}
