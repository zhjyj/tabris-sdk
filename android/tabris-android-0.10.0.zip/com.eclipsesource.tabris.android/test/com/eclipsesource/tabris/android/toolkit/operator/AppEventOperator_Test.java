
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.AppEvent;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;

public class AppEventOperator_Test {

  private static final String TYPE_TABRIS_APP = "tabris.App";

  @Test
  public void testGetTypeShouldReturnAppEventType() {
    AppEventOperator operator = new AppEventOperator( mock( TabrisActivity.class ) );

    String type = operator.getType();

    assertEquals( TYPE_TABRIS_APP, type );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenOperationShouldNotBeNull() throws Exception {
    AppEventOperator operator = new AppEventOperator( mock( TabrisActivity.class ) );

    operator.listen( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenOperationShouldNotHaveNullTarget() throws Exception {
    AppEventOperator operator = new AppEventOperator( mock( TabrisActivity.class ) );
    ListenOperation operation = new ListenOperation();

    operator.listen( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenOperationShouldNotHaveNullProperties() throws Exception {
    AppEventOperator operator = new AppEventOperator( mock( TabrisActivity.class ) );
    ListenOperation operation = new ListenOperation();
    operation.setTarget( TYPE_TABRIS_APP );

    operator.listen( operation );
  }

  @Test
  public void testListenShouldRegisterAppEventIfNotExisting() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation();

    operator.listen( operation );

    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    ObjectRegistry objectRegistry = widgetToolkit.getObjectRegistry();
    verify( widgetToolkit ).addAppStateListener( isA( AppEvent.class ) );
    verify( objectRegistry ).register( eq( TYPE_TABRIS_APP ),
                                       isA( AppEvent.class ),
                                       eq( TYPE_TABRIS_APP ) );
  }

  @Test
  public void testListenShouldNotRegisterAppEventIfAlreadyExists() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation();
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    ObjectRegistry objectRegistry = widgetToolkit.getObjectRegistry();
    when( objectRegistry.getObject( TYPE_TABRIS_APP, AppEvent.class ) ).thenReturn( new AppEvent( activity ) );

    operator.listen( operation );

    verify( widgetToolkit, never() ).addAppStateListener( isA( AppEvent.class ) );
    verify( objectRegistry, never() ).register( eq( TYPE_TABRIS_APP ),
                                                isA( AppEvent.class ),
                                                eq( TYPE_TABRIS_APP ) );
  }

  @Test
  public void testListenShouldAddPauseOnRemoteObject() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation( EVENT_PAUSE, true );
    RemoteObject remoteObject = mockAppEventAndRemoteObject( activity );

    operator.listen( operation );

    verify( remoteObject ).addListen( EVENT_PAUSE );
  }

  @Test
  public void testListenShouldRemovePauseOnRemoteObject() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation( EVENT_PAUSE, false );
    RemoteObject remoteObject = mockAppEventAndRemoteObject( activity );

    operator.listen( operation );

    verify( remoteObject ).removeListen( EVENT_PAUSE );
  }

  @Test
  public void testListenShouldRemoveResumeOnRemoteObject() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation( EVENT_RESUME, false );
    RemoteObject remoteObject = mockAppEventAndRemoteObject( activity );

    operator.listen( operation );

    verify( remoteObject ).removeListen( EVENT_RESUME );
  }

  @Test
  public void testListenShouldAddResumeOnRemoteObject() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEventOperator operator = new AppEventOperator( activity );
    ListenOperation operation = createListenOperation( EVENT_RESUME, true );
    RemoteObject remoteObject = mockAppEventAndRemoteObject( activity );

    operator.listen( operation );

    verify( remoteObject ).addListen( EVENT_RESUME );
  }

  private ListenOperation createListenOperation() {
    ListenOperation operation = new ListenOperation();
    operation.setTarget( TYPE_TABRIS_APP );
    Properties properties = new Properties();
    operation.setProperties( properties );
    return operation;
  }

  private ListenOperation createListenOperation( String event, boolean state ) {
    ListenOperation operation = new ListenOperation();
    operation.setTarget( TYPE_TABRIS_APP );
    Properties properties = new Properties();
    properties.add( event, state );
    operation.setProperties( properties );
    return operation;
  }

  private RemoteObject mockAppEventAndRemoteObject( TabrisActivity activity ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    when( objectRegistry.getObject( TYPE_TABRIS_APP, AppEvent.class ) ).thenReturn( new AppEvent( activity ) );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( objectRegistry.getRemoteObject( TYPE_TABRIS_APP ) ).thenReturn( remoteObject );
    return remoteObject;
  }
}
