/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.VideoSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;

@RunWith(RobolectricTestRunner.class)
public class VideoOperator_Test {

  private static final String VIEW_ID = "w3";
  private static final String PARENT_ID = "w2";
  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;
  private ViewGroup display;
  private ObjectRegistry objectRegistry;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( VIEW_ID );
    toolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = new ListenerRegistry();
    listenerRegistry.registerListener( VIEW_ID, new CompositeTouchListener() );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, activity.getProcessor() ) );
    display = new FrameLayout( activity );
    display.setTag( new RemoteObject( DisplayOperator.DISPLAY_ID, activity.getProcessor() ) );
    objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getObject( DisplayOperator.DISPLAY_ID, View.class ) ).thenReturn( display );
    when( objectRegistry.getObject( DisplayOperator.DISPLAY_ID, ViewGroup.class ) ).thenReturn( display );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    when( objectRegistry.getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new VideoOperator( activity );

    assertTrue( operator.getViewSetter( mock( VideoHolder.class ) ) instanceof VideoSetter );
  }

  @Test
  public void testGetType() {
    VideoOperator op = new VideoOperator( activity );

    assertEquals( VideoOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new VideoOperator( activity );

    operator.create( null );
  }

  @Test
  public void testCreateOk() {
    AbstractWidgetOperator operator = new VideoOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    VideoHolder holder = getCreatedValidatedView();
    verify( toolkit.getObjectRegistry() ).register( VIEW_ID, holder, "tabris.widgets.Video" );
    Video video = holder.getVideo();
    ShadowVideoView shadowView = Robolectric.shadowOf( video );
    assertEquals( video, shadowView.getOnPreparedListener() );
    verify( toolkit ).addAppStateListener( holder );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    op.setType( "tabris.widgets.Video" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  private VideoHolder getCreatedValidatedView() {
    ArgumentCaptor<View> captor = ArgumentCaptor.forClass( View.class );
    verify( objectRegistry ).register( eq( VIEW_ID ), captor.capture(), anyString() );
    View view = captor.getValue();
    assertTrue( view instanceof VideoHolder );
    assertEquals( VIEW_ID, activity.getRemoteObject( view ).getId() );
    return ( VideoHolder )view;
  }

  @Test
  public void testDestroyShouldUnregisterFromAppStateListeners() throws Exception {
    AbstractWidgetOperator operator = new VideoOperator( activity );
    CreateOperation op = createValidCreateOperation();
    operator.create( op );
    VideoHolder holder = getCreatedValidatedView();
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( VIEW_ID );
    when( toolkit.getObjectRegistry().getObject( VIEW_ID, View.class ) ).thenReturn( holder );
    when( toolkit.getObjectRegistry().getObject( VIEW_ID, VideoHolder.class ) ).thenReturn( holder );

    operator.destroy( destroyOperation );

    verify( toolkit ).removeAppStateListener( holder );
  }
}
