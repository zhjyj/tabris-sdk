/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TransportException_Test {

  @Test
  public void testIsParsable() {
    TransportException ex = new TransportException( null, 42 );

    assertEquals( 42, ex.getStatusCode() );
  }

}
