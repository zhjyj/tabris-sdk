
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static com.eclipsesource.tabris.android.toolkit.AppState.*;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;

public class AppEvent_Test {

  @Test
  public void testPauseEventShouldNotifyRemoteObject() {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEvent appEvent = new AppEvent( activity );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( activity.getRemoteObject( appEvent ) ).thenReturn( remoteObject );

    appEvent.stateChanged( PAUSE );

    verify( remoteObject ).notify( EVENT_PAUSE );
    verifyNoMoreInteractions( remoteObject );
  }

  @Test
  public void testResumeEventShouldNotifyRemoteObject() {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppEvent appEvent = new AppEvent( activity );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( activity.getRemoteObject( appEvent ) ).thenReturn( remoteObject );

    appEvent.stateChanged( RESUME );

    verify( remoteObject ).notify( EVENT_RESUME );
    verifyNoMoreInteractions( remoteObject );
  }

}
