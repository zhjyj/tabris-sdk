
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Swipe;
import com.eclipsesource.tabris.android.toolkit.view.SwipeAdapter;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SwipeOperator_Test {

  private static final String WIDGET_TYPE = "tabris.Swipe";
  private static final String WIDGET_ID = "w34";
  private static final String PARENT_ID = "w3";

  private TabrisActivity activity;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFields();
  }

  @Test
  public void testGetType() {
    SwipeOperator operator = new SwipeOperator( mock( TabrisActivity.class ) );

    String type = operator.getType();

    assertEquals( WIDGET_TYPE, type );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    SwipeOperator operator = new SwipeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    SwipeOperator operator = new SwipeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    SwipeOperator operator = new SwipeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateSwipeNoProps() throws Exception {
    SwipeOperator operator = new SwipeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateSwipeNoParentSet() throws Exception {
    SwipeOperator operator = new SwipeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test
  public void testCreateShouldCreateSwipeAdapter() throws Exception {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    Swipe swipe = mock( Swipe.class );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( swipe );
    when( objectRegistry.getObject( PARENT_ID, View.class ) ).thenReturn( swipe );
    when( objectRegistry.getObject( PARENT_ID, Swipe.class ) ).thenReturn( swipe );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( objectRegistry.getRemoteObjectForObject( isA( SwipeAdapter.class ) ) ).thenReturn( remoteObject );
    SwipeOperator operator = new SwipeOperator( activity );
    CreateOperation operation = createValidCreateOperation();

    operator.create( operation );

    verify( objectRegistry ).register( eq( WIDGET_ID ), isA( SwipeAdapter.class ), eq( WIDGET_TYPE ) );
    verify( remoteObject ).addListen( EVENT_SWIPED_TO_ITEM );
    verify( swipe ).setAdapter( isA( SwipeAdapter.class ) );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    op.setType( WIDGET_TYPE );
    Properties props = new Properties();
    props.add( PROP_PARENT, PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCallItemLoadedShouldAddViewToSwipeAdapter() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "itemLoaded" );
    Properties properties = operation.getProperties();
    properties.add( "index", 3 );
    properties.add( "content", "w23" );

    operator.call( operation );

    verify( swipeAdapter ).addItemAt( 3, "w23" );
  }

  @Test
  public void testCallRemoveItemsShouldRemoveItem() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "removeItems" );
    Properties properties = operation.getProperties();
    properties.add( "items", Arrays.asList( 3, 4, 5 ) );

    operator.call( operation );

    verify( swipeAdapter ).removeItemsAt( Arrays.asList( 3, 4, 5 ) );
  }

  @Test
  public void testCallLockLeftShouldLockLeft() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "lockLeft" );
    Properties properties = operation.getProperties();
    properties.add( "index", 3 );

    operator.call( operation );

    verify( swipeAdapter ).lockLeft( 3 );
  }

  @Test
  public void testCallLockRightShouldLockRight() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "lockRight" );
    Properties properties = operation.getProperties();
    properties.add( "index", 2 );

    operator.call( operation );

    verify( swipeAdapter ).lockRight( 2 );
  }

  @Test
  public void testCallUnlockLeftShouldUnlockLeft() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "unlockLeft" );

    operator.call( operation );

    verify( swipeAdapter ).lockLeft( SwipeAdapter.UNLOCKED );
  }

  @Test
  public void testCallUnlockRightShouldUnlockRight() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    CallOperation operation = createCallOperation();
    operation.setMethod( "unlockRight" );

    operator.call( operation );

    verify( swipeAdapter ).lockRight( SwipeAdapter.UNLOCKED );
  }

  private CallOperation createCallOperation() {
    CallOperation operation = new CallOperation();
    operation.setTarget( WIDGET_ID );
    Properties properties = new Properties();
    operation.setProperties( properties );
    return operation;
  }

  @Test
  public void testSetActiveItemShouldActivateItem() throws Exception {
    SwipeAdapter swipeAdapter = mockSwipeAdapter();
    SwipeOperator operator = new SwipeOperator( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET_ID );
    Properties properties = new Properties();
    properties.add( "activeItem", 3 );
    operation.setProperties( properties );

    operator.set( operation );

    verify( swipeAdapter ).setActiveItem( 3 );
  }

  private SwipeAdapter mockSwipeAdapter() {
    SwipeAdapter swipeAdapter = mock( SwipeAdapter.class );
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    when( objectRegistry.getObject( WIDGET_ID, SwipeAdapter.class ) ).thenReturn( swipeAdapter );
    return swipeAdapter;
  }
}
