/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class Properties_Test {

  private Properties properties;

  @Before
  public void setUp() {
    properties = new Properties();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAdd_NullKey() throws Exception {
    properties.add( null, "bar" );
  }

  @Test
  public void testAddAll() throws Exception {
    Map<String, Object> propertiesMap = new HashMap<String, Object>();
    propertiesMap.put( "prop1", "value1" );
    propertiesMap.put( "prop2", "value2" );

    properties.add( propertiesMap );

    assertEquals( "value1", properties.getString( "prop1" ) );
    assertEquals( "value2", properties.getString( "prop2" ) );
  }

  @Test
  public void testGetString_OK() throws Exception {
    properties.add( "foo", "bar" );

    assertEquals( "bar", properties.getString( "foo" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetString_NullKey() throws Exception {
    properties.getString( null );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetString_NotString() throws Exception {
    properties.add( "foo", Boolean.TRUE );

    properties.getString( "foo" );
  }

  @Test
  public void testGetString_Missing() throws Exception {
    assertNull( properties.getString( "foo" ) );
  }

  @Test
  public void testGetBoolean_OK() throws Exception {
    properties.add( "foo", Boolean.TRUE );

    assertEquals( Boolean.TRUE, properties.getBoolean( "foo" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetBoolean_NotBoolean() throws Exception {
    properties.add( "foo", "bar" );

    properties.getBoolean( "foo" );
  }

  @Test
  public void testGetInteger_OK() throws Exception {
    properties.add( "foo", Integer.valueOf( 5 ) );

    assertEquals( Integer.valueOf( 5 ), properties.getInteger( "foo" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetInteger_NotInteger() throws Exception {
    properties.add( "foo", "bar" );

    properties.getInteger( "foo" );
  }

  @Test
  public void testGetFloat_OK() throws Exception {
    properties.add( "foo", Float.valueOf( 5f ) );

    assertEquals( Float.valueOf( 5f ), properties.getFloat( "foo" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetFloat_NotFloat() throws Exception {
    properties.add( "foo", "bar" );

    properties.getFloat( "foo" );
  }

  @Test
  public void testGetList_OK_Typed() throws Exception {
    List<String> value = Arrays.asList( new String[]{
      "a", "b", "c"
    } );
    properties.add( "foo", value );

    List<String> property = properties.getList( "foo", String.class );
    assertEquals( "a", property.get( 0 ) );
    assertEquals( "b", property.get( 1 ) );
    assertEquals( "c", property.get( 2 ) );
  }

  @Test
  public void testGetList_OK_Generic() throws Exception {
    List<Object> value = Arrays.asList( new Object[]{
      "a", Boolean.TRUE, null, 1
    } );
    properties.add( "foo", value );

    List<Object> property = properties.getList( "foo", Object.class );
    assertEquals( "a", property.get( 0 ) );
    assertEquals( Boolean.TRUE, property.get( 1 ) );
    assertNull( property.get( 2 ) );
    assertEquals( 1, property.get( 3 ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetList_DifferentElementsType() throws Exception {
    List<String> value = Arrays.asList( new String[]{
      "a", "b", "c"
    } );
    properties.add( "foo", value );

    properties.getList( "foo", Integer.class );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetList_DifferentlyTypedElementsForConcreteType() throws Exception {
    List<Object> value = Arrays.asList( new Object[]{
      "a", 1, 4l
    } );
    properties.add( "foo", value );

    properties.getList( "foo", String.class );
  }

  @Test
  public void testGetMatrix_OK_Typed() throws Exception {
    List<String> row1 = Arrays.asList( new String[]{
      "a", "b", "c"
    } );
    List<String> row2 = Arrays.asList( new String[]{
      "d", "e", "f"
    } );
    List<List<String>> value = new ArrayList<List<String>>();
    value.add( row1 );
    value.add( row2 );
    properties.add( "foo", value );

    List<List<String>> property = properties.getMatrix( "foo", String.class );
    assertEquals( "a", property.get( 0 ).get( 0 ) );
    assertEquals( "b", property.get( 0 ).get( 1 ) );
    assertEquals( "c", property.get( 0 ).get( 2 ) );
    assertEquals( "d", property.get( 1 ).get( 0 ) );
    assertEquals( "e", property.get( 1 ).get( 1 ) );
    assertEquals( "f", property.get( 1 ).get( 2 ) );
  }

  @Test
  public void testGetMatrix_OK_Generic() throws Exception {
    List<Object> row1 = Arrays.asList( new Object[]{
      "a", Boolean.TRUE, 1
    } );
    List<Object> row2 = Arrays.asList( new Object[]{
      "d", null, 0.5
    } );
    List<List<Object>> value = new ArrayList<List<Object>>();
    value.add( row1 );
    value.add( row2 );
    properties.add( "foo", value );

    List<List<Object>> property = properties.getMatrix( "foo", Object.class );
    assertEquals( "a", property.get( 0 ).get( 0 ) );
    assertEquals( Boolean.TRUE, property.get( 0 ).get( 1 ) );
    assertEquals( 1, property.get( 0 ).get( 2 ) );
    assertEquals( "d", property.get( 1 ).get( 0 ) );
    assertNull( property.get( 1 ).get( 1 ) );
    assertEquals( 0.5, property.get( 1 ).get( 2 ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetMatrix_DifferentRowsType() throws Exception {
    List<String> row1 = Arrays.asList( new String[]{
      "a", "b", "c"
    } );
    String row2 = "d";
    List<Object> value = new ArrayList<Object>();
    value.add( row1 );
    value.add( row2 );
    properties.add( "foo", value );

    properties.getMatrix( "foo", String.class );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetMatrix_DifferentElementsType() throws Exception {
    List<String> row1 = Arrays.asList( new String[]{
      "a", "b", "c"
    } );
    List<Object> row2 = Arrays.asList( new Object[]{
      "d", 32, "f"
    } );
    List<List<?>> value = new ArrayList<List<?>>();
    value.add( row1 );
    value.add( row2 );
    properties.add( "foo", value );

    properties.getMatrix( "foo", String.class );
  }

  @Test
  public void testGetAll() throws Exception {
    properties.add( "prop1", "bar" );
    properties.add( "prop2", 2 );
    properties.add( "prop3", true );

    Map<String, Object> allProperties = properties.getAll();

    assertEquals( "bar", allProperties.get( "prop1" ) );
    assertEquals( 2, allProperties.get( "prop2" ) );
    assertEquals( true, allProperties.get( "prop3" ) );
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testGetAll_Unmodifiable() throws Exception {
    properties.add( "prop1", "bar" );
    properties.add( "prop2", 2 );
    properties.add( "prop3", true );

    Map<String, Object> allProperties = properties.getAll();

    allProperties.put( "prop1", "foo" );
  }

  @Test
  public void testHasProperty_Exists() throws Exception {
    properties.add( "foo", "bar" );

    assertTrue( properties.hasProperty( "foo" ) );
  }

  @Test
  public void testHasProperty_NotExists() throws Exception {
    assertFalse( properties.hasProperty( "foo" ) );
  }

  @Test
  public void testHasProperty_NullValue() throws Exception {
    properties.add( "foo", null );

    assertTrue( properties.hasProperty( "foo" ) );
  }

}
