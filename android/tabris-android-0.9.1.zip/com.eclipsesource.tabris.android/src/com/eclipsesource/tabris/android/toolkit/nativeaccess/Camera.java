
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;

public class Camera {

  private static final String PHOTO_FILE_DATE_FORMAT = "yyyyMMdd_HHmmss";
  private static final String FILE_NAME_NOMEDIA = ".nomedia";
  private static final String INTENT_PICK_IMAGE_MIME_TYPE = "image/*";

  private final TabrisActivity activity;
  private final DateFactory dateFactory;
  private SourceType sourceType;
  private int width;
  private int height;

  public enum SourceType {
    CAMERA,
    GALLERY;
  }

  public Camera( TabrisActivity activity, DateFactory dateFactory ) {
    this.activity = activity;
    this.dateFactory = dateFactory;
  }

  public void setSourceType( SourceType sourceType ) {
    this.sourceType = sourceType;
  }

  public void setResolution( int width, int height ) {
    this.width = width;
    this.height = height;
  }

  public void requestImage() {
    switch( sourceType ) {
      case CAMERA:
        requestImageFromCamera();
      break;
      case GALLERY:
        requestImageFromGallery();
      break;
    }
  }

  private void requestImageFromCamera() {
    File photoFile = createImageFile();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    RequestCodePool requestCodePool = toolkit.getRequestCodePool();
    int requestCode = requestCodePool.takeRequestCode();
    RemoteObject remoteObject = activity.getRemoteObject( this );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              requestCode,
                                                                              remoteObject,
                                                                              photoFile,
                                                                              width,
                                                                              height );
    toolkit.addActivityResultListener( listener );
    try {
      Intent intent = new Intent( MediaStore.ACTION_IMAGE_CAPTURE );
      intent.putExtra( MediaStore.EXTRA_OUTPUT, Uri.fromFile( photoFile ) );
      activity.startActivityForResult( intent, requestCode );
    } catch( ActivityNotFoundException e ) {
      toolkit.removeActivityResultListener( listener );
      requestCodePool.returnRequestCode( requestCode );
      throw new ActivityNotFoundException( "No camera application available on the device." );
    }
  }

  private File createImageFile() {
    File externalPicturesDir = Environment.getExternalStorageDirectory();
    String sep = File.separator;
    String path = sep + "Android" + sep + "data" + sep + activity.getPackageName() + sep + "images";
    File mediaStorageDir = new File( externalPicturesDir, path );
    if( !mediaStorageDir.exists() ) {
      if( mediaStorageDir.mkdirs() ) {
        createNoMediaFile( mediaStorageDir );
      } else {
        throw new IllegalStateException( "Could not create directory " + mediaStorageDir );
      }
    }
    String date = new SimpleDateFormat( PHOTO_FILE_DATE_FORMAT ).format( dateFactory.getDate() );
    RemoteObject remoteObject = activity.getRemoteObject( this );
    return new File( mediaStorageDir.getPath() + sep + "IMG_" + date + "_" + remoteObject.getId() + ".jpg" );
  }

  private void createNoMediaFile( File mediaStorageDir ) {
    File noMediaFile = new File( mediaStorageDir, FILE_NAME_NOMEDIA );
    try {
      noMediaFile.createNewFile();
    } catch( IOException e ) {
      throw new IllegalStateException( "Could not create '.nomedia' file for temp Camera directory",
                                       e );
    }
  }

  private void requestImageFromGallery() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    RequestCodePool requestCodePool = toolkit.getRequestCodePool();
    int requestCode = requestCodePool.takeRequestCode();
    RemoteObject remoteObject = activity.getRemoteObject( this );
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                requestCode,
                                                                                remoteObject,
                                                                                width,
                                                                                height );
    toolkit.addActivityResultListener( listener );
    try {
      Intent intent = new Intent( Intent.ACTION_PICK );
      intent.setType( INTENT_PICK_IMAGE_MIME_TYPE );
      activity.startActivityForResult( intent, requestCode );
    } catch( ActivityNotFoundException e ) {
      toolkit.removeActivityResultListener( listener );
      requestCodePool.returnRequestCode( requestCode );
      throw new ActivityNotFoundException( "No application to pick an image available on the device." );
    }
  }

}
