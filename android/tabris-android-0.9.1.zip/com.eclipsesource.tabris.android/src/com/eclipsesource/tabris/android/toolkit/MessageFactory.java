/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.core.LocalizableException;

public class MessageFactory {

  private final Map<String, Integer> messages;

  private final Activity activity;

  MessageFactory( Activity activity ) {
    this.activity = activity;
    messages = new HashMap<String, Integer>();
    initializeMessage();
  }

  private void initializeMessage() {
    messages.put( LocalizableException.SESSION_TIMEOUT, R.string.dialog_restart_message );
  }

  public String createMessage( String key ) {
    Integer messageId = messages.get( key );
    if( messageId != null ) {
      return activity.getString( messageId );
    }
    return null;
  }

}
