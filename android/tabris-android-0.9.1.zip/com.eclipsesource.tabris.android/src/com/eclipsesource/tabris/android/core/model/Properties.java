/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class Properties {

  private static final String NOT_INSTANCE_TEXT = "Property ''{0}'' is not an instance of {1}: {2}";
  private static final String NOT_LIST_INSTANCE_TEXT = "List element is not an instance of {0}: {1}";

  private final Map<String, Object> propertiesMap;

  public Properties() {
    propertiesMap = new HashMap<String, Object>();
  }

  public boolean hasProperty( String key ) {
    ParamCheck.notNull( key, "key" );
    return propertiesMap.containsKey( key );
  }

  public void add( String key, Object value ) {
    ParamCheck.notNull( key, "key" );
    propertiesMap.put( key, value );
  }

  public void add( Map<String, Object> properties ) {
    ParamCheck.notNull( properties, "properties" );
    propertiesMap.putAll( properties );
  }

  public Map<String, Object> getAll() {
    return Collections.unmodifiableMap( propertiesMap );
  }

  public String getString( String key ) {
    return getAs( key, String.class );
  }

  public Integer getInteger( String key ) {
    return getAs( key, Integer.class );
  }

  public Boolean getBoolean( String key ) {
    return getAs( key, Boolean.class );
  }

  public Float getFloat( String key ) {
    return getAs( key, Float.class );
  }

  public Font getFont( String key ) {
    return getAs( key, Font.class );
  }

  @SuppressWarnings("unchecked")
  public <T> List<T> getList( String key, Class<T> clazz ) {
    ParamCheck.notNull( key, "key" );
    List<T> result = null;
    Object value = propertiesMap.get( key );
    if( value != null ) {
      if( List.class.isInstance( value ) ) {
        result = ( List<T> )value;
        checkElements( result, clazz );
      } else {
        Object[] args = new Object[]{
          key, List.class.getSimpleName(), value.getClass().getSimpleName()
        };
        String msg = MessageFormat.format( NOT_INSTANCE_TEXT, args );
        throw new IllegalStateException( msg );
      }
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  public <T> List<List<T>> getMatrix( String key, Class<T> clazz ) {
    ParamCheck.notNull( key, "key" );
    List<List<T>> result = null;
    Object value = propertiesMap.get( key );
    if( value != null ) {
      if( List.class.isInstance( value ) ) {
        result = ( List<List<T>> )value;
        checkElements( result, List.class );
        for( List<?> list : result ) {
          checkElements( list, clazz );
        }
      } else {
        Object[] args = new Object[]{
          key, List.class.getSimpleName(), value.getClass().getSimpleName()
        };
        String msg = MessageFormat.format( NOT_INSTANCE_TEXT, args );
        throw new IllegalStateException( msg );
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    return propertiesMap.hashCode();
  }

  @Override
  public boolean equals( Object object ) {
    boolean result = false;
    if( object == this ) {
      result = true;
    } else if( object.getClass() == Properties.class ) {
      Properties other = ( Properties )object;
      result = propertiesMap.equals( other.propertiesMap );
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  private <T> T getAs( String key, Class<T> clazz ) {
    ParamCheck.notNull( key, "key" );
    T result = null;
    Object value = propertiesMap.get( key );
    if( value != null ) {
      if( clazz.isInstance( value ) ) {
        result = ( T )value;
      } else {
        Object[] args = new Object[]{
          key, clazz.getSimpleName(), value.getClass().getSimpleName()
        };
        String msg = MessageFormat.format( NOT_INSTANCE_TEXT, args );
        throw new IllegalStateException( msg );
      }
    }
    return result;
  }

  private void checkElements( List<?> list, Class<?> clazz ) {
    if( list != null ) {
      for( Object element : list ) {
        if( element != null && !clazz.isInstance( element ) ) {
          Object[] args = new Object[]{
            clazz.getSimpleName(), element.getClass().getSimpleName()
          };
          String msg = MessageFormat.format( NOT_LIST_INSTANCE_TEXT, args );
          throw new IllegalStateException( msg );
        }
      }
    }
  }

  @Override
  public String toString() {
    return "Properties [propertiesMap=" + propertiesMap + "]";
  }

}
