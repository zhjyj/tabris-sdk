/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.List;

import android.widget.ScrollView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.Parent;

public class ObservableVerticalScrollView extends ScrollView implements Parent {

  private final ScrollSupport scrollSupport;
  private final List<Object> children;

  public ObservableVerticalScrollView( TabrisActivity activity ) {
    super( activity );
    scrollSupport = new ScrollSupport( activity, this );
    children = new ArrayList<Object>();
  }

  public ObservableVerticalScrollView( TabrisActivity activity,
                                       ObservableScrollView observableScrollView )
  {
    super( activity );
    scrollSupport = new ScrollSupport( activity, observableScrollView );
    children = new ArrayList<Object>();
  }

  @Override
  protected void onScrollChanged( int x, int y, int oldx, int oldy ) {
    super.onScrollChanged( x, y, oldx, oldy );
    scrollSupport.onScrollChanged( x, y, oldx, oldy );
  }

  public void doSmoothScrollTo( int x, int y ) {
    scrollSupport.setScrollTargetX( x );
    scrollSupport.setScrollTargetY( y );
    smoothScrollTo( x, y );
  }

  public ScrollSupport getScrollSupport() {
    return scrollSupport;
  }

  public void addChild( Object child ) {
    children.add( child );
  }

  public List<Object> getChildren() {
    return children;
  }

}