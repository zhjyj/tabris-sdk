/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

public class ProtocolConstants {

  public static final String EVENT_MODIFY = "Modify";
  public static final String EVENT_PROGRESS = "Progress";
  public static final String EVENT_UPDATE = "LocationUpdate";
  public static final String EVENT_ERROR = "LocationUpdateError";
  public static final String EVENT_PRESENTATION_CHANGED = "PresentationChanged";
  public static final String EVENT_PLAYBACK_CHANGED = "PlaybackChanged";
  public static final String EVENT_IMAGE_SELECTION = "ImageSelection";
  public static final String EVENT_IMAGE_SELECTION_ERROR = "ImageSelectionError";
  public static final String EVENT_MOUSE_DOWN = "MouseDown";
  public static final String EVENT_MOUSE_UP = "MouseUp";
  public static final String EVENT_MENU_DETECT = "MenuDetect";
  public static final String EVENT_DRAWING = "Drawing";
  public static final String EVENT_SET_DATA = "SetData";
  public static final String EVENT_COLLAPSE = "Collapse";
  public static final String EVENT_EXPAND = "Expand";
  public static final String EVENT_SELECTION = "Selection";
  public static final String EVENT_DEFAULT_SELECTION = "DefaultSelection";
  public static final String EVENT_SHELL_CLOSE = "Close";

  public static final String PROP_CURSOR_LOCATION = "cursorLocation";
  public static final String PROP_BUTTON = "button";
  public static final String PROP_X = "x";
  public static final String PROP_Y = "y";
  public static final String PROP_TIME = "time";
  public static final String PROP_SHIFT_KEY = "shiftKey";
  public static final String PROP_CTRL_KEY = "ctrlKey";
  public static final String PROP_ALT_KEY = "altKey";
  public static final String PROP_SELECTION_START = "selectionStart";
  public static final String PROP_SELECTION_LENGTH = "selectionLength";
  public static final String PROP_DRAWINGS = "drawings";
  public static final String PROP_ITEM = "item";
  public static final String PROP_TOP_ITEM_INDEX = "topItemIndex";
  public static final String PROP_VERTICAL_SELECTION = "verticalBar.selection";
  public static final String PROP_HORIZONTAL_SELECTION = "horizontalBar.selection";
  public static final String PROP_STYLE = "style";
  public static final String PROP_PARENT = "parent";
  public static final String PROP_ACTIVE = "active";
  public static final String PROP_MODE = "mode";
  public static final String PROP_ALIGNMENT = "alignment";
  public static final String PROP_MESSAGE = "message";
  public static final String PROP_FONT = "font";
  public static final String PROP_IMAGE = "image";
  public static final String PROP_IMAGES = "images";
  public static final String PROP_TEXT = "text";
  public static final String PROP_TEXTS = "texts";
  public static final String PROP_FOREGROUND = "foreground";
  public static final String PROP_BACKGROUND = "background";
  public static final String PROP_ITEMS = "items";
  public static final String PROP_TOP_INDEX = "topIndex";
  public static final String PROP_SELECTION_INDICES = "selectionIndices";
  public static final String PROP_SELECTION_INDEX = "selectionIndex";
  public static final String PROP_YEAR = "year";
  public static final String PROP_MONTH = "month";
  public static final String PROP_DAY = "day";
  public static final String PROP_HOURS = "hours";
  public static final String PROP_MINUTES = "minutes";
  public static final String PROP_DATE_PATTERN = "datePattern";
  public static final String PROP_DATE_SEPARATOR = "dateSeparator";
  public static final String PROP_CUSTOM_VARIANT = "customVariant";
  public static final String PROP_VISIBILITY = "visibility";
  public static final String PROP_ENABLED = "enabled";
  public static final String PROP_BOUNDS = "bounds";
  public static final String PROP_SELECTION = "selection";
  public static final String PROP_FOCUS_INDEX = "focusIndex";
  public static final String PROP_BACKGROUND_IMAGE = "backgroundImage";
  public static final String PROP_EDITABLE = "editable";
  public static final String PROP_URL = "url";
  public static final String PROP_CHILDREN = "children";
  public static final String PROP_CONTROL = "control";
  public static final String PROP_FOCUS_CONTROL = "focusControl";
  public static final String PROP_TEXT_LIMIT = "textLimit";
  public static final String PROP_ORIGIN = "origin";
  public static final String PROP_STATE = "state";
  public static final String PROP_MINIMUM = "minimum";
  public static final String PROP_MAXIMUM = "maximum";
  public static final String PROP_CELL_FOREGROUNDS = "cellForegrounds";
  public static final String PROP_CELL_BACKGROUNDS = "cellBackgrounds";
  public static final String PROP_ITEM_COUNT = "itemCount";
  public static final String PROP_EXPANDED = "expanded";
  public static final String PROP_TOOLTIP = "toolTip";
  public static final String PROP_NEEDS_POSITION = "needsPosition";
  public static final String PROP_ENABLE_HIGH_ACCURACY = "enableHighAccuracy";
  public static final String PROP_FREQUENCY = "frequency";
  public static final String PROP_MAXIMUM_AGE = "maximumAge";
  public static final String PROP_SOURCE_TYPE = "sourceType";
  public static final String PROP_RESOLUTION = "resolution";
  public static final String PROP_VIDEO_URL = "videoURL";
  public static final String PROP_REPEAT = "repeat";
  public static final String PROP_PLAYBACK_MODE = "playback_mode";
  public static final String PROP_PRESENTATION_MODE = "presentation_mode";
  public static final String PROP_CONTROLS_VISIBLE = "controls_visible";
  public static final String PROP_EXECUTE_RESULT = "executeResult";
  public static final String PROP_EVALUATE_RESULT = "evaluateResult";
  public static final String PROP_APP = "app";
  public static final String PROP_COLOR_DEPTH = "colorDepth";
  public static final String PROP_DPI = "dpi";
  public static final String PROP_RWT_INITIALIZE = "rwt_initialize";

  private ProtocolConstants() {
    // prevent instantiation
  }

}
