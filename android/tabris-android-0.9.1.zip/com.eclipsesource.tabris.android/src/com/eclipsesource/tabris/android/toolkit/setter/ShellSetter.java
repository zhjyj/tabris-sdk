/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_IMAGE;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_MODE;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_TEXT;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_VISIBILITY;
import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.checkNullArg;

import java.util.List;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.Shell;

public class ShellSetter<T extends Shell> extends CompositeSetter<T> {

  public ShellSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T shell, Properties properties ) {
    checkNullArg( this, shell, View.class );
    checkNullArg( this, properties, Properties.class );
    setMode( shell, properties );
    super.execute( shell, properties );
    setText( shell, properties );
    setIcon( shell, properties );
  }

  private void setText( T shell, Properties properties ) {
    String text = properties.getString( PROP_TEXT );
    if( text != null ) {
      shell.setText( text );
    }
  }

  private void setIcon( T shell, Properties properties ) {
    if( hasImage( properties ) ) {
      List<Object> image = properties.getList( PROP_IMAGE, Object.class );
      asynchSetIconOnTitle( shell, image );
    }
  }
  
  @SuppressWarnings("unchecked")
  private void asynchSetIconOnTitle( final T shell, List<Object> image ) {
    new LoadImageTask( getActivity() ) {

      @Override
      protected void onPostExecute( BitmapDrawable drawable ) {
        dereferenceIcon( getProcessor(), shell );
        shell.setIcon( drawable );
      }

    }.loadBitmap( image );
  }

  private boolean hasImage( Properties properties ) {
    if( properties == null ) {
      return false;
    }
    List<Object> image = properties.getList( PROP_IMAGE, Object.class );
    return image != null && !image.isEmpty();
  }

  @Override
  protected void setVisibility( View view, Properties properties ) {
    super.setVisibility( view, properties );
    Boolean visible = properties.getBoolean( PROP_VISIBILITY );
    if( visible != null ) {
      if( visible ) {
        ( ( Shell )view ).playShowAnimation( getActivity() );
      } else if( !visible ) {
        ( ( Shell )view ).playHideAnimation( getActivity() );
      }
    }
  }

  private void setMode( Shell shell, Properties properties ) {
    if( properties.hasProperty( PROP_MODE ) ) {
      shell.setMode( properties.getString( PROP_MODE ) );
    }
  }

  public static void dereferenceIcon( ProtocolProcessor processor, final Shell shell ) {
    BitmapDrawableCache bitmapCache = processor.getWidgetToolkit().getBitmapCache();
    DialogHeader header = shell.getHeader();
    if( header != null ) {
      BitmapDrawable bitmapDrawable = ( BitmapDrawable )header.getIcon().getDrawable();
      bitmapCache.decreaseReferenceCount( bitmapDrawable );
    }
  }

}
