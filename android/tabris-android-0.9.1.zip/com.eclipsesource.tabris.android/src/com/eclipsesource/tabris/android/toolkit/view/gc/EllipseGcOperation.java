/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.RectF;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class EllipseGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "ellipse";

  public EllipseGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 9 );
    RectF rect = createRect( properties );
    float startAngle = createStartAngle( properties );
    float rotationAngle = createRotationAngle( properties );
    gc.getPath().addArc( rect, startAngle, rotationAngle - startAngle );
  }

  private RectF createRect( List<?> properties ) {
    float left = getScaledFloat( properties, 1 );
    float top = getScaledFloat( properties, 2 );
    float right = getScaledFloat( properties, 3 );
    float bottom = getScaledFloat( properties, 4 );
    return new RectF( left - right, top - bottom, right + left, bottom + top );
  }

  private float createStartAngle( List<?> properties ) {
    float startAngleRadiant = ( ( Number )properties.get( 6 ) ).floatValue();
    return ( float )( startAngleRadiant * 180f / Math.PI );
  }

  private float createRotationAngle( List<?> properties ) {
    float angleRadiant = ( ( Number )properties.get( 7 ) ).floatValue();
    return ( float )( angleRadiant * 180f / Math.PI );
  }

}
