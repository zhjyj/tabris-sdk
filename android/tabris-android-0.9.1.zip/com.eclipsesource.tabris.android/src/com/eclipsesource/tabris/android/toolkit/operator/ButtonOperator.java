/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;

import java.util.List;

import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.ToggleButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.PropertiesOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.ButtonSetter;
import com.eclipsesource.tabris.android.toolkit.setter.CompoundButtonSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.CheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.CompoundButtonClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;

public class ButtonOperator extends LabelOperator {

  public static final String TYPE = "rwt.widgets.Button";

  public static final String STYLE_PUSH = "PUSH";
  public static final String STYLE_TOGGLE = "TOGGLE";
  public static final String STYLE_RADIO = "RADIO";
  public static final String STYLE_CHECK = "CHECK";

  private final IViewSetter<? extends View> setter;
  private final IViewSetter<? extends View> compoundSetter;

  public ButtonOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ButtonSetter<Button>( activity );
    compoundSetter = new CompoundButtonSetter<CompoundButton>( activity );
  }

  @Override
  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    IViewSetter<View> result = ( IViewSetter<View> )setter;
    if( view instanceof CompoundButton ) {
      result = ( IViewSetter<View> )compoundSetter;
    }
    return result;
  }

  @Override
  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    List<String> styles = operation.getProperties().getList( ProtocolConstants.PROP_STYLE,
                                                             String.class );
    if( styles == null || styles.isEmpty() || styles.contains( STYLE_PUSH ) ) {
      createButton( operation );
    } else if( styles.contains( STYLE_TOGGLE ) ) {
      createToggleButton( operation );
    } else if( styles.contains( STYLE_CHECK ) ) {
      createCheckBox( operation );
    } else if( styles.contains( STYLE_RADIO ) ) {
      createRadioButton( operation );
    }
    adjustOpacity();
  }

  private void adjustOpacity() {
  }

  private void createToggleButton( CreateOperation operation ) {
    ToggleButton button = new ToggleButton( getActivity() );
    button.setMaxLines( 1 );
    setDefaultProperties( button );
    setCheckedChangedListener( button, operation.getTarget() );
    initiateNewView( operation, button );
    setTextOnToggleButton( operation );
  }

  private void createButton( CreateOperation operation ) {
    Button button = new Button( getActivity() );
    setDefaultProperties( button );
    initiateNewView( operation, button );
  }

  private void createRadioButton( CreateOperation operation ) {
    RadioButton button = new RadioButton( getActivity() );
    button.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.BUTTON_RADIO_TEXT_SIZE );
    setCheckedChangedListener( button, operation.getTarget() );
    initiateNewView( operation, button );
  }

  private void createCheckBox( CreateOperation operation ) {
    CheckBox button = new CheckBox( getActivity() );
    button.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.BUTTON_CHECK_TEXT_SIZE );
    setCheckedChangedListener( button, operation.getTarget() );
    button.setGravity( Gravity.LEFT );
    initiateNewView( operation, button );
  }

  private void setCheckedChangedListener( CompoundButton button, String target ) {
    ListenerRegistry listenerRegistry = getProcessor().getWidgetToolkit().getListenerRegistry();
    CompositeCheckedChangedListener listener = new CompositeCheckedChangedListener();
    listener.addListener( new CheckedChangedListener( getActivity() ) );
    button.setOnCheckedChangeListener( listener );
    listenerRegistry.registerListener( target, listener );
  }

  private void setDefaultProperties( Button button ) {
    button.setTextSize( IThemeConstants.BUTTON_TEXT_SIZE );
  }

  @Override
  public void set( SetOperation operation ) {
    super.set( operation );
    setTextOnToggleButton( operation );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    if( view instanceof CompoundButton ) {
      view.setOnClickListener( new CompoundButtonClickListener( getActivity() ) );
    } else {
      view.setOnClickListener( new ViewClickListener( getActivity() ) );
    }
  }

  private void setTextOnToggleButton( PropertiesOperation operation ) {
    Properties properties = operation.getProperties();
    if( properties != null ) {
      String text = properties.getString( ProtocolConstants.PROP_TEXT );
      final View view = findViewByTarget( operation );
      if( text != null && view instanceof ToggleButton ) {
        ToggleButton toggleButton = ( ToggleButton )view;
        toggleButton.setTextOn( text );
        toggleButton.setTextOff( text );
      }
    }
  }

}
