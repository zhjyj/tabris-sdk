/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.AlternativeSelection;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListSelectionAdapter;

public class ListSetter<T extends List> extends ViewSetter<List> {

  private static final String CUSTOM_VARIANT_ALT_SELECTION = "variant_ALT_SELECTION";

  public ListSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( List list, Properties properties ) {
    super.execute( list, properties );
    setItems( list, properties );
    setSelectionIndices( list, properties );
    setTopIndex( list, properties );
    setAlternativeSelection( list, properties );
  }

  private void setItems( List list, Properties properties ) {
    java.util.List<String> items = properties.getList( ProtocolConstants.PROP_ITEMS, String.class );
    if( items != null ) {
      list.setItems( items, getActivity() );
    }
  }

  private void setSelectionIndices( List list, Properties properties ) {
    java.util.List<Integer> selectionIndices = properties.getList( ProtocolConstants.PROP_SELECTION_INDICES,
                                                                   Integer.class );
    if( selectionIndices != null ) {
      ListSelectionAdapter adapter = ( ListSelectionAdapter )list.getAdapter();
      if( selectionIndices.isEmpty() ) {
        adapter.setSelectionIndex( ListSelectionAdapter.NOTHING_SELECTED );
      } else {
        adapter.setSelectionIndex( selectionIndices.get( 0 ) );
      }
    }
  }

  private void setTopIndex( List list, Properties properties ) {
    Integer topIndex = properties.getInteger( ProtocolConstants.PROP_TOP_INDEX );
    if( topIndex != null ) {
      list.smoothScrollToPosition( topIndex );
    }
  }

  private void setAlternativeSelection( List list, Properties properties ) {
    String customeVariant = properties.getString( ProtocolConstants.PROP_CUSTOM_VARIANT );
    if( customeVariant != null && customeVariant.equals( CUSTOM_VARIANT_ALT_SELECTION ) ) {
      list.setAlternativeSelection( AlternativeSelection.ALL );
    }
  }

  @Override
  protected void setBackground( View view, Properties properties ) {
    super.setBackground( view, properties );
    java.util.List<Integer> background = properties.getList( ProtocolConstants.PROP_BACKGROUND,
                                                             Integer.class );
    if( background != null ) {
      ( ( List )view ).setCacheColorHint( ColorUtil.colorToupleToInt( background ) );
    }
  }

}
