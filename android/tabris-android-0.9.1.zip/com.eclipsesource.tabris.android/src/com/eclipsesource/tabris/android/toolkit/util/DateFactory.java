
package com.eclipsesource.tabris.android.toolkit.util;

import java.util.Date;

public class DateFactory {

  public Date getDate() {
    return new Date();
  }

}
