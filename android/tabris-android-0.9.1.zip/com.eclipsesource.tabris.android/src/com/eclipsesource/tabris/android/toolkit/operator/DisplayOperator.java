/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.DisplaySetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.Display;

public class DisplayOperator extends AbstractWidgetOperator {

  public static final String DISPLAY_ID = "w1";
  public static final String TYPE = "rwt.widgets.Display";

  private final IViewSetter<? extends View> setter;

  public DisplayOperator( TabrisActivity activity ) {
    super( activity );
    setter = new DisplaySetter<Display>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    Display display = ( Display )getActivity().findViewById( R.id.root_layout );
    getObjectRegistry().register( operation.getTarget(), display, DisplayOperator.TYPE );
    display.sendInitialPostRequest();
  }

}
