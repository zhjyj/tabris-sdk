/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;

public interface IVideoStateListener {

  void videoStateChanged( VideoState videoState );

}
