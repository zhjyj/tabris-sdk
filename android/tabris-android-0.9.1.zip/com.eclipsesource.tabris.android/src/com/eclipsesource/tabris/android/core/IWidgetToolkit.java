/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.List;

import android.content.Intent;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.AppState;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.IActivityResultListener;
import com.eclipsesource.tabris.android.toolkit.IAppStateListener;
import com.eclipsesource.tabris.android.toolkit.IOperationsListProcessedListener;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.OperatorRegistry;
import com.eclipsesource.tabris.android.toolkit.view.FocusTrackingListener;

public interface IWidgetToolkit {

  void process( List<Operation> operations );

  void showError( Throwable t, TransportRequest request );

  int getSurfaceWidth();

  int getSurfaceHeight();

  int getSurfaceDpiX();

  int getSurfaceDpiY();

  int getSurfaceColorDepth();

  float getDensityFactor();

  int getDensityDpi();

  float divideByDensityFactor( float value );

  int divideByDensityFactor( int value );

  int multiplyByDensityFactor( int value );

  float multiplyByDensityFactor( float value );

  void dispose();

  void executeDelayedInUiThread( Runnable runnable, long delay );

  void cancelInUiThread( Runnable runnable );

  IProgressIndicator getProgressIndicator();

  ListenerRegistry getListenerRegistry();

  ObjectRegistry getObjectRegistry();

  OperatorRegistry getOperatorRegistry();

  BitmapDrawableCache getBitmapCache();

  FocusTrackingListener getFocusTrackingListener();

  void addAppStateListener( IAppStateListener listener );

  void removeAppStateListener( IAppStateListener listener );

  void appStateChanged( AppState resume );

  void addActivityResultListener( IActivityResultListener listener );

  void removeActivityResultListener( IActivityResultListener listener );

  void receivedActivityResult( int requestCode, int resultCode, Intent data );

  RequestCodePool getRequestCodePool();

  void fireOperationsListProcessed();

  void removeOperationsListProcessedListener( IOperationsListProcessedListener listener );

  void addOperationsListProcessedListener( IOperationsListProcessedListener listener );

}
