/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_ITEM;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.TabHostSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;

public class TabFolderOperator extends AbstractWidgetOperator {

  private static final String STYLE_BOTTOM = "BOTTOM";

  public static final String TYPE = "rwt.widgets.TabFolder";

  private final IViewSetter<? extends View> setter;

  class TabChangeListener implements OnTabChangeListener {

    boolean firstTabSetVisible = false;

    private final TabrisActivity activity;
    private final TabHost folder;

    public TabChangeListener( TabHost folder, TabrisActivity activity ) {
      this.folder = folder;
      this.activity = activity;
    }

    public void onTabChanged( String tabId ) {
      if( !firstTabSetVisible ) {
        firstTabSetVisible = true;
      } else {
        RemoteObject remoteObject = activity.getRemoteObject( folder );
        Map<String, Object> properties = new HashMap<String, Object>();
        properties.put( PROP_ITEM, tabId );
        remoteObject.notify( EVENT_SELECTION, properties );
      }
    }
  }

  public TabFolderOperator( TabrisActivity activity ) {
    super( activity );
    setter = new TabHostSetter<TabFolder>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( final CreateOperation operation ) {
    TabHost tabHost = null;
    TabrisActivity activity = getActivity();
    ValidationUtil.validateCreateOperation( activity, operation );
    Properties properties = operation.getProperties();
    List<String> style = properties.getList( ProtocolConstants.PROP_STYLE, String.class );
    if( style != null && style.contains( STYLE_BOTTOM ) ) {
      tabHost = ( TabHost )activity.getLayoutInflater().inflate( R.layout.tabfolder_bottom, null );
    } else {
      tabHost = ( TabHost )activity.getLayoutInflater().inflate( R.layout.tabfolder_top, null );
    }
    getObjectRegistry().register( operation.getTarget(), tabHost, TYPE );
    tabHost.setup();
    initiateNewView( operation, tabHost );
    initializeListeners( tabHost );
    tabHost.setOnTabChangedListener( new TabChangeListener( tabHost, getActivity() ) );
  }

  private void initializeListeners( TabHost tabHost ) {
    RemoteObject remoteObject = getActivity().getRemoteObject( tabHost );
    remoteObject.addListen( EVENT_SELECTION );
  }

}
