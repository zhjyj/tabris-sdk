/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_ERROR;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_UPDATE;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;

public class GeolocationOperator implements IOperator {

  public enum NeedsPositionFlavor {
    NEVER,
    ONCE,
    CONTINUOUS
  }

  public static final String TYPE = "tabris.Geolocation";
  private final TabrisActivity activity;

  public GeolocationOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    Geolocation geolocation = new Geolocation( activity );
    getObjectRegistry().register( operation.getTarget(), geolocation, TYPE );
    addDefaultListners( getObjectRegistry().getRemoteObject( operation.getTarget() ) );
  }

  private void addDefaultListners( RemoteObject remoteObject ) {
    remoteObject.addListen( EVENT_UPDATE );
    remoteObject.addListen( EVENT_ERROR );
  }

  public void set( SetOperation operation ) {
    Geolocation geolocation = getObjectRegistry().getObject( operation.getTarget(),
                                                             Geolocation.class );
    checkObject( geolocation, operation );
    Properties properties = operation.getProperties();
    if( properties != null ) {
      synchronizeProperties( geolocation, properties );
    }
  }

  private void synchronizeProperties( Geolocation geolocation, Properties properties ) {
    synchronizeNeedsPosition( geolocation, properties );
    synchronizeHighAccuracy( geolocation, properties );
    synchronizeFrequency( geolocation, properties );
    synchronizeMaximumAge( geolocation, properties );
  }

  private void synchronizeNeedsPosition( Geolocation geolocation, Properties properties ) {
    String needsPosition = properties.getString( ProtocolConstants.PROP_NEEDS_POSITION );
    if( needsPosition != null ) {
      NeedsPositionFlavor flavor;
      if( needsPosition.equals( "NEVER" ) ) {
        flavor = NeedsPositionFlavor.NEVER;
      } else if( needsPosition.equals( "ONCE" ) ) {
        flavor = NeedsPositionFlavor.ONCE;
      } else if( needsPosition.equals( "CONTINUOUS" ) ) {
        flavor = NeedsPositionFlavor.CONTINUOUS;
      } else {
        String msg = "NeedsPositionFlavor " + needsPosition + " is not valid.";
        throw new IllegalArgumentException( msg );
      }
      geolocation.setNeedsPosition( flavor );
    }
  }

  private void synchronizeHighAccuracy( Geolocation geolocation, Properties properties ) {
    Boolean enableHighAccuracy = properties.getBoolean( ProtocolConstants.PROP_ENABLE_HIGH_ACCURACY );
    if( enableHighAccuracy != null ) {
      geolocation.setEnableHighAccuracy( enableHighAccuracy );
    }
  }

  private void synchronizeFrequency( Geolocation geolocation, Properties properties ) {
    Integer frequency = properties.getInteger( ProtocolConstants.PROP_FREQUENCY );
    if( frequency != null ) {
      geolocation.setFrequency( frequency.intValue() );
    }
  }

  private void synchronizeMaximumAge( Geolocation geolocation, Properties properties ) {
    Integer maximumAge = properties.getInteger( ProtocolConstants.PROP_MAXIMUM_AGE );
    if( maximumAge != null ) {
      geolocation.setMaximumAge( maximumAge.intValue() );
    }
  }

  public void listen( ListenOperation operation ) {
    // nothing to do
  }

  public void call( CallOperation operation ) {
    // nothing to do
  }

  public void destroy( DestroyOperation operation ) {
    ObjectRegistry objectRegistry = getObjectRegistry();
    Geolocation geolocation = objectRegistry.getObject( operation.getTarget(), Geolocation.class );
    checkObject( geolocation, operation );
    geolocation.destroy();
    objectRegistry.unregister( operation.getTarget() );
  }

  private void checkObject( Geolocation geolocation, Operation operation ) {
    if( geolocation == null ) {
      throw new IllegalStateException( "Object with id "
                                       + operation.getTarget()
                                       + " does not exist." );
    }
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }
}
