/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_MENU_DETECT;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_X;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_Y;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;

import java.util.HashMap;
import java.util.Map;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ListItemLongClickListener implements OnItemLongClickListener {

  private final TabrisActivity activity;

  public ListItemLongClickListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public boolean onItemLongClick( AdapterView<?> parent, View view, int position, long id ) {
    sendMenuDetect( parent );
    ( ( List )parent ).getOnItemClickListener().onItemClick( parent, view, position, id );
    return true;
  }

  private void sendMenuDetect( View view ) {
    String widgetId = activity.getRemoteObject( view ).getId();
    TouchPositionBuffer buffer = getTouchPositionBuffer( widgetId );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_X, transformByDensity( buffer.getX() ) );
    properties.put( PROP_Y, transformByDensity( buffer.getY() ) );
    remoteObject.notify( EVENT_MENU_DETECT, properties );
  }

  private int transformByDensity( float ordinate ) {
    return activity.getProcessor().getWidgetToolkit()
      .divideByDensityFactor( Math.round( ordinate ) );
  }

  private TouchPositionBuffer getTouchPositionBuffer( String widgetId ) {
    return activity.getProcessor().getWidgetToolkit()
      .getListenerRegistry()
      .findListener( widgetId, TouchPositionBuffer.class );
  }

}
