/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.setter.BrowserSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.BrowserProgressListener;

public class BrowserOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Browser";

  private static final String STR_SCRIPT = "script";
  private static final String STR_EVALUATE = "evaluate";

  private final IViewSetter<? extends View> setter;

  public BrowserOperator( TabrisActivity activity ) {
    super( activity );
    setter = new BrowserSetter<Browser>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Browser browser = new Browser( getActivity() );
    initiateNewView( operation, browser );
    browser.init();
  }

  @Override
  protected void attachProgressListener( ListenOperation operation ) {
    Browser browser = findObjectById( operation.getTarget(), Browser.class );
    browser.setProgressListener( new BrowserProgressListener( getActivity(), browser ) );
  }

  @Override
  protected void removeProgressListener( ListenOperation operation ) {
    Browser browser = findObjectById( operation.getTarget(), Browser.class );
    browser.setProgressListener( null );
  }

  @Override
  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    Properties properties = operation.getProperties();
    if( STR_EVALUATE.equals( operation.getMethod() ) ) {
      Object scriptObj = properties.getString( STR_SCRIPT );
      if( scriptObj != null && scriptObj instanceof String ) {
        Browser browser = findObjectById( operation.getTarget(), Browser.class );
        browser.executeScript( ( String )scriptObj );
      }
    }
  }
}
