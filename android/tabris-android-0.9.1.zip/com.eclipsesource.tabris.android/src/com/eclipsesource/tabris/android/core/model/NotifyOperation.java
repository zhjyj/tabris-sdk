package com.eclipsesource.tabris.android.core.model;


public class NotifyOperation extends PropertiesOperation {

  public static final String ACTION = "notify";

  private String eventType;

  public String getEventType() {
    return eventType;
  }

  public void setEventType( String eventType ) {
    this.eventType = eventType;
  }

  @Override
  public int hashCode() {
    return 31 * super.hashCode() + ( eventType == null ? 0 : eventType.hashCode() );
  }

  @Override
  public boolean equals( Object object ) {
    boolean result = super.equals( object );
    if( result ) {
      NotifyOperation other = ( NotifyOperation )object;
      if( eventType == null ) {
        result = other.eventType == null;
      } else {
        result = eventType.equals( other.eventType );
      }
    }
    return result;
  }

  @Override
  public String toString() {
    return "NotifyOperation [eventType="
           + eventType
           + ", getTarget()="
           + getTarget()
           + ", getProperties()="
           + getProperties()
           + "]";
  }

}
