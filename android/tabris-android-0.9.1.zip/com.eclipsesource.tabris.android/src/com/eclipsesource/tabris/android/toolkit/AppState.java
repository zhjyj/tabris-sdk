
package com.eclipsesource.tabris.android.toolkit;

public enum AppState {

  RESUME,
  PAUSE

}
