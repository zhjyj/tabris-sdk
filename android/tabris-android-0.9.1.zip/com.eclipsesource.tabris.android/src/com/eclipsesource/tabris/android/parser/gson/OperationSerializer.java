package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;


public class OperationSerializer implements JsonSerializer<Operation> {

  public JsonElement serialize( Operation operation, 
                                Type typeOfOperation, 
                                JsonSerializationContext context ) 
  {
    JsonArray jsonArray = new JsonArray();
    if( operation instanceof SetOperation ) {
      serializeSet( operation, context, jsonArray );
    } else if( operation instanceof CallOperation ) {
      serializeCall( operation, context, jsonArray );
    } else if( operation instanceof NotifyOperation ) {
      serializeNotify( operation, context, jsonArray );
    }
    return jsonArray;
  }

  private void serializeSet( Operation operation,
                             JsonSerializationContext context,
                             JsonArray jsonArray )
  {
    jsonArray.add( new JsonPrimitive( "set" ) );
    jsonArray.add( new JsonPrimitive( operation.getTarget() ) );
    SetOperation setOperation = ( SetOperation )operation;
    jsonArray.add( context.serialize( setOperation.getProperties(), Properties.class ) );
  }

  private void serializeCall( Operation operation,
                              JsonSerializationContext context,
                              JsonArray jsonArray )
  {
    jsonArray.add( new JsonPrimitive( "call" ) );
    jsonArray.add( new JsonPrimitive( operation.getTarget() ) );
    CallOperation call = ( CallOperation )operation;
    jsonArray.add( new JsonPrimitive( call.getMethod() ) );
    jsonArray.add( context.serialize( call.getProperties(), Properties.class ) );
  }

  private void serializeNotify( Operation operation,
                                JsonSerializationContext context,
                                JsonArray jsonArray )
  {
    jsonArray.add( new JsonPrimitive( "notify" ) );
    jsonArray.add( new JsonPrimitive( operation.getTarget() ) );
    NotifyOperation notify = ( NotifyOperation )operation;
    jsonArray.add( new JsonPrimitive( notify.getEventType() ) );
    jsonArray.add( context.serialize( notify.getProperties(), Properties.class ) );
  }

}
