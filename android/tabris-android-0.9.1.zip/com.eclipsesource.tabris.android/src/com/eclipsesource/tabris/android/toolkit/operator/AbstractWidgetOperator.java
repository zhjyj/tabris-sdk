/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.Map;
import java.util.Map.Entry;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DefaultSelectionListener;
import com.eclipsesource.tabris.android.toolkit.view.FocusChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.LongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;

public abstract class AbstractWidgetOperator implements IOperator {

  private final TabrisActivity activity;

  public AbstractWidgetOperator( TabrisActivity activity ) {
    if( activity == null ) {
      throw new IllegalArgumentException( "No activity provided." );
    }
    this.activity = activity;
  }

  public TabrisActivity getActivity() {
    return activity;
  }

  protected ProtocolProcessor getProcessor() {
    return activity.getProcessor();
  }

  protected IWidgetToolkit getWidgetToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }

  protected ListenerRegistry getListenerRegistry() {
    return activity.getProcessor().getWidgetToolkit().getListenerRegistry();
  }

  protected ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    View view = findViewByTarget( operation );
    getViewSetter( view ).execute( view, operation.getProperties() );
  }

  protected void initiateNewView( CreateOperation operation, View view ) {
    setInitialLayoutParams( view );
    getObjectRegistry().register( operation.getTarget(), view, operation.getType() );
    getParentView( operation ).addView( view );
    registerDefaultListeners( operation, view, getWidgetToolkit() );
    applyProperties( operation, view );
  }

  private void registerDefaultListeners( CreateOperation operation,
                                         View view,
                                         IWidgetToolkit toolkit )
  {
    CompositeTouchListener listener = new CompositeTouchListener();
    toolkit.getListenerRegistry().registerListener( operation.getTarget(), listener );
    listener.addListener( toolkit.getFocusTrackingListener() );
    view.setOnTouchListener( listener );
  }

  protected void applyProperties( CreateOperation operation, View view ) {
    if( operation.getProperties() != null ) {
      getViewSetter( view ).execute( view, operation.getProperties() );
    }
  }

  protected abstract IViewSetter<View> getViewSetter( View view );

  private ViewGroup getParentView( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( activity, operation );
    Properties props = operation.getProperties();
    return findObjectById( props.getString( ProtocolConstants.PROP_PARENT ), ViewGroup.class );
  }

  protected <T> T findObjectById( String id, Class<? extends T> clazz ) {
    return getObjectRegistry().getObject( id, clazz );
  }

  protected void setInitialLayoutParams( View view ) {
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams( 0, 0 );
    layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
    view.setLayoutParams( layoutParams );
  }

  public void listen( ListenOperation operation ) {
    ValidationUtil.validateListenOperation( operation );
    Properties properties = operation.getProperties();
    updateRemoteObject( operation );
    attachFocusListener( operation );
    if( properties.hasProperty( EVENT_SELECTION ) ) {
      if( properties.getBoolean( EVENT_SELECTION ) ) {
        attachSelectionListener( operation );
      } else {
        removeSelectionListener( operation );
      }
    }
    if( properties.hasProperty( EVENT_DEFAULT_SELECTION ) ) {
      if( properties.getBoolean( EVENT_DEFAULT_SELECTION ) ) {
        attachDefaultSelectionListener( operation );
      } else {
        removeDefaultSelectionListener( operation );
      }
    }
    if( properties.hasProperty( EVENT_MOUSE_DOWN ) || properties.hasProperty( EVENT_MOUSE_UP ) ) {
      boolean needToAdd = needToAddMouseListener( properties );
      if( needToAdd ) {
        attachMouseListener( operation );
      } else {
        removeMouseListener( operation );
      }
    }
    if( properties.hasProperty( EVENT_MODIFY ) ) {
      if( properties.getBoolean( EVENT_MODIFY ) ) {
        attachModifyListener( operation );
      } else {
        removeModifyListener( operation );
      }
    }
    if( properties.hasProperty( EVENT_PROGRESS ) ) {
      if( properties.getBoolean( EVENT_PROGRESS ) ) {
        attachProgressListener( operation );
      } else {
        removeProgressListener( operation );
      }
    }
    if( properties.hasProperty( EVENT_MENU_DETECT ) ) {
      if( properties.getBoolean( EVENT_MENU_DETECT ) ) {
        attachMenuDetectListener( operation );
      } else {
        removeMenuDetectListener( operation );
      }
    }
  }

  private boolean needToAddMouseListener( Properties properties ) {
    boolean hasMouseUp = properties.hasProperty( EVENT_MOUSE_UP )
                                                                 ? properties.getBoolean( EVENT_MOUSE_UP )
                                                                 : false;
    boolean hasMouseDown = properties.hasProperty( EVENT_MOUSE_DOWN )
                                                                     ? properties.getBoolean( EVENT_MOUSE_DOWN )
                                                                     : false;
    return hasMouseUp || hasMouseDown;
  }

  private void updateRemoteObject( ListenOperation operation ) {
    RemoteObject remoteObject = getObjectRegistry().getRemoteObject( operation.getTarget() );
    Map<String, Object> properties = operation.getProperties().getAll();
    for( Entry<String, Object> entry : properties.entrySet() ) {
      if( entry.getValue() instanceof Boolean ) {
        Boolean shouldListen = ( Boolean )entry.getValue();
        if( shouldListen.booleanValue() ) {
          remoteObject.addListen( entry.getKey() );
        } else {
          remoteObject.removeListen( entry.getKey() );
        }
      }
    }
  }

  protected View findViewByTarget( Operation operation ) {
    return findObjectById( operation.getTarget(), View.class );
  }

  protected void attachFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( new FocusChangeListener( activity ) );
  }

  protected void removeFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( null );
  }

  protected void attachMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = getObjectId( view );
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, true, false );
    } else {
      if( !previousTouchListener.isTransmittingUpDown() ) {
        previousTouchListener.setTransmittingUpDown( true );
      }
    }
  }

  public void attachInitialTouchListener( final View view,
                                          boolean transmitUpDownEvents,
                                          boolean transmitMenuDetectEvents )
  {
    String widgetId = getObjectId( view );
    MouseEventTouchListener mouseEventTouchListener;
    mouseEventTouchListener = new MouseEventTouchListener( activity, transmitUpDownEvents );
    LongClickListener longClickListener = new LongClickListener( activity,
                                                                 mouseEventTouchListener,
                                                                 mouseEventTouchListener,
                                                                 transmitMenuDetectEvents );
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    compListener.removeListeners( ConsumingTouchListener.class );
    compListener.addListener( mouseEventTouchListener );
    view.setOnLongClickListener( longClickListener );
    getListenerRegistry().registerListener( widgetId, longClickListener );
  }

  protected void attachMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = getObjectId( view );
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, false, true );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( true );
    }
  }

  private MouseEventTouchListener getPreviousTouchListener( String widgetId ) {
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    return ( MouseEventTouchListener )compListener.findListener( MouseEventTouchListener.class );
  }

  private LongClickListener getPreviousLongClickListener( String widgetId ) {
    return getListenerRegistry().findListener( widgetId, LongClickListener.class );
  }

  protected void removeMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    if( !remoteObject.isListeningToEvent( EVENT_MOUSE_DOWN )
        && !remoteObject.isListeningToEvent( EVENT_MOUSE_UP ) )
    {
      doRemoveMouseListener( view );
    }
  }

  private void doRemoveMouseListener( final View view ) {
    final String widgetId = getObjectId( view );
    LongClickListener previousLongClickListener = getPreviousLongClickListener( widgetId );
    if( previousLongClickListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousLongClickListener.isTransmittingMenuDetect() ) {
      removeTouchListenersFinally( view );
      applyConsumingTouchListener( view );
    } else {
      getPreviousTouchListener( widgetId ).setTransmittingUpDown( false );
    }
  }

  protected void applyConsumingTouchListener( View view ) {
    // to be implemented by subclasses
  }

  private void throwNoTouchListenerException( final String widgetId ) {
    throw new NullPointerException( "Widget with id="
                                    + widgetId
                                    + " does not have a touch listener attached." );
  }

  public void removeTouchListenersFinally( final View view ) {
    String widgetId = getObjectId( view );
    CompositeTouchListener compListener = getListenerRegistry().findListener( widgetId,
                                                                              CompositeTouchListener.class );
    compListener.removeListeners( MouseEventTouchListener.class );
    view.setOnLongClickListener( null );
    getListenerRegistry().unregisterListener( widgetId, LongClickListener.class );
  }

  protected void attachSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( new ViewClickListener( activity ) );
  }

  protected void removeSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( null );
  }

  protected void attachDefaultSelectionListener( ListenOperation operation ) {
    getListenerRegistry().registerListener( operation.getTarget(),
                                            new DefaultSelectionListener( activity ) );
  }

  protected void removeDefaultSelectionListener( ListenOperation operation ) {
    getListenerRegistry().unregisterListener( operation.getTarget(), DefaultSelectionListener.class );
  }

  protected void removeMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = getObjectId( view );
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousTouchListener.isTransmittingUpDown() ) {
      removeTouchListenersFinally( view );
      applyConsumingTouchListener( view );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( false );
    }
  }

  protected void attachModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void attachProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null ) {
      throw new IllegalArgumentException( "Could not find widget "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    ViewSetter.dereferenceBackground( getProcessor(), view );
    // It would be possible to directly call viewGroup.removeView(view) but to
    // support robolectric we use the index based approach. Could be minimized
    // with custom shadow object.
    ViewGroup viewGroup = ( ViewGroup )view.getParent();
    viewGroup.removeViewAt( viewGroup.indexOfChild( view ) );
    getObjectRegistry().unregister( operation.getTarget() );
    getListenerRegistry().unregisterAllListeners( operation.getTarget() );
  }

  public void call( CallOperation operation ) {
    // to be implemented by subclasses
  }

  protected String getObjectId( Object object ) {
    return getObjectRegistry().getRemoteObjectForObject( object ).getId();
  }

}
