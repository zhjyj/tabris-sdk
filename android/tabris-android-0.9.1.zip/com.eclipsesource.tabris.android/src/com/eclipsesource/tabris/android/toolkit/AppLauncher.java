
package com.eclipsesource.tabris.android.toolkit;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.text.Html;

import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class AppLauncher {

  private static final String SCHEME_TELEPHONE = "tel:";
  private static final String SCHEME_GEO = "geo:";
  private static final String SCHEME_SMS = "sms:";
  private static final int DEFAULT_ZOOM_LEVEL = 14;

  private final Activity activity;

  public AppLauncher( Activity activity ) {
    notNull( activity, "activity" );
    this.activity = activity;
  }

  public void openBrowser( String url ) {
    ParamCheck.notNull( url, "url" );
    Intent intent = new Intent( Intent.ACTION_VIEW );
    intent.setData( Uri.parse( url ) );
    startActivity( intent, "Opening in browser is not supported on device." );
  }

  public void openMail( String to, String cc, String subject, String body, boolean useHtml ) {
    Intent intent = new Intent( Intent.ACTION_SEND );
    intent.setType( "text/plain" );
    setTo( to, intent );
    setCc( cc, intent );
    setSubject( subject, intent );
    setBody( intent, body, useHtml );
    startActivity( intent, "Mail is not supported on device." );
  }

  private void setTo( String to, Intent intent ) {
    if( to != null ) {
      intent.putExtra( Intent.EXTRA_EMAIL, new String[]{ to } );
    }
  }

  private void setCc( String cc, Intent intent ) {
    if( cc != null ) {
      intent.putExtra( Intent.EXTRA_CC, new String[]{ cc } );
    }
  }

  private void setSubject( String subject, Intent intent ) {
    if( subject != null ) {
      intent.putExtra( Intent.EXTRA_SUBJECT, subject );
    }
  }

  private void setBody( Intent intent, String body, boolean useHtml ) {
    if( body != null ) {
      if( useHtml ) {
        intent.putExtra( Intent.EXTRA_TEXT, Html.fromHtml( body ) );
      } else {
        intent.putExtra( Intent.EXTRA_TEXT, body );
      }
    }
  }

  public void openPhone( String number ) {
    Intent intent = null;
    if( number == null ) {
      intent = new Intent( Intent.ACTION_DIAL );
    } else {
      intent = new Intent( Intent.ACTION_CALL, Uri.parse( SCHEME_TELEPHONE + number ) );
    }
    startActivity( intent, "Phone functionallity is not supported on device." );
  }

  public void openMaps( String latitude, String longitude ) {
    openMaps( latitude, longitude, DEFAULT_ZOOM_LEVEL );
  }

  public void openMaps( String latitude, String longitude, int zoom ) {
    Uri uri = Uri.parse( SCHEME_GEO + latitude + "," + longitude + "?z=" + zoom );
    Intent intent = new Intent( Intent.ACTION_VIEW, uri );
    startActivity( intent, "No maps support on device." );
  }

  public void openMaps( String query ) {
    Uri uri = Uri.parse( SCHEME_GEO + "0,0?q=" + query );
    Intent intent = new Intent( Intent.ACTION_VIEW, uri );
    startActivity( intent, "No maps supported on device." );
  }

  public void openSms( String number, String text ) {
    String uri = SCHEME_SMS;
    if( number != null ) {
      uri += number;
    }
    Intent intent = new Intent( Intent.ACTION_VIEW, Uri.parse( uri ) );
    if( text != null ) {
      intent.putExtra( "sms_body", text );
    }
    startActivity( intent, "Sms is not supported on device." );
  }

  public void openUrl( String url ) {
    if( url != null ) {
      Intent intent = new Intent( Intent.ACTION_VIEW, Uri.parse( url ) );
      startActivity( intent, "Opening url is not supported on device.      " );
    }
  }

  private void startActivity( Intent intent, String message ) {
    try {
      activity.startActivity( intent );
    } catch( ActivityNotFoundException activityNotFound ) {
      throw new IllegalStateException( message );
    }
  }
}
