/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.validateDestroyOperation;

import java.util.LinkedHashMap;
import java.util.Random;
import java.util.Set;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.eclipsesource.tabris.android.toolkit.view.TabItemView;

public class TabItemOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.TabItem";

  private final IViewSetter<? extends View> setter;
  private final Random random;

  public TabItemOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ViewSetter<View>( activity );
    random = new Random();
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Properties properties = operation.getProperties();
    TabFolder tabFolder = findObjectById( properties.getString( ProtocolConstants.PROP_PARENT ),
                                          TabFolder.class );
    TabSpec tabSpec = createTabSpec( operation, properties, tabFolder );
    FrameLayout tabContentView = tabFolder.getTabContentView();
    int id = createUniqueId( tabContentView );
    createParentLayout( tabContentView, id );
    tabSpec.setContent( id );
    tabFolder.addTab( tabSpec, properties.getString( ProtocolConstants.PROP_CONTROL ) );
    createTabItem( operation, tabFolder );
  }

  /**
   * The TabItem maps the widget id to a concrete widget
   * 
   * @param operation The operation creating the {@link TabItemView}
   * @param tabHost the parent tabhost on which the tab item is placed
   */
  private void createTabItem( CreateOperation operation, TabFolder tabHost ) {
    TabItemView tabItemView = new TabItemView( getActivity() );
    getObjectRegistry().register( operation.getTarget(), tabItemView, TYPE );
    tabHost.addView( tabItemView );
  }

  private void createParentLayout( FrameLayout tabContentView, int id ) {
    LinearLayout linearLayout = new LinearLayout( getActivity() );
    linearLayout.setId( id );
    tabContentView.addView( linearLayout,
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT );
  }

  private TabSpec createTabSpec( CreateOperation operation, Properties properties, TabFolder tabHost )
  {
    TabSpec tabSpec = tabHost.newTabSpec( operation.getTarget() );
    View layout = getActivity().getLayoutInflater().inflate( R.layout.tab_indicator_holo, null );
    TextView titleView = ( TextView )layout.findViewById( android.R.id.title );
    titleView.setText( properties.getString( ProtocolConstants.PROP_TEXT ) );
    tabSpec.setIndicator( layout );
    return tabSpec;
  }

  private int createUniqueId( FrameLayout tabContentView ) {
    int id = random.nextInt();
    if( id < 0 ) {
      id *= -1;
    }
    if( tabContentView.findViewById( id ) == null ) {
      return id;
    } else {
      return createUniqueId( tabContentView );
    }
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    validateDestroyOperation( operation );
    TabItemView tabItemView = findObjectById( operation.getTarget(), TabItemView.class );
    TabFolder tabFolder = findParentTabHost( tabItemView );
    if( tabFolder == null ) {
      throw new IllegalStateException( "The widget to destroy does not have a TabHost as one of its parents." );
    }
    TabWidget tabWidget = tabFolder.getTabWidget();
    LinkedHashMap<TabSpec, String> tabSpecsMap = tabFolder.getTabSpecs();
    Set<TabSpec> tabSpecs = tabSpecsMap.keySet();
    int i = 0;
    for( TabSpec tabSpec : tabSpecs ) {
      String tag = tabSpec.getTag();
      if( tag != null && tag.equals( operation.getTarget() ) ) {
        tabWidget.removeView( tabWidget.getChildTabViewAt( i ) );
        FrameLayout tabContentView = tabFolder.getTabContentView();
        tabContentView.removeViewAt( i );
        tabSpecsMap.remove( tabSpec );
      }
      i++;
    }
    super.destroy( operation );
  }

  private TabFolder findParentTabHost( View view ) {
    if( view instanceof TabFolder ) {
      TabFolder tabHost = ( TabFolder )view;
      return tabHost;
    } else {
      ViewParent parent = view.getParent();
      if( parent != null ) {
        return findParentTabHost( ( ViewGroup )parent );
      }
    }
    return null;
  }

}
