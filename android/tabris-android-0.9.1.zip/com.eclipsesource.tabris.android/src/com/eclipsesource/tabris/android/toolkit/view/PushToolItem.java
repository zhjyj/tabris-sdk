/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.util.TypedValue;
import android.view.Gravity;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;

public class PushToolItem extends ToolItem {

  private static final int MINIMUM_WIDTH = 32;

  public PushToolItem( TabrisActivity activity ) {
    super( activity );
    setGravity( Gravity.CENTER_VERTICAL );
    setSingleLine( true );
    setGravity( Gravity.CENTER );
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    setMinWidth( widgetToolkit.multiplyByDensityFactor( MINIMUM_WIDTH ) );
    setBackgroundResource( R.drawable.item_background_holo_dark_no_selection );
  }

  @Override
  public void updateAppearance() {
    String customVariant = ( String )getTag( R.id.custom_variant );
    if( customVariant != null && customVariant.equals( ICustomVariants.TITLE ) ) {
      setTextAppearance( getContext(), android.R.style.TextAppearance_Medium );
    } else {
      setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.BUTTON_TEXT_SIZE );
    }
  }

}