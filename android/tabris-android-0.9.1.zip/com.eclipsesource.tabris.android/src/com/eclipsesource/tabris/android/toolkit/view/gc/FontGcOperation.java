/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Typeface;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.toolkit.TextSizeMeasurement;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class FontGcOperation extends AbstractGcOperation {

  public static final String OPERATION = "font";

  public FontGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> fonts ) {
    Font font = getFont( fonts );
    Typeface typeface = getTypeface( font.getFamily(), font.getBold(), font.getItalic() );
    gc.getPaint().setTypeface( typeface );
    gc.getPaint().setTextSize( font.getSize().intValue() );
  }

  private Font getFont( List<?> fonts ) {
    if( fonts.get( 0 ) instanceof Font ) {
      return ( Font )fonts.get( 0 );
    } else {
      return parseFont( fonts );
    }
  }

  @SuppressWarnings("unchecked")
  private Font parseFont( List<?> properties ) {
    Font result = new Font();
    List<?> fontDef = ( List<?> )properties.get( 1 );
    result.setFamily( ( List<String> )fontDef.get( 0 ) );
    result.setSize( getScaledInt( fontDef, 1 ) );
    result.setBold( ( Boolean )fontDef.get( 2 ) );
    result.setItalic( ( Boolean )fontDef.get( 3 ) );
    return result;
  }
  
  private int getScaledInt( List<?> properties, int i ) {
    IWidgetToolkit toolkit = getActivity().getProcessor().getWidgetToolkit();
    int value = ( ( Number )properties.get( i ) ).intValue();
    return toolkit.multiplyByDensityFactor( value );
  }

  protected Typeface getTypeface( List<?> fontNames, Boolean bold, Boolean italic ) {
    return TextSizeMeasurement.getTypeface( fontNames, bold, italic );
  }

}
