/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_SELECTION;

import java.util.Calendar;

import android.util.SparseArray;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class DateTimeChangedListener {

  private final SparseArray<String> dateValues;
  private final TabrisActivity activity;

  public DateTimeChangedListener( TabrisActivity activity, SparseArray<String> dateValues ) {
    ValidationUtil.checkNullArg( this, dateValues, SparseArray.class );
    ValidationUtil.checkNullArg( this, activity, TabrisActivity.class );
    this.dateValues = dateValues;
    this.activity = activity;
  }

  public void dateTimeChanged( DateTimeSpinner spinner ) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime( spinner.getDate() );
    RemoteObject remoteObject = activity.getRemoteObject( spinner );
    createDateProperties( remoteObject, calendar );
    remoteObject.notify( EVENT_SELECTION, null );
  }

  private void createDateProperties( RemoteObject remoteObject, Calendar calendar ) {
    for( int i = 0; i < dateValues.size(); i++ ) {
      String protocolField = dateValues.valueAt( i );
      int dateValue = dateValues.keyAt( i );
      remoteObject.set( protocolField, calendar.get( dateValue ) );
    }
  }

  /** To be used for testing only. */
  public SparseArray<String> getDateValues() {
    return dateValues;
  }
}
