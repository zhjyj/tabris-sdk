/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.Arrays;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class BrowserJSCallback {

  public static final String CALLBACK_NAME = "androidCallback";

  private final TabrisActivity activity;
  private final Browser browser;

  public BrowserJSCallback( TabrisActivity activity, Browser browser ) {
    this.activity = activity;
    this.browser = browser;
  }

  public void setResult( String result ) {
    RemoteObject remoteObject = activity.getRemoteObject( browser );
    remoteObject.set( PROP_EXECUTE_RESULT, true );
    remoteObject.set( PROP_EVALUATE_RESULT, Arrays.asList( result ) );
    remoteObject.getProcessor().send();
  }
}