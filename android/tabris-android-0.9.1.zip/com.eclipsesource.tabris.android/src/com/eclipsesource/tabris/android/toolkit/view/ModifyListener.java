/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_MODIFY;
import android.text.Editable;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ModifyListener extends TextChangeListener {

  private final TabrisActivity activity;
  private final View view;

  public ModifyListener( TabrisActivity activity, View view ) {
    super( activity, view );
    this.activity = activity;
    this.view = view;
  }

  @Override
  public void afterTextChanged( Editable s ) {
    super.afterTextChanged( s );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.notify( EVENT_MODIFY, null );
  }

  @Override
  public void beforeTextChanged( CharSequence s, int start, int count, int after ) {
    // not required
  }

  @Override
  public void onTextChanged( CharSequence s, int start, int before, int count ) {
    // not required
  }

}
