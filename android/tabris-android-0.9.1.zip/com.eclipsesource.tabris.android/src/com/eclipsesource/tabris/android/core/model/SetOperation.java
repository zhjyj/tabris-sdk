/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class SetOperation extends PropertiesOperation {

  public static final String ACTION = "set";

  @Override
  public String toString() {
    return "SetOperation [getTarget()="
           + getTarget()
           + ", getProperties()="
           + getProperties()
           + "]";
  }

}
