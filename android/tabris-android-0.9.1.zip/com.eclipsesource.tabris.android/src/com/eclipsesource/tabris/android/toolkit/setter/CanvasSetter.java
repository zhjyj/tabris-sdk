/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static com.eclipsesource.tabris.android.core.model.ICustomVariants.CLIENT_CANVAS;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_DRAWING;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_CUSTOM_VARIANT;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;

public class CanvasSetter<T extends Canvas> extends ViewSetter<T> {

  public CanvasSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  protected void setCustomVariant( T view, Properties properties ) {
    super.setCustomVariant( view, properties );
    if( properties.hasProperty( PROP_CUSTOM_VARIANT ) ) {
      String customVariant = properties.getString( PROP_CUSTOM_VARIANT );
      if( customVariant == null ) {
        view.setClientDrawingEnabled( false );
      } else if( customVariant.equals( CLIENT_CANVAS ) ) {
        RemoteObject remoteObject = getActivity().getRemoteObject( view );
        remoteObject.addListen( EVENT_DRAWING );
        view.setClientDrawingEnabled( true );
      }
    }
  }
}
