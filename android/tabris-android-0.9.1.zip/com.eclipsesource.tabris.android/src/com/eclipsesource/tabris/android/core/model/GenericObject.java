/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class GenericObject {

  private final Object obj;

  public GenericObject( Object obj ) {
    if( obj == null ) {
      throw new IllegalArgumentException( "Object can not be null!" );
    }
    this.obj = obj;
  }

  @SuppressWarnings("unchecked")
  public <T> T getObjectAs( Class<T> expectedType ) {
    if( !expectedType.isInstance( obj ) ) {
      throw new IllegalArgumentException( "Type missmatch in protocol message. Expected "
                                          + expectedType.getName()
                                          + " but got "
                                          + obj.getClass().getName() );
    }
    return ( T )obj;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( obj == null )
                                               ? 0
                                               : obj.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( obj == null )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    GenericObject other = ( GenericObject )obj;
    if( this.obj == null ) {
      if( other.obj != null )
        return false;
    } else if( !this.obj.equals( other.obj ) )
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "GenericObject [obj=" + obj + "]";
  }

}
