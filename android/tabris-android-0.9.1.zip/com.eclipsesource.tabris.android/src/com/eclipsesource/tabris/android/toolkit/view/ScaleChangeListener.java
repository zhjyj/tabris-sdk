/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ScaleChangeListener implements OnSeekBarChangeListener {

  private final TabrisActivity activity;

  public ScaleChangeListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onStopTrackingTouch( SeekBar seekBar ) {
    if( seekBar instanceof Scale ) {
      Scale scale = ( Scale )seekBar;
      RemoteObject remoteObject = activity.getRemoteObject( scale );
      int curProgress = scale.getProgress() + scale.getMin();
      remoteObject.set( PROP_SELECTION, curProgress );
      remoteObject.notify( EVENT_SELECTION, null );
    }
  }

  public void onStartTrackingTouch( SeekBar seekBar ) {
    // nothing to do here
  }

  public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {
    // nothing to do here
  }

}
