/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;

public class LoggingInputStream extends InputStream {

  private final InputStream is;
  private final CharArrayWriter writer;

  public LoggingInputStream( InputStream is ) {
    this.is = is;
    writer = new CharArrayWriter();
  }

  @Override
  public int available() throws IOException {
    return is.available();
  }

  @Override
  public void mark( int readlimit ) {
    is.mark( readlimit );
  }

  @Override
  public boolean markSupported() {
    return is.markSupported();
  }

  @Override
  public int read() throws IOException {
    int read = is.read();
    System.out.print( ( char )read );
    return read;
  }

  @Override
  public int read( byte[] buffer ) throws IOException {
    int read = is.read( buffer );
    writeBuffer( buffer );
    return read;
  }

  private void writeBuffer( byte[] buffer ) {
    System.out.print( new String( buffer ) );
  }

  @Override
  public int read( byte[] buffer, int offset, int length ) throws IOException {
    int read = is.read( buffer, offset, length );
    writeBuffer( buffer );
    return read;
  }

  @Override
  public synchronized void reset() throws IOException {
    is.reset();
  }

  @Override
  public long skip( long byteCount ) throws IOException {
    return is.skip( byteCount );
  }

  @Override
  public void close() throws IOException {
    is.close();
  }
}
