/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;

public class ProgressBarSetter<T extends ProgressBar> extends ScaleSetter<T> {

  private static final int HEIGHT_NORMAL = 12;
  private static final int HEIGHT_INDETERMINATE = 9;
  private static final String STATE_NORMAL = "normal";
  private static final String STATE_PAUSED = "paused";
  private static final String STATE_ERROR = "error";

  public ProgressBarSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T progressBar, Properties properties ) {
    super.execute( progressBar, properties );
    setState( progressBar, properties );
  }

  private void setState( T progressBar, Properties properties ) {
    String state = properties.getString( ProtocolConstants.PROP_STATE );
    if( state != null ) {
      Drawable drawable;
      if( progressBar.isIndeterminate() ) {
        drawable = progressBar.getIndeterminateDrawable();
      } else {
        drawable = progressBar.getProgressDrawable();
      }
      if( state.equals( STATE_ERROR ) ) {
        ColorUtil.applyColorFilter( drawable, 1f, 0f, 0f );
      } else if( state.equals( STATE_PAUSED ) ) {
        ColorUtil.applyColorFilter( drawable, 0.7f, 0.7f, 0.7f );
      } else if( state.equals( STATE_NORMAL ) ) {
        drawable.setColorFilter( null );
      }
    }
  }

  @Override
  protected List<Integer> adjustBounds( View view, List<Integer> bounds ) {
    int top = bounds.get( 1 );
    int height = bounds.get( 3 );
    int newHeight = HEIGHT_NORMAL;
    if( ( ( ProgressBar )view ).isIndeterminate() ) {
      newHeight = HEIGHT_INDETERMINATE;
    }
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    newBounds.add( bounds.get( 0 ) );
    newBounds.add( top + height / 2 - newHeight / 2 );
    newBounds.add( bounds.get( 2 ) );
    newBounds.add( newHeight );
    return newBounds;
  }

}
