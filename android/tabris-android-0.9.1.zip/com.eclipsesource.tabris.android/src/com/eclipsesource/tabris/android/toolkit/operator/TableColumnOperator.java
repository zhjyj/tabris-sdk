/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.TableColumn;

/**
 * The support for the TableColumn swt widget does not create any android ui.
 * This {@link IOperator} is currently only used to ignore create calls to the
 * tree column.
 */
public class TableColumnOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.GridColumn";

  private final IViewSetter<? extends View> setter;

  public TableColumnOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ViewSetter<View>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    getObjectRegistry().register( operation.getTarget(), new TableColumn( getActivity() ), TYPE );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null ) {
      throw new IllegalArgumentException( "Could not find TableColumn "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    getObjectRegistry().unregister( operation.getTarget() );
    getListenerRegistry().unregisterAllListeners( operation.getTarget() );
  }

  @Override
  public void set( SetOperation operation ) {
    // ignore all set operations
  }
}