package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_PARENT;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_STYLE;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_VISIBILITY;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.PropertiesOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.Parent;
import com.eclipsesource.tabris.android.toolkit.view.ScrollBar;


public class ScrollBarOperator implements IOperator {
  
  private static final String STYLE_VERTICAL = "VERTICAL";
  public static final String TYPE = "rwt.widgets.ScrollBar";
  private final TabrisActivity activity;
  
  public ScrollBarOperator( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    String style = getStyle( operation );
    String parentId = operation.getProperties().getString( PROP_PARENT );
    ScrollBar scrollBar = new ScrollBar( activity, style, parentId );
    handleVisisibility( scrollBar, operation );
    registerScrollBar( operation, scrollBar );
    addToParent( scrollBar, parentId );
  }

  private String getStyle( CreateOperation operation ) {
    String style = STYLE_VERTICAL;
    if( operation.getProperties().hasProperty( PROP_STYLE ) ) {
      style = operation.getProperties().getList( PROP_STYLE, String.class ).get( 0 );
    }
    return style;
  }

  private void registerScrollBar( CreateOperation operation, ScrollBar scrollBar ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( operation.getTarget(), scrollBar, TYPE );
  }

  private void addToParent( ScrollBar scrollBar, String parentId ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    Object parent = objectRegistry.getObject( parentId );
    if( parent instanceof Parent ) {
      ( ( Parent )parent ).addChild( scrollBar );
    } else {
      throw new IllegalStateException( "Can not add ScrollBar to parent. " 
                                        + parent.getClass().getName()  
                                        + " does not implement Parent." );
    }
  }

  public void set( SetOperation operation ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    ScrollBar scrollBar = ( ScrollBar )objectRegistry.getObject( operation.getTarget() );
    handleVisisibility( scrollBar, operation );
  }

  private void handleVisisibility( ScrollBar scrollBar, PropertiesOperation operation ) {
    Properties properties = operation.getProperties();
    if( properties.hasProperty( PROP_VISIBILITY ) ) {
      scrollBar.setVisibility( properties.getBoolean( PROP_VISIBILITY ) );
    }
  }

  public void listen( ListenOperation operation ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    RemoteObject remoteObject = objectRegistry.getRemoteObject( operation.getTarget() );
    Properties properties = operation.getProperties();
    if( properties.hasProperty( EVENT_SELECTION ) ) {
      Boolean selectionEvent = properties.getBoolean( EVENT_SELECTION );
      if( selectionEvent.booleanValue() ) {
        remoteObject.addListen( EVENT_SELECTION );
      } else {
        remoteObject.removeListen( EVENT_SELECTION );
      }
    }
  }

  public void destroy( DestroyOperation operation ) {
    // do nothing, will be destroyed by parent
  }

  public void call( CallOperation operation ) {
    // do nothing
  }

}
