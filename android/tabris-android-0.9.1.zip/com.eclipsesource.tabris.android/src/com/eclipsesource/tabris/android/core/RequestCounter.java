
package com.eclipsesource.tabris.android.core;

public class RequestCounter {

  private Integer count;
  private final Object lock = new Object();

  public RequestCounter() {
    count = Integer.valueOf( 0 );
  }

  public void set( Integer count ) {
    synchronized( lock ) {
      this.count = count;
    }
  }

  public Integer get() {
    synchronized( lock ) {
      return count;
    }
  }

}
