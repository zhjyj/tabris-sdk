/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.setter.CanvasSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;

public class CanvasOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Canvas";

  private final IViewSetter<? extends View> setter;

  public CanvasOperator( TabrisActivity activity ) {
    super( activity );
    setter = new CanvasSetter<Canvas>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Canvas canvas = new Canvas( getActivity() );
    initiateNewView( operation, canvas );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    Canvas canvas = findObjectById( operation.getTarget(), Canvas.class );
    canvas.destroyBitmap();
    super.destroy( operation );
  }

}
