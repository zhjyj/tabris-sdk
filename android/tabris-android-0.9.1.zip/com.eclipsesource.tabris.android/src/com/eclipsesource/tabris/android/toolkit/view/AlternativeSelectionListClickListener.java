
package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.HashMap;

import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class AlternativeSelectionListClickListener implements OnClickListener {

  private final RemoteObject remoteObject;
  private int position;

  public AlternativeSelectionListClickListener( RemoteObject remoteObject ) {
    this.remoteObject = remoteObject;
  }

  public void onClick( View v ) {
    remoteObject.set( PROP_SELECTION, new int[]{ position } );
    remoteObject.set( PROP_FOCUS_INDEX, position );
    HashMap<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, remoteObject.getId() );
    properties.put( PROP_ALT_KEY, true );
    remoteObject.notify( EVENT_SELECTION, properties );
  }

  public void setPosition( int position ) {
    this.position = position;
  }

}