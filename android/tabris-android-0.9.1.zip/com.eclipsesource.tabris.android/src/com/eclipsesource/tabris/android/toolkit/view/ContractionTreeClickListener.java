/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_COLLAPSE;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_ITEM;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;

import java.util.HashMap;
import java.util.Map;

import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

class ContractionTreeClickListener implements OnClickListener {

  private final TabrisActivity activity;
  private final TreeView treeView;

  public ContractionTreeClickListener( TabrisActivity activity, TreeView treeView ) {
    notNull( activity, "Activity" );
    notNull( treeView, "View" );
    this.activity = activity;
    this.treeView = treeView;
  }

  public void onClick( View v ) {
    TreeItemView parentTreeItem = treeView.getParentTreeItem();
    RemoteObject remoteObject = activity.getRemoteObject( parentTreeItem );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, remoteObject.getId() );
    remoteObject.notify( EVENT_COLLAPSE, properties );
    addVirtualTreeParameter( treeView, parentTreeItem );
    treeView.contractTree( parentTreeItem );
  }

  private void addVirtualTreeParameter( TreeView treeView, TreeItemView selectedItem ) {
    if( treeView.hasVirtualTreeSupport() ) {
      VirtualTreeSupport virtualTreeSupport = treeView.getVirtualTreeSupport();
      virtualTreeSupport.reset();
      virtualTreeSupport.setTopItemIndex( treeView, selectedItem );
    }
  }
};