/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ScaleSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Scale;
import com.eclipsesource.tabris.android.toolkit.view.ScaleChangeListener;

public class ScaleOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Scale";

  private final IViewSetter<? extends View> setter;

  public ScaleOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ScaleSetter<Scale>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  @SuppressWarnings("unchecked")
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Scale scale = new Scale( getActivity() );
    scale.setOnSeekBarChangeListener( new ScaleChangeListener( getActivity() ) );
    initiateNewView( operation, scale );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    // not supported
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    // not supported
  }

}
