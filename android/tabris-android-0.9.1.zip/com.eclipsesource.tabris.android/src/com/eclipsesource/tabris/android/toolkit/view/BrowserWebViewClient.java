/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.webkit.WebView;
import android.webkit.WebViewClient;

public class BrowserWebViewClient extends WebViewClient {

  private IBrowserProgressListener progressListener;

  @Override
  public void onPageFinished( WebView view, String url ) {
    if( progressListener != null ) {
      progressListener.pageFinishedLoading();
    }
  }

  public void setProgressListener( IBrowserProgressListener progressListener ) {
    this.progressListener = progressListener;
  }
}