/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.TransportException;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;

public class InitialGetRequestRunnable implements Runnable {

  private final GetRequest request;
  private final ProtocolProcessor processor;
  private final IProtocolParser snippetParser;

  public InitialGetRequestRunnable( GetRequest request,
                                    ProtocolProcessor processor,
                                    IProtocolParser snippetParser )
  {
    this.request = request;
    this.processor = processor;
    this.snippetParser = snippetParser;
  }

  public void run() {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    IProgressIndicator progressIndicator = toolkit.getProgressIndicator();
    progressIndicator.start();
    ITransportResult transportResult = processor.getTransport().get( request );
    progressIndicator.stop();
    InputStream responseStream = transportResult.getResult();
    if( transportResult.hasException() ) {
      toolkit.showError( transportResult.getException(), request );
      return;
    }
    handleResponse( responseStream );
  }

  public void handleResponse( InputStream responseStream ) {
    try {
      String initialResponse = readInputStreamAsString( responseStream );
      ByteArrayInputStream buffer = new ByteArrayInputStream( initialResponse.getBytes(), 0, 4096 );
      snippetParser.parse( buffer );
    } catch( Exception e ) {
      e = new TransportException( "Could not connect to "
                                  + processor.getTransport().getEndPoint()
                                  + request.getPath(), e );
      processor.getWidgetToolkit().showError( e, request );
    } finally {
      if( responseStream != null ) {
        try {
          responseStream.close();
        } catch( IOException e ) {
          processor.getWidgetToolkit()
            .showError( new TransportException( "Could not close input stream from initial http response",
                                                e ),
                        request );
        }
      }
    }
  }

  private String readInputStreamAsString( final InputStream in ) throws IOException {
    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    BufferedInputStream bis = new BufferedInputStream( in );
    int result;
    result = bis.read();
    while( result != -1 ) {
      byte b = ( byte )result;
      buf.write( b );
      result = bis.read();
    }
    return buf.toString();
  }

}
