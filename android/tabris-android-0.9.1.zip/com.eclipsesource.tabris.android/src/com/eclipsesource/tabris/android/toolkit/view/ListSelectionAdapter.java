/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ListSelectionAdapter extends BaseAdapter {

  public static final int NOTHING_SELECTED = -1;

  private final TabrisActivity activity;
  private final List list;
  private final LayoutInflater inflater;
  private final ArrayList<String> items;
  private int selectionIndex;
  private AlternativeSelection altSelection;

  static class ViewHolder {

    public TextView text;
    public ImageView altSelection;
  }

  public ListSelectionAdapter( TabrisActivity activity, List list ) {
    this.activity = activity;
    this.list = list;
    inflater = activity.getLayoutInflater();
    selectionIndex = NOTHING_SELECTED;
    items = new ArrayList<String>();
  }

  public void setSelectionIndex( int selectedIndex ) {
    selectionIndex = selectedIndex;
    notifyDataSetChanged();
  }

  public int getSelection() {
    return selectionIndex;
  }

  public View getView( int position, View convertView, ViewGroup parent ) {
    ViewHolder viewHolder;
    View rowView = convertView;
    if( rowView == null ) {
      rowView = inflater.inflate( R.layout.list_item, null, true );
      viewHolder = createHolder( rowView );
    } else {
      viewHolder = ( ViewHolder )rowView.getTag();
    }
    populateViewHolder( viewHolder, position );
    setBackgroundColor( position, rowView );
    return rowView;
  }

  @SuppressWarnings("deprecation")
  private void setBackgroundColor( int position, View rowView ) {
    if( isPositionSelected( position ) ) {
      // robolectric has a bug in setBackgroundColor so we use a ColorDrawable
      ColorDrawable drawable = new ColorDrawable( activity.getResources()
        .getColor( R.color.list_item_selected ) );
      rowView.setBackgroundDrawable( drawable );
    } else {
      rowView.setBackgroundDrawable( null );
    }
  }

  private void populateViewHolder( ViewHolder viewHolder, int position ) {
    viewHolder.text.setText( items.get( position ) );
    if( altSelection != null && altSelection.equals( AlternativeSelection.ALL ) ) {
      viewHolder.altSelection.setVisibility( View.VISIBLE );
      AlternativeSelectionListClickListener listener = ( AlternativeSelectionListClickListener )viewHolder.altSelection.getTag();
      listener.setPosition( position );
    } else {
      viewHolder.altSelection.setVisibility( View.GONE );
    }
  }

  private ViewHolder createHolder( View rowView ) {
    ViewHolder holder;
    holder = new ViewHolder();
    holder.text = ( TextView )rowView.findViewById( R.id.list_item_text );
    holder.altSelection = ( ImageView )rowView.findViewById( R.id.list_item_alt_selection );
    RemoteObject remoteObject = activity.getRemoteObject( list );
    AlternativeSelectionListClickListener listener = new AlternativeSelectionListClickListener( remoteObject );
    holder.altSelection.setOnClickListener( listener );
    holder.altSelection.setTag( listener );
    rowView.setTag( holder );
    return holder;
  }

  public int getCount() {
    return items.size();
  }

  public Object getItem( int position ) {
    return items.get( position );
  }

  public long getItemId( int position ) {
    return position;
  }

  private boolean isPositionSelected( int position ) {
    return selectionIndex == position;
  }

  public void clear() {
    items.clear();
  }

  public void addItem( String item ) {
    items.add( item );
  }

  public void setAlternativeSelection( AlternativeSelection altSelection ) {
    this.altSelection = altSelection;
    notifyDataSetChanged();
  }

}
