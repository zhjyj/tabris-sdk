package com.eclipsesource.tabris.android.toolkit.util;

import java.util.Arrays;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;


public class ComparableColorMatrixColorFilter extends ColorMatrixColorFilter {

  private final float[] matrix;

  public ComparableColorMatrixColorFilter( ColorMatrix matrix ) {
    super( matrix );
    this.matrix = matrix.getArray();
  }

  public ComparableColorMatrixColorFilter( float[] array ) {
    super( array );
    this.matrix = array;
  }

  @Override
  public int hashCode() {
    return Arrays.hashCode( matrix );
  }

  @Override
  public boolean equals( Object object ) {
    boolean result = false;
    if( object == this ) {
      result = true;
    } else if( object.getClass() == ComparableColorMatrixColorFilter.class ) {
      ComparableColorMatrixColorFilter other = ( ComparableColorMatrixColorFilter )object;
      result = Arrays.equals( matrix, other.matrix );
    }
    return result;
  }

}
