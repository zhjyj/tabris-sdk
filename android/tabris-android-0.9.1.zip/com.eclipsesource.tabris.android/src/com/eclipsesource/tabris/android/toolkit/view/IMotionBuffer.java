/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;

public interface IMotionBuffer {

  public MotionEvent getLastMotion();

  public void clear();
}
