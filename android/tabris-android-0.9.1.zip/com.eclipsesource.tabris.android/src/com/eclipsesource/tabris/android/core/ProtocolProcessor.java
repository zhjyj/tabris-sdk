/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.parser.SessionIDExtractor;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class ProtocolProcessor implements IProtocolParserCallback {

  private ITransport transport;
  private IProtocolParser parser;
  private IWidgetToolkit widgetToolkit;
  private long sessionStartTime;
  private ExecutorService requestThreadPool;
  private final Head currentHead;
  private final List<Operation> operationsQueue;
  private RequestCounter requestCounter;
  private final Object lock;
  private Timer sendTimer;
  private boolean sendTimerRunning;

  public ProtocolProcessor() {
    requestThreadPool = Executors.newSingleThreadExecutor();
    currentHead = new Head();
    operationsQueue = new ArrayList<Operation>();
    sendTimer = new Timer();
    requestCounter = new RequestCounter();
    lock = new Object();
  }

  public void startSession() {
    verify();
    parser.addProtocolParserCallback( this );
    sessionStartTime = System.currentTimeMillis();
    sendInitialGetRequest( new GetRequest( "" ), parser );
  }

  private void sendInitialGetRequest( GetRequest getRequest, IProtocolParser parser ) {
    synchronized( lock ) {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new InitialGetRequestRunnable( getRequest, this, parser ) );
      }
    }
  }

  /**
   * Executes the {@link PostRequest} in an asynchronous fashion. The call
   * returns immediately.
   */
  public void processPostRequest() {
    synchronized( lock ) {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new PostRequestRunnable( this ) );
      }
    }
  }

  public void appendHeader( String name, Object value ) {
    ParamCheck.notNullOrEmpty( name, "name" );
    synchronized( lock ) {
      currentHead.add( name, value );
    }
  }

  public void appendOperation( Operation operation ) {
    ParamCheck.notNull( operation, "operation" );
    synchronized( lock ) {
      operationsQueue.add( operation );
    }
  }

  public void send() {
    if( !sendTimerRunning && sendTimer != null ) {
      sendTimerRunning = true;

      sendTimer.schedule( new TimerTask() {

        @Override
        public void run() {
          processPostRequest();
          sendTimerRunning = false;
        }
      }, 60 );
    }
  }

  public PostRequest getNextRequest() {
    synchronized( lock ) {
      List<Operation> optimizedOperations = optimizeSetOperations( operationsQueue );
      PostRequest request = new PostRequest();
      currentHead.add( Head.PROP_REQUEST_COUNTER, requestCounter.get() );
      request.setContent( getParser().createMessage( optimizedOperations, currentHead.getAll() ) );
      currentHead.clear();
      operationsQueue.clear();
      return request;
    }
  }

  List<Operation> optimizeSetOperations( List<Operation> operations ) {
    List<Operation> result = new ArrayList<Operation>();
    SetOperation lastSetOperation = null;
    for( Operation operation : operations ) {
      if( operation instanceof SetOperation ) {
        SetOperation currentSetOperation = ( SetOperation )operation;
        if( lastSetOperation == null ) {
          lastSetOperation = currentSetOperation;
        } else if( lastSetOperation.getTarget().equals( currentSetOperation.getTarget() ) ) {
          Map<String, Object> properties = currentSetOperation.getProperties().getAll();
          lastSetOperation.getProperties().add( properties );
        } else {
          result.add( lastSetOperation );
          lastSetOperation = currentSetOperation;
        }
      } else {
        if( lastSetOperation != null ) {
          result.add( lastSetOperation );
          lastSetOperation = null;
        }
        result.add( operation );
      }
    }
    if( lastSetOperation != null ) {
      result.add( lastSetOperation );
    }
    return result;
  }

  public ITransportResult processGetRequest( GetRequest request ) {
    ITransportResult transportResult = transport.get( request );
    if( transportResult.hasException() && !request.isSilentRequest() ) {
      showError( transportResult.getException() );
    }
    return transportResult;
  }

  private void verify() {
    if( parser == null ) {
      throw new IllegalStateException( "The IProtocolParser can not be null" );
    }
    if( widgetToolkit == null ) {
      throw new IllegalStateException( "The IWidgetToolkit can not be null" );
    }
    if( transport == null ) {
      throw new IllegalStateException( "The ITransport can not be null" );
    }
  }

  private void showError( final Exception exception ) {
    widgetToolkit.showError( exception, null );
  }

  public ITransport getTransport() {
    return transport;
  }

  public void setTransport( ITransport transport ) {
    this.transport = transport;
  }

  public IProtocolParser getParser() {
    return parser;
  }

  public void setParser( IProtocolParser parser ) {
    this.parser = parser;
  }

  public IWidgetToolkit getWidgetToolkit() {
    return widgetToolkit;
  }

  public void setWidgetToolkit( IWidgetToolkit widgetToolkit ) {
    this.widgetToolkit = widgetToolkit;
  }

  public void operationsFound( final List<Operation> operations ) {
    try {
      widgetToolkit.process( operations );
    } catch( Exception e ) {
      showError( e );
    }
  }

  public void headFound( Head head ) {
    synchronized( lock ) {
      if( head.hasHeader( Head.PROP_REQUEST_COUNTER ) ) {
        requestCounter.set( head.getInteger( Head.PROP_REQUEST_COUNTER ) );
      }
      handleURL( head );
      handleError( head );
    }
  }

  private void handleURL( Head head ) {
    if( head.hasHeader( Head.PROP_URL ) ) {
      String url = head.getString( Head.PROP_URL );
      SessionIDExtractor sessionIDExtractor = new SessionIDExtractor();
      transport.setSessionId( sessionIDExtractor.extract( url ) );
    }
  }

  private void handleError( Head head ) {
    if( head.hasHeader( Head.PROP_ERROR ) ) {
      String error = head.getString( Head.PROP_ERROR );
      if( Head.ERROR_SESSION_TIMEOUT.equals( error ) ) {
        LocalizableException exception = new LocalizableException( LocalizableException.SESSION_TIMEOUT );
        widgetToolkit.showError( exception, null );
      }
    }
  }

  public long getSessionTime() {
    if( sessionStartTime == 0 ) {
      return 0;
    } else {
      return System.currentTimeMillis() - sessionStartTime;
    }
  }

  /** Should only be used for testing. */
  void setRequestThreadPool( ExecutorService postThreadPool ) {
    this.requestThreadPool = postThreadPool;
  }

  /** Should only be used for testing. */
  void setSendTimer( Timer sendTimer ) {
    this.sendTimer = sendTimer;
  }

  /** Should only be used for testing. */
  void setRequestCounter( RequestCounter requestCounter ) {
    this.requestCounter = requestCounter;
  }

  public void shutdown() {
    synchronized( lock ) {
      if( requestThreadPool != null ) {
        requestThreadPool.shutdownNow();
        requestThreadPool = null;
      }
    }
    if( widgetToolkit != null ) {
      widgetToolkit.dispose();
    }
    sendTimer.cancel();
    sendTimer.purge();
    sendTimer = null;
  }
}
