/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.remote;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNullOrEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class RemoteObject {

  private final String id;
  private final ProtocolProcessor processor;
  private final List<String> listeners;

  public RemoteObject( String id, ProtocolProcessor processor ) {
    notNullOrEmpty( id, "id" );
    notNull( processor, "processor" );
    this.processor = processor;
    this.id = id;
    this.listeners = new ArrayList<String>();
  }

  public ProtocolProcessor getProcessor() {
    return processor;
  }

  public String getId() {
    return id;
  }

  public void addListen( String eventType ) {
    notNullOrEmpty( eventType, "EventType" );
    listeners.add( eventType );
  }

  public void removeListen( String eventType ) {
    notNullOrEmpty( eventType, "EventType" );
    listeners.remove( eventType );
  }
  
  public boolean isListeningToEvent( String eventType ) {
    notNullOrEmpty( eventType, "EventType" );
    return listeners.contains( eventType );
  }

  public void set( String name, int value ) {
    appendSetOperation( name, value );
  }

  public void set( String name, double value ) {
    appendSetOperation( name, value );
  }

  public void set( String name, boolean value ) {
    appendSetOperation( name, value );
  }

  public void set( String name, String value ) {
    appendSetOperation( name, value );
  }

  public void set( String name, Object value ) {
    appendSetOperation( name, value );
  }

  public void notify( String eventType, Map<String, Object> properties ) {
    ParamCheck.notNullOrEmpty( eventType, "eventType" );
    checkProcessor();
    if( listeners.contains( eventType ) ) {
      NotifyOperation operation = new NotifyOperation();
      operation.setTarget( id );
      operation.setEventType( eventType );
      operation.setProperties( createPropertiesObject( properties ) );
      processor.appendOperation( operation );
      processor.send();
    }
  }

  public void call( String method, Map<String, Object> properties ) {
    ParamCheck.notNullOrEmpty( method, "method" );
    checkProcessor();
    CallOperation operation = new CallOperation();
    operation.setTarget( id );
    operation.setMethod( method );
    operation.setProperties( createPropertiesObject( properties ) );
    processor.appendOperation( operation );
    processor.send();
  }

  private void checkProcessor() {
    if( processor == null ) {
      throw new IllegalStateException( "Protocol processor is not set." );
    }
  }

  private void appendSetOperation( String name, Object value ) {
    ParamCheck.notNullOrEmpty( name, "name" );
    checkProcessor();
    Properties properties = new Properties();
    properties.add( name, value );
    SetOperation operation = new SetOperation();
    operation.setTarget( id );
    operation.setProperties( properties );
    processor.appendOperation( operation );
  }

  private Properties createPropertiesObject( Map<String, Object> properties ) {
    Properties result = new Properties();
    if( properties != null ) {
      for( Entry<String, Object> entry : properties.entrySet() ) {
        result.add( entry.getKey(), entry.getValue() );
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    return id.hashCode();
  }

  @Override
  public boolean equals( Object object ) {
    boolean result = false;
    if( this == object ) {
      result = true;
    } else if( object instanceof RemoteObject ) {
      RemoteObject other = ( RemoteObject )object;
      result = id.equals( other.id );
    }
    return result;
  }

}
