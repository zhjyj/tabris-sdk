/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.view.View;

public class TableColumn extends View {

  // A dummy class used only as a anchor to find the TableColumnOperator

  public TableColumn( Context context ) {
    super( context );
  }

}
