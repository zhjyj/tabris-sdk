/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;


public class OperatorRegistry {

  private final Map<String, IOperator> registry;

  public OperatorRegistry() {
    registry = new HashMap<String, IOperator>();
  }

  public void register( String type, IOperator operator ) {
    ParamCheck.notNull( type, "type" );
    ParamCheck.notNull( operator, "operator" );
    registry.put( type, operator );
  }

  public void unregister( String type ) {
    ParamCheck.notNull( type, "type" );
    registry.remove( type );
  }

  public IOperator get( String type ) {
    ParamCheck.notNull( type, "type" );
    return registry.get( type );
  }

  public Collection<IOperator> getAll() {
    return Collections.unmodifiableCollection( registry.values() );
  }

}
