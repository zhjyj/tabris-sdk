/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Paint.Join;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class LineJoinGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "lineJoin";
  private static final String JOIN_BEVEL = "bevel";
  private static final String JOIN_MITER = "miter";
  private static final String JOIN_ROUND = "round";

  public LineJoinGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    String joinStr = ( String )properties.get( 1 );
    Join lineJoin = null;
    if( joinStr.equals( JOIN_BEVEL ) ) {
      lineJoin = Join.BEVEL;
    } else if( joinStr.equals( JOIN_MITER ) ) {
      lineJoin = Join.MITER;
    } else if( joinStr.equals( JOIN_ROUND ) ) {
      lineJoin = Join.ROUND;
    }
    gc.getPaint().setStrokeJoin( lineJoin );
  }

}
