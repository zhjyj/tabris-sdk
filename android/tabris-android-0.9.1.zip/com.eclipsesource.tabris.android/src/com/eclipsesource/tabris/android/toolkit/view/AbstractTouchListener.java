/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_ALT_KEY;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_BUTTON;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_CTRL_KEY;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_CURSOR_LOCATION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_SHIFT_KEY;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_TIME;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_X;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_Y;

import java.util.HashMap;
import java.util.Map;

import android.view.MotionEvent;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public abstract class AbstractTouchListener {

  static final int MOUSE_BUTTON_1 = 1;
  static final int MOUSE_BUTTON_3 = 3;

  protected final TabrisActivity activity;

  protected AbstractTouchListener( TabrisActivity activity ) {
    this.activity = activity;
  }

  protected void sendMouseEvent( MotionEvent event, String mouseEvent, int mouseButton, View view ) {
    int[] coordinates = getMouseCoordinates( event );
    long sessionTime = activity.getProcessor().getSessionTime();
    updateDisplayCursorLocation( coordinates );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_BUTTON, mouseButton );
    properties.put( PROP_X, coordinates[ 0 ] );
    properties.put( PROP_Y, coordinates[ 1 ] );
    properties.put( PROP_TIME, sessionTime );
    properties.put( PROP_SHIFT_KEY, false );
    properties.put( PROP_CTRL_KEY, false );
    properties.put( PROP_ALT_KEY, false );
    remoteObject.notify( mouseEvent, properties );
  }

  protected void updateDisplayCursorLocation( int[] coordinates ) {
    RemoteObject displayRemoteObject = activity.getDisplayRemoteObject();
    displayRemoteObject.set( PROP_CURSOR_LOCATION, coordinates );
  }
  
  protected int[] getMouseCoordinates( MotionEvent event ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    int coordY = toolkit.divideByDensityFactor( Math.round( event.getRawY() ) );
    int coordX = toolkit.divideByDensityFactor( Math.round( event.getRawX() ) );
    return new int[] { coordX, coordY };
  }

}
