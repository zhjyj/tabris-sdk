/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class CreateLinearGradiantGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "createLinearGradient";

  public CreateLinearGradiantGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 5 );
    float x0 = getScaledFloat( properties, 1 );
    float x1 = getScaledFloat( properties, 2 );
    float y0 = getScaledFloat( properties, 3 );
    float y1 = getScaledFloat( properties, 4 );
    gc.getLinearGradient().setCoords( x0, y0, x1, y1 );
  }

}
