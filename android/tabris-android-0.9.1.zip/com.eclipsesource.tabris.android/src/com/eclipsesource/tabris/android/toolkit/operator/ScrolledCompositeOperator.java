/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ObservableHorizontalScrollViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ObservableVerticalScrollViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;

public class ScrolledCompositeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.ScrolledComposite";

  private static final String STYLE_H_SCROLL = "H_SCROLL";
  private static final String STYLE_V_SCROLL = "V_SCROLL";

  private IViewSetter<? extends View> setter;
  private IViewSetter<? extends View> setterHorizontal;
  private IViewSetter<? extends View> setterVertical;

  public ScrolledCompositeOperator( TabrisActivity activity ) {
    super( activity );
    setter = new CompositeSetter<Composite>( activity );
    setterHorizontal = new ObservableHorizontalScrollViewSetter<ObservableHorizontalScrollView>( activity );
    setterVertical = new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    IViewSetter<View> result = ( IViewSetter<View> )setter;
    if( view instanceof ObservableHorizontalScrollView ) {
      result = ( IViewSetter<View> )setterHorizontal;
    } else if( view instanceof ObservableVerticalScrollView ) {
      result = ( IViewSetter<View> )setterVertical;
    }
    return result;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List<String> styles = operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class );
    if( styles == null || styles.isEmpty() ) {
      throw new IllegalArgumentException( "The style of the ScrollComposite has to be either V_SCROLL or H_SCROLL." );
    }
    createScrollView( operation, styles );
  }

  private void createScrollView( CreateOperation operation, List<String> styles ) {
    if( styles.contains( STYLE_V_SCROLL ) && styles.contains( STYLE_H_SCROLL ) ) {
      ObservableScrollView scrollView = new ObservableScrollView( getActivity() );
      initiateNewView( operation, scrollView );
      scrollView.createNestedScrollViews();
    } else if( styles.contains( STYLE_V_SCROLL ) ) {
      ObservableVerticalScrollView scrollView = new ObservableVerticalScrollView( getActivity() );
      initiateNewView( operation, scrollView );
    } else if( styles.contains( STYLE_H_SCROLL ) ) {
      ObservableHorizontalScrollView scrollView = new ObservableHorizontalScrollView( getActivity() );
      initiateNewView( operation, scrollView );
    }
  }

}
