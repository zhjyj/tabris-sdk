/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.Arrays;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class Display extends FrameLayout {

  private boolean sessionRunning;

  // private static final String PROP_RWT_INITIALIZE = "rwt_initialize";
  // private static final String PROP_BOUNDS = "bounds";
  // private static final String PROP_COLOR_DEPTH = "colorDepth";
  // private static final String PROP_DPI = "dpi";
  // private static final String PROP_CURSOR_LOCATION = "cursorLocation";

  public Display( Context context ) {
    super( context );
  }

  public Display( Context context, AttributeSet attrSet ) {
    super( context, attrSet );
  }

  @Override
  public void onSizeChanged( int w, int h, int oldw, int oldh ) {
    super.onSizeChanged( w, h, oldw, oldh );
    TabrisActivity activity = ( TabrisActivity )getContext();
    ProtocolProcessor processor = activity.getProcessor();
    if( !sessionRunning ) {
      if( getAutoStartSessionFromIntent( activity ) ) {
        try {
          processor.startSession();
        } catch( Throwable t ) {
          activity.closeActivity( t );
        }
        sessionRunning = true;
      }
    } else {
      processDisplaySizeChanged( activity, w, h );
    }
  }

  private void processDisplaySizeChanged( TabrisActivity activity, final int width, final int height )
  {
    updateShellDimensions( width, height );
    sendDisplayScaleMessage( activity, width, height );
  }

  private void sendDisplayScaleMessage( TabrisActivity activity, final int width, final int height )
  {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    int scaledWidth = toolkit.divideByDensityFactor( width );
    int scaledHeight = toolkit.divideByDensityFactor( height );
    RemoteObject remoteObject = activity.getRemoteObject( this );
    remoteObject.set( PROP_BOUNDS, Arrays.asList( 0, 0, scaledWidth, scaledHeight ) );
    remoteObject.getProcessor().send();
  }

  private void updateShellDimensions( final int width, final int height ) {
    for( int i = 0; i < getChildCount(); i++ ) {
      View view = getChildAt( i );
      if( view instanceof Shell && ( ( Shell )view ).isMaximized() ) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = width;
        params.height = height;
      }
    }
  }

  private boolean getAutoStartSessionFromIntent( Activity activity ) {
    return activity.getIntent().getBooleanExtra( TabrisActivity.AUTO_START_SESSION, true );
  }

  public boolean isSessionRunning() {
    return sessionRunning;
  }

  public void sendInitialPostRequest() {
    TabrisActivity activity = ( TabrisActivity )getContext();
    RemoteObject remoteObject = activity.getRemoteObject( this );
    ProtocolProcessor processor = activity.getProcessor();
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    processor.appendHeader( PROP_RWT_INITIALIZE, true );
    remoteObject.set( PROP_BOUNDS, getBounds( toolkit ) );
    remoteObject.set( PROP_COLOR_DEPTH, getColorDepth( toolkit ) );
    remoteObject.set( PROP_DPI, getDpi( toolkit ) );
    remoteObject.set( PROP_CURSOR_LOCATION, getCursorLocation() );
    processor.send();
  }

  private int[] getBounds( IWidgetToolkit toolkit ) {
    int width = toolkit.divideByDensityFactor( toolkit.getSurfaceWidth() );
    int height = toolkit.divideByDensityFactor( toolkit.getSurfaceHeight() );
    return new int[]{ 0, 0, width, height };
  }

  private int getColorDepth( IWidgetToolkit toolkit ) {
    return toolkit.getSurfaceColorDepth();
  }

  private int[] getDpi( IWidgetToolkit toolkit ) {
    return new int[]{ toolkit.getSurfaceDpiX(), toolkit.getSurfaceDpiY() };
  }

  private int[] getCursorLocation() {
    return new int[]{ 0, 0 };
  }

  /** To be used for testing only. */
  void setSessionRunning( boolean sessionRunning ) {
    this.sessionRunning = sessionRunning;
  }

}
