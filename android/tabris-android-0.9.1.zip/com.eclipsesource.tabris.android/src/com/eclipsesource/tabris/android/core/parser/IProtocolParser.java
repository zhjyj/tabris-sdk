/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.parser;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.eclipsesource.tabris.android.core.model.Operation;

public interface IProtocolParser {

  void addProtocolParserCallback( IProtocolParserCallback callback );

  void parse( InputStream is );

  String toJson( Object obj );

  String createMessage( List<Operation> operations, Map<String, Object> headers );

}
