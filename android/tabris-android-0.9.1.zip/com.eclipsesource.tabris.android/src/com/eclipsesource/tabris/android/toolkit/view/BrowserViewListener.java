/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public final class BrowserViewListener implements OnTouchListener {

  public boolean onTouch( View v, MotionEvent event ) {
    switch( event.getAction() ) {
      case MotionEvent.ACTION_DOWN:
      case MotionEvent.ACTION_UP:
        if( !v.hasFocus() ) {
          v.requestFocus();
        }
      break;
    }
    return false;
  }
}
