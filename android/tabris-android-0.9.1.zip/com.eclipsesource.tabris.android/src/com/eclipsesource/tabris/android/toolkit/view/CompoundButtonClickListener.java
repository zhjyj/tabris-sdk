/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.view.View;
import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.TabrisActivity;

public class CompoundButtonClickListener extends ViewClickListener {

  private final TabrisActivity activity;

  public CompoundButtonClickListener( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }
  
  @Override
  public void onClick( View view ) {
    notNull( view, "View" );
    if( view instanceof CompoundButton ) {
      super.onClick( view );
    }
  }

}