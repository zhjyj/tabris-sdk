/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.Group;

public class GroupSetter<T extends Group> extends CompositeSetter<T> {

  public GroupSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T group, Properties properties ) {
    super.execute( group, properties );
    setText( group, properties );
    setForeground( group, properties );
  }

  private void setText( T group, Properties properties ) {
    String text = properties.getString( ProtocolConstants.PROP_TEXT );
    if( text != null ) {
      group.setTitle( text );
    }
  }

  private void setForeground( T group, Properties properties ) {
    List<Integer> foreground = properties.getList( ProtocolConstants.PROP_FOREGROUND, Integer.class );
    if( foreground != null ) {
      group.setTitleAndSeparatorColor( ColorUtil.colorToupleToInt( foreground ) );
    }
  }

}
