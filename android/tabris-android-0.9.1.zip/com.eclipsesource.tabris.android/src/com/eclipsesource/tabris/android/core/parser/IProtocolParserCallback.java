/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.parser;

import java.util.List;

import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.Operation;

public interface IProtocolParserCallback {

  void operationsFound( List<Operation> ops );

  void headFound( Head head );

}
