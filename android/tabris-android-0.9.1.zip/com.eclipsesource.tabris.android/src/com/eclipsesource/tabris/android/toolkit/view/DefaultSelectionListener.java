package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_DEFAULT_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;


public class DefaultSelectionListener {
  
  private final TabrisActivity activity;

  public DefaultSelectionListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }
  
  public void onDefaultSelection( View view ) {
    notNull( view, "View" );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.notify( EVENT_DEFAULT_SELECTION, null );
  }

}
