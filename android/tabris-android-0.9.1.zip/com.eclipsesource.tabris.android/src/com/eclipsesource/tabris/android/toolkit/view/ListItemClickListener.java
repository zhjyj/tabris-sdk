/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ListItemClickListener implements OnItemClickListener {

  private final TabrisActivity activity;

  public ListItemClickListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    RemoteObject remoteObject = activity.getRemoteObject( parent );
    remoteObject.set( PROP_FOCUS_INDEX, position );
    remoteObject.set( PROP_SELECTION, new int[]{
      position
    } );
    remoteObject.notify( EVENT_SELECTION, null );
    setSelection( parent, position );
  }

  private void setSelection( AdapterView<?> parent, int position ) {
    ListSelectionAdapter adapter = ( ListSelectionAdapter )parent.getAdapter();
    if( adapter != null && !adapter.isEmpty() ) {
      adapter.setSelectionIndex( position );
    }
  }

}
