/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;

public class CompositeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Composite";

  private final IViewSetter<? extends View> setter;

  public CompositeOperator( TabrisActivity activity ) {
    super( activity );
    setter = new CompositeSetter<Composite>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Composite comp = new Composite( getActivity() );
    initiateNewView( operation, comp );
    applyConsumingTouchListener( comp );
  }

  @Override
  protected void applyConsumingTouchListener( View view ) {
    CompositeTouchListener compListener = getListenerRegistry().findListener( getObjectId( view ),
                                                                              CompositeTouchListener.class );
    compListener.addListener( new ConsumingTouchListener() );
  }

}
