/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.util.List;

import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.drawable.Drawable;

public class ColorUtil {

  static final int COLOR_COMP_A = 24;
  static final int COLOR_COMP_R = 16;
  static final int COLOR_COMP_G = 8;
  static final int COLOR_COMP_B = 0;

  private ColorUtil() {
    // prevent instantiation
  }

  public static void applyColorFilter( Drawable drawable, float r, float g, float b ) {
    drawable.setColorFilter( createColorFilter( r, g, b ) );
  }

  public static ColorFilter createColorFilter( float r, float g, float b ) {
    ColorMatrix cmDesat = new ColorMatrix();
    cmDesat.setSaturation( 0 );
    ColorMatrix cm = new ColorMatrix();
    // @formatter:off
    cm.set( new float[]{
      r, 0, 0, 0, 0,
      0, g, 0, 0, 0,
      0, 0, b, 0, 0,
      0, 0, 0, 1, 0
    } );
    // @formatter:on
    cmDesat.postConcat( cm );
    return new ComparableColorMatrixColorFilter( cmDesat );
  }

  public static int colorToupleToInt( List<Integer> touple ) {
    if( touple == null ) {
      throw new IllegalArgumentException( "The given color touple can not be null" );
    }
    if( touple.size() < 3 ) {
      throw new IllegalArgumentException( "The given color touple can not be smaller than 3. Given Touple is "
                                          + touple.size() );
    }
    if( touple.size() > 4 ) {
      throw new IllegalArgumentException( "The given color touple can not be larger than 4. Given Touple is "
                                          + touple.size() );
    }

    int r = createHex( touple.get( 0 ), COLOR_COMP_R );
    int g = createHex( touple.get( 1 ), COLOR_COMP_G );
    int b = createHex( touple.get( 2 ), COLOR_COMP_B );
    int a;
    if( touple.size() == 4 ) {
      a = createHex( touple.get( 3 ), COLOR_COMP_A );
    } else {
      a = 0xFF000000;
    }
    return a | r | g | b;
  }

  private static int createHex( int value, int component ) {
    if( value < 0 || value > 255 ) {
      throw new IllegalArgumentException( "Can not create color because color value is not in the range of [0-255]" );
    }
    return ( value & 0xff ) << component;
  }

}
