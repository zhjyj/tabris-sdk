/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;

public class TouchPositionBuffer implements OnTouchListener {

  private float x;
  private float y;

  public TouchPositionBuffer( IWidgetToolkit toolkit ) {
    clear();
  }

  public boolean onTouch( View v, MotionEvent event ) {
    x = event.getRawX();
    y = event.getRawY();
    return false;
  }

  public boolean isEmpty() {
    return ( x < 0 ) && ( y < 0 );
  }

  public void clear() {
    x = -1;
    y = -1;
  }

  public float getX() {
    return x;
  }

  public float getY() {
    return y;
  }
}
