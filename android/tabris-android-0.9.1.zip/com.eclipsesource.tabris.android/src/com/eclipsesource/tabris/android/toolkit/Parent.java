package com.eclipsesource.tabris.android.toolkit;

import java.util.List;


public interface Parent {
  
  void addChild( Object child );
  
  List<Object> getChildren();

}
