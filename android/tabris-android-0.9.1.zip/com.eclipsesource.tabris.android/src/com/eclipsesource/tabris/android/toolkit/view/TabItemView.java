/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import com.eclipsesource.tabris.android.toolkit.operator.TabItemOperator;

/**
 * This class is only used so that set operations can be performed for the rwt
 * TabItem. See {@link TabFolder} and {@link TabItemOperator} for the
 * proper implementation.
 */
public class TabItemView extends View {

  public TabItemView( Context context ) {
    super( context );
  }

  public TabItemView( Context context, AttributeSet attrs ) {
    super( context, attrs );
  }

}
