/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ServerPush_Test {

  private ServerPush serverPush;
  private IWidgetToolkit toolkit;
  private TabrisActivity activity;

  class ServerPushUnderTest extends ServerPush {

    public ServerPushUnderTest( TabrisActivity activity ) {
      super( activity );
    }

    @Override
    protected Thread createNewThread() {
      return mock( Thread.class );
    }

    @Override
    public boolean isServerPushActive() {
      return getThread() != null;
    }
  }

  @Before
  public void setUp() {
    activity = mock( TabrisActivity.class );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( activity.getProcessor() ).thenReturn( processor );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    serverPush = new ServerPushUnderTest( activity );
  }

  @Test
  public void testSetActiveTrueShouldRegisterServerPush() {
    serverPush.activate( true );

    verify( serverPush.getThread() ).start();
    verify( activity ).registerReceiver( eq( serverPush ), any( IntentFilter.class ) );
    verify( toolkit ).addOperationsListProcessedListener( serverPush );
  }

  @Test
  public void testSetActiveFalseShouldUnregisterServerPush() {
    serverPush.activate( true );
    serverPush.activate( false );

    verify( activity ).registerReceiver( eq( serverPush ), any( IntentFilter.class ) );
    verify( serverPush.getThread() ).interrupt();
    verify( activity ).unregisterReceiver( eq( serverPush ) );
  }

  @Test
  public void testOnReceiveStartsServerPush() throws Exception {
    Intent intent = new Intent( ConnectivityManager.CONNECTIVITY_ACTION );
    intent.putExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY, false );
    serverPush.onReceive( activity, intent );

    verify( serverPush.getThread() ).start();
  }

  @Test
  public void testOnReceiveStopsServerPush() throws Exception {
    serverPush.activate( true );
    Intent intent = new Intent( ConnectivityManager.CONNECTIVITY_ACTION );
    intent.putExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY, true );

    serverPush.onReceive( activity, intent );

    verify( serverPush.getThread() ).interrupt();
  }

  @Test
  public void testShouldStartServerPushWhenOperationsListExecuted() throws Exception {
    serverPush.activate( true );
    serverPush.activate( false );

    serverPush.listProcessed();

    verify( serverPush.getThread() ).start();
  }

}
