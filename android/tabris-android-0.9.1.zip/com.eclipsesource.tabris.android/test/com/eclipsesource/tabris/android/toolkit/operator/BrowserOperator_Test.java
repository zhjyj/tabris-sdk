/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.BrowserSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.BrowserWebViewClient;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.IBrowserProgressListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowWebView;

@RunWith(RobolectricTestRunner.class)
public class BrowserOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String VIEW_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;
  private ObjectRegistry objectRegistry;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( VIEW_ID );
    activity.setContentView( R.layout.protocol );
    toolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = new ListenerRegistry();
    listenerRegistry.registerListener( VIEW_ID, new CompositeTouchListener() );
    parentLayout = new FrameLayout( activity );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getRemoteObjectForObject( parentLayout ) )
     .thenReturn( new RemoteObject( PARENT_ID, activity.getProcessor() ) );
    when( objectRegistry.getRemoteObject( anyString() ) )
      .thenReturn( new RemoteObject( PARENT_ID, activity.getProcessor() ) );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );

    assertTrue( operator.getViewSetter( mock( View.class ) ) instanceof BrowserSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new BrowserOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateBrowserNoProps() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateBrowserNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateBrowserNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private Browser getCreatedValidatedView() {
    ArgumentCaptor<Browser> captor = ArgumentCaptor.forClass( Browser.class );
    verify( toolkit.getObjectRegistry() ).register( eq( VIEW_ID ), captor.capture(), eq( BrowserOperator.TYPE ) );
    Browser view = captor.getValue();
    assertEquals( VIEW_ID, activity.getRemoteObject( view ).getId() );
    return view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    op.setType( "rwt.widgets.Browser" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Browser view = getCreatedValidatedView();
    verify( toolkit.getObjectRegistry() ).register( VIEW_ID, view, "rwt.widgets.Browser" );
    assertTrue( view instanceof Browser );
    FrameLayout parent = ( FrameLayout )view.getParent();
    assertEquals( PARENT_ID, toolkit.getObjectRegistry().getRemoteObjectForObject( parent ).getId() );
  }

  @Test
  public void testGetType() throws Exception {
    BrowserOperator op = new BrowserOperator( new TabrisActivity() );
    assertEquals( BrowserOperator.TYPE, op.getType() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testAttachProgressListener() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    when( objectRegistry.getObject( eq( VIEW_ID ), any( Class.class ) ) ).thenReturn( browser );
    BrowserWebViewClient client = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( client );
    ListenOperation op = new ListenOperation();
    op.setTarget( VIEW_ID );
    Properties props = new Properties();
    props.add( "Progress", true );
    op.setProperties( props );

    operator.listen( op );

    verify( client ).setProgressListener( any( IBrowserProgressListener.class ) );
  }

  private Browser createAddedBrowserWidget() {
    Browser browser = new Browser( activity );
    browser.init();
    when( toolkit.getObjectRegistry().getObject( VIEW_ID, Browser.class ) ).thenReturn( browser );
    return browser;
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testRemoveProgressListener() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    when( objectRegistry.getObject( eq( VIEW_ID ), any( Class.class ) ) ).thenReturn( browser );
    BrowserWebViewClient client = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( client );
    ListenOperation op = new ListenOperation();
    op.setTarget( VIEW_ID );
    Properties props = new Properties();
    props.add( "Progress", false );
    op.setProperties( props );

    operator.listen( op );

    verify( client ).setProgressListener( null );
  }

  @Test
  public void testCallEvaluate() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    CallOperation op = new CallOperation();
    op.setMethod( "evaluate" );
    op.setTarget( VIEW_ID );
    Properties props = new Properties();
    props.add( "script", "someScript" );
    op.setProperties( props );

    operator.call( op );

    ShadowWebView shadowBrowser = Robolectric.shadowOf( browser );
    assertTrue( shadowBrowser.getLastLoadedUrl().contains( "someScript" ) );
  }
}
