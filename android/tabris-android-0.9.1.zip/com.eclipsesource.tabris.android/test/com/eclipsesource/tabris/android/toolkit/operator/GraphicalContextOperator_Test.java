/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.ClientGraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class GraphicalContextOperator_Test {

  private static final String CANVAS_ID = "w3";
  private static final String GC_ID = "gc4";

  private TabrisActivity activity;
  private GraphicalContextOperator operator;
  private GraphicalContext gc;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.getObjectRegistry() ).thenReturn( mock( ObjectRegistry.class ) );
    activity.setProcessor( processor );
    Canvas canvas = new Canvas( activity );
    canvas.setTag( new RemoteObject( CANVAS_ID, processor ) );
    when( toolkit.getObjectRegistry().getObject( CANVAS_ID, ViewGroup.class ) ).thenReturn( canvas );
    when( toolkit.getObjectRegistry().getObject( CANVAS_ID, View.class ) ).thenReturn( canvas );
    operator = new GraphicalContextOperator( activity );
  }

  @Test
  public void testGetType() throws Exception {
    GraphicalContextOperator op = new GraphicalContextOperator( new TabrisActivity() );
    assertEquals( GraphicalContextOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalidTarget() {
    IOperator operator = new GraphicalContextOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoProps() throws Exception {
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoParentSet() throws Exception {
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    CreateOperation op = new CreateOperation();
    op.setTarget( GC_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( GC_ID );
    op.setType( "rwt.widgets.GC" );
    Properties props = new Properties();
    props.add( "parent", CANVAS_ID );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateParentNotCanvas() throws Exception {
    CreateOperation op = createValidCreateOperation();
    FrameLayout parentLayout = new FrameLayout( activity );
    when( toolkit.getObjectRegistry().getObject( "widgetId", View.class ) ).thenReturn( parentLayout );
    op.getProperties().add( "parent", "widgetId" );

    operator.create( op );
  }

  @Test
  public void testCreateOk() throws Exception {
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    verify( toolkit.getObjectRegistry() ).register( eq( GC_ID ),
                                                    any( ClientGraphicalContext.class ),
                                                    eq( "rwt.widgets.GC" ) );
  }

  @Test
  public void testDestroy() throws Exception {
    testCreateOk();
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( GC_ID );

    operator.destroy( destroyOperation );

    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    verify( toolkit.getObjectRegistry() ).unregister( eq( GC_ID ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallNull() {
    operator.call( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallNoTarget() throws Exception {
    CallOperation op = mock( CallOperation.class );

    operator.call( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallInvalidTarget() {
    CallOperation op = mock( CallOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.call( op );
  }

  @Test
  public void testCallInit() throws Exception {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    GraphicalContext gc = mock( GraphicalContext.class );
    when( toolkit.getObjectRegistry().getObject( GC_ID, GraphicalContext.class ) ).thenReturn( gc );
    CallOperation op = new CallOperation();
    op.setTarget( GC_ID );
    op.setMethod( "init" );
    Properties callProps = new Properties();
    op.setProperties( callProps );

    operator.call( op );

    gc.init( callProps );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallDrawWithNullOperation() throws Exception {
    CallOperation op = new CallOperation();
    Properties callProps = createDrawCallOperationProperties( op );
    op.setProperties( callProps );

    operator.call( op );
  }

  private Properties createDrawCallOperationProperties( CallOperation op ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    gc = mock( GraphicalContext.class );
    when( toolkit.getObjectRegistry().getObject( GC_ID, GraphicalContext.class ) ).thenReturn( gc );
    op.setTarget( GC_ID );
    op.setMethod( "draw" );
    Properties callProps = new Properties();
    op.setProperties( callProps );
    return callProps;
  }

  @Test(expected = IllegalStateException.class)
  public void testCallDrawWithInvalidOperationsType() throws Exception {
    CallOperation op = new CallOperation();
    Properties callProps = createDrawCallOperationProperties( op );
    callProps.add( "operations", "hello world" );
    op.setProperties( callProps );

    operator.call( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallDrawWithInvalidOperationsEntries() throws Exception {
    CallOperation op = new CallOperation();
    Properties callProps = createDrawCallOperationProperties( op );
    callProps.add( "operations", Arrays.asList( "Hello World!" ) );

    operator.call( op );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testCallDrawOk() throws Exception {
    CallOperation op = new CallOperation();
    Properties callProps = createDrawCallOperationProperties( op );
    IGcOperation gcOp = mock( IGcOperation.class );
    String opName = "testGcOperation";
    when( gcOp.getOperation() ).thenReturn( opName );
    List<String> params = Arrays.asList( opName, "" );
    callProps.add( "operations", Arrays.asList( params ) );
    HashMap<String, IGcOperation> gcOperations = operator.getGcOperations();
    gcOperations.clear();
    gcOperations.put( opName, gcOp );

    operator.call( op );

    verify( gcOp ).execute( gc, params );
  }
}
