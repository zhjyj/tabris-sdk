/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.RadioButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowFrameLayout;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.xtremelabs.robolectric.Robolectric;

@RunWith(TabrisTestRunner.class)
public class Composite_Test {

  private TabrisActivity activity;
  private CompositeCheckedChangedListener compListener;
  private ListenerRegistry listenerRegistry;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithoutOnCreate();
    ProtocolProcessor processor = activity.getProcessor();
    listenerRegistry = mock( ListenerRegistry.class );
    compListener = mock( CompositeCheckedChangedListener.class );
    when( listenerRegistry.findListener( "w2", CompositeCheckedChangedListener.class ) ).thenReturn( compListener );
    when( listenerRegistry.findListener( "w3", CompositeCheckedChangedListener.class ) ).thenReturn( compListener );
    when( processor.getWidgetToolkit().getListenerRegistry() ).thenReturn( listenerRegistry );
    ObjectRegistry objectRegistry = processor.getWidgetToolkit().getObjectRegistry();
    when( objectRegistry.getRemoteObjectForObject( any( RadioButton.class ) ) )
      .thenReturn( new RemoteObject( "w3", processor ) );

  }

  @Test
  public void testAddRadioButton() {
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );
    RadioButton radioButtonUnderTest = new RadioButton( activity );
    assertEquals( 0, compositeLayout.getChildCount() );

    compositeLayout.addView( radioButtonUnderTest );

    assertEquals( 1, compositeLayout.getChildCount() );
    verify( compListener ).addListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveRadioButtonAt() {
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    RadioButton radioButtonUnderTest = new RadioButton( activity );
    assertEquals( 0, compositeLayout.getChildCount() );
    compositeLayout.addView( radioButtonUnderTest );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeViewAt( 0 );
    assertEquals( 0, compositeLayout.getChildCount() );
    verify( compListener ).removeListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveRadioButton() {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    RadioButton radioButtonUnderTest = new RadioButton( activity );
    assertEquals( 0, compositeLayout.getChildCount() );
    compositeLayout.addView( radioButtonUnderTest );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeView( radioButtonUnderTest );
    assertEquals( 0, compositeLayout.getChildCount() );
    verify( compListener ).removeListener( any( OnCheckedChangeListener.class ) );
  }

  @Test
  public void testRemoveView() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );

    verifyNoMoreInteractions( listenerRegistry );
    View view = new View( activity );
    view.setTag( new RemoteObject( "w3", mock( ProtocolProcessor.class ) ) );
    compositeLayout.addView( view );
    assertEquals( 1, compositeLayout.getChildCount() );
    compositeLayout.removeView( view );
    assertEquals( 0, compositeLayout.getChildCount() );
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testRadioButtonsToggled() throws Exception {
    activity = UiTestUtil.createActivityWithMockedFields();
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    CompositeCheckedChangedListener complistenerW2 = new CompositeCheckedChangedListener();
    CompositeCheckedChangedListener complistenerW3 = new CompositeCheckedChangedListener();
    ListenerRegistry listenerRegistry = toolkit.getListenerRegistry();
    when( listenerRegistry.findListener( eq( "w2" ), any( Class.class ) ) ).thenReturn( complistenerW2 );
    when( listenerRegistry.findListener( eq( "w3" ), any( Class.class ) ) ).thenReturn( complistenerW3 );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Composite compositeLayout = new Composite( activity );
    rootLayout.addView( compositeLayout );
    RadioButton rb2 = new RadioButton( activity );
    when( objectRegistry.getRemoteObjectForObject( rb2 ) ).thenReturn( new RemoteObject( "w2", activity.getProcessor() ) );
    rb2.setOnCheckedChangeListener( complistenerW2 );
    RadioButton rb3 = new RadioButton( activity );
    when( objectRegistry.getRemoteObjectForObject( rb3 ) ).thenReturn( new RemoteObject( "w3", activity.getProcessor() ) );
    rb3.setOnCheckedChangeListener( complistenerW3 );
    compositeLayout.addView( rb2 );
    compositeLayout.addView( rb3 );

    assertFalse( rb2.isChecked() );
    assertFalse( rb3.isChecked() );

    rb2.setChecked( true );

    assertTrue( rb2.isChecked() );
    assertFalse( rb3.isChecked() );

    rb3.setChecked( true );

    assertFalse( rb2.isChecked() );
    assertTrue( rb3.isChecked() );

    rb3.setChecked( false );

    assertFalse( rb2.isChecked() );
    assertFalse( rb3.isChecked() );
  }

}
