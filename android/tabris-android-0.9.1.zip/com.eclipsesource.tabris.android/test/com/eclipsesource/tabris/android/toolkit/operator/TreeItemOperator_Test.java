/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.TreeItemViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

@RunWith(TabrisTestRunner.class)
public class TreeItemOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentView;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithoutOnCreate();
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentView = new FrameLayout( activity );
    parentView.setTag( new RemoteObject( PARENT_ID, activity.getProcessor() ) );
    rootLayout.addView( parentView );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );

    assertTrue( operator.getViewSetter( mock( TreeItemView.class ) ) instanceof TreeItemViewSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeItemNoProps() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeItemNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeItemParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, activity.getProcessor() ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateTreeItemOk() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivity();
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( PARENT_ID, parentView, "FrameLayout" );
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof TreeItemView );
    assertEquals( WIDGET_ID, activity.getRemoteObject( view ).getId() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    op.setType( "rwt.widgets.GridItem" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;

  }

  @Test
  public void testGetType() throws Exception {
    TreeItemOperator op = new TreeItemOperator( new TabrisActivity() );
    assertEquals( TreeItemOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNullOperation() throws Exception {
    TreeItemOperator operator = new TreeItemOperator( activity );
    operator.destroy( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNoTarget() throws Exception {
    TreeItemOperator operator = new TreeItemOperator( activity );
    DestroyOperation destroyOperation = new DestroyOperation();
    operator.destroy( destroyOperation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyTargetDoesNotExist() throws Exception {
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    TreeItemOperator operator = new TreeItemOperator( activity );

    assertNull( rootLayout.findViewWithTag( WIDGET_ID ) );

    operator.destroy( destroyOperation );
  }

  @Test
  public void testDestroyOk() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    TreeView treeView = new TreeView( activity );
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.setTag( new RemoteObject( WIDGET_ID, activity.getProcessor() ) );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    rootTreeItem.addView( treeItem );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getObjectRegistry().getObject( WIDGET_ID, TreeItemView.class ) ).thenReturn( treeItem );
    when( toolkit.getObjectRegistry().getObject( WIDGET_ID, View.class ) ).thenReturn( treeItem );
    ListenerRegistry registry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    TreeItemOperator operator = new TreeItemOperator( activity );

    assertTrue( treeView.getRootTreeItem().getChildren().contains( treeItem ) );

    operator.destroy( destroyOperation );

    assertNull( treeView.findViewWithTag( WIDGET_ID ) );
    verify( toolkit.getBitmapCache() ).decreaseReferenceCount( any( BitmapDrawable.class ) );
    verify( registry ).unregisterAllListeners( WIDGET_ID );
  }
}
