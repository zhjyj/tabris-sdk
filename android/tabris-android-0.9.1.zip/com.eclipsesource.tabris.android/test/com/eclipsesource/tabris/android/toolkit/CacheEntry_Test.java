/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.util.ReferenceAwareLRUCache.CacheEntry;

public class CacheEntry_Test {

  @Test
  public void testCreateCacheEntry() {
    CacheEntry<String> entry = new CacheEntry<String>( "abc" );

    assertEquals( "abc", entry.getValue() );
    assertEquals( 0, entry.getReferenceCount() );
  }

  @Test
  public void testIncrementAndDecerementReferenceCount() {
    CacheEntry<String> entry = new CacheEntry<String>( "abc" );

    entry.increaseReferenceCount();

    assertEquals( 1, entry.getReferenceCount() );

    entry.decreaseReferenceCount();

    assertEquals( 0, entry.getReferenceCount() );
  }

}
