/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.InputStream;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.ProgressIndicator;

public class PostRequestRunnable_Test {

  private ITransportResult result;
  private ITransport transport;
  private IWidgetToolkit toolkit;
  private IProtocolParser parser;
  private ProgressIndicator progressIndicator;

  @Before
  public void setUp() {
    result = mock( ITransportResult.class );
    transport = mock( ITransport.class );
    toolkit = mock( IWidgetToolkit.class );
    progressIndicator = mock( ProgressIndicator.class );
    when( toolkit.getProgressIndicator() ).thenReturn( progressIndicator );
    parser = mock( IProtocolParser.class );
  }

  private ProtocolProcessor setUpProtocolProcessor( PostRequest request ) {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getTransport() ).thenReturn( transport );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( processor.getParser() ).thenReturn( parser );
    when( processor.getNextRequest() ).thenReturn( request );
    return processor;
  }

  @Test
  public void testProcessPostRequestOk() throws Exception {
    PostRequest request = new PostRequest();
    ProtocolProcessor processor = setUpProtocolProcessor( request );
    when( result.hasException() ).thenReturn( false );
    when( result.hasParsableContent() ).thenReturn( true );
    when( transport.post( request ) ).thenReturn( result );
    PostRequestRunnable runnable = new PostRequestRunnable( processor );
    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( request );
    verify( parser ).parse( any( InputStream.class ) );
  }

  private void verifyProgressIndication() {
    verify( toolkit ).getProgressIndicator();
    verify( progressIndicator ).start();
    verify( progressIndicator ).stop();
  }

  @Test
  public void testProcessPostRequestTransportFail() throws Exception {
    PostRequest request = new PostRequest();
    ProtocolProcessor processor = setUpProtocolProcessor( request );
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( true );
    when( transport.post( request ) ).thenReturn( result );
    PostRequestRunnable runnable = new PostRequestRunnable( processor );

    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( any( PostRequest.class ) );
    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  public void testInitiateSessionParseFail() throws Exception {
    when( result.hasException() ).thenReturn( false );
    PostRequest request = new PostRequest();
    when( transport.post( request ) ).thenReturn( result );
    doThrow( ParseException.class ).when( parser ).parse( any( InputStream.class ) );
    ProtocolProcessor processor = setUpProtocolProcessor( request );
    PostRequestRunnable runnable = new PostRequestRunnable( processor );

    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( any( PostRequest.class ) );
    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }
}
