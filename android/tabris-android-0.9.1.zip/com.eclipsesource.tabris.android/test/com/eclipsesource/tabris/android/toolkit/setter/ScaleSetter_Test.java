/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Scale;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ScaleSetter_Test {

  @Test
  public void testSetMinimum() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    Properties props = new Properties();
    props.add( "minimum", 50 );

    setter.execute( scale, props );

    verify( scale ).setMin( 50 );
  }

  @Test
  public void testSetMaximum() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    Properties props = new Properties();
    props.add( "maximum", 50 );

    setter.execute( scale, props );

    verify( scale ).setMax( 50 );
  }

  @Test
  public void testSetSelection() throws Exception {
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( new TabrisActivity() );
    Scale scale = mock( Scale.class );
    Properties props = new Properties();
    props.add( "selection", 50 );

    setter.execute( scale, props );

    verify( scale ).setProgress( 50 );
  }

  @Test
  public void testApplyBoundsToView() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ScaleSetter<Scale> setter = new ScaleSetter<Scale>( activity );
    Scale scale = mock( Scale.class );
    MarginLayoutParams layoutParams = new MarginLayoutParams( 0, 0 );
    when( scale.getLayoutParams() ).thenReturn( layoutParams );
    Properties props = new Properties();
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    props.add( "bounds", bounds );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, 10, 24, 30, 32 );

    setter.execute( scale, props );

    assertEquals( 10, layoutParams.leftMargin );
    assertEquals( 24, layoutParams.topMargin );
    assertEquals( 30, layoutParams.width );
    assertEquals( 32, layoutParams.height );
  }

}
