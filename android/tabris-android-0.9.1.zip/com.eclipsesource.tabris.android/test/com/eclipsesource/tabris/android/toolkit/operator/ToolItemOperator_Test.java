/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.ToolItemSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.eclipsesource.tabris.android.toolkit.view.SeparatorToolItem;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;

@RunWith(TabrisTestRunner.class)
public class ToolItemOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentWidget;
  private ObjectRegistry objectRegistry;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    parentWidget = new FrameLayout( activity );
    objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( PARENT_ID, parentWidget, "FrameLayout" );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );

    assertTrue( operator.getViewSetter( mock( ToolItem.class ) ) instanceof ToolItemSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolItemNoProps() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolItemNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateToolItemNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private ToolItem getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof ToolItem );
    assertEquals( WIDGET_ID, activity.getRemoteObject( view ).getId() );
    return ( ToolItem )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    op.setType( "rwt.widgets.ToolItem" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateWithStylePush() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( "PUSH" ) );

    operator.create( op );

    ToolItem view = getCreatedValidatedView();
    assertTrue( view instanceof PushToolItem );
    assertEquals( parentWidget, view.getParent() );
  }

  @Test
  public void testCreateWithStyleSeparator() throws Exception {
    AbstractWidgetOperator operator = new ToolItemOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( "SEPARATOR" ) );

    operator.create( op );

    ToolItem view = getCreatedValidatedView();
    assertTrue( view instanceof SeparatorToolItem );
    assertEquals( parentWidget, view.getParent() );
  }

  @Test
  public void testGetType() throws Exception {
    ToolItemOperator op = new ToolItemOperator( new TabrisActivity() );
    assertEquals( ToolItemOperator.TYPE, op.getType() );
  }

  @Test
  public void testAttachSelectionListener() throws Exception {
    ToolItemOperator operator = new ToolItemOperator( activity );
    PushToolItem toolItem = mock( PushToolItem.class );
    when( toolItem.getPaddingLeft() ).thenReturn( 1 );
    when( toolItem.getPaddingTop() ).thenReturn( 2 );
    when( toolItem.getPaddingRight() ).thenReturn( 3 );
    when( toolItem.getPaddingBottom() ).thenReturn( 4 );
    objectRegistry.register( WIDGET_ID, toolItem, "rwt.widgets.ToolItem" );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    Properties listenProps = new Properties();
    listenProps.add( "Selection", true );
    op.setProperties( listenProps );

    operator.listen( op );

    verify( toolItem ).setBackgroundResource( R.drawable.item_background_holo_dark );
    verify( toolItem ).setPadding( 1, 2, 3, 4 );
  }

  @Test
  public void testRemoveSelectionListener() throws Exception {
    ToolItemOperator operator = new ToolItemOperator( activity );
    PushToolItem toolItem = mock( PushToolItem.class );
    when( toolItem.getPaddingLeft() ).thenReturn( 1 );
    when( toolItem.getPaddingTop() ).thenReturn( 2 );
    when( toolItem.getPaddingRight() ).thenReturn( 3 );
    when( toolItem.getPaddingBottom() ).thenReturn( 4 );
    objectRegistry.register( WIDGET_ID, toolItem, "rwt.widgets.ToolItem" );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    Properties listenProps = new Properties();
    listenProps.add( "Selection", false );
    op.setProperties( listenProps );

    operator.listen( op );

    verify( toolItem ).setBackgroundResource( R.drawable.item_background_holo_dark_no_selection );
    verify( toolItem ).setPadding( 1, 2, 3, 4 );
  }
}
