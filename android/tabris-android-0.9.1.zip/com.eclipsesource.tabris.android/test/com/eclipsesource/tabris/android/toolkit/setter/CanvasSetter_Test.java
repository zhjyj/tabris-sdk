/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CanvasSetter_Test {

  @Test
  public void testSetCustomVariantNull() {
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( new TabrisActivity() );
    Properties properties = new Properties();
    properties.add( "customVariant", null );
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas ).setClientDrawingEnabled( false );
  }

  @Test
  public void testSetCustomVariantDefault() {
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( new TabrisActivity() );
    Properties properties = new Properties();
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas, never() ).setClientDrawingEnabled( anyBoolean() );
  }

  @Test
  public void testSetCustomVariantClientCanvas() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( activity );
    Properties properties = new Properties();
    properties.add( "customVariant", ICustomVariants.CLIENT_CANVAS );
    Canvas canvas = mock( Canvas.class );

    setter.setCustomVariant( canvas, properties );

    verify( canvas ).setClientDrawingEnabled( true );
  }
  
  @Test
  public void testClientCanvasAddsListenerForDraw() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    CanvasSetter<Canvas> setter = new CanvasSetter<Canvas>( activity );
    Properties properties = new Properties();
    properties.add( "customVariant", ICustomVariants.CLIENT_CANVAS );
    Canvas canvas = mock( Canvas.class );
    RemoteObject remoteObject = activity.getRemoteObject( canvas );
    
    setter.setCustomVariant( canvas, properties );
    
    verify( remoteObject ).addListen( "Drawing" );
  }
}
