/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.parser.ParseException;

public class GsonProtocolParser_Test {

  IProtocolParserCallback nullCallback = new IProtocolParserCallback() {

    public void operationsFound( List<Operation> operations ) {
      Assert.fail( "operationsFound should not have been called" );
    }

    public void headFound( Head head ) {
      Assert.fail( "headFound should not have been called" );
    }
  };

  @Test(expected = IllegalArgumentException.class)
  public void testParseNull() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( null );
  }

  @Test(expected = ParseException.class)
  public void testParseEmpty() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseInvalidJson() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "foo".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseEmptyObject() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{}".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseNoHead() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{\"key\":\"value\"}".getBytes() ) );
  }

  @Test(expected = ParseException.class)
  public void testParseNoHeadWithEmptyOperations() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    parser.addProtocolParserCallback( nullCallback );

    parser.parse( new ByteArrayInputStream( "{ \"operations:\": []}".getBytes() ) );
  }

  @Test
  public void testParseWithValidHead() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Head head = new Head();
    head.add( "requestCounter", 123 );

    parser.parse( new ByteArrayInputStream( "{\"head\": {\"requestCounter\": 123}}".getBytes() ) );

    verify( callback ).headFound( head );
  }

  @Test
  public void testParseHeadWithEmptyOperations() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Head head = new Head();
    head.add( "requestCounter", 123 );

    parser.parse( new ByteArrayInputStream( "{ \"head\": {\"requestCounter\": 123}, \"operations\": []}".getBytes() ) );
    verify( callback ).headFound( head );
    verify( callback ).operationsFound( new ArrayList<Operation>() );
  }

  @Test
  public void testParseHeadAndCreateOperationWithoutProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Head head = new Head();
    head.add( "requestCounter", 123 );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( "w3" );
    createOp.setType( "Shell" );
    operations.add( createOp );

    parser.parse( new ByteArrayInputStream( "{ \"head\": {\"requestCounter\": 123}, \"operations\": [ [ \"create\", \"w3\", \"Shell\" ] ] }".getBytes() ) );
    verify( callback ).headFound( head );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  public void testParseHeadAndCreateOperationWithProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Head head = new Head();
    head.add( "requestCounter", 123 );
    Properties properties = new Properties();
    properties.add( "active", true );
    properties.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    properties.add( "tabIndex", 5 );
    properties.add( "bounds", Arrays.asList( 10, 20, 30, 40 ) );
    properties.add( "style", Arrays.asList( "CENTER", "TOGGLE" ) );
    properties.add( "activeControl", "someControl" );
    properties.add( "minimumSize", Arrays.asList( 200, 300 ) );
    properties.add( "mode", "modusOperandi" );
    properties.add( "text", "forHumans" );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    CreateOperation createOp = new CreateOperation();
    operations.add( createOp );
    createOp.setTarget( "w3" );
    createOp.setType( "Shell" );
    createOp.setProperties( properties );

    String content = "{ \"head\": {\"requestCounter\": 123}, "
                     + "\"operations\": [ "
                     + "[\"create\", "
                     + "\"w3\", "
                     + "\"Shell\", "
                     + "{"
                     + "\"active\": true, "
                     + "\"background\": [10, 20, 30, 40], "
                     + "\"tabIndex\": 5, "
                     + "\"bounds\": [10, 20, 30, 40], "
                     + "\"style\": [\"CENTER\", \"TOGGLE\"], "
                     + "\"activeControl\": \"someControl\", "
                     + "\"minimumSize\": [200, 300], "
                     + "\"mode\": \"modusOperandi\", "
                     + "\"text\": \"forHumans\" "
                     + "} "
                     + "] "
                     + "]}";
    parser.parse( new ByteArrayInputStream( content.getBytes() ) );
    verify( callback ).headFound( head );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testParseHeadAndMultipleOpsWithProps() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Head head = new Head();
    head.add( "requestCounter", -1 );

    parser.parse( new FileInputStream( new File( "../com.eclipsesource.tabris.android.test/test-data/prot.json" ) ) );

    verify( callback ).headFound( head );
    verify( callback, times( 1 ) ).operationsFound( any( ArrayList.class ) );
    verifyNoMoreInteractions( callback );
  }

  @Test
  @Ignore("Does not work because of the upgrade to gson-2.1. Primitive type values in List<Object> are converted differently")
  @SuppressWarnings("unchecked")
  public void testParseGarbageAndHeadAndMultipleOpsWithProps() throws Exception {
    // parsing a real life message from server
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );

    Head head = new Head();
    head.add( "requestCounter", 0 );

    CreateOperation create1 = new CreateOperation();
    create1.setTarget( "w2" );
    create1.setType( "org.eclipse.swt.widgets.Shell" );
    Properties createProps = new Properties();
    createProps.add( "style", Arrays.asList( "NO_TRIM" ) );
    createProps.add( "text", "Snippet" );
    createProps.add( "active", true );
    createProps.add( "mode", "maximized" );
    createProps.add( "minimumSize", Arrays.asList( 80, 2 ) );
    createProps.add( "activeControl", "w3" );
    createProps.add( "bounds", Arrays.asList( 0, 0, 320, 460 ) );
    createProps.add( "tabIndex", -1 );
    createProps.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    create1.setProperties( createProps );

    CreateOperation create2 = new CreateOperation();
    create2.setTarget( "w3" );
    create2.setType( "org.eclipse.swt.widgets.Composite" );
    Properties createProps2 = new Properties();
    createProps2.add( "parent", "w2" );
    createProps2.add( "style", Arrays.asList( "LEFT_TO_RIGHT" ) );
    createProps2.add( "bounds", Arrays.asList( 5, 5, 310, 450 ) );
    createProps2.add( "children", Arrays.asList( "w9", "w10", "w11" ) );
    createProps2.add( "tabIndex", -1 );
    createProps2.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    create2.setProperties( createProps2 );

    ListenOperation listen1 = new ListenOperation();
    listen1.setTarget( "w3" );
    Properties listenProps = new Properties();
    listenProps.add( "mouse", true );
    listen1.setProperties( listenProps );

    CreateOperation create3 = new CreateOperation();
    create3.setTarget( "w4" );
    create3.setType( "org.eclipse.swt.widgets.Label" );
    Properties createProps3 = new Properties();
    createProps3.add( "parent", "w3" );
    createProps3.add( "style", Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps3.add( "bounds", Arrays.asList( 5, 5, 121, 32 ) );
    createProps3.add( "children", Arrays.asList( "w9", "w10", "w11" ) );
    createProps3.add( "tabIndex", -1 );
    createProps3.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    createProps3.add( "foreground", Arrays.asList( 10, 20, 30, 40 ) );
    create3.setProperties( createProps3 );

    CreateOperation create4 = new CreateOperation();
    create4.setTarget( "w5" );
    create4.setType( "org.eclipse.swt.widgets.Button" );
    Properties createProps4 = new Properties();
    createProps4.add( "parent", "w3" );
    createProps4.add( "style", Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps4.add( "bounds", Arrays.asList( 5, 5, 121, 32 ) );
    createProps4.add( "children", Arrays.asList( "w9", "w10", "w11" ) );
    createProps4.add( "tabIndex", -1 );
    createProps4.add( "text", "Hello World!" );
    createProps4.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    createProps4.add( "foreground", Arrays.asList( 10, 20, 30, 40 ) );
    create4.setProperties( createProps4 );

    CreateOperation create5 = new CreateOperation();
    create5.setTarget( "w6" );
    create5.setType( "org.eclipse.swt.widgets.Label" );
    Properties createProps5 = new Properties();
    createProps5.add( "parent", "w3" );
    createProps5.add( "style", Arrays.asList( "LEFT", "LEFT_TO_RIGHT" ) );
    createProps5.add( "bounds", Arrays.asList( 5, 5, 121, 32 ) );
    createProps5.add( "children", Arrays.asList( "w9", "w10", "w11" ) );
    createProps5.add( "tabIndex", -1 );
    createProps5.add( "text", "Hello Label!" );
    createProps5.add( "background", Arrays.asList( 10, 20, 30, 40 ) );
    createProps5.add( "foreground", Arrays.asList( 10, 20, 30, 40 ) );
    create5.setProperties( createProps5 );

    ListenOperation listen2 = new ListenOperation();
    listen2.setTarget( "w4" );
    listenProps = new Properties();
    listenProps.add( "mouse", true );
    listen2.setProperties( listenProps );

    SetOperation set1 = new SetOperation();
    set1.setTarget( "w4" );
    Properties setProps = new Properties();
    setProps.add( "text", "Text alskj lakfj lkjf\nLine 2:bla" );
    set1.setProperties( setProps );

    CallOperation callOperation = new CallOperation();
    callOperation.setTarget( "w1" );
    callOperation.setMethod( "measureStrings" );
    Properties props = new Properties();
    props.add( "strings", Arrays.asList( Arrays.asList( 501642321,
                                                        "Search",
                                                        Arrays.asList( "Verdana" ),
                                                        12,
                                                        false,
                                                        false,
                                                        -1 ) ) );
    callOperation.setProperties( props );

    parser.parse( new FileInputStream( new File( "../com.eclipsesource.tabris.android.test/test-data/prot2.json" ) ) );

    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( create1 );
    operations.add( create2 );
    operations.add( listen1 );
    operations.add( create3 );
    operations.add( create4 );
    operations.add( create5 );
    operations.add( listen2 );
    operations.add( set1 );
    operations.add( callOperation );
    verify( callback ).headFound( head );
    verify( callback ).operationsFound( operations );
    verifyNoMoreInteractions( callback );
  }

  @Test
  public void testToJsonNull() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( null );

    assertEquals( "null", json );
  }

  @Test
  public void testToJsonString() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( "hello" );

    assertEquals( "\"hello\"", json );
  }

  @Test
  public void testToJsonNumber() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( 123 );

    assertEquals( "123", json );
  }

  @Test
  public void testToJsonBoolean() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( Boolean.TRUE );

    assertEquals( "true", json );
  }

  @Test
  public void testToJsonArray() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( new Object[]{
      "abc", 123
    } );

    assertEquals( "[\"abc\",123]", json );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testToJsonList() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();

    String json = parser.toJson( Arrays.asList( "abc", 123 ) );

    assertEquals( "[\"abc\",123]", json );
  }

  @Test
  public void testToJsonMap() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    HashMap<String, Object> map = new LinkedHashMap<String, Object>();
    map.put( "one", "abc" );
    map.put( "two", 123 );

    String json = parser.toJson( map );

    assertEquals( "{\"one\":\"abc\",\"two\":123}", json );
  }

  @Test
  public void testCreateMessage() throws IOException {
    GsonProtocolParser parser = new GsonProtocolParser();
    List<Operation> operations = createOperations();
    Map<String, Object> headers = createHeaders();

    String message = parser.createMessage( operations, headers );

    parser.addProtocolParserCallback( createAssertCallback() );
    parser.parse( new ByteArrayInputStream( message.getBytes( "utf-8" ) ) );
  }

  private Map<String, Object> createHeaders() {
    Map<String, Object> headers = new HashMap<String, Object>();
    headers.put( "requestCounter", 23 );
    return headers;
  }

  private List<Operation> createOperations() {
    Properties properties = new Properties();
    properties.add( "foo1", "bar1" );
    properties.add( "foo2", "bar2" );
    SetOperation setOperation = new SetOperation();
    setOperation.setTarget( "foo" );
    setOperation.setProperties( properties );
    CallOperation callOperation = new CallOperation();
    callOperation.setTarget( "foo" );
    callOperation.setMethod( "bar" );
    callOperation.setProperties( properties );
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( setOperation );
    operations.add( callOperation );
    return operations;
  }

  private IProtocolParserCallback createAssertCallback() {
    IProtocolParserCallback assertCallback = new IProtocolParserCallback() {

      public void operationsFound( List<Operation> ops ) {
        assertEquals( 2, ops.size() );
        SetOperation setOperation = ( SetOperation )ops.get( 0 );
        assertEquals( "foo", setOperation.getTarget() );
        assertEquals( "bar1", setOperation.getProperties().getString( "foo1" ) );
        assertEquals( "bar2", setOperation.getProperties().getString( "foo2" ) );
        CallOperation callOperation = ( CallOperation )ops.get( 1 );
        assertEquals( "foo", callOperation.getTarget() );
        assertEquals( "bar", callOperation.getMethod() );
        assertEquals( "bar1", callOperation.getProperties().getString( "foo1" ) );
        assertEquals( "bar2", callOperation.getProperties().getString( "foo2" ) );
      }

      public void headFound( Head head ) {
        assertEquals( Integer.valueOf( 23 ), head.getInteger( "requestCounter" ) );
      }
    };
    return assertCallback;
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testShouldDeserializeFontObject() throws Exception {
    GsonProtocolParser parser = new GsonProtocolParser();
    IProtocolParserCallback callback = mock( IProtocolParserCallback.class );
    parser.addProtocolParserCallback( callback );
    Font font = new Font();
    font.setFamily( Arrays.asList( "" ) );
    font.setSize( 24 );
    font.setBold( true );
    font.setItalic( true );

    parser.parse( new ByteArrayInputStream( "{ \"head\": {\"requestCounter\": 123}, \"operations\": [ [ \"set\", \"w3\", { \"font\": [ [ \"\" ], 24, true, true ] } ] ] }".getBytes() ) );

    ArgumentCaptor<List> captor = ArgumentCaptor.forClass( List.class );
    verify( callback ).operationsFound( captor.capture() );
    List<Operation> operations = captor.getValue();
    SetOperation set = ( SetOperation )operations.get( 0 );
    assertEquals( font, set.getProperties().getFont( "font" ) );
  }
}
