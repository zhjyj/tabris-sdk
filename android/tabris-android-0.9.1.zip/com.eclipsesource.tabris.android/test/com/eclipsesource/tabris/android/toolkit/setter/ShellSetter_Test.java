/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertNotSame;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapFactory;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ShellSetter_Test {

  private static final String MODE_VALUE = "modeValue";
  private TabrisActivity activity;
  private Shell shell;

  @Before
  public void setUp() {
    activity = mock( TabrisActivity.class );
    shell = mock( Shell.class );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    setter.execute( mock( Shell.class ), null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    setter.execute( null, mock( Properties.class ) );
  }

  @Test
  public void testSetModeToValue() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "mode", MODE_VALUE );

    setter.execute( shell, props );

    verify( shell ).setMode( MODE_VALUE );
  }

  @Test
  public void testShouldApplyModeBeforeVisibility() throws Exception {
    Properties properties = new Properties();
    properties.add( "visibility", true );
    properties.add( "mode", MODE_VALUE );
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Shell shell = mock( Shell.class );

    setter.execute( shell, properties );

    InOrder inOrder = inOrder( shell );
    inOrder.verify( shell ).setMode( MODE_VALUE );
    inOrder.verify( shell ).playShowAnimation( activity );
  }

  @Test
  public void testSetModeToNull() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "mode", null );

    setter.execute( shell, props );

    verify( shell ).setMode( null );
  }

  @Test
  public void testSetModeNotSet() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    Properties props = new Properties();

    setter.execute( shell, props );

    verify( shell, never() ).setMode( any( String.class ) );
  }

  @Test
  public void testAnimatedIfSetVisible() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Properties props = new Properties();
    props.add( "visibility", true );

    setter.execute( shell, props );

    verify( shell ).playShowAnimation( eq( activity ) );
  }

  @Test
  public void testAnimatedIfSetInvisible() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Properties props = new Properties();
    props.add( "visibility", false );

    setter.execute( shell, props );

    verify( shell ).playHideAnimation( eq( activity ) );
  }

  @Test
  public void testSetText() {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "text", "foo" );

    setter.execute( shell, props );

    verify( shell ).setText( eq( "foo" ) );
  }

  @Test
  public void testSetNullText() throws Exception {
    ShellSetter<Shell> setter = new ShellSetter<Shell>( new TabrisActivity() );
    Properties props = new Properties();
    props.add( "text", null );

    setter.execute( shell, props );

    verifyNoMoreInteractions( shell );
  }

  @Test
  public void testSetIcon() {
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    Properties props = new Properties();
    props.add( "image", Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    when( cache.get( props.getList( "image", String.class ).get( 0 ) ) ).thenReturn( mock( BitmapDrawable.class ) );
    ShellSetter<Shell> setter = new ShellSetter<Shell>( activity );
    Shell shell = new Shell( activity, mock( ShellAnimationSupport.class ) );
    DialogHeader dialogHeader = new DialogHeader( activity );
    BitmapDrawable drawable = mock( BitmapDrawable.class );
    dialogHeader.setIcon( drawable );
    shell.setHeader( dialogHeader );

    setter.execute( shell, props );

    assertNotSame( drawable, shell.getHeader().getIcon().getDrawable() );
    verify( cache ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }

}
