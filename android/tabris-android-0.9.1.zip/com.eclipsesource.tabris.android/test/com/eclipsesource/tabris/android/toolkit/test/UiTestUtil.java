/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.test;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import android.content.Intent;
import android.view.View;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.OperatorRegistry;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.view.FocusTrackingListener;

public class UiTestUtil {

  public static TabrisActivity createActivity() {
    TabrisActivity activity = createActivityWithoutOnCreate();
    activity.onCreate( null );
    return activity;
  }

  public static TabrisActivity createMockedActivity() {
    ProtocolProcessor processor = mockActivityObjects();
    TabrisActivity activity = mock( TabrisActivity.class );
    when( activity.getProcessor() ).thenReturn( processor );
    return activity;
  }

  public static TabrisActivity createActivityWithMockedFields() {
    ProtocolProcessor processor = mockActivityObjects();
    TabrisActivity activity = new TabrisActivity();
    activity.setProcessor( processor );
    return activity;
  }

  private static ProtocolProcessor mockActivityObjects() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    when( toolkit.getListenerRegistry() ).thenReturn( mock( ListenerRegistry.class ) );
    ObjectRegistry objectRegistry = mock( ObjectRegistry.class );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( remoteObject.getId() ).thenReturn( "foo" );
    when( objectRegistry.getRemoteObjectForObject( anyObject() ) ).thenReturn( remoteObject );
    when( objectRegistry.getRemoteObject( DisplayOperator.DISPLAY_ID ) ).thenReturn( mock( RemoteObject.class ) );
    when( toolkit.getObjectRegistry() ).thenReturn( objectRegistry );
    when( toolkit.getOperatorRegistry() ).thenReturn( mock( OperatorRegistry.class ) );
    when( toolkit.getFocusTrackingListener() ).thenReturn( mock( FocusTrackingListener.class ) );
    when( toolkit.getRequestCodePool() ).thenReturn( mock( RequestCodePool.class ) );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( processor.getParser() ).thenReturn( mock( IProtocolParser.class ) );
    return processor;
  }

  public static TabrisActivity createActivityWithMockedFieldsWithObjectId( String id ) {
    TabrisActivity activity = createActivityWithMockedFields();
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( remoteObject.getId() ).thenReturn( id );
    when( objectRegistry.getRemoteObjectForObject( anyObject() ) ).thenReturn( remoteObject );
    return activity;
  }

  public static TabrisActivity createActivityWithoutOnCreate() {
    TabrisActivity activity = createActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( TabrisActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    return activity;
  }

  public static void mockToolkitMultiply( TabrisActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivide( TabrisActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.divideByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivideIdentity( TabrisActivity activity, int... numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( int i : numbers ) {
      when( toolkit.divideByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static void mockToolkitMultiplyIdentity( TabrisActivity activity, int... numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( int i : numbers ) {
      when( toolkit.multiplyByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static void mockToolkitMultiplyIdentity( TabrisActivity activity, List<Integer> numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( Integer i : numbers ) {
      when( toolkit.multiplyByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static <T> T findObjectById( TabrisActivity activity, String id, Class<? extends T> clazz )
  {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry().getObject( id, clazz );
  }

  public static View findViewById( TabrisActivity activity, String id ) {
    return findObjectById( activity, id, View.class );
  }

  public static void waitForRequest() throws InterruptedException {
    Thread.sleep( 100 );
  }
}
