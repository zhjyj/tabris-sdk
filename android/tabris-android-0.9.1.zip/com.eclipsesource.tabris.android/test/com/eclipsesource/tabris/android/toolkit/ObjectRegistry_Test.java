/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ObjectRegistry_Test {

  private ObjectRegistry objectRegistry;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    processor = mock( ProtocolProcessor.class );
    objectRegistry = new ObjectRegistry( processor );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldHaveProcessor() {
    new ObjectRegistry( null );
  }

  @Test
  public void testRegisterObject_OK() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );

    assertSame( object, objectRegistry.getObject( "obj_id" ) );
    assertEquals( "rwt.Object", objectRegistry.getObjectType( "obj_id" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testShouldNotReturnRemoteObject() throws Exception {
    objectRegistry.getRemoteObject( "foo" );
  }

  @Test
  public void testShouldReturnRemoteObject() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );

    RemoteObject result = objectRegistry.getRemoteObject( "obj_id" );

    assertNotNull( result );
  }
  
  @Test
  public void testShouldReturnRemoteObjectForObject() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );
    
    RemoteObject result = objectRegistry.getRemoteObjectForObject( object );
    
    assertNotNull( result );
  }
  
  @Test( expected = IllegalStateException.class )
  public void testShouldNotReturnRemoteObjectForNonExistingObject() throws Exception {
    objectRegistry.getRemoteObjectForObject( new Object() );
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testShouldNotReturnRemoteObjectForNullObject() throws Exception {
    objectRegistry.getRemoteObjectForObject( null );
  }
  
  @Test
  public void testShouldReturnRemoteObjectForObjectIsAlwaysSame() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );
    
    RemoteObject result1 = objectRegistry.getRemoteObjectForObject( object );
    RemoteObject result2 = objectRegistry.getRemoteObjectForObject( object );
    
    assertSame( result1, result2 );
  }

  @Test
  public void testShouldAlwaysSameReturnRemoteObject() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );

    RemoteObject result1 = objectRegistry.getRemoteObject( "obj_id" );
    RemoteObject result2 = objectRegistry.getRemoteObject( "obj_id" );

    assertSame( result1, result2 );
  }

  @Test
  public void testShouldInitializeWithProcessor() throws Exception {
    Object object = new Object();
    objectRegistry.register( "obj_id", object, "rwt.Object" );

    ProtocolProcessor result = objectRegistry.getRemoteObject( "obj_id" ).getProcessor();

    assertEquals( processor, result );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldNotAcceptNullObjectId() throws Exception {
    objectRegistry.getRemoteObject( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldNotAcceptEmptyObjectIdString() throws Exception {
    objectRegistry.getRemoteObject( "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegisterObject_NullId() throws Exception {
    objectRegistry.register( null, new Object(), "rwt.Object" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegisterObject_NullObject() throws Exception {
    objectRegistry.register( "obj_id", null, "rwt.Object" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testRegisterObject_NullType() throws Exception {
    objectRegistry.register( "obj_id", new Object(), null );
  }

  @Test
  public void testUnegisterObject_OK() throws Exception {
    objectRegistry.register( "obj_id", new Object(), "rwt.Object" );

    objectRegistry.unregister( "obj_id" );

    assertNull( objectRegistry.getObject( "obj_id" ) );
    assertNull( objectRegistry.getObjectType( "obj_id" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUnegisterObject_NullId() throws Exception {
    objectRegistry.unregister( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetObject_NullId() throws Exception {
    objectRegistry.getObject( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetObjectWithType_NullId() throws Exception {
    objectRegistry.getObject( null, String.class );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetObjectType_NullId() throws Exception {
    objectRegistry.getObjectType( null );
  }

  @Test
  public void testGetObjectWithType_OK() throws Exception {
    String object = "foo";
    objectRegistry.register( "obj_id", object, "rwt.String" );

    assertSame( object, objectRegistry.getObject( "obj_id", String.class ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetObjectWithType_WrongType() throws Exception {
    objectRegistry.register( "obj_id", "foo", "rwt.String" );

    objectRegistry.getObject( "obj_id", Integer.class );
  }

  @Test
  public void testGetObject_MissingObject() throws Exception {
    assertNull( objectRegistry.getObject( "obj_id" ) );
  }

  @Test
  public void testGetObjectWithType_MissingObject() throws Exception {
    assertNull( objectRegistry.getObject( "obj_id", String.class ) );
  }
  
  @Test
  public void testUnregistersChildren() {
    Parent parent = mock( Parent.class );
    List<Object> children = new ArrayList<Object>();
    Object child1 = mock( Object.class );
    Object child2 = mock( Object.class );
    children.add( child1 );
    children.add( child2 );
    when( parent.getChildren() ).thenReturn( children );
    objectRegistry.register( "foo", parent, "type" );
    objectRegistry.register( "child1", child1, "type" );
    objectRegistry.register( "child2", child2, "type" );
    
    objectRegistry.unregister( "foo" );
    
    assertNull( objectRegistry.getObject( "foo" ) );
    assertNull( objectRegistry.getObject( "child1" ) );
    assertNull( objectRegistry.getObject( "child2" ) );
  }

}
