/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProtocolProcessor_Test {

  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    processor = new ProtocolProcessor();
  }

  @Test
  public void testCreateProcolProcessor() {
    processor = new ProtocolProcessor();
    assertNotNull( processor );
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionParserNull() throws Exception {
    ITransport transport = mock( ITransport.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setTransport( transport );
    processor.setWidgetToolkit( toolkit );

    processor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionTransportNull() throws Exception {
    IProtocolParser transport = mock( IProtocolParser.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setParser( transport );
    processor.setWidgetToolkit( toolkit );

    processor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionToolkitNull() throws Exception {
    IProtocolParser parser = mock( IProtocolParser.class );
    ITransport transport = mock( ITransport.class );
    processor.setParser( parser );
    processor.setTransport( transport );

    processor.startSession();
  }

  @Test
  public void testSendInitialGetRequest() throws Exception {
    ExecutorService executerService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executerService );
    processor.setTransport( mock( ITransport.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setWidgetToolkit( toolkit );
    processor.setParser( mock( IProtocolParser.class ) );

    processor.startSession();

    verify( executerService ).execute( any( InitialGetRequestRunnable.class ) );
  }

  @Test
  public void testProcessGetRequestOk() throws Exception {
    ITransport transport = mock( ITransport.class );
    processor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( false );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( eq( request ) ) ).thenReturn( result );

    ITransportResult transportResult = processor.processGetRequest( request );

    verify( transport ).get( request );
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessGetRequestFail() throws Exception {
    ITransport transport = mock( ITransport.class );
    processor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    when( result.hasException() ).thenReturn( true );
    when( result.getException() ).thenReturn( any( Exception.class ) );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( request ) ).thenReturn( result );

    ITransportResult transportResult = processor.processGetRequest( request );

    verify( transport ).get( request );
    verify( transportResult ).getException();
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessPostRequest() throws Exception {
    ExecutorService executorService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executorService );
    Head head = new Head();
    head.add( "requestCounter", 123 );
    processor.headFound( head );

    processor.processPostRequest();

    verify( executorService ).execute( any( PostRequestRunnable.class ) );
  }

  @Test
  public void testSetGetTransport() {
    ITransport transport = mock( ITransport.class );

    processor.setTransport( transport );

    assertSame( processor.getTransport(), transport );
  }

  @Test
  public void testSetGetParser() {
    IProtocolParser parser = mock( IProtocolParser.class );

    processor.setParser( parser );

    assertSame( processor.getParser(), parser );
  }

  @Test
  public void testSetGetToolkit() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );

    processor.setWidgetToolkit( toolkit );

    assertSame( processor.getWidgetToolkit(), toolkit );
  }

  @Test
  public void testGetSessionTime() throws Exception {
    ITransport transport = mock( ITransport.class );
    ITransportResult getResult = mock( ITransportResult.class );
    when( getResult.getResult() ).thenReturn( new ByteArrayInputStream( "".getBytes() ) );
    when( transport.get( any( GetRequest.class ) ) ).thenReturn( getResult );
    ITransportResult transportResult = mock( ITransportResult.class );
    when( transportResult.hasException() ).thenReturn( false );
    when( transport.post( any( PostRequest.class ) ) ).thenReturn( transportResult );
    processor.setTransport( transport );
    processor.setParser( mock( IProtocolParser.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    processor.setWidgetToolkit( toolkit );

    assertEquals( 0, processor.getSessionTime() );
    processor.startSession();
    Thread.sleep( 1 );

    assertTrue( processor.getSessionTime() > 0 );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundNull() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( null );

    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundError() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundOk() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );

    processor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).process( any( ArrayList.class ) );
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testHeadFoundShouldSetRequestCounterOnRequestCounterObject() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    RequestCounter requestCounter = mock( RequestCounter.class );
    processor.setRequestCounter( requestCounter );
    Head head = mock( Head.class );
    when( head.hasHeader( Head.PROP_REQUEST_COUNTER ) ).thenReturn( true );
    when( head.getInteger( Head.PROP_REQUEST_COUNTER ) ).thenReturn( Integer.valueOf( 123 ) );

    processor.headFound( head );

    verify( requestCounter ).set( Integer.valueOf( 123 ) );
  }

  @Test
  public void testHeadSessionTimeoutFoundOk() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    Head head = mock( Head.class );
    when( head.hasHeader( Head.PROP_ERROR ) ).thenReturn( true );
    when( head.getString( Head.PROP_ERROR ) ).thenReturn( Head.ERROR_SESSION_TIMEOUT );

    processor.headFound( head );

    verify( toolkit ).showError( eq( new LocalizableException( LocalizableException.SESSION_TIMEOUT ) ),
                                 any( TransportRequest.class ) );
  }

  @Test
  public void testShutdown() throws Exception {
    ITransport transport = mock( ITransport.class );
    processor.setTransport( transport );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    ExecutorService threadPool = mock( ExecutorService.class );
    processor.setRequestThreadPool( threadPool );
    Timer sendTimer = mock( Timer.class );
    processor.setSendTimer( sendTimer );

    processor.shutdown();

    verify( toolkit ).dispose();
    verify( threadPool ).shutdownNow();
    InOrder order = inOrder( sendTimer );
    order.verify( sendTimer ).cancel();
    order.verify( sendTimer ).purge();
  }

  @Test
  public void testMultipleOperationsSendOneRequest() throws Exception {
    ExecutorService executorService = mock( ExecutorService.class );
    processor.setRequestThreadPool( executorService );
    processor.setParser( mock( IProtocolParser.class ) );
    RemoteObject remoteObject = new RemoteObject( "w3", processor );

    remoteObject.notify( "Selection", null );
    remoteObject.call( "close", null );
    UiTestUtil.waitForRequest();

    verify( executorService ).execute( any( Runnable.class ) );
  }

  @Test
  public void testOptimizeSetOperations_WithoutOptimizations() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = processor.optimizeSetOperations( operations );

    assertEquals( operations, optimizedOpertations );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Start() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = processor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 0 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Middle() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = processor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 1 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_End() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );

    List<Operation> optimizedOpertations = processor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 3 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  private SetOperation createSetOperation( String target, String propertyName, String propertyValue )
  {
    SetOperation result = new SetOperation();
    result.setTarget( target );
    Properties properties = new Properties();
    properties.add( propertyName, propertyValue );
    result.setProperties( properties );
    return result;
  }

  private NotifyOperation createNotifyOperation( String target, String eventType ) {
    NotifyOperation result = new NotifyOperation();
    result.setTarget( target );
    result.setEventType( eventType );
    return result;
  }

  @Test
  public void testShouldNotSendRequestAfterShutdown() throws Exception {
    ITransport transport = mock( ITransport.class );
    processor.setTransport( transport );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    ExecutorService threadPool = mock( ExecutorService.class );
    processor.setRequestThreadPool( threadPool );
    processor.setWidgetToolkit( toolkit );
    processor.setParser( mock( IProtocolParser.class ) );
    Timer sendTimer = spy( new Timer() );
    processor.setSendTimer( sendTimer );

    processor.send();
    UiTestUtil.waitForRequest();
    processor.shutdown();
    processor.send();
    UiTestUtil.waitForRequest();

    verify( sendTimer, times( 1 ) ).schedule( any( TimerTask.class ), anyInt() );
  }

  @Test
  public void testGetNextRequestShouldCreatePostRequestFromCurrentProcessorState() {
    IProtocolParser parser = mock( IProtocolParser.class );
    SetOperation operation = new SetOperation();
    Properties properties = new Properties();
    properties.add( "key", "value" );
    operation.setProperties( properties );
    processor.appendOperation( operation );
    RequestCounter requestCounter = new RequestCounter();
    requestCounter.set( Integer.valueOf( 123 ) );
    processor.setRequestCounter( requestCounter );
    HashMap<String, Object> headers = new HashMap<String, Object>();
    headers.put( "requestCounter", 123 );
    when( parser.createMessage( Arrays.asList( ( Operation )operation ), headers ) ).thenReturn( "jsonMessage" );
    processor.setParser( parser );

    PostRequest request = processor.getNextRequest();

    assertEquals( "jsonMessage", request.getContent() );
  }
}
