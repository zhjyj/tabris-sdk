/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.R;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SpinnerSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( new TabrisActivity() );

    setter.execute( null, mock( Properties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( new TabrisActivity() );

    setter.execute( mock( Spinner.class ), null );
  }

  @Test
  public void testSetItemsNull() {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>( activity,
                                                                    R.layout.simple_spinner_dropdown_item );
    spinner.setAdapter( spinnerAdapter );

    setter.execute( spinner, new Properties() );

    assertEquals( 0, spinnerAdapter.getCount() );
  }

  @Test
  public void testSetItems() {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    spinner.setAdapter( adapter );
    Properties props = new Properties();
    props.add( "items", Arrays.asList( "1", "2", "3" ) );

    setter.execute( spinner, props );

    assertEquals( 3, adapter.getCount() );
    assertEquals( "1", adapter.getItem( 0 ) );
    assertEquals( "2", adapter.getItem( 1 ) );
    assertEquals( "3", adapter.getItem( 2 ) );
  }

  @Test
  public void testSetItemsAndOverride() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    adapter.add( "1" );
    adapter.add( "2" );
    adapter.add( "3" );
    spinner.setAdapter( adapter );
    Properties props = new Properties();
    props.add( "items", Arrays.asList( "a", "b", "c", "d" ) );

    setter.execute( spinner, props );

    assertEquals( 4, adapter.getCount() );
    assertEquals( "a", adapter.getItem( 0 ) );
    assertEquals( "b", adapter.getItem( 1 ) );
    assertEquals( "c", adapter.getItem( 2 ) );
    assertEquals( "d", adapter.getItem( 3 ) );
  }

  @Test
  public void testSetSelectionIndexNull() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    spinner.setAdapter( new ArrayAdapter<String>( activity, R.layout.simple_spinner_dropdown_item ) );
    Properties props = new Properties();

    setter.execute( spinner, props );

    assertEquals( 0, spinner.getSelectedItemPosition() );
  }

  /**
   * Android does not support an empty selection on a Spinner so we can not set
   * "-1" as an "empty" selection. We explicitly set the selection to the first
   * element.
   */
  @Test
  public void testSetSelectionRemoveSelectedItem() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    adapter.add( "1" );
    adapter.add( "2" );
    adapter.add( "3" );
    spinner.setAdapter( adapter );
    spinner.setSelection( 3 );
    Properties props = new Properties();
    props.add( "items", Arrays.asList( "1", "2" ) );
    props.add( "selectionIndex", -1 );

    setter.execute( spinner, props );

    assertEquals( 0, spinner.getSelectedItemPosition() );
  }

  @Test
  public void testSetSelectionIndex() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>( activity );
    Spinner spinner = new Spinner( activity );
    spinner.setAdapter( new ArrayAdapter<String>( activity,
                                                  R.layout.simple_spinner_dropdown_item,
                                                  Arrays.asList( "1", "2", "3" ) ) );
    Properties props = new Properties();
    props.add( "selectionIndex", 1 );

    setter.execute( spinner, props );

    assertEquals( 1, spinner.getSelectedItemPosition() );
  }
}
