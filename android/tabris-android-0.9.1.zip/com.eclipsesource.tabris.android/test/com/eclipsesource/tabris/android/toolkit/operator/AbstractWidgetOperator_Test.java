/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowFrameLayout;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowView;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DefaultSelectionListener;
import com.eclipsesource.tabris.android.toolkit.view.FocusTrackingListener;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.eclipsesource.tabris.android.toolkit.view.LongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;
import com.xtremelabs.robolectric.shadows.ShadowTextView;

@RunWith(RobolectricTestRunner.class)
public class AbstractWidgetOperator_Test {

  private static final String WIDGET_ID = "w3";
  private static final String PARENT_ID = "w2";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private BitmapDrawableCache drawableCache;
  private ListenerRegistry listenerRegistry;
  private ObjectRegistry objectRegistry;
  private FrameLayout parentLayout;

  class OperatorUnderTest extends AbstractWidgetOperator {

    public OperatorUnderTest( TabrisActivity activity ) {
      super( activity );
    }

    public String getType() {
      return null;
    }

    public void create( CreateOperation operation ) {
    }

    @Override
    protected IViewSetter<View> getViewSetter( View view ) {
      return new ViewSetter<View>( activity );
    }

  }

  @Before
  public void setup() {
    activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    toolkit = mock( IWidgetToolkit.class );
    drawableCache = mock( BitmapDrawableCache.class );
    when( toolkit.getBitmapCache() ).thenReturn( drawableCache );
    listenerRegistry = spy( new ListenerRegistry() );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    objectRegistry = mock( ObjectRegistry.class );
    when( toolkit.getObjectRegistry() ).thenReturn( objectRegistry );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentLayout = spy( new FrameLayout( activity ) );
    parentLayout.setTag( new RemoteObject( PARENT_ID, processor ) );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getObjectRegistry().getRemoteObjectForObject( anyObject() ) ).thenReturn( new RemoteObject( WIDGET_ID,
                                                                                                              processor ) );
    when( toolkit.getFocusTrackingListener() ).thenReturn( mock( FocusTrackingListener.class ) );
    rootLayout.addView( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenNullOp() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );

    operator.listen( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenNoProperties() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = new ListenOperation();

    operator.listen( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testListenNoTarget() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = new ListenOperation();
    op.setProperties( new Properties() );

    operator.listen( op );
  }

  @Test
  public void testListenAddFocusListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createFocusListenOperation( WIDGET_ID, true );

    TabrisShadowView shadowView = ( TabrisShadowView )Robolectric.shadowOf( view );
    assertNull( shadowView.getOnFocusChangeListener() );

    operator.listen( op );

    OnFocusChangeListener focusListener = shadowView.getOnFocusChangeListener();
    assertNotNull( focusListener );
  }

  @Test
  public void testAlwaysAttachesFocusListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    view.setOnFocusChangeListener( mock( OnFocusChangeListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    op.setProperties( new Properties() );
    TabrisShadowView shadowView = ( TabrisShadowView )Robolectric.shadowOf( view );

    operator.listen( op );

    assertNotNull( shadowView.getOnFocusChangeListener() );
  }

  private View createView( String targetId ) {
    View view = new View( activity );
    when( toolkit.getObjectRegistry().getObject( targetId, View.class ) ).thenReturn( view );
    return view;
  }

  private ListenOperation createFocusListenOperation( String targetId, boolean focus ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "focus", focus );
    op.setProperties( properties );
    return op;
  }

  @Test
  public void testListenUpdatesRemoteObject() throws Exception {
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( toolkit.getObjectRegistry().getRemoteObject( anyString() ) ).thenReturn( remoteObject );
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createSelectionListenOperation( WIDGET_ID, true );

    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    assertNull( shadowButton.getOnClickListener() );

    operator.listen( op );

    verify( remoteObject ).addListen( eq( "Selection" ) );
  }

  @Test
  public void testListenRemoveUpdatesRemoteObject() throws Exception {
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( toolkit.getObjectRegistry().getRemoteObject( anyString() ) ).thenReturn( remoteObject );
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    button.setOnClickListener( mock( OnClickListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createSelectionListenOperation( WIDGET_ID, false );

    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    assertNotNull( shadowButton.getOnClickListener() );

    operator.listen( op );

    verify( remoteObject ).removeListen( eq( "Selection" ) );
  }

  @Test
  public void testListenAddSelectionListener() throws Exception {
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createSelectionListenOperation( WIDGET_ID, true );

    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    assertNull( shadowButton.getOnClickListener() );

    operator.listen( op );

    OnClickListener onClickListener = shadowButton.getOnClickListener();
    assertNotNull( onClickListener );
  }

  @Test
  public void testListenRemoveSelectionListener() throws Exception {
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    button.setOnClickListener( mock( OnClickListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createSelectionListenOperation( WIDGET_ID, false );

    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    assertNotNull( shadowButton.getOnClickListener() );

    operator.listen( op );

    OnClickListener onClickListener = shadowButton.getOnClickListener();
    assertNull( onClickListener );
  }

  private ListenOperation createSelectionListenOperation( String targetId, boolean selection ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "Selection", selection );
    op.setProperties( properties );
    return op;
  }

  @Test
  public void testListenAddDefaultSelectionListener() throws Exception {
    createButtonInRootLayout( WIDGET_ID, activity );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createDefaultSelectionListenOperation( WIDGET_ID, true );

    operator.listen( op );

    verify( listenerRegistry ).registerListener( eq( WIDGET_ID ),
                                                 any( DefaultSelectionListener.class ) );
  }

  @Test
  public void testListenremovesDefaultSelectionListener() throws Exception {
    createButtonInRootLayout( WIDGET_ID, activity );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createDefaultSelectionListenOperation( WIDGET_ID, true );
    operator.listen( op );
    ListenOperation operation = createDefaultSelectionListenOperation( WIDGET_ID, false );

    operator.listen( operation );

    verify( listenerRegistry ).unregisterListener( WIDGET_ID, DefaultSelectionListener.class );
  }

  private ListenOperation createDefaultSelectionListenOperation( String targetId, boolean selection )
  {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "DefaultSelection", selection );
    op.setProperties( properties );
    return op;
  }

  @Test
  public void testListenAddMouseDownListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    CompositeTouchListener compTouchListener = new CompositeTouchListener();
    listenerRegistry.registerListener( WIDGET_ID, compTouchListener );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMouseDownListenOperation( WIDGET_ID, true );
    TabrisShadowView shadowButton = ( TabrisShadowView )Robolectric.shadowOf( view );

    operator.listen( op );

    assertNotNull( compTouchListener.findListener( MouseEventTouchListener.class ) );
    OnLongClickListener onLongClickListener = shadowButton.getOnLongClickListener();
    assertNotNull( onLongClickListener );
  }

  @Test
  public void testListenAddMouseUpListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    CompositeTouchListener compTouchListener = new CompositeTouchListener();
    listenerRegistry.registerListener( WIDGET_ID, compTouchListener );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMouseUpListenOperation( WIDGET_ID, true );
    TabrisShadowView shadowButton = ( TabrisShadowView )Robolectric.shadowOf( view );

    operator.listen( op );

    assertNotNull( compTouchListener.findListener( MouseEventTouchListener.class ) );
    OnLongClickListener onLongClickListener = shadowButton.getOnLongClickListener();
    assertNotNull( onLongClickListener );
  }

  @Test
  public void testListenAddMouseUpAndDownListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    CompositeTouchListener compTouchListener = new CompositeTouchListener();
    listenerRegistry.registerListener( WIDGET_ID, compTouchListener );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( WIDGET_ID );
    Properties properties = new Properties();
    properties.add( "MouseUp", true );
    properties.add( "MouseDown", true );
    op.setProperties( properties );
    TabrisShadowView shadowButton = ( TabrisShadowView )Robolectric.shadowOf( view );

    operator.listen( op );

    assertNotNull( compTouchListener.findListener( MouseEventTouchListener.class ) );
    OnLongClickListener onLongClickListener = shadowButton.getOnLongClickListener();
    assertNotNull( onLongClickListener );
  }

  @Test
  public void testListenRemoveMouseListener() throws Exception {
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    button.setOnTouchListener( mock( OnTouchListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMouseDownListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = mock( ListenerRegistry.class );
    LongClickListener longClickListener = mock( LongClickListener.class );
    when( registry.findListener( WIDGET_ID, LongClickListener.class ) ).thenReturn( longClickListener );
    CompositeTouchListener compTouchListener = mock( CompositeTouchListener.class );
    when( registry.findListener( WIDGET_ID, CompositeTouchListener.class ) ).thenReturn( compTouchListener );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    ShadowTextView shadowButton = Robolectric.shadowOf( button );
    assertNotNull( shadowButton.getOnTouchListener() );

    operator.listen( op );

    assertNotNull( shadowButton.getOnTouchListener() );
    verify( compTouchListener ).removeListeners( MouseEventTouchListener.class );
    verify( registry ).unregisterListener( WIDGET_ID, LongClickListener.class );
  }

  @Test
  public void testListenRemoveMouseListenerFromGroup() throws Exception {
    Group group = createGroupInRootLayout( WIDGET_ID, activity );
    group.setOnTouchListener( mock( OnTouchListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMouseDownListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = mock( ListenerRegistry.class );
    LongClickListener longClickListener = mock( LongClickListener.class );
    when( registry.findListener( WIDGET_ID, LongClickListener.class ) ).thenReturn( longClickListener );
    CompositeTouchListener compTouchListener = mock( CompositeTouchListener.class );
    when( registry.findListener( WIDGET_ID, CompositeTouchListener.class ) ).thenReturn( compTouchListener );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    ShadowFrameLayout shadowGroup = Robolectric.shadowOf( group );
    assertNotNull( shadowGroup.getOnTouchListener() );

    operator.listen( op );

    assertNotNull( shadowGroup.getOnTouchListener() );
    verify( compTouchListener ).removeListeners( MouseEventTouchListener.class );
    verify( registry ).unregisterListener( WIDGET_ID, LongClickListener.class );
  }

  @Test
  public void testListenRemoveMouseListenerWithSurvival() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    MouseEventTouchListener touchListener = new MouseEventTouchListener( activity, true );
    CompositeTouchListener compListener = new CompositeTouchListener();
    compListener.addListener( touchListener );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMouseDownListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = mock( ListenerRegistry.class );
    when( registry.findListener( WIDGET_ID, CompositeTouchListener.class ) ).thenReturn( compListener );
    LongClickListener longClickListener = mock( LongClickListener.class );
    view.setOnLongClickListener( longClickListener );
    when( longClickListener.isTransmittingMenuDetect() ).thenReturn( true );
    when( registry.findListener( WIDGET_ID, MouseEventTouchListener.class ) ).thenReturn( touchListener );
    when( registry.findListener( WIDGET_ID, LongClickListener.class ) ).thenReturn( longClickListener );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    TabrisShadowView shadowView = ( TabrisShadowView )Robolectric.shadowOf( view );

    operator.listen( op );

    assertNotNull( shadowView.getOnLongClickListener() );
    assertTrue( compListener.getListeners().contains( touchListener ) );
    assertFalse( touchListener.isTransmittingUpDown() );
  }

  private ListenOperation createMouseDownListenOperation( String targetId, boolean mouse ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "MouseDown", mouse );
    op.setProperties( properties );
    return op;
  }

  private ListenOperation createMouseUpListenOperation( String targetId, boolean mouse ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "MouseUp", mouse );
    op.setProperties( properties );
    return op;
  }

  @Test
  public void testListenAddMenueDetectListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    view.setOnTouchListener( mock( OnTouchListener.class ) );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMenueDetectListenOperation( WIDGET_ID, true );
    ListenerRegistry listenerRegistry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    CompositeTouchListener compTouchListener = mock( CompositeTouchListener.class );
    when( listenerRegistry.findListener( WIDGET_ID, CompositeTouchListener.class ) ).thenReturn( compTouchListener );
    TabrisShadowView shadowButton = ( TabrisShadowView )Robolectric.shadowOf( view );
    assertNull( shadowButton.getOnLongClickListener() );

    operator.listen( op );

    OnLongClickListener onLongClickListener = shadowButton.getOnLongClickListener();
    assertNotNull( onLongClickListener );
  }

  @Test
  public void testListenRemoveMenueDetectListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMenueDetectListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = setUpListenerRegistry( toolkit, false, true, view );
    TabrisShadowView shadowView = ( TabrisShadowView )Robolectric.shadowOf( view );
    assertNotNull( shadowView.getOnLongClickListener() );

    operator.listen( op );

    assertNull( shadowView.getOnTouchListener() );
    assertNull( shadowView.getOnLongClickListener() );
    assertFalse( registry.findListener( WIDGET_ID, CompositeTouchListener.class )
      .contains( MouseEventTouchListener.class ) );
    verify( registry ).unregisterListener( WIDGET_ID, LongClickListener.class );
  }

  @Test
  public void testListenRemoveMenueDetectListenerFromGroup() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    Group group = createGroupInRootLayout( WIDGET_ID, activity );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMenueDetectListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = setUpListenerRegistry( toolkit, false, true, group );
    TabrisShadowFrameLayout shadowGroup = ( TabrisShadowFrameLayout )Robolectric.shadowOf( group );
    assertNotNull( shadowGroup.getOnLongClickListener() );

    operator.listen( op );

    assertNull( shadowGroup.getOnLongClickListener() );
    verify( registry, never() ).unregisterListener( eq( WIDGET_ID ),
                                                    eq( CompositeTouchListener.class ) );
    verify( registry ).unregisterListener( WIDGET_ID, LongClickListener.class );
  }

  @Test
  public void testListenRemoveMenueDetectListenerWithSurvival() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowView.class );
    View view = createView( WIDGET_ID );
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    ListenOperation op = createMenueDetectListenOperation( WIDGET_ID, false );
    ListenerRegistry registry = setUpListenerRegistry( toolkit, true, true, view );
    TabrisShadowView shadowView = ( TabrisShadowView )Robolectric.shadowOf( view );

    assertNotNull( shadowView.getOnLongClickListener() );
    LongClickListener longClickListener = ( LongClickListener )shadowView.getOnLongClickListener();
    assertTrue( longClickListener.isTransmittingMenuDetect() );

    operator.listen( op );

    assertNotNull( shadowView.getOnLongClickListener() );
    assertTrue( registry.findListener( WIDGET_ID, CompositeTouchListener.class )
      .contains( MouseEventTouchListener.class ) );
    verify( longClickListener ).setTransmittingMenuDetect( eq( false ) );
  }

  public ListenerRegistry setUpListenerRegistry( IWidgetToolkit toolkit,
                                                 boolean transmittingUpDown,
                                                 boolean transmittingMenuDetect,
                                                 View view )
  {
    ListenerRegistry registry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    MouseEventTouchListener touchListener = new MouseEventTouchListener( activity,
                                                                         transmittingUpDown );
    CompositeTouchListener compTouchListener = new CompositeTouchListener();
    compTouchListener.addListener( touchListener );
    LongClickListener longClickListener = mock( LongClickListener.class );
    when( longClickListener.isTransmittingMenuDetect() ).thenReturn( transmittingMenuDetect );
    when( registry.findListener( WIDGET_ID, LongClickListener.class ) ).thenReturn( longClickListener );
    when( registry.findListener( WIDGET_ID, CompositeTouchListener.class ) ).thenReturn( compTouchListener );
    view.setOnLongClickListener( longClickListener );
    return registry;
  }

  private ListenOperation createMenueDetectListenOperation( String targetId, boolean menuDetect ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "MenuDetect", menuDetect );
    op.setProperties( properties );
    return op;
  }

  private Button createButtonInRootLayout( String widgetId, Activity activity ) {
    Button button = new Button( activity );
    FrameLayout rootLayout = getRootLayout( activity );
    rootLayout.addView( button );
    when( toolkit.getObjectRegistry().getObject( widgetId, Button.class ) ).thenReturn( button );
    when( toolkit.getObjectRegistry().getObject( widgetId, View.class ) ).thenReturn( button );
    return button;
  }

  private FrameLayout getRootLayout( Activity activity ) {
    return ( FrameLayout )activity.findViewById( R.id.root_layout );
  }

  private Group createGroupInRootLayout( String widgetId, TabrisActivity activity ) {
    Group group = new Group( activity );
    when( toolkit.getObjectRegistry().getObject( widgetId, Group.class ) ).thenReturn( group );
    when( toolkit.getObjectRegistry().getObject( widgetId, View.class ) ).thenReturn( group );
    return group;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNullOperation() throws Exception {
    OperatorUnderTest operator = new OperatorUnderTest( activity );
    operator.destroy( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNoTarget() throws Exception {
    OperatorUnderTest operator = new OperatorUnderTest( activity );
    DestroyOperation destroyOperation = new DestroyOperation();
    operator.destroy( destroyOperation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyTargetDoesNotExist() throws Exception {
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    OperatorUnderTest operator = new OperatorUnderTest( activity );

    assertNull( rootLayout.findViewWithTag( WIDGET_ID ) );

    operator.destroy( destroyOperation );
  }

  @Test
  public void testDestroyOk() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    OperatorUnderTest operator = new OperatorUnderTest( activity );
    BitmapDrawable prevBitmapDrawable = mock( BitmapDrawable.class );
    button.setBackgroundDrawable( prevBitmapDrawable );
    listenerRegistry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );

    operator.destroy( destroyOperation );

    verify( objectRegistry ).unregister( WIDGET_ID );
    verify( drawableCache ).decreaseReferenceCount( prevBitmapDrawable );
    verify( listenerRegistry ).unregisterAllListeners( WIDGET_ID );
  }

  @Test
  public void testSetOk() throws Exception {
    Button button = createButtonInRootLayout( WIDGET_ID, activity );
    ButtonOperator op = new ButtonOperator( activity );
    SetOperation operation = new SetOperation();
    Properties properties = new Properties();
    properties.add( "text", "foo" );
    operation.setProperties( properties );
    operation.setTarget( WIDGET_ID );

    op.set( operation );

    assertEquals( "foo", button.getText().toString() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullOp() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    operator.set( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullTarget() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    SetOperation operation = new SetOperation();
    operation.setProperties( new Properties() );
    operator.set( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullProperties() throws Exception {
    AbstractWidgetOperator operator = new OperatorUnderTest( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET_ID );
    operator.set( operation );
  }

  @Test
  public void testInit() throws Exception {
    OperatorUnderTest operator = new OperatorUnderTest( activity );
    CreateOperation operation = new CreateOperation();
    operation.setTarget( WIDGET_ID );
    Properties properties = new Properties();
    properties.add( "parent", PARENT_ID );
    operation.setProperties( properties );

    assertNull( listenerRegistry.findListener( WIDGET_ID, CompositeTouchListener.class ) );

    operator.initiateNewView( operation, createView( WIDGET_ID ) );

    assertNotNull( listenerRegistry.findListener( WIDGET_ID, CompositeTouchListener.class ) );
  }

  @Test
  public void testShouldAddViewToParent() throws Exception {
    OperatorUnderTest operator = new OperatorUnderTest( activity );
    CreateOperation operation = new CreateOperation();
    operation.setTarget( WIDGET_ID );
    Properties properties = new Properties();
    properties.add( "parent", PARENT_ID );
    operation.setProperties( properties );
    View child = createView( WIDGET_ID );

    operator.initiateNewView( operation, child );

    InOrder order = inOrder( objectRegistry, parentLayout );
    order.verify( objectRegistry ).register( eq( WIDGET_ID ), eq( child ), anyString() );
    order.verify( parentLayout ).addView( child );
  }
}
