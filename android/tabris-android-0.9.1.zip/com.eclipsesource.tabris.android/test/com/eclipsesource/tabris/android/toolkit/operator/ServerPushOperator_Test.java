/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.os.MessageQueue;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.ServerPush;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;

@RunWith(TabrisTestRunner.class)
public class ServerPushOperator_Test {

  private static final String WIDGET_ID = "w4";

  private ServerPushOperator operator;
  private TabrisActivity activity;
  private ServerPush serverPush;
  private SetOperation setOp;
  private IWidgetToolkit awt;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivity();
    serverPush = mock( ServerPush.class );
    awt = new AndroidWidgetToolkit( activity, mock( MessageQueue.class ) );
    awt.getObjectRegistry().register( ServerPushOperator.TYPE, serverPush, ServerPushOperator.TYPE );
    activity.getProcessor().setWidgetToolkit( awt );
    operator = new ServerPushOperator( activity );
    setOp = new SetOperation();
    setOp.setTarget( ServerPushOperator.TYPE );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullOp() throws Exception {
    operator.set( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullTarget() throws Exception {
    SetOperation operation = new SetOperation();
    operation.setProperties( new Properties() );

    operator.set( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnNullProperties() throws Exception {
    SetOperation operation = new SetOperation();
    operation.setTarget( WIDGET_ID );

    operator.set( operation );
  }

  @Test
  public void testShouldCreateServerPushAndRegister() throws Exception {
    TabrisActivity activity2 = UiTestUtil.createActivity();
    ServerPushOperator op = new ServerPushOperator( activity2 );
    Properties props = new Properties();
    props.add( "active", true );
    setOp.setProperties( props );

    op.set( setOp );

    Object callback = activity2.getProcessor()
      .getWidgetToolkit()
      .getObjectRegistry()
      .getObject( ServerPushOperator.TYPE );
    assertNotNull( callback );
  }

  @Test
  public void testSetActiveTrue() {
    Properties props = new Properties();
    props.add( "active", true );
    setOp.setProperties( props );

    operator.set( setOp );

    verify( serverPush ).activate( true );
  }

  @Test
  public void testSetActiveFalse() {
    Properties props = new Properties();
    props.add( "active", false );
    setOp.setProperties( props );

    operator.set( setOp );

    verify( serverPush ).activate( false );
  }

}
