package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.Parent;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ScrollBar;
import com.xtremelabs.robolectric.RobolectricTestRunner;


@RunWith( RobolectricTestRunner.class )
public class ScrollBarOperator_Test {
  
  private static final String PARENT_ID = "w2";
  private static final String SCROLLBAR_ID = "w23";
  private ScrollBarOperator scrollBarOperator;
  private TabrisActivity activity;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFields();
    scrollBarOperator = new ScrollBarOperator( activity );
  }
  
  @Test( expected = IllegalArgumentException.class )
  public void testFailsWithNullActivity() {
    new ScaleOperator( null );
  }
  
  @Test
  public void testTypeIsScrollBar() {
    assertEquals( "rwt.widgets.ScrollBar", scrollBarOperator.getType() );
  }
  
  @Test
  public void testCreateRegistersObjectAndInitializesScrollBarCorrectly() {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    when( objectRegistry.getObject( PARENT_ID ) ).thenReturn( mock( Parent.class ) );
    CreateOperation operation = createCreateOperation();
    
    scrollBarOperator.create( operation );
    
    ArgumentCaptor<ScrollBar> captor = ArgumentCaptor.forClass( ScrollBar.class );
    verify( objectRegistry ).register( eq( SCROLLBAR_ID ), 
                                       captor.capture(), 
                                       eq( ScrollBarOperator.TYPE ) );
    ScrollBar scrollBar = captor.getValue();
    assertEquals( "HORIZONTAL", scrollBar.getStyle() );
    assertEquals( PARENT_ID, scrollBar.getParent() );
  }
  
  @Test
  public void testSetsVisibility() {
    ScrollBar scrollBar = mock( ScrollBar.class );
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    when( objectRegistry.getObject( anyString() ) ).thenReturn( scrollBar );
    SetOperation setOperation = new SetOperation();
    setOperation.setTarget( SCROLLBAR_ID );
    Properties properties = new Properties();
    properties.add( "visibility", true );
    setOperation.setProperties( properties );

    scrollBarOperator.set( setOperation );
    
    verify( scrollBar ).setVisibility( true );
  }

  @Test
  public void testAddsItselfToParent() {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    Parent parent = mock( Parent.class );
    when( objectRegistry.getObject( PARENT_ID ) ).thenReturn( parent );
    CreateOperation operation = createCreateOperation();
    
    scrollBarOperator.create( operation );
    
    verify( parent ).addChild( any( ScrollBar.class ) );
  }
  
  @Test( expected = IllegalStateException.class )
  public void testAddsItselfToParentFailsWhenNoParent() {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    Object nonParent = mock( Object.class );
    when( objectRegistry.getObject( PARENT_ID ) ).thenReturn( nonParent );
    CreateOperation operation = createCreateOperation();
    
    scrollBarOperator.create( operation );
  }
  
  @Test
  public void testListenUpdatesRemoteObject() {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( remoteObject );
    ListenOperation listenOperation = new ListenOperation();
    listenOperation.setTarget( "foo" );
    Properties properties = new Properties();
    properties.add( "Selection", true );
    listenOperation.setProperties( properties );
    
    scrollBarOperator.listen( listenOperation );
    
    verify( remoteObject ).addListen( "Selection" );
  }

  private CreateOperation createCreateOperation() {
    CreateOperation operation = new CreateOperation();
    operation.setTarget( SCROLLBAR_ID );
    operation.setType( ShellOperator.TYPE );
    Properties properties = new Properties();
    ArrayList<String> style = new ArrayList<String>();
    style.add( "HORIZONTAL" );
    properties.add( "style", style );
    properties.add( "parent", PARENT_ID );
    operation.setProperties( properties );
    return operation;
  }

}
