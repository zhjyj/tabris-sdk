/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.ProgressDialog;

import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProgressIndicator_Test {

  private ProgressIndicator indicator;
  private AndroidWidgetToolkit toolkit;
  private Runnable openRunnable;
  private Runnable closeRunnable;

  @Before
  public void setup() {
    toolkit = mock( AndroidWidgetToolkit.class );
    indicator = new ProgressIndicator( UiTestUtil.createActivity(), toolkit );
    openRunnable = mock( Runnable.class );
    indicator.setOpenDialogRunnable( openRunnable );
    closeRunnable = mock( Runnable.class );
    indicator.setCloseDialogRunnable( closeRunnable );
  }

  @Test
  public void testCreate() {
    ProgressIndicator indicator = new ProgressIndicator( UiTestUtil.createActivity(),
                                                         mock( AndroidWidgetToolkit.class ) );

    assertTrue( indicator.getProgressDialog().isIndeterminate() );
  }

  @Test
  public void testDoNotOpenWhenAlreadyShowing() {
    indicator = mock( ProgressIndicator.class );
    when( indicator.isAnyDialogShowing() ).thenReturn( true );
    Runnable showRunnable = new ProgressIndicator.OpenDialogRunnable( indicator );

    showRunnable.run();

    verify( indicator, never() ).openProgressDialog();
  }

  @Test
  public void testOpenWhenNotShowing() {
    indicator = mock( ProgressIndicator.class );
    when( indicator.isAnyDialogShowing() ).thenReturn( false );
    Runnable showRunnable = new ProgressIndicator.OpenDialogRunnable( indicator );

    showRunnable.run();

    verify( indicator ).openProgressDialog();
  }

  @Test
  public void testCloseProgressDialogFromRunnable() {
    indicator = mock( ProgressIndicator.class );
    Runnable closeRunnable = new ProgressIndicator.CloseDialogRunnable( indicator );

    closeRunnable.run();

    verify( indicator ).closeProgressDialog();
  }

  @Test
  public void testAnyDialogShowingFalseTrue() {
    setUpShowingDialogs( false, true );

    boolean result = indicator.isAnyDialogShowing();

    assertTrue( result );
  }

  @Test
  public void testAnyDialogShowingTrueFalse() {
    setUpShowingDialogs( true, false );

    boolean result = indicator.isAnyDialogShowing();

    assertTrue( result );
  }

  @Test
  public void testAnyDialogShowingTrueTrue() {
    setUpShowingDialogs( true, true );

    boolean result = indicator.isAnyDialogShowing();

    assertTrue( result );
  }

  @Test
  public void testAnyDialogShowingFalseFalse() {
    setUpShowingDialogs( false, false );

    boolean result = indicator.isAnyDialogShowing();

    assertFalse( result );
  }

  private void setUpShowingDialogs( boolean progressDialogShowing,
                                    boolean progressInterruptedDialogShowing )
  {
    ProgressDialog dialog = mock( ProgressDialog.class );
    when( dialog.isShowing() ).thenReturn( progressDialogShowing );
    indicator.setProgressDialog( dialog );
    ErrorDialog progressInterruptedDialog = mock( ProgressInterruptedDialog.class );
    when( progressInterruptedDialog.isShowing() ).thenReturn( progressInterruptedDialogShowing );
    indicator.setProgressInterruptedDialog( progressInterruptedDialog );
  }

  @Test
  public void testStartSubmitsOpenRunnableInUiThread() {
    indicator.start();

    verify( toolkit ).executeDelayedInUiThread( openRunnable, 2000 );
  }

  @Test
  public void testStopBeforeShowing() {
    ProgressDialog dialog = mock( ProgressDialog.class );
    indicator.setProgressDialog( dialog );

    indicator.stop();

    verify( dialog ).dismiss();
    verify( toolkit ).cancelInUiThread( closeRunnable );
  }

  @Test
  public void testStopAfterShortShowing() {
    indicator.setOpenTime( 1 );
    ProgressIndicator.WallClock timer = mock( ProgressIndicator.WallClock.class );
    indicator.setTimer( timer );
    when( timer.getCurrentTime() ).thenReturn( 23l );

    indicator.stop();

    verify( toolkit ).cancelInUiThread( openRunnable );
    verify( toolkit ).executeDelayedInUiThread( closeRunnable, 1500 );
  }

  @Test
  public void testStopAfterLongShowing() {
    ProgressDialog dialog = mock( ProgressDialog.class );
    indicator.setProgressDialog( dialog );
    indicator.setOpenTime( 1 );
    ProgressIndicator.WallClock timer = mock( ProgressIndicator.WallClock.class );
    indicator.setTimer( timer );
    when( timer.getCurrentTime() ).thenReturn( 1502l );

    indicator.stop();

    verify( toolkit ).cancelInUiThread( closeRunnable );
    verify( toolkit, never() ).executeDelayedInUiThread( closeRunnable, 1500 );
    verify( dialog ).dismiss();
  }

}
