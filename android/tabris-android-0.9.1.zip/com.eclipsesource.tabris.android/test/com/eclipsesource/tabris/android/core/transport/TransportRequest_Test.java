/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TransportRequest_Test {

  @Test
  public void testConstructorString() {
    ITransportRequest request = new TransportRequest( "abc" );

    assertEquals( "abc", request.getPath() );
  }

  @Test
  public void testConstructorStringString() {
    ITransportRequest request = new TransportRequest( "abc", "xyz" );

    assertEquals( "abc", request.getPath() );
    assertEquals( "xyz", request.getQuery() );
  }

  @Test
  public void testSetGetTimeout() throws Exception {
    ITransportRequest request = new TransportRequest( "abc", "xyz" );

    request.setTimeout( 213 );

    assertEquals( 213, request.getTimeout() );
  }

  @Test
  public void testSetBackgroundRequest() throws Exception {
    ITransportRequest request = new TransportRequest( "abc", "xyz" );

    request.setSilentRequest( true );

    assertTrue( request.isSilentRequest() );
  }
}
