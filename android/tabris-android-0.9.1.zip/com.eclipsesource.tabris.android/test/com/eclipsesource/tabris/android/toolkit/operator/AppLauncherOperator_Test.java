
package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.AppLauncher;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;

public class AppLauncherOperator_Test {

  private static final String TYPE = "tabris.AppLauncher";

  @Test
  public void testGetTypeShouldReturnCorrectType() {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );

    String type = operator.getType();

    assertEquals( TYPE, type );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorShouldNotAcceptNullActivity() throws Exception {
    new AppLauncherOperator( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateWithoutNullOperationShouldFail() throws Exception {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateWithoutTargetShouldFail() throws Exception {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );

    operator.create( new CreateOperation() );
  }

  @Test
  public void testCreateShouldRegisterAppLauncher() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    CreateOperation operation = new CreateOperation();
    operation.setTarget( "r3" );
    operation.setType( TYPE );

    operator.create( operation );

    ObjectRegistry objectRegistry = getObjectRegistry( activity );
    verify( objectRegistry ).register( eq( "r3" ), isA( AppLauncher.class ), eq( TYPE ) );
  }

  @Test
  public void testDestroyShouldRemoveAppLauncherFromObjectRegistry() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );

    DestroyOperation operation = new DestroyOperation();
    operation.setTarget( "r3" );
    operator.destroy( operation );

    ObjectRegistry objectRegistry = getObjectRegistry( activity );
    verify( objectRegistry ).unregister( "r3" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithNullOperationShouldFail() throws Exception {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );

    operator.call( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithoutTargetShouldFail() throws Exception {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );

    operator.call( new CallOperation() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithoutPropertiesShouldFail() throws Exception {
    AppLauncherOperator operator = new AppLauncherOperator( mock( TabrisActivity.class ) );
    CallOperation operation = new CallOperation();
    operation.setTarget( "r3" );

    operator.call( operation );
  }

  @Test
  public void testCallShouldOpenBrowser() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "BROWSER" );
    properties.add( "url", "http://google.com" );

    operator.call( operation );

    verify( appLauncher ).openBrowser( "http://google.com" );
  }

  @Test
  public void testCallShouldOpenMail() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "MAIL" );
    properties.add( "to", "user@mail.com" );
    properties.add( "cc", "account@mail.com" );
    properties.add( "subject", "Contact me" );
    properties.add( "body", "Urgent" );
    properties.add( "useHtml", "true" );

    operator.call( operation );

    verify( appLauncher ).openMail( "user@mail.com",
                                    "account@mail.com",
                                    "Contact me",
                                    "Urgent",
                                    true );
  }

  @Test
  public void testCallShouldOpenPhone() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "PHONE" );
    properties.add( "number", "55534545" );

    operator.call( operation );

    verify( appLauncher ).openPhone( "55534545" );
  }

  @Test
  public void testCallShouldOpenMapsWithCoordinates() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "MAPS" );
    properties.add( "latitude", "52.5233" );
    properties.add( "longitude", "13.4127" );

    operator.call( operation );

    verify( appLauncher ).openMaps( "52.5233", "13.4127" );
  }

  @Test
  public void testCallShouldOpenMapsWithQuery() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "MAPS" );
    properties.add( "query", "Street 123, Town" );

    operator.call( operation );

    verify( appLauncher ).openMaps( "Street 123, Town" );
  }

  @Test
  public void testCallShouldOpenSms() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "SMS" );

    operator.call( operation );

    verify( appLauncher ).openSms( null, null );
  }

  @Test
  public void testCallShouldOpenSmsWithNumberAndText() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "SMS" );
    properties.add( "number", "5551234" );
    properties.add( "text", "Hello World!" );

    operator.call( operation );

    verify( appLauncher ).openSms( "5551234", "Hello World!" );
  }

  @Test
  public void testCallToTwitterShouldOpenTwitter() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "TWITTER" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://twitter.com/intent/tweet" );
  }

  @Test
  public void testCallToTwitterWithTextShouldOpenTwitter() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "TWITTER" );
    properties.add( "text", "Hello World!" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://twitter.com/intent/tweet?text=Hello+World%21" );
  }

  @Test
  public void testCallToTwitterWithUrlShouldOpenTwitter() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "TWITTER" );
    properties.add( "url", "http://url.com" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://twitter.com/intent/tweet?text=http%3A%2F%2Furl.com" );
  }

  @Test
  public void testCallToTwitterWithTextAndUrlShouldOpenTwitter() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "TWITTER" );
    properties.add( "text", "Hello World!" );
    properties.add( "url", "http://url.com" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://twitter.com/intent/tweet?text=Hello+World%21+-+http%3A%2F%2Furl.com" );
  }

  @Test
  public void testCallToFacebookShouldOpenFacebook() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "FACEBOOK" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://www.facebook.com/sharer/sharer.php" );
  }

  @Test
  public void testCallToFacebookWithTextShouldOpenFacebook() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "FACEBOOK" );
    properties.add( "text", "Hello World!" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://www.facebook.com/sharer/sharer.php?t=Hello+World%21" );
  }

  @Test
  public void testCallToFacebookWithUrlShouldOpenFacebook() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "FACEBOOK" );
    properties.add( "url", "http://url.com" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Furl.com" );
  }

  @Test
  public void testCallToFacebookWithTextAndUrlShouldOpenFacebook() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallOperation();
    Properties properties = operation.getProperties();
    properties.add( "app", "FACEBOOK" );
    properties.add( "text", "Hello World!" );
    properties.add( "url", "http://url.com" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://www.facebook.com/sharer/sharer.php?t=Hello+World%21&u=http%3A%2F%2Furl.com" );
  }

  @Test
  public void testCallShouldOpenUrl() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallUrlOperation();
    Properties properties = operation.getProperties();
    properties.add( "url", "http://url.com/path/file.txt" );

    operator.call( operation );

    verify( appLauncher ).openUrl( "http://url.com/path/file.txt" );
  }

  @Test
  public void testCallWithNullUrlShouldNotOpenUrl() throws Exception {
    TabrisActivity activity = UiTestUtil.createMockedActivity();
    AppLauncherOperator operator = new AppLauncherOperator( activity );
    AppLauncher appLauncher = mockAppLauncher( activity );
    CallOperation operation = createOpenCallUrlOperation();
    Properties properties = operation.getProperties();
    properties.add( "url", null );

    operator.call( operation );

    verify( appLauncher, never() ).openUrl( anyString() );
  }

  private CallOperation createOpenCallOperation() {
    CallOperation operation = new CallOperation();
    operation.setTarget( "r3" );
    operation.setProperties( new Properties() );
    operation.setMethod( "open" );
    return operation;
  }

  private CallOperation createOpenCallUrlOperation() {
    CallOperation operation = new CallOperation();
    operation.setTarget( "r3" );
    operation.setProperties( new Properties() );
    operation.setMethod( "openUrl" );
    return operation;
  }

  private AppLauncher mockAppLauncher( TabrisActivity activity ) {
    AppLauncher appLauncher = mock( AppLauncher.class );
    when( getObjectRegistry( activity ).getObject( "r3", AppLauncher.class ) ).thenReturn( appLauncher );
    return appLauncher;
  }

  private ObjectRegistry getObjectRegistry( TabrisActivity activity ) {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }
}
