/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TabHost.TabSpec;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAsyncTask;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowTabHost;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.BoundsAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupport;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ViewSetter_Test {

  private static final String CUSTOM_VARIANT_VALUE = "customVariantValue";

  private final Random random = new Random();

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    setter.execute( null, mock( Properties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    setter.execute( mock( View.class ), null );
  }

  @Test
  public void testSetBoundsNotSet() {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    MarginLayoutParams layout = mock( MarginLayoutParams.class );
    layout.leftMargin = 1;
    when( view.getLayoutParams() ).thenReturn( layout );
    Properties props = new Properties();

    setter.execute( view, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )view.getLayoutParams();
    assertEquals( 1, layoutParams.leftMargin );
    assertEquals( 0, layoutParams.topMargin );
    assertEquals( 0, layoutParams.width );
    assertEquals( 0, layoutParams.height );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetBoundsMalformed() {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    Properties props = new Properties();
    props.add( "bounds", Arrays.asList( 10, 20, 30 ) );

    setter.execute( view, props );
  }

  @Test
  public void testSetBoundsOk() {
    View view = mock( View.class );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    Properties props = new Properties();
    props.add( "bounds", Arrays.asList( 10, 20, 30, 40 ) );

    TabrisActivity activity = mock( TabrisActivity.class );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.multiplyByDensityFactor( 10 ) ).thenReturn( 15 );
    when( toolkit.multiplyByDensityFactor( 20 ) ).thenReturn( 25 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 35 );
    when( toolkit.multiplyByDensityFactor( 40 ) ).thenReturn( 45 );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( activity.getProcessor() ).thenReturn( processor );

    ViewSetter<View> setter = new ViewSetter<View>( activity );

    setter.execute( view, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )view.getLayoutParams();
    assertEquals( 15, layoutParams.leftMargin );
    assertEquals( 25, layoutParams.topMargin );
    assertEquals( 35, layoutParams.width );
    assertEquals( 45, layoutParams.height );
    verify( view ).setMinimumHeight( 45 );
    verify( view ).setMinimumWidth( 35 );
  }

  @Test
  public void testSetBoundsWithHorizontalScrollCompositeParent() throws Exception {
    View view = mock( View.class );
    ObservableHorizontalScrollView scrollView = createHorizontalScrollView( 50, 100 );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( view.getParent() ).thenReturn( scrollView );

    setupAndAssertSetBounds( view );
  }

  @Test
  public void testSetBoundsWithVerticalScrollCompositeParent() throws Exception {
    View view = mock( View.class );
    ObservableVerticalScrollView scrollView = createVerticalScrollView( 50, 100 );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( view.getParent() ).thenReturn( scrollView );

    setupAndAssertSetBounds( view );
  }

  @Test
  public void testSetBoundsWithVerticalHorizontalScrollCompositeParent() throws Exception {
    View view = mock( View.class );
    ObservableScrollView scrollView = mock( ObservableScrollView.class );
    ObservableHorizontalScrollView horizontalScrollView = createHorizontalScrollView( 50, 1235425 );
    ObservableVerticalScrollView verticalScrollView = createVerticalScrollView( 213234, 100 );
    when( scrollView.getHorizontalScroll() ).thenReturn( horizontalScrollView );
    when( scrollView.getVerticalScroll() ).thenReturn( verticalScrollView );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( view.getParent() ).thenReturn( scrollView );

    setupAndAssertSetBounds( view );
  }

  private ObservableHorizontalScrollView createHorizontalScrollView( int x, int y ) {
    ObservableHorizontalScrollView scrollView = mock( ObservableHorizontalScrollView.class );
    ScrollSupport scrollSupport = mock( ScrollSupport.class );
    when( scrollView.getScrollSupport() ).thenReturn( scrollSupport );
    when( scrollSupport.getScrollTargetX() ).thenReturn( x );
    when( scrollSupport.getScrollTargetY() ).thenReturn( y );
    return scrollView;
  }

  private ObservableVerticalScrollView createVerticalScrollView( int x, int y ) {
    ObservableVerticalScrollView scrollView = mock( ObservableVerticalScrollView.class );
    ScrollSupport scrollSupport = mock( ScrollSupport.class );
    when( scrollView.getScrollSupport() ).thenReturn( scrollSupport );
    when( scrollSupport.getScrollTargetX() ).thenReturn( x );
    when( scrollSupport.getScrollTargetY() ).thenReturn( y );
    return scrollView;
  }

  private void setupAndAssertSetBounds( View view ) {
    Properties props = new Properties();
    props.add( "bounds", Arrays.asList( 10, 20, 30, 40 ) );

    TabrisActivity activity = mock( TabrisActivity.class );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.divideByDensityFactor( 50 ) ).thenReturn( 50 );
    when( toolkit.divideByDensityFactor( 100 ) ).thenReturn( 100 );
    when( toolkit.multiplyByDensityFactor( 120 ) ).thenReturn( 180 );
    when( toolkit.multiplyByDensityFactor( 60 ) ).thenReturn( 90 );
    when( toolkit.multiplyByDensityFactor( 120 ) ).thenReturn( 180 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 35 );
    when( toolkit.multiplyByDensityFactor( 40 ) ).thenReturn( 45 );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( activity.getProcessor() ).thenReturn( processor );

    ViewSetter<View> setter = new ViewSetter<View>( activity );

    setter.execute( view, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )view.getLayoutParams();
    assertEquals( 90, layoutParams.leftMargin );
    assertEquals( 180, layoutParams.topMargin );
    assertEquals( 35, layoutParams.width );
    assertEquals( 45, layoutParams.height );
    verify( view ).setMinimumHeight( 45 );
    verify( view ).setMinimumWidth( 35 );
  }

  @Test
  public void testSetBoundsWithTabFolderParent() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowTabHost.class );
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( "widgetId" );
    View view = new View( activity );
    view.setLayoutParams( new LinearLayout.LayoutParams( 0, 0 ) );
    TabFolder tabFolder = ( TabFolder )activity.getLayoutInflater()
      .inflate( R.layout.tabfolder_bottom, null );
    TabSpec tabSpec = tabFolder.newTabSpec( "tabItemId" );
    tabFolder.addTab( tabSpec, "widgetId" );
    FrameLayout tabContentView = tabFolder.getTabContentView();
    createParentLayout( activity, tabContentView, createUniqueId( tabContentView ) );
    tabFolder.addView( view );
    Properties props = new Properties();
    props.add( "bounds", Arrays.asList( 10, 20, 30, 40 ) );

    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.multiplyByDensityFactor( 10 ) ).thenReturn( 20 );
    when( toolkit.multiplyByDensityFactor( 20 ) ).thenReturn( 40 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 60 );
    when( toolkit.multiplyByDensityFactor( 40 ) ).thenReturn( 80 );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );

    ViewSetter<View> setter = new ViewSetter<View>( activity );
    setter.execute( view, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )view.getLayoutParams();
    assertEquals( 0, layoutParams.leftMargin );
    assertEquals( 0, layoutParams.topMargin );
    assertEquals( 60, layoutParams.width );
    assertEquals( 80, layoutParams.height );
  }

  @Test
  public void testSetBoundsWithCustomVariantAnimated() throws Exception {
    View view = mock( View.class );
    when( view.getTag( R.id.custom_variant ) ).thenReturn( ICustomVariants.ANIMATED );
    when( view.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    Properties props = new Properties();
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    props.add( "bounds", bounds );
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    BoundsAnimationSupport animSupport = mock( BoundsAnimationSupport.class );
    setter.setBoundsAnimationSupport( animSupport );

    setter.execute( view, props );

    verify( animSupport ).applyBoundsAnimations( setter, view, bounds );
  }

  private void createParentLayout( TabrisActivity activity, FrameLayout tabContentView, int id ) {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setId( id );
    tabContentView.addView( linearLayout,
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT );
  }

  private int createUniqueId( FrameLayout tabContentView ) {
    int id = random.nextInt();
    if( id < 0 ) {
      id *= -1;
    }
    if( tabContentView.findViewById( id ) == null ) {
      return id;
    } else {
      return createUniqueId( tabContentView );
    }
  }

  @Test
  public void testSetVisibilityTrue() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "visibility", true );

    setter.execute( view, props );

    verify( view ).setVisibility( View.VISIBLE );
  }

  @Test
  public void testSetVisibilityFalse() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "visibility", false );

    setter.execute( view, props );

    verify( view ).setVisibility( View.INVISIBLE );
  }

  @Test
  public void testSetVisibilityNull() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();

    setter.execute( view, props );

    verify( view, never() ).setVisibility( anyInt() );
  }

  @Test
  public void testSetEnabledTrue() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "enabled", true );

    setter.execute( view, props );

    verify( view ).setEnabled( true );
  }

  @Test
  public void testSetEnabledFalse() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "enabled", false );

    setter.execute( view, props );

    verify( view ).setEnabled( false );
  }

  @Test
  public void testSetEnabledNull() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();

    setter.execute( view, props );

    verify( view, never() ).setEnabled( anyBoolean() );
  }

  @Test
  public void testSetSelectionTrue() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "selection", true );

    setter.execute( view, props );

    verify( view ).setSelected( true );
  }

  @Test
  public void testSetSelectionFalse() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "selection", false );

    setter.execute( view, props );

    verify( view ).setSelected( false );
  }

  @Test
  public void testSetSelectionNull() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();

    setter.execute( view, props );

    verifyNoMoreInteractions( view );
  }

  @Test
  public void testSetCustomVariantToValue() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "customVariant", CUSTOM_VARIANT_VALUE );

    setter.execute( view, props );

    verify( view ).setTag( R.id.custom_variant, CUSTOM_VARIANT_VALUE );
  }

  @Test
  public void testSetCustomVariantToNull() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "customVariant", null );

    setter.execute( view, props );

    verify( view ).setTag( R.id.custom_variant, null );
  }

  @Test
  public void testSetCustomVariantNotSet() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();

    setter.execute( view, props );

    verifyNoMoreInteractions( view );
  }

  @Test
  public void testSetBackgroundOk() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    List<Integer> colorTouple = Arrays.asList( 10, 20, 30, 40 );
    props.add( "background", colorTouple );

    setter.execute( view, props );

    int color = ColorUtil.colorToupleToInt( colorTouple );
    verify( view ).setBackgroundColor( color );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetBackgroundImageMalformed() throws Throwable {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "backgroundImage", Arrays.asList( "somePath/toAn/Image", "256" ) );

    setter.execute( view, props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetBackgroundImageUrlMissing() throws Throwable {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();
    props.add( "backgroundImage", Arrays.asList( "", "256", "100" ) );

    setter.execute( view, props );
  }

  @Test
  public void testSetBackgroundImageNoProps() throws Exception {
    ViewSetter<View> setter = new ViewSetter<View>( new TabrisActivity() );
    View view = mock( View.class );
    Properties props = new Properties();

    setter.execute( view, props );

    verifyZeroInteractions( view );
  }

  @Test
  public void testSetBackgroundImage() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    ViewSetter<View> setter = new ViewSetter<View>( activity );
    View view = mock( View.class );
    BitmapDrawable prevBitmapDrawable = mock( BitmapDrawable.class );
    when( view.getBackground() ).thenReturn( prevBitmapDrawable );
    Properties props = new Properties();
    props.add( "backgroundImage", Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    when( activity.getProcessor().processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    when( transportResult.getResult() ).thenReturn( inputImage );

    setter.execute( view, props );

    verify( view ).setBackgroundDrawable( any( Drawable.class ) );
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    verify( cache ).decreaseReferenceCount( prevBitmapDrawable );
  }
}
