/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowEditText;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener_Test;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.TextChangeListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowEditText;

@RunWith(RobolectricTestRunner.class)
public class TextOperator_Test {

  private static final String PASSWORD = "PASSWORD";
  private static final String BORDER = "BORDER";
  private static final String PARENT_ID = "w2";
  private static final String EDIT_TEXT_ID = "w3";

  private TabrisActivity activity;
  private ListenerRegistry listenerRegistry;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;
  private ObjectRegistry objectRegistry;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( EDIT_TEXT_ID );
    listenerRegistry = activity.getProcessor().getWidgetToolkit().getListenerRegistry();
    parentLayout = new FrameLayout( activity );
    toolkit = activity.getProcessor().getWidgetToolkit();
    objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new TextOperator( activity );

    assertTrue( operator.getViewSetter( mock( Text.class ) ) instanceof EditTextSetter );
  }

  @Test
  public void testGetType() {
    TextOperator textOperator = new TextOperator( new TabrisActivity() );

    String type = textOperator.getType();

    assertEquals( "rwt.widgets.Text", type );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() {
    new TextOperator( null );
  }

  @Test
  public void testCreateOk() {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );

    View view = findCreatedWidget();
    assertEquals( Text.class, view.getClass() );
    EditText editText = ( EditText )view;
    assertTrue( ( editText.getInputType() & EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE ) == 0 );
    verify( listenerRegistry, times( 2 ) ).registerListener( eq( EDIT_TEXT_ID ),
                                                             any( CompositeFocusListener_Test.class ) );
  }

  private CreateOperation createCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( EDIT_TEXT_ID );
    op.setType( "rwt.widgets.Text" );
    Properties properties = new Properties();
    properties.add( "parent", PARENT_ID );
    op.setProperties( properties );
    return op;
  }

  private CreateOperation createCreateOperationWithStyle( String style ) {
    CreateOperation op = createCreateOperation();
    List<String> styles = new ArrayList<String>();
    styles.add( style );
    op.getProperties().add( "style", styles );
    return op;
  }

  private EditText findCreatedWidget() {
    ArgumentCaptor<EditText> captor = ArgumentCaptor.forClass( EditText.class );
    verify( toolkit.getObjectRegistry() ).register( eq( EDIT_TEXT_ID ), captor.capture(), eq( "rwt.widgets.Text" ) );
    return captor.getValue();
  }

  @Test
  public void testCreatePasswordEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperationWithStyle( PASSWORD );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getTransformationMethod() instanceof PasswordTransformationMethod );
    assertEquals( InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS, view.getInputType() );
  }

  @Test
  public void testCreateReadOnlyEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();
    op.getProperties().add( "editable", false );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getInputType() == InputType.TYPE_NULL );
  }

  @Test
  public void testHasTextListener() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );
    EditText view = findCreatedWidget();

    List<TextWatcher> watchers = ( ( ShadowEditText )Robolectric.shadowOf( view ) ).getWatchers();
    assertFalse( watchers.isEmpty() );
    boolean textChangeListenerFound = false;
    for( TextWatcher watcher : watchers ) {
      if( watcher instanceof TextChangeListener ) {
        textChangeListenerFound = true;
      }
    }
    assertTrue( textChangeListenerFound );
  }

  @Test
  @Ignore("The following asserts check for side effects of Android's EditText.setSingleLine() These side effects do not occur with robolectric!")
  public void testCreateSingleLineEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperationWithStyle( "SINGLE" );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getTransformationMethod() instanceof SingleLineTransformationMethod );
    assertTrue( ( view.getInputType() & EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE ) == EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE );
  }

  @Test
  public void testCreateBorderlessEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertNull( view.getBackground() );
  }

  @Test
  public void testCreateWithBorderOk() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperationWithStyle( BORDER );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertNotNull( view.getBackground() );
  }

  @Test
  public void testTextScaling() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertEquals( 16f, view.getTextSize(), 0 );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testListenAddModifyListener() throws Exception {
    when( listenerRegistry.findListener( EDIT_TEXT_ID, CompositeFocusListener.class ) )
      .thenReturn( mock( CompositeFocusListener.class ) );
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    AbstractWidgetOperator operator = new TextOperator( activity );
    operator.create( createCreateOperation() );
    when( objectRegistry.getObject( eq( EDIT_TEXT_ID ), any( Class.class ) ) ).thenReturn( text );
    ListenOperation op = createModifyListenOperation( EDIT_TEXT_ID, true );
    ShadowEditText shadowText = ( ShadowEditText )Robolectric.shadowOf( text );

    operator.listen( op );

    assertEquals( 1, shadowText.getWatchers().size() );
    verify( listenerRegistry, times( 3 ) ).registerListener( eq( EDIT_TEXT_ID ), anyObject() );
  }

  @Test
  public void testAttachModifyListenerUpdatesRegistry() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TextOperator operator = new TextOperator( activity );
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    TabrisShadowEditText shadowText = ( TabrisShadowEditText )Robolectric.shadowOf( text );

    operator.attachModifyListener( createModifyListenOperation( EDIT_TEXT_ID, true ) );

    assertEquals( 1, shadowText.getWatchers().size() );
  }

  private EditText createEditTextInRootLayout( String targetId ) {
    EditText text = new EditText( activity );
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    when( widgetToolkit.getObjectRegistry().getObject( targetId, EditText.class ) ).thenReturn( text );
    when( widgetToolkit.getObjectRegistry().getObject( targetId, View.class ) ).thenReturn( text );
    return text;
  }

  private ListenOperation createModifyListenOperation( String targetId, boolean modify ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    Properties properties = new Properties();
    properties.add( "Modify", modify );
    op.setProperties( properties );
    return op;
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testListenRemoveModifyListener() throws Exception {
    when( listenerRegistry.findListener( EDIT_TEXT_ID, CompositeFocusListener.class ) )
      .thenReturn( mock( CompositeFocusListener.class ) );
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    TextWatcher listener = mock( TextWatcher.class );
    text.addTextChangedListener( listener );
    when( listenerRegistry.unregisterListener( EDIT_TEXT_ID, TextWatcher.class ) ).thenReturn( listener );
    AbstractWidgetOperator operator = new TextOperator( activity );
    operator.create( createCreateOperation() );
    when( objectRegistry.getObject( eq( EDIT_TEXT_ID ), any( Class.class ) ) ).thenReturn( text );
    ListenOperation op = createModifyListenOperation( EDIT_TEXT_ID, false );
    TabrisShadowEditText shadowText = ( TabrisShadowEditText )Robolectric.shadowOf( text );

    assertEquals( 1, shadowText.getWatchers().size() );

    operator.listen( op );

    assertEquals( 0, shadowText.getWatchers().size() );
  }
}
