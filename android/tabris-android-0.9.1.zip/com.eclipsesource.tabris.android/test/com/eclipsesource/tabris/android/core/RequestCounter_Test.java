
package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class RequestCounter_Test {

  @Test
  public void testShouldBeInitializedWithZero() {
    RequestCounter requestCounter = new RequestCounter();

    Integer result = requestCounter.get();

    assertEquals( Integer.valueOf( 0 ), result );
  }

  @Test
  public void testGetAndSetShouldModifyCounter() throws Exception {
    RequestCounter requestCounter = new RequestCounter();

    requestCounter.set( 123 );

    assertEquals( Integer.valueOf( 123 ), requestCounter.get() );
  }

}
