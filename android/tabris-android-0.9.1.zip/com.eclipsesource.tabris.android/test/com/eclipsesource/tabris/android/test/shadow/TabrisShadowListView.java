/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowListView;

@Implements(ListView.class)
public class TabrisShadowListView extends ShadowListView {

  private AdapterView.OnItemLongClickListener onItemLongClickListener;
  private boolean longClickable;

  @Override
  @Implementation
  public void setOnItemLongClickListener( OnItemLongClickListener listener ) {
    super.setOnItemLongClickListener( listener );
    this.onItemLongClickListener = listener;
  }

  public OnItemLongClickListener getOnItemLongClickListener() {
    return onItemLongClickListener;
  }

  @Implementation
  public void setLongClickable( boolean longClickable ) {
    this.longClickable = longClickable;
  }

  @Implementation
  public boolean isLongClickable() {
    return longClickable;
  }
}
