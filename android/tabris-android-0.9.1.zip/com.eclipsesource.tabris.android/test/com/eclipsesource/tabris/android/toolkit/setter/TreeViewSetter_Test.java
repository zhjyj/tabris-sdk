/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.AlternativeSelection;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeViewSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( UiTestUtil.createActivityWithMockedFields() );
    setter.execute( null, mock( Properties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( UiTestUtil.createActivityWithMockedFields() );
    setter.execute( mock( TreeView.class ), null );
  }

  @Test
  public void testNullCustomVariantShouldNotChangeAlternativeSelection() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( activity );
    Properties props = new Properties();
    props.add( "customVariant", null );
    TreeView treeView = mock( TreeView.class );

    setter.execute( treeView, props );

    verify( treeView, never() ).setAlternativeSelection( any( AlternativeSelection.class ) );
  }

  @Test
  public void testShouldSetAlternativeSelectionAll() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( activity );
    Properties props = new Properties();
    props.add( "customVariant", "variant_ALT_SELECTION" );
    TreeView treeView = mock( TreeView.class );

    setter.execute( treeView, props );

    verify( treeView ).setAlternativeSelection( AlternativeSelection.ALL );
  }

  @Test
  public void testShouldSetAlternativeSelectionLeaf() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( activity );
    Properties props = new Properties();
    props.add( "customVariant", "variant_ALT_SELECTION_LEAF" );
    TreeView treeView = mock( TreeView.class );

    setter.execute( treeView, props );

    verify( treeView ).setAlternativeSelection( AlternativeSelection.LEAF );
  }

  @Test
  public void testShouldSetAlternativeSelectionBranch() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( activity );
    Properties props = new Properties();
    props.add( "customVariant", "variant_ALT_SELECTION_BRANCH" );
    TreeView treeView = mock( TreeView.class );

    setter.execute( treeView, props );

    verify( treeView ).setAlternativeSelection( AlternativeSelection.BRANCH );
  }
}
