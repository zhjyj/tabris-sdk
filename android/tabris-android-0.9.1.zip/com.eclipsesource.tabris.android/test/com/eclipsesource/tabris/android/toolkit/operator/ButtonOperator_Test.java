/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.os.MessageQueue;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.ToggleButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowCompoundButton;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.setter.ButtonSetter;
import com.eclipsesource.tabris.android.toolkit.setter.CompoundButtonSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.CheckedChangedListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ButtonOperator_Test {

  private static final String BUTTON_ID = "w3";
  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentView;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    toolkit = new AndroidWidgetToolkit( activity, mock( MessageQueue.class ) );
    parentView = new FrameLayout( activity );
    toolkit.getObjectRegistry().register( PARENT_ID, parentView, "FrameLayout" );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
  }

  @Test
  public void testViewSetterPush() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    assertTrue( operator.getViewSetter( mock( Button.class ) ) instanceof ButtonSetter );
  }

  @Test
  public void testViewSetterToggle() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    assertTrue( operator.getViewSetter( mock( ToggleButton.class ) ) instanceof CompoundButtonSetter );
  }

  @Test
  public void testViewSetterCheck() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    assertTrue( operator.getViewSetter( mock( CheckBox.class ) ) instanceof CompoundButtonSetter );
  }

  @Test
  public void testViewSetterRadio() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    assertTrue( operator.getViewSetter( mock( RadioButton.class ) ) instanceof CompoundButtonSetter );
  }

  @Test
  public void testViewSetterSameInstance() throws Exception {
    Button button = mock( Button.class );
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    assertSame( operator.getViewSetter( button ), operator.getViewSetter( button ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ButtonOperator operator = new ButtonOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateButtonNoProps() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateButtonNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateButtonNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateButtonParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateButtonOkDefault() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    getCreatedValidatedButton();
  }

  @Test
  public void testCreateButtonStyleCheck() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( ButtonOperator.STYLE_CHECK ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertEquals( CheckBox.class, view.getClass() );
    assertEquals( BUTTON_ID, activity.getRemoteObject( view ).getId() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .findListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( CheckedChangedListener.class ) );
  }

  @Test
  public void testCreateButtonStyleRadio() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( ButtonOperator.STYLE_RADIO ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertEquals( RadioButton.class, view.getClass() );
    assertEquals( BUTTON_ID, activity.getRemoteObject( view ).getId() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .findListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( CheckedChangedListener.class ) );
  }

  @Test
  public void testCreateButtonStylePush() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( ButtonOperator.STYLE_PUSH ) );

    operator.create( op );

    getCreatedValidatedButton();
  }

  @Test
  public void testCreateButtonStyleToggle() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowCompoundButton.class );
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( ButtonOperator.STYLE_TOGGLE ) );
    op.getProperties().add( "text", "Hello" );

    operator.create( op );

    ToggleButton view = UiTestUtil.findObjectById( activity, BUTTON_ID, ToggleButton.class );
    assertEquals( ToggleButton.class, view.getClass() );
    assertEquals( BUTTON_ID, activity.getRemoteObject( view ).getId() );
    // Robolectric does not have a shadow object for ToggleButton so
    // we can not check if the text on/off has been set.
    // assertEquals( text, view.getTextOn() );
    // assertEquals( text, view.getTextOff() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .findListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( CheckedChangedListener.class ) );
    TabrisShadowCompoundButton shadow = ( TabrisShadowCompoundButton )Robolectric.shadowOf( view );
    assertEquals( 1, shadow.getLines() );
  }

  private Button getCreatedValidatedButton() {
    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertTrue( view instanceof Button );
    assertEquals( BUTTON_ID, activity.getRemoteObject( view ).getId() );
    return ( Button )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    op.setType( "rwt.widgets.Button" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateAndInitiateView() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Button view = UiTestUtil.findObjectById( activity, BUTTON_ID, Button.class );
    assertEquals( parentView, view.getParent() );
  }

  @Test
  public void testGetType() throws Exception {
    ButtonOperator op = new ButtonOperator( new TabrisActivity() );
    assertEquals( ButtonOperator.TYPE, op.getType() );
  }
}
