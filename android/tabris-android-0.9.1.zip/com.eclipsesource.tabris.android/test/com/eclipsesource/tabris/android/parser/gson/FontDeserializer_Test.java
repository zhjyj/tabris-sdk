/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Type;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

public class FontDeserializer_Test {

  private Type type;
  private JsonDeserializationContext context;

  @Before
  public void setUp() {
    type = Mockito.mock( Type.class );
    context = Mockito.mock( JsonDeserializationContext.class );
  }

  @Test
  public void testDeserializeNoneJsonArray() {
    FontDeserializer deserializer = new FontDeserializer();
    Font result = deserializer.deserialize( null, type, context );
    assertNull( result );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeJsonArrayWithWrongElementCount() {
    FontDeserializer deserializer = new FontDeserializer();
    JsonArray array = new JsonArray();
    deserializer.deserialize( array, type, context );
  }

  @Test
  public void testDeserializeFamilyNotStringArray() throws Exception {
    assertFontFamilyIsNull( new JsonPrimitive( "fontFamily" ) );
  }

  @Test
  public void testDeserializeFamilyEmpty() throws Exception {
    assertFontFamilyIsNull( new JsonArray() );
  }

  @Test
  public void testDeserializeFamilyNotJsonPrimitve() throws Exception {
    JsonArray familyArray = new JsonArray();
    familyArray.add( new JsonObject() );
    assertFontFamilyIsNull( familyArray );
  }

  private void assertFontFamilyIsNull( JsonElement element ) {
    FontDeserializer deserializer = new FontDeserializer();
    JsonArray array = new JsonArray();
    array.add( element );
    array.add( new JsonPrimitive( 12 ) );
    array.add( new JsonPrimitive( true ) );
    array.add( new JsonPrimitive( false ) );
    Font font = deserializer.deserialize( array, type, context );
    assertNull( font.getFamily() );
  }

  @Test
  public void testDeserializeFamilyToList() throws Exception {
    FontDeserializer deserializer = new FontDeserializer();
    JsonArray array = new JsonArray();
    JsonArray familyArray = new JsonArray();
    familyArray.add( new JsonPrimitive( "" ) );
    familyArray.add( new JsonPrimitive( true ) );
    array.add( familyArray );
    array.add( new JsonPrimitive( 12 ) );
    array.add( new JsonPrimitive( true ) );
    array.add( new JsonPrimitive( false ) );
    Font font = deserializer.deserialize( array, type, context );
    assertNotNull( font.getFamily() );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeFamilyToListFails() throws Exception {
    FontDeserializer deserializer = new FontDeserializer();
    JsonArray array = new JsonArray();
    JsonArray familyArray = new JsonArray();
    familyArray.add( new JsonPrimitive( "" ) );
    familyArray.add( new JsonArray() );
    array.add( familyArray );
    array.add( new JsonPrimitive( 12 ) );
    array.add( new JsonPrimitive( true ) );
    array.add( new JsonPrimitive( false ) );
    deserializer.deserialize( array, type, context );
  }

  @Test
  public void testDeserializeSizeBoldItalicOk() throws Exception {
    Font font = createFont( new JsonPrimitive( 12 ),
                            new JsonPrimitive( true ),
                            new JsonPrimitive( false ) );
    assertEquals( 12, ( int )font.getSize() );
    assertTrue( font.getBold() );
    assertFalse( font.getItalic() );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeSizeFail() throws Exception {
    createFont( new JsonArray(), new JsonPrimitive( true ), new JsonPrimitive( 23 ) );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeBoldFail() throws Exception {
    createFont( new JsonPrimitive( 12 ), new JsonArray(), new JsonPrimitive( 23 ) );
  }

  @Test(expected = ParseException.class)
  public void testDeserializeItalicFail() throws Exception {
    createFont( new JsonPrimitive( 12 ), new JsonPrimitive( 33 ), new JsonArray() );
  }

  private Font createFont( JsonElement size, JsonElement bold, JsonElement italic ) {
    FontDeserializer deserializer = new FontDeserializer();
    JsonArray array = new JsonArray();
    JsonArray familyArray = new JsonArray();
    familyArray.add( new JsonPrimitive( "" ) );
    array.add( familyArray );
    array.add( size );
    array.add( bold );
    array.add( italic );
    return deserializer.deserialize( array, type, context );
  }
}
