package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class OperationSerializer_Test {
  
  private Gson gson;

  @Before
  public void setUp() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( SetOperation.class, new OperationSerializer() );
    gsonBuilder.registerTypeAdapter( CallOperation.class, new OperationSerializer() );
    gsonBuilder.registerTypeAdapter( NotifyOperation.class, new OperationSerializer() );
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesSerializer() );
    gson = gsonBuilder.create();
  }
  
  @Test
  public void testSerializesSetWithProperties() {
    SetOperation setOperation = new SetOperation();
    setOperation.setTarget( "foo" );
    Properties properties = new Properties();
    properties.add( "foo1", "bar1" );
    properties.add( "foo2", "bar2" );
    setOperation.setProperties( properties );
    
    String json = gson.toJson( setOperation );

    SetOperation actualOperation = deserializeOperation( SetOperation.class, json );
    assertEquals( "foo", actualOperation.getTarget() );
    Properties actualProperties = actualOperation.getProperties();
    assertEquals( 2, actualProperties.getAll().size() );
    assertEquals( "bar1", actualProperties.getString( "foo1" ) );
    assertEquals( "bar2", actualProperties.getString( "foo2" ) );
  }
  
  @Test
  public void testSerializesCallWithProperties() {
    CallOperation callOperation = new CallOperation();
    callOperation.setTarget( "foo" );
    callOperation.setMethod( "bar" );
    Properties properties = new Properties();
    properties.add( "foo1", "bar1" );
    properties.add( "foo2", "bar2" );
    callOperation.setProperties( properties );
    
    String json = gson.toJson( callOperation );
    
    CallOperation actualOperation = deserializeOperation( CallOperation.class, json );
    assertEquals( "foo", actualOperation.getTarget() );
    assertEquals( "bar", actualOperation.getMethod() );
    Properties actualProperties = actualOperation.getProperties();
    assertEquals( 2, actualProperties.getAll().size() );
    assertEquals( "bar1", actualProperties.getString( "foo1" ) );
    assertEquals( "bar2", actualProperties.getString( "foo2" ) );
  }
  
  @Test
  public void testSerializesCallWithNullProperties() {
    CallOperation callOperation = new CallOperation();
    callOperation.setTarget( "foo" );
    callOperation.setMethod( "bar" );
    
    String json = gson.toJson( callOperation );
    
    CallOperation actualOperation = deserializeOperation( CallOperation.class, json );
    assertEquals( "foo", actualOperation.getTarget() );
    assertEquals( "bar", actualOperation.getMethod() );
    assertNull( actualOperation.getProperties() );
  }
  
  @Test
  public void testSerializesNotifyWithProperties() {
    NotifyOperation callOperation = new NotifyOperation();
    callOperation.setTarget( "foo" );
    callOperation.setEventType( "bar" );
    Properties properties = new Properties();
    properties.add( "foo1", "bar1" );
    properties.add( "foo2", "bar2" );
    callOperation.setProperties( properties );
    
    String json = gson.toJson( callOperation );
    
    NotifyOperation actualOperation = deserializeOperation( NotifyOperation.class, json );
    assertEquals( "foo", actualOperation.getTarget() );
    assertEquals( "bar", actualOperation.getEventType() );
    Properties actualProperties = actualOperation.getProperties();
    assertEquals( 2, actualProperties.getAll().size() );
    assertEquals( "bar1", actualProperties.getString( "foo1" ) );
    assertEquals( "bar2", actualProperties.getString( "foo2" ) );
  }
  
  @Test
  public void testSerializesNotifyWithNullProperties() {
    NotifyOperation callOperation = new NotifyOperation();
    callOperation.setTarget( "foo" );
    callOperation.setEventType( "bar" );
    
    String json = gson.toJson( callOperation );
    
    NotifyOperation actualOperation = deserializeOperation( NotifyOperation.class, json );
    assertEquals( "foo", actualOperation.getTarget() );
    assertEquals( "bar", actualOperation.getEventType() );
    assertNull( actualOperation.getProperties() );
  }

  private <T> T deserializeOperation( Class<T> type, String json ) {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( type, new OperationDeserializer() );
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesDeserializer() );
    Gson deserializer = gsonBuilder.create();
    return deserializer.fromJson( json, type );
  }

}
