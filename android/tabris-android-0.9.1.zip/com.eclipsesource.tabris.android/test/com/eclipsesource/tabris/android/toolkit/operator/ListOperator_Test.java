/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowListView;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.ListSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DelegatingItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ScrollListener;
import com.eclipsesource.tabris.android.toolkit.view.TouchPositionBuffer;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowListView;

@RunWith(RobolectricTestRunner.class)
public class ListOperator_Test {

  private static final String PARENT_ID = "w1";

  private static final String LIST_VIEW_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( LIST_VIEW_ID );
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = activity.getProcessor();
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, processor ) );
    toolkit = processor.getWidgetToolkit();
    ObjectRegistry objectRegistry = toolkit.getObjectRegistry();
    when( objectRegistry.getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( objectRegistry.getRemoteObject( anyString() ) ).thenReturn( mock( RemoteObject.class ) );
    rootLayout.addView( parentLayout );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );

    assertTrue( operator.getViewSetter( mock( List.class ) ) instanceof ListSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ListOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ListOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoProps() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewParentNotFrameLayout() throws Exception {
    String listViewId = "ListView";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    ListView listView = new ListView( activity );
    listView.setTag( new RemoteObject( listViewId, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( listView );

    AbstractWidgetOperator operator = new LabelOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    Properties props = new Properties();
    props.add( "parent", listViewId );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    op.setType( "rwt.widgets.List" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateListViewOk() throws Exception {
    ListOperator operator = new ListOperator( activity );
    CreateOperation op = createValidCreateOperation();
    registerCompositTouchListener( LIST_VIEW_ID );

    operator.create( op );

    ArgumentCaptor<View> captor = ArgumentCaptor.forClass( View.class );
    verify( toolkit.getObjectRegistry() ).register( eq( LIST_VIEW_ID ), captor.capture(), eq( "rwt.widgets.List" ) );
    View view = captor.getValue();
    assertTrue( view instanceof List );
    assertEquals( LIST_VIEW_ID, activity.getRemoteObject( view ).getId() );
    List list = ( List )view;
    OnItemClickListener onItemClickListener = list.getOnItemClickListener();
    assertNotNull( onItemClickListener );
    assertEquals( CompositeItemClickListener.class, onItemClickListener.getClass() );
    ArrayList<OnItemClickListener> listeners = ( ( CompositeItemClickListener )onItemClickListener ).getListeners();
    assertEquals( 1, listeners.size() );
    assertEquals( ListItemClickListener.class, listeners.get( 0 ).getClass() );
    ShadowListView shadow = Robolectric.shadowOf( ( List )view );
    OnItemSelectedListener onItemSelectedListener = list.getOnItemSelectedListener();
    assertNotNull( onItemSelectedListener );
    assertEquals( DelegatingItemSelectedListener.class, onItemSelectedListener.getClass() );
    assertNotNull( shadow.getOnScrollListener() );
    assertEquals( ScrollListener.class, shadow.getOnScrollListener().getClass() );
    verify( toolkit.getListenerRegistry(), times( 2 ) ).registerListener( eq( LIST_VIEW_ID ),
                                                                          any( TouchPositionBuffer.class ) );
  }

  @Test
  public void testGetType() {
    ListOperator listOperator = new ListOperator( new TabrisActivity() );

    String type = listOperator.getType();

    assertEquals( "rwt.widgets.List", type );
  }

  private CompositeTouchListener registerCompositTouchListener( String widgetId ) {
    ListenerRegistry registry = toolkit.getListenerRegistry();
    CompositeTouchListener compositTouchListener = mock( CompositeTouchListener.class );
    when( registry.findListener( widgetId, CompositeTouchListener.class ) ).thenReturn( compositTouchListener );
    return compositTouchListener;
  }

  @Test
  public void testAttachMenuDetectListener() {
    Robolectric.bindShadowClass( TabrisShadowListView.class );
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    Properties listenProps = new Properties();
    listenProps.add( "MenuDetect", true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );

    op.listen( listenOp );

    TabrisShadowListView shadow = ( TabrisShadowListView )Robolectric.shadowOf( listView );
    assertNotNull( shadow.getOnItemLongClickListener() );
  }

  @Test
  public void testRemoveMenuDetectListener() {
    Robolectric.bindShadowClass( TabrisShadowListView.class );
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    Properties listenProps = new Properties();
    listenProps.add( "MenuDetect", true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );

    op.listen( listenOp );

    listenProps.add( "MenuDetect", false );

    op.listen( listenOp );

    TabrisShadowListView shadow = ( TabrisShadowListView )Robolectric.shadowOf( listView );
    assertNull( shadow.getOnItemLongClickListener() );
    assertFalse( listView.isLongClickable() );
  }

  private ListenerRegistry createAndRegisterListenerRegistry( ListOperator op ) {
    ListenerRegistry listenerRegistry = mock( ListenerRegistry.class );
    when( op.getListenerRegistry() ).thenReturn( listenerRegistry );
    return listenerRegistry;
  }

  private List createAndRegisterListView() {
    List result = new List( activity );
    when( toolkit.getObjectRegistry().getObject( LIST_VIEW_ID, List.class ) ).thenReturn( result );
    parentLayout.addView( result );
    return result;
  }

  @Test
  public void testDestroy() {
    ListOperator op = new ListOperator( activity );
    ListenerRegistry listenerRegistry = createAndRegisterListenerRegistry( op );
    List listView = createAndRegisterListView();
    DestroyOperation destroyOp = new DestroyOperation();
    destroyOp.setTarget( LIST_VIEW_ID );
    when( op.findViewByTarget( destroyOp ) ).thenReturn( listView );

    op.destroy( destroyOp );

    verify( listenerRegistry ).unregisterListener( eq( LIST_VIEW_ID ),
                                                   eq( ScrollListener.class ) );
    verify( toolkit.getListenerRegistry() ).unregisterListener( LIST_VIEW_ID,
                                                                TouchPositionBuffer.class );
    InOrder order = inOrder( toolkit.getObjectRegistry() );
    order.verify( toolkit.getObjectRegistry() ).getObject( LIST_VIEW_ID, List.class );
    order.verify( toolkit.getObjectRegistry() ).unregister( LIST_VIEW_ID );
    ShadowListView shadow = Robolectric.shadowOf( listView );
    assertNull( shadow.getOnScrollListener() );
  }
}
