/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_SELECTION_LENGTH;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_SELECTION_START;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class TextSelectionChangeListener {

  private final EditText view;
  private final TabrisActivity activity;

  public TextSelectionChangeListener( TabrisActivity activity, EditText view ) {
    notNull( activity, "Activity" );
    notNull( view, "EditText" );
    this.activity = activity;
    this.view = view;
  }

  public void afterSelectionChanged( int selectionStart, int selectionLength ) {
    RemoteObject remoteObject = activity.getRemoteObject( view );
    remoteObject.set( PROP_SELECTION_START, selectionStart );
    remoteObject.set( PROP_SELECTION_LENGTH, selectionLength );
  }
}
