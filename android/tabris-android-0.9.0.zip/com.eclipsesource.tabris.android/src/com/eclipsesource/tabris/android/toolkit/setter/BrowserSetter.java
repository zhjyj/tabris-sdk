/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.net.MalformedURLException;
import java.net.URL;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Browser;

public class BrowserSetter<T extends Browser> extends ViewSetter<Browser> {

  public BrowserSetter( TabrisActivity activity ) {
    super( activity );
  }

  private static final String RWT_RESOURCES = "rwt-resources";

  @Override
  public void execute( Browser browser, Properties properties ) {
    super.execute( browser, properties );
    setUrl( browser, properties );
  }

  private void setUrl( Browser browser, Properties properties ) {
    String url = properties.getString( ProtocolConstants.PROP_URL );
    if( url != null ) {
      if( url.startsWith( RWT_RESOURCES ) ) {
        URL endPoint = getProcessor().getTransport().getEndPoint();
        try {
          URL fullUrl = new URL( endPoint.getProtocol(),
                                 endPoint.getHost(),
                                 endPoint.getPort(),
                                 StringUtil.SLASH + url );
          browser.loadUrl( fullUrl.toExternalForm() );
        } catch( MalformedURLException e ) {
          throw new IllegalStateException( "Can not create url from '" + endPoint + "' and " + url );
        }
      } else {
        browser.loadUrl( url );
      }
    }
  }
}
