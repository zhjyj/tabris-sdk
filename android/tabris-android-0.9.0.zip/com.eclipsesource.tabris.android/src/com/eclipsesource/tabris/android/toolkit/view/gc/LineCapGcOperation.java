/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Paint.Cap;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class LineCapGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "lineCap";
  private static final String CAP_ROUND = "round";
  private static final String CAP_SQUARE = "square";
  private static final String CAP_BUTT = "butt";

  public LineCapGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    String capStr = ( String )properties.get( 1 );
    Cap lineCap = null;
    if( capStr.equals( CAP_ROUND ) ) {
      lineCap = Cap.ROUND;
    } else if( capStr.equals( CAP_SQUARE ) ) {
      lineCap = Cap.SQUARE;
    } else if( capStr.equals( CAP_BUTT ) ) {
      lineCap = Cap.BUTT;
    }
    gc.getPaint().setStrokeCap( lineCap );
  }

}
