/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public enum Action {

  CREATE(CreateOperation.ACTION),
  SET(SetOperation.ACTION),
  LISTEN(ListenOperation.ACTION),
  CALL(CallOperation.ACTION),
  DESTROY(DestroyOperation.ACTION),
  EXECUTE(ExecuteOperation.ACTION);

  private final String key;

  Action( String key ) {
    this.key = key;
  }

  public static Action findAction( String key ) {
    if( key == null ) {
      throw new IllegalArgumentException( "Can not find action for null key." );
    }
    Action[] values = values();
    for( Action action : values ) {
      if( action.key.equals( key ) ) {
        return action;
      }
    }
    return null;
  }
}
