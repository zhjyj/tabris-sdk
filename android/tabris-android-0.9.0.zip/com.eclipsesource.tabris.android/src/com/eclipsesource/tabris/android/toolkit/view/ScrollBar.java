package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNullOrEmpty;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;


public class ScrollBar {

  private final String style;
  private final String parentId;
  private boolean visiblity;
  private final TabrisActivity activity;

  public ScrollBar( TabrisActivity activity, String style, String parentId ) {
    notNull( activity, "Activity" );
    notNullOrEmpty( style, "Style" );
    notNullOrEmpty( parentId, "Parent" );
    this.style = style;
    this.parentId = parentId;
    this.activity = activity;
  }

  public void setVisibility( Boolean visiblity ) {
    this.visiblity = visiblity;
  }

  public boolean getVisibility() {
    return visiblity;
  }

  public String getStyle() {
    return style;
  }

  public String getParent() {
    return parentId;
  }

  public void scrollChanged() {
    RemoteObject remoteObject = activity.getRemoteObject( this );
    remoteObject.notify( EVENT_SELECTION, null );
  }

}
