/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;

public class ToolBarOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.ToolBar";

  private final IViewSetter<? extends View> setter;

  public ToolBarOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ViewSetter<View>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    initiateNewView( operation, new ToolBar( getActivity() ) );
  }

}
