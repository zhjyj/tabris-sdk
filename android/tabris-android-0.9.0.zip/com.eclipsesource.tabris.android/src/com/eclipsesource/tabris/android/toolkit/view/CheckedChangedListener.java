/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class CheckedChangedListener implements OnCheckedChangeListener {

  private final TabrisActivity activity;

  public CheckedChangedListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onCheckedChanged( CompoundButton buttonView, boolean isChecked ) {
    RemoteObject remoteObject = activity.getRemoteObject( buttonView );
    remoteObject.set( PROP_SELECTION, isChecked );
  }
}