/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;

public class TabHostSetter<T extends TabFolder> extends ViewSetter<TabFolder> {

  public TabHostSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  protected void setSelection( View view, Properties properties ) {
    // Not yet implemented
  }
}
