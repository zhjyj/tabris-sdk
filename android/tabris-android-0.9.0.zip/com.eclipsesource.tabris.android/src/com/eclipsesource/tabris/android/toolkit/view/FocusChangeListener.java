/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator.DISPLAY_ID;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.view.View;
import android.view.View.OnFocusChangeListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;

public class FocusChangeListener implements OnFocusChangeListener {

  private final TabrisActivity activity;

  public FocusChangeListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onFocusChange( View view, boolean hasFocus ) {
    notNull( view, "View" );
    RemoteObject remoteObject = activity.getRemoteObject( view );
    if( hasFocus ) {
      remoteObject.notify( "FocusIn", null );
    } else {
      remoteObject.notify( "FocusOut", null );
    }
    updateFocusControl( view, hasFocus, remoteObject.getId() );
  }

  private void updateFocusControl( View view, boolean hasFocus, String viewId ) {
    String focusedWidget;
    if( hasFocus ) {
      focusedWidget = viewId;
    } else {
      focusedWidget = DISPLAY_ID;
    }
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    RemoteObject remoteObject = objectRegistry.getRemoteObject( DISPLAY_ID );
    remoteObject.set( "focusControl", focusedWidget );
  }
}
