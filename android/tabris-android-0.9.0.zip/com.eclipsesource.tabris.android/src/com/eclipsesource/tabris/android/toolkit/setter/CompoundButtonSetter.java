/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;

public class CompoundButtonSetter<T extends CompoundButton> extends ButtonSetter<T> {

  public CompoundButtonSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T view, Properties properties ) {
    super.execute( view, properties );
    if( view == null ) {
      throw new IllegalArgumentException( "The view to set properties on can not be null" );
    }
    if( properties == null ) {
      throw new IllegalArgumentException( "The properties to set properties on a view can not be null" );
    }
    setChecked( view, properties );
  }

  private void setChecked( CompoundButton view, Properties properties ) {
    Boolean selection = properties.getBoolean( ProtocolConstants.PROP_SELECTION );
    if( selection != null ) {
      view.setChecked( selection );
    }
  }

}
