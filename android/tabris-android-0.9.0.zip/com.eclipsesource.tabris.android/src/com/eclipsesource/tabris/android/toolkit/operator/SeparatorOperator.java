/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.SeparatorSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Separator.Orientation;

public class SeparatorOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Separator";

  private static final String STYLE_HORIZONTAL = "HORIZONTAL";

  private final IViewSetter<? extends View> setter;

  public SeparatorOperator( TabrisActivity activity ) {
    super( activity );
    setter = new SeparatorSetter<Separator>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Separator separator = new Separator( getActivity() );
    List<String> style = operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class );
    if( style != null && style.contains( STYLE_HORIZONTAL ) ) {
      separator.setOrientation( Orientation.HORIZONTAL );
    } else {
      separator.setOrientation( Orientation.VERTICAL );
    }
    initiateNewView( operation, separator );
  }

}
