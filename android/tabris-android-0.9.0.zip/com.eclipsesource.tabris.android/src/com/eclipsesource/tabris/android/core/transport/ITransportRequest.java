/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

public interface ITransportRequest {

  String getPath();

  String getQuery();

  void setQuery( String query );

  /**
   * Sets the timeout of the particular request.
   * <ul>
   * <li>Set -1 (default) to ignore the individual value and use the application
   * default instead</li>
   * <li>Set 0 to set an infinite timeout</li>
   * <li>Set a value > 0 to set the specific timeout</li>
   * </ul>
   *
   * @param timeouty the timeout to set
   */
  void setTimeout( int timeout );

  /**
   * @see #setTimeout(int)
   * @return the currently configured timeout
   */
  int getTimeout();

  /**
   * Silent requests do not show up in the ui in case of failure.
   *
   * @return <code>true</code> if the request is silent or <code>false</code>
   *         otherwise
   */
  boolean isSilentRequest();

  void setSilentRequest( boolean backgroundRequest );

}
