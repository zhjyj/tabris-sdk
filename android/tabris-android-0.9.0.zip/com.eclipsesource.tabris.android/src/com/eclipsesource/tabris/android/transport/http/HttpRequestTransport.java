
package com.eclipsesource.tabris.android.transport.http;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportException;

public class HttpRequestTransport implements ITransport {

  public static final String SESSION_ID_PREFIX = ";jsessionid=";
  public static final String CONTENT_TYPE_JSON = "application/json";

  private final URL endPoint;
  private final String userAgent;
  private String sessionId;

  public HttpRequestTransport( URL endPointUrl, String userAgent ) {
    notNull( endPointUrl, "endPointUrl" );
    notNull( userAgent, "userAgent" );
    this.endPoint = endPointUrl;
    this.userAgent = userAgent;
  }

  public ITransportResult get( GetRequest request ) {
    notNull( request, "request" );
    HttpTransportResult result = new HttpTransportResult();
    try {
      URL url = getUri( request ).toURL();
      HttpRequest get = initRequest( createGetRequest( url ) );
      executeRequest( result, get );
    } catch( Exception connectionException ) {
      result.setException( new TransportException( "GET request could not be executed: " + request,
                                                   connectionException ) );
    }
    return result;
  }

  protected HttpRequest createGetRequest( URL url ) {
    return HttpRequest.get( url );
  }

  public ITransportResult post( PostRequest request ) {
    notNull( request, "request" );
    HttpTransportResult result = new HttpTransportResult();
    try {
      URL url = getUri( request ).toURL();
      HttpRequest post = initRequest( createPostRequest( url ) ).contentType( CONTENT_TYPE_JSON );
      if( request.getContent() != null ) {
        post = post.send( request.getContent() );
      }
      executeRequest( result, post );
    } catch( Exception connectionException ) {
      result.setException( new TransportException( "POST request could not be executed: " + request,
                                                   connectionException ) );
    }
    return result;
  }

  protected HttpRequest createPostRequest( URL url ) {
    return HttpRequest.post( url );
  }

  private HttpRequest initRequest( HttpRequest request ) {
    HttpRequest initializedRequest = request.userAgent( userAgent )
      .acceptGzipEncoding()
      .uncompress( true )
      .trustAllCerts()
      .trustAllHosts();
    return initializedRequest;
  }

  private void executeRequest( HttpTransportResult result, HttpRequest request ) {
    if( request.ok() ) {
      result.setResult( request.stream() );
    } else {
      result.setException( new TransportException( createErrorMessage( request ), request.code() ) );
    }
  }

  private String createErrorMessage( HttpRequest request ) {
    String result = "Unassigned Error";
    if( request.badRequest() ) {
      result = "Request was bad. Server returned: " + request.message();
    } else if( request.serverError() ) {
      result = "There was a server error with the message: " + request.message();
    } else if( request.notFound() ) {
      result = "Application at " + request.getConnection().getURL() + " not found.";
    }
    return result;
  }

  private URI getUri( ITransportRequest request ) {
    try {
      String path = createPath( request, endPoint.getPath() );
      String queryParameter = createQuery( request );
      return createUri( path, queryParameter );
    } catch( URISyntaxException e ) {
      throw new TransportException( "Could not create request uri with "
                                    + endPoint
                                    + " for "
                                    + request, e );
    }
  }

  private String createPath( ITransportRequest request, String endPoint ) {
    StringBuilder stringBuilder = new StringBuilder( endPoint );
    if( request.getPath() != null ) {
      stringBuilder.append( request.getPath() );
    }
    if( sessionId != null ) {
      stringBuilder.append( SESSION_ID_PREFIX );
      stringBuilder.append( sessionId );
    }
    return stringBuilder.toString();
  }

  private String createQuery( ITransportRequest request ) {
    StringBuilder query = new StringBuilder();
    if( endPoint.getQuery() != null ) {
      query.append( endPoint.getQuery() );
    }
    if( request.getQuery() != null ) {
      query.append( request.getQuery() );
    }
    return query.toString();
  }

  private URI createUri( String path, String queryParameter ) throws URISyntaxException {
    return new URI( endPoint.getProtocol(),
                    endPoint.getUserInfo(),
                    endPoint.getHost(),
                    endPoint.getPort(),
                    path,
                    queryParameter.toString(),
                    endPoint.getRef() );
  }

  public URL getEndPoint() {
    return endPoint;
  }

  public void dispose() {
    // disposing is not necessary
  }

  public void setSessionId( String sessionId ) {
    this.sessionId = sessionId;
  }

}
