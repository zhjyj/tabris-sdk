/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.core.transport.TransportException;
import com.eclipsesource.tabris.android.parser.gson.GsonProtocolParser;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.AppState;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.eclipsesource.tabris.android.transport.http.HttpRequestTransport;

public class TabrisActivity extends Activity {

  public static final String LOG_TAG = "Tabris";

  public static final String END_POINT = "endPoint";
  public static final String AUTO_START_SESSION = "autoStartSession";
  public static final String THEME = "theme";
  public static final String RESULT_MESSAGE = "throwableMessage";
  public static final int RESULT_CODE_ERROR = 2;

  private static final String TABRIS_VERSION = "0.9";

  private ProtocolProcessor processor;

  @Override
  public void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    try {
      validateIntent();
      applyThemeFromIntent();
      setContentView( R.layout.protocol );
      initProcessor();
    } catch( Throwable t ) {
      closeActivity( t );
    }
  }

  @Override
  protected void onResume() {
    super.onResume();
    processor.getWidgetToolkit().appStateChanged( AppState.RESUME );
  }

  @Override
  protected void onPause() {
    super.onPause();
    processor.getWidgetToolkit().appStateChanged( AppState.PAUSE );
  }

  @Override
  protected void onActivityResult( int requestCode, int resultCode, Intent data ) {
    processor.getWidgetToolkit().receivedActivityResult( requestCode, resultCode, data );
  }

  public void closeActivity( Throwable t ) {
    if( BuildConfig.DEBUG ) {
      Log.e( TabrisActivity.LOG_TAG, t.getMessage(), t );
    }
    Intent result = new Intent();
    result.putExtra( RESULT_MESSAGE, t.getMessage() );
    setResult( RESULT_CODE_ERROR, result );
    if( !isFinishing() ) {
      finish();
    }
  }

  private void initProcessor() {
    processor = new ProtocolProcessor();
    processor.setWidgetToolkit( new AndroidWidgetToolkit( this, Looper.myQueue() ) );
    processor.setParser( new GsonProtocolParser() );
    processor.setTransport( new HttpRequestTransport( getEndPointUrlFromIntent(), createUserAgent() ) );
  }

  public ProtocolProcessor getProcessor() {
    return processor;
  }

  public RemoteObject getDisplayRemoteObject() {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    ObjectRegistry objectRegistry = toolkit.getObjectRegistry();
    return objectRegistry.getRemoteObject( DisplayOperator.DISPLAY_ID );
  }

  public RemoteObject getRemoteObject( Object object ) {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    ObjectRegistry objectRegistry = toolkit.getObjectRegistry();
    return objectRegistry.getRemoteObjectForObject( object );
  }

  /** To be used for testing only. */
  public void setProcessor( ProtocolProcessor processor ) {
    this.processor = processor;
  }

  String createUserAgent() {
    StringBuilder strBuilder = new StringBuilder();
    strBuilder.append( "com.eclipsesource.tabris.android/" );
    strBuilder.append( Build.VERSION.RELEASE );
    strBuilder.append( "," );
    strBuilder.append( Build.VERSION.SDK_INT );
    strBuilder.append( " (" );
    strBuilder.append( Build.MANUFACTURER );
    strBuilder.append( "; " );
    strBuilder.append( Build.MODEL );
    strBuilder.append( ") Tabris/" );
    strBuilder.append( TABRIS_VERSION );
    return strBuilder.toString();
  }

  private void applyThemeFromIntent() {
    int themeKey = getThemeFromIntent();
    if( themeKey == 1 ) {
      setTheme( R.style.Theme_Holo_Light_Tabris );
    } else if( themeKey == 2 ) {
      setTheme( R.style.Theme_Holo_Tabris );
    }
  }

  private void validateIntent() {
    if( getIntent() == null ) {
      throw new IllegalArgumentException( "The UiActivity needs to be created with an intent" );
    }
  }

  private URL getEndPointUrlFromIntent() {
    String endPoint = getIntent().getStringExtra( END_POINT );
    if( endPoint == null ) {
      throw new IllegalArgumentException( "Extra data passed to Intent of UiActivity needs to provide a transport end-point." );
    }
    URL endPointUrl;
    try {
      endPointUrl = new URL( endPoint );
      if( endPointUrl.getHost().equals( "" ) ) {
        throw new TransportException( "The given end-point url does not provide a host: "
                                      + endPoint, null );
      }
    } catch( MalformedURLException e ) {
      throw new TransportException( "The given end-point url is not well formed: " + endPoint, e );
    }
    return endPointUrl;
  }

  private int getThemeFromIntent() {
    return getIntent().getIntExtra( THEME, 1 );
  }

  @Override
  public boolean onKeyDown( int keyCode, KeyEvent event ) {
    if( KeyEvent.KEYCODE_BACK == keyCode ) {
      FrameLayout viewGroup = ( FrameLayout )findViewById( R.id.root_layout );
      if( numberOfShellsIn( viewGroup ) <= 1 ) {
        finish();
      } else {
        sendCloseTopMostShellEvent( viewGroup );
      }
      return true;
    } else {
      return super.onKeyDown( keyCode, event );
    }
  }

  private int numberOfShellsIn( FrameLayout viewGroup ) {
    int result = 0;
    for( int i = 0; i < viewGroup.getChildCount(); i++ ) {
      if( viewGroup.getChildAt( i ) instanceof Shell ) {
        result++;
      }
    }
    return result;
  }

  private void sendCloseTopMostShellEvent( FrameLayout viewGroup ) {
    View topMostShell = viewGroup.getChildAt( viewGroup.getChildCount() - 1 );
    RemoteObject remoteObject = getRemoteObject( topMostShell );
    remoteObject.notify( EVENT_SHELL_CLOSE, null );
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    processor.shutdown();
  }

}
