/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class StrokeStyleGcOperation extends PaintColorGcOperation {

  public static final String OPERATION = "strokeStyle";

  public StrokeStyleGcOperation() {
    super( OPERATION );
  }

  @Override
  public void setColor( GraphicalContext gc, int color ) {
    gc.setStrokeColor( color );
  }
}
