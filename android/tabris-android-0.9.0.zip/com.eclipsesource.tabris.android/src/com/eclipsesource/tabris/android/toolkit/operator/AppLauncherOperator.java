
package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.*;
import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.AppLauncher;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;

public class AppLauncherOperator implements IOperator {

  public static final String TYPE = "tabris.AppLauncher";

  private static final String METHOD_OPEN = "open";
  private static final String METHOD_OPEN_URL = "openUrl";
  private static final String APP_MAIL = "MAIL";
  private static final String APP_BROWSER = "BROWSER";
  private static final String APP_PHONE = "PHONE";
  private static final String APP_MAPS = "MAPS";
  private static final String APP_SMS = "SMS";
  private static final String APP_TWITTER = "TWITTER";
  private static final String APP_FACEBOOK = "FACEBOOK";
  private static final String KEY_URL = "url";
  private static final String KEY_TO = "to";
  private static final String KEY_CC = "cc";
  private static final String KEY_SUBJECT = "subject";
  private static final String KEY_BODY = "body";
  private static final String KEY_USE_HTML = "useHtml";
  private static final String KEY_NUMBER = "number";
  private static final String KEY_LATITUDE = "latitude";
  private static final String KEY_LONGITUDE = "longitude";
  private static final String KEY_QUERY = "query";
  private static final String KEY_TEXT = "text";

  private static final String TWITTER_POST_URL = "http://twitter.com/intent/tweet";
  private static final String FACEBOOK_POST_URL = "http://www.facebook.com/sharer/sharer.php";

  private final TabrisActivity activity;

  public AppLauncherOperator( TabrisActivity activity ) {
    notNull( activity, "activity" );
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    notNull( operation, "operation" );
    notNull( operation.getTarget(), "operation target" );
    AppLauncher appLauncher = new AppLauncher( activity );
    getObjectRegistry().register( operation.getTarget(), appLauncher, TYPE );
  }

  public void call( CallOperation operation ) {
    validateCallOperation( operation );
    Properties properties = operation.getProperties();
    notNull( properties, "operation properties" );
    AppLauncher appLauncher = getObjectRegistry().getObject( operation.getTarget(),
                                                             AppLauncher.class );
    if( operation.getMethod().equals( METHOD_OPEN ) ) {
      processOpenInApp( appLauncher, properties );
    } else if( operation.getMethod().equals( METHOD_OPEN_URL ) ) {
      processOpenUrl( appLauncher, properties );
    }
  }

  private void processOpenInApp( AppLauncher appLauncher, Properties properties ) {
    String app = properties.getString( ProtocolConstants.PROP_APP );
    if( app != null ) {
      if( app.equals( APP_BROWSER ) ) {
        openBrowser( appLauncher, properties );
      } else if( app.equals( APP_MAIL ) ) {
        openMail( appLauncher, properties );
      } else if( app.equals( APP_PHONE ) ) {
        openPhone( appLauncher, properties );
      } else if( app.equals( APP_MAPS ) ) {
        openMaps( appLauncher, properties );
      } else if( app.equals( APP_SMS ) ) {
        openSms( appLauncher, properties );
      } else if( app.equals( APP_TWITTER ) ) {
        openTwitter( appLauncher, properties );
      } else if( app.equals( APP_FACEBOOK ) ) {
        openFacebook( appLauncher, properties );
      }
    }
  }

  private void openBrowser( AppLauncher appLauncher, Properties properties ) {
    appLauncher.openBrowser( properties.getString( KEY_URL ) );
  }

  private void openMail( AppLauncher appLauncher, Properties properties ) {
    String to = properties.getString( KEY_TO );
    String cc = properties.getString( KEY_CC );
    String subject = properties.getString( KEY_SUBJECT );
    String body = properties.getString( KEY_BODY );
    boolean useHtml = Boolean.valueOf( properties.getString( KEY_USE_HTML ) );
    appLauncher.openMail( to, cc, subject, body, useHtml );
  }

  private void openPhone( AppLauncher appLauncher, Properties properties ) {
    appLauncher.openPhone( properties.getString( KEY_NUMBER ) );
  }

  private void openMaps( AppLauncher appLauncher, Properties properties ) {
    String latitude = properties.getString( KEY_LATITUDE );
    String longitude = properties.getString( KEY_LONGITUDE );
    if( latitude != null && longitude != null ) {
      appLauncher.openMaps( latitude, longitude );
    } else {
      String query = properties.getString( KEY_QUERY );
      appLauncher.openMaps( query );
    }
  }

  private void openSms( AppLauncher appLauncher, Properties properties ) {
    String number = properties.getString( KEY_NUMBER );
    String text = properties.getString( KEY_TEXT );
    appLauncher.openSms( number, text );
  }

  private void openTwitter( AppLauncher appLauncher, Properties properties ) {
    String text = properties.getString( KEY_TEXT );
    String url = properties.getString( KEY_URL );
    try {
      appLauncher.openUrl( createTwitterPostUrl( text, url ) );
    } catch( UnsupportedEncodingException e ) {
      throw new IllegalStateException( "Can not url encode tweet to UTF-8", e );
    }
  }

  private String createTwitterPostUrl( String text, String url ) throws UnsupportedEncodingException {
    String twitterPostUrl = TWITTER_POST_URL;
    if( text != null || url != null ) {
      twitterPostUrl += "?text=";
    }
    if( text != null ) {
      twitterPostUrl += URLEncoder.encode( text, StringUtil.UTF_8 );
    }
    if( text != null && url != null ) {
      twitterPostUrl += URLEncoder.encode( " - ", StringUtil.UTF_8 );
    }
    if( url != null ) {
      twitterPostUrl += URLEncoder.encode( url, StringUtil.UTF_8 );
    }
    return twitterPostUrl;
  }

  private void openFacebook( AppLauncher appLauncher, Properties properties ) {
    String text = properties.getString( KEY_TEXT );
    String url = properties.getString( KEY_URL );
    try {
      String fbPostUrl = createFacebookPostUrl( text, url );
      appLauncher.openUrl( fbPostUrl );
    } catch( UnsupportedEncodingException e ) {
      throw new IllegalStateException( "Can not url encode facebook post to UTF-8", e );
    }
  }

  private String createFacebookPostUrl( String text, String url )
    throws UnsupportedEncodingException
  {
    String fbPostUrl = FACEBOOK_POST_URL;
    if( text != null || url != null ) {
      fbPostUrl += "?";
    }
    if( text != null ) {
      fbPostUrl += "t=" + URLEncoder.encode( text, StringUtil.UTF_8 );
    }
    if( text != null && url != null ) {
      fbPostUrl += "&";
    }
    if( url != null ) {
      fbPostUrl += "u=" + URLEncoder.encode( url, StringUtil.UTF_8 );
    }
    return fbPostUrl;
  }

  private void processOpenUrl( AppLauncher appLauncher, Properties properties ) {
    String url = properties.getString( KEY_URL );
    if( url != null ) {
      appLauncher.openUrl( url );
    }
  }

  public void destroy( DestroyOperation operation ) {
    validateDestroyOperation( operation );
    getObjectRegistry().unregister( operation.getTarget() );
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

  public void set( SetOperation operation ) {
    // not required
  }

  public void listen( ListenOperation operation ) {
    // not required
  }

}
