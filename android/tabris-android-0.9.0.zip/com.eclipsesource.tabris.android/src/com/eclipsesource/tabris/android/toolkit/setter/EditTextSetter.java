/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static android.text.InputType.TYPE_CLASS_NUMBER;
import static android.text.InputType.TYPE_CLASS_PHONE;
import static android.text.InputType.TYPE_CLASS_TEXT;
import static android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;
import static android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
import static android.text.InputType.TYPE_TEXT_VARIATION_URI;

import java.util.HashMap;
import java.util.List;

import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;

public class EditTextSetter<T extends EditText> extends TextViewSetter<EditText> {

  static final String VARIANT_KEYBOARD_ASCII = "variant_KEYBOARD_ASCII";
  static final String VARIANT_KEYBOARD_DECIMAL = "variant_KEYBOARD_DECIMAL";
  static final String VARIANT_KEYBOARD_EMAIL = "variant_KEYBOARD_EMAIL";
  static final String VARIANT_KEYBOARD_NUMBER = "variant_KEYBOARD_NUMBER";
  static final String VARIANT_KEYBOARD_NUMBERSANDPUNCTUATION = "variant_KEYBOARD_NUMBERSANDPUNCTUATION";
  static final String VARIANT_KEYBOARD_PHONE = "variant_KEYBOARD_PHONE";
  static final String VARIANT_KEYBOARD_URL = "variant_KEYBOARD_URL";

  private HashMap<String, Integer> keyboardTypes;

  public EditTextSetter( TabrisActivity activity ) {
    super( activity );
    initKeyboardTypesMap();
  }

  private void initKeyboardTypesMap() {
    keyboardTypes = new HashMap<String, Integer>();
    keyboardTypes.put( VARIANT_KEYBOARD_ASCII, TYPE_CLASS_TEXT );
    keyboardTypes.put( VARIANT_KEYBOARD_DECIMAL, TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_DECIMAL );
    keyboardTypes.put( VARIANT_KEYBOARD_EMAIL, TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_EMAIL_ADDRESS );
    keyboardTypes.put( VARIANT_KEYBOARD_NUMBER, TYPE_CLASS_NUMBER );
    keyboardTypes.put( VARIANT_KEYBOARD_NUMBERSANDPUNCTUATION, TYPE_CLASS_NUMBER
                                                               | TYPE_NUMBER_FLAG_DECIMAL );
    keyboardTypes.put( VARIANT_KEYBOARD_PHONE, TYPE_CLASS_PHONE );
    keyboardTypes.put( VARIANT_KEYBOARD_URL, TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_URI );
  }

  @Override
  public void execute( EditText editText, Properties properties ) {
    super.execute( editText, properties );
    setEditable( editText, properties );
    setTextLimit( editText, properties );
  }

  private void setTextLimit( EditText editText, Properties properties ) {
    Integer textLimit = properties.getInteger( ProtocolConstants.PROP_TEXT_LIMIT );
    if( textLimit != null ) {
      InputFilter[] filterArray = new InputFilter[ 1 ];
      filterArray[ 0 ] = new InputFilter.LengthFilter( textLimit );
      editText.setFilters( filterArray );
    }
  }

  @Override
  protected void setEnabled( View view, Properties properties ) {
    Boolean enabled = properties.getBoolean( ProtocolConstants.PROP_ENABLED );
    if( enabled != null ) {
      view.setEnabled( enabled );
      setEditable( view, enabled );
    }
  }

  protected void setEditable( EditText editText, Properties properties ) {
    Boolean editable = properties.getBoolean( ProtocolConstants.PROP_EDITABLE );
    if( editable != null ) {
      setEditable( editText, editable );
    }
  }

  private void setEditable( View view, boolean editable ) {
    EditText editText = ( ( EditText )view );
    editText.setFocusable( editable );
    editText.setFocusableInTouchMode( editable );
  }

  @Override
  protected void setCustomVariant( EditText view, Properties properties ) {
    Integer previousInputType = getKeyboardTypeForCustomVariant( view );
    super.setCustomVariant( view, properties );
    Integer newInputType = getKeyboardTypeForCustomVariant( view );
    if( newInputType != null ) {
      if( previousInputType != null ) {
        removeInputType( view, previousInputType );
      }
      addInputType( view, newInputType );
    }
  }

  private Integer getKeyboardTypeForCustomVariant( EditText view ) {
    return keyboardTypes.get( view.getTag( R.id.custom_variant ) );
  }

  private void removeInputType( EditText view, int inputType ) {
    int currentInputType = view.getInputType();
    currentInputType &= ~inputType;
    view.setInputType( currentInputType );
  }

  private void addInputType( EditText view, int inputType ) {
    int currentInputType = view.getInputType();
    currentInputType |= inputType;
    view.setInputType( currentInputType );
  }

  @Override
  protected void setSelection( View view, Properties properties ) {
    List<Integer> selection = properties.getList( ProtocolConstants.PROP_SELECTION, Integer.class );
    if( selection != null ) {
      if( selection.size() != 2 ) {
        throw new IllegalArgumentException( "The text selection property for an EditText is not a two element list." );
      }
      int start = selection.get( 0 ).intValue();
      int end = selection.get( 1 ).intValue();
      ( ( EditText )view ).setSelection( start, end );
    }
  }
}
