/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static android.view.ViewGroup.LayoutParams.FILL_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class ToolBar extends LinearLayout {

  private static final int HORIZONTAL_TOOLBAR_PADDING = 5;
  private static final int ITEM_SPACING = 5;

  private final int itemSpacing;
  private LinearLayout itemsLayout;
  private LinearLayout titleLayout;

  public ToolBar( TabrisActivity activity ) {
    super( activity );
    setGravity( Gravity.CENTER_VERTICAL );
    setBackgroundResource( ThemeUtil.getAttrResId( activity, R.attr.toolbarBackground ) );
    setUpContainer();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    int horizontalPadding = toolkit.multiplyByDensityFactor( HORIZONTAL_TOOLBAR_PADDING );
    setPadding( horizontalPadding, 0, horizontalPadding, 0 );
    itemSpacing = toolkit.multiplyByDensityFactor( ITEM_SPACING );
  }

  private void setUpContainer() {
    titleLayout = new LinearLayout( getContext() );
    titleLayout.setGravity( Gravity.CENTER_VERTICAL );
    super.addView( titleLayout, new LayoutParams( WRAP_CONTENT, FILL_PARENT ) );
    itemsLayout = new LinearLayout( getContext() );
    itemsLayout.setGravity( Gravity.RIGHT | Gravity.CENTER_VERTICAL );
    super.addView( itemsLayout, new LayoutParams( FILL_PARENT, FILL_PARENT ) );
  }

  @Override
  public void addView( View child ) {
    if( !( child instanceof ToolItem ) ) {
      throw new IllegalArgumentException( "Can only add ToolItems to a ToolBar. Trying to add: "
                                          + child );
    }
    ToolItem toolItem = ( ToolItem )child;
    String customVariant = ( String )toolItem.getTag( R.id.custom_variant );
    LayoutParams params = toolItem.createLayoutParams();
    if( customVariant != null && customVariant.equals( ICustomVariants.TITLE ) ) {
      titleLayout.addView( toolItem, params );
    } else {
      itemsLayout.addView( toolItem, params );
    }
    toolItem.setParentToolBar( this );
    toolItem.updateAppearance();
    toolItem.setHorizontalSpacing( itemSpacing );
  }

}
