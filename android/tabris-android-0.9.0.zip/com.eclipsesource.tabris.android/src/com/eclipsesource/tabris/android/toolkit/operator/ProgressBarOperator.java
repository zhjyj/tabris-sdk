/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ProgressBarSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;

public class ProgressBarOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.ProgressBar";

  private static final String STYLE_INDETERMINATE = "INDETERMINATE";

  private final IViewSetter<? extends View> setter;

  public ProgressBarOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ProgressBarSetter<ProgressBar>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    ProgressBar progressBar = new ProgressBar( getActivity() );
    List<String> styles = operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class );
    if( styles != null && styles.contains( STYLE_INDETERMINATE ) ) {
      progressBar.setIndeterminate( true );
      Drawable drawable = getActivity().getResources()
        .getDrawable( R.drawable.progress_indeterminate_horizontal_holo );
      progressBar.setIndeterminateDrawable( drawable );
    }
    initiateNewView( operation, progressBar );
  }

}
