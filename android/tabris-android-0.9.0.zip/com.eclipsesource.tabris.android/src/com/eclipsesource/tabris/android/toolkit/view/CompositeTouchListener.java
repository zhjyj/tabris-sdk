/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class CompositeTouchListener extends ListenerHolder<OnTouchListener>
  implements OnTouchListener
{

  public boolean onTouch( View v, MotionEvent event ) {
    ArrayList<OnTouchListener> listeners = getListeners();
    boolean result = false;
    for( int i = 0; i < listeners.size(); i++ ) {
      result |= listeners.get( i ).onTouch( v, event );
    }
    return result;
  }

}
