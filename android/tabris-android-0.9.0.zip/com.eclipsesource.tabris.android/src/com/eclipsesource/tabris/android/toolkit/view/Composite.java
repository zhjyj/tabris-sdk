/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.RadioButton;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;

public class Composite extends FrameLayout {

  private final TabrisActivity activity;

  OnCheckedChangeListener listener = new OnCheckedChangeListener() {

    public void onCheckedChanged( CompoundButton buttonView, boolean isChecked ) {
      if( isChecked ) {
        for( int i = 0; i < getChildCount(); i++ ) {
          View child = getChildAt( i );
          if( child instanceof RadioButton && child != buttonView ) {
            RadioButton radioButton = ( RadioButton )child;
            radioButton.setChecked( false );
          }
        }
      }
    }
  };

  public Composite( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  @Override
  public void addView( View view ) {
    super.addView( view, 0 );
    if( view instanceof RadioButton ) {
      ListenerRegistry listenerRegistry = activity.getProcessor()
        .getWidgetToolkit()
        .getListenerRegistry();
      String id = activity.getRemoteObject( view ).getId();
      CompositeCheckedChangedListener compositeListener = listenerRegistry.findListener( id,
                                                                                         CompositeCheckedChangedListener.class );
      compositeListener.addListener( listener );
    }
  }

  @Override
  public void removeView( View view ) {
    unregisterRadioButtonListener( view );
    super.removeView( view );
  }

  private void unregisterRadioButtonListener( View view ) {
    ListenerRegistry listenerRegistry = activity.getProcessor()
      .getWidgetToolkit()
      .getListenerRegistry();
    String id = activity.getRemoteObject( view ).getId();
    CompositeCheckedChangedListener compositeListener = listenerRegistry.findListener( id,
                                                                                       CompositeCheckedChangedListener.class );
    if( view instanceof RadioButton ) {
      compositeListener.removeListener( listener );
    }
  }

  @Override
  public void removeViewAt( int index ) {
    unregisterRadioButtonListener( getChildAt( index ) );
    super.removeViewAt( index );
  }

}
