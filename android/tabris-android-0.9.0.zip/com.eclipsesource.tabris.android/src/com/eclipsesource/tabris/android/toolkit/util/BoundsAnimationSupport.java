/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.util.List;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;

public class BoundsAnimationSupport {

  private static final int ANIMATION_DURATION = 400;
  private static final boolean ANIMATION_IS_INTERPOLATED = false;

  public void applyBoundsAnimations( final ViewSetter<? extends View> viewSetter,
                                     final View view,
                                     final List<Integer> bounds )
  {
    validateParams( viewSetter, view, bounds );
    IWidgetToolkit toolkit = viewSetter.getProcessor().getWidgetToolkit();
    Animation transAnim = createTranslateAnimation( view, bounds, toolkit );
    Animation scaleAnim = createScaleAnimation( view, bounds, toolkit );
    Animation animToApply = createAnimationToApply( viewSetter, view, bounds, transAnim, scaleAnim );
    if( animToApply != null ) {
      view.startAnimation( animToApply );
    }
  }

  private void validateParams( final ViewSetter<? extends View> viewSetter,
                               final View view,
                               final List<Integer> bounds )
  {
    ValidationUtil.checkNullArg( this, viewSetter, ViewSetter.class );
    ValidationUtil.checkNullArg( this, view, View.class );
    ValidationUtil.checkNullArg( this, bounds, List.class );
    if( bounds.size() != 4 ) {
      throw new IllegalArgumentException( "The bounds properties have to be a 4 element touple" );
    }
  }

  private Animation createAnimationToApply( final ViewSetter<? extends View> viewSetter,
                                            final View view,
                                            final List<Integer> bounds,
                                            Animation transAnim,
                                            Animation scaleAnim )
  {
    if( transAnim == null && scaleAnim == null ) {
      return null;
    }
    Animation anim;
    if( scaleAnim == null ) {
      anim = transAnim;
    } else if( transAnim == null ) {
      anim = scaleAnim;
    } else {
      AnimationSet animSet = new AnimationSet( false );
      // The order in which the animation is added is utmost important
      animSet.addAnimation( scaleAnim );
      animSet.addAnimation( transAnim );
      anim = animSet;
    }
    anim.setAnimationListener( new ApplyBoundsOnFinishAnimationListener( view, bounds, viewSetter ) );
    return anim;
  }

  private Animation createTranslateAnimation( final View view,
                                              final List<Integer> bounds,
                                              IWidgetToolkit toolkit )
  {
    int deltaX = toolkit.multiplyByDensityFactor( bounds.get( 0 ) ) - view.getLeft();
    int deltaY = toolkit.multiplyByDensityFactor( bounds.get( 1 ) ) - view.getTop();
    if( deltaX == 0 && deltaY == 0 ) {
      return null;
    }
    return initiAnimation( new TranslateAnimation( 0, deltaX, 0, deltaY ) );
  }

  private Animation createScaleAnimation( final View view,
                                          final List<Integer> bounds,
                                          IWidgetToolkit toolkit )
  {
    int newWidth = toolkit.multiplyByDensityFactor( bounds.get( 2 ) );
    int newHeight = toolkit.multiplyByDensityFactor( bounds.get( 3 ) );
    float scaleWidth = newWidth / Math.max( 1f, view.getWidth() );
    float scaleHeight = newHeight / Math.max( 1f, view.getHeight() );
    if( scaleWidth == 1 && scaleHeight == 1 ) {
      return null;
    }
    return initiAnimation( new ScaleAnimation( 1, scaleWidth, 1, scaleHeight ) );
  }

  private Animation initiAnimation( Animation anim ) {
    anim.setFillEnabled( true );
    anim.setDuration( ANIMATION_DURATION );
    if( ANIMATION_IS_INTERPOLATED ) {
      anim.setInterpolator( new DecelerateInterpolator( 4 ) );
    }
    return anim;
  }
}
