
package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.HashMap;

import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class AlternativeSelectionTreeClickListener implements OnClickListener {

  private final RemoteObject remoteObject;
  private String treeItemId;

  public AlternativeSelectionTreeClickListener( RemoteObject remoteObject ) {
    this.remoteObject = remoteObject;
  }

  public void onClick( View v ) {
    remoteObject.set( PROP_SELECTION, new String[]{ treeItemId } );
    remoteObject.set( PROP_FOCUS_INDEX, treeItemId );
    HashMap<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_ITEM, treeItemId );
    properties.put( PROP_ALT_KEY, true );
    remoteObject.notify( EVENT_SELECTION, properties );
  }

  public void setTreeItemId( String treeItemId ) {
    this.treeItemId = treeItemId;
  }

}