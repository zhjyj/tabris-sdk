/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNullOrEmpty;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ObjectRegistry {

  private final Map<String, RegistryEntry> registry;
  private final ProtocolProcessor processor;

  private final class RegistryEntry {

    private final Object object;
    private final String type;
    private RemoteObject remoteObject;
    private final String id;

    public RegistryEntry( String id, Object object, String type ) {
      this.id = id;
      this.object = object;
      this.type = type;
    }

    public Object getObject() {
      return object;
    }

    public String getType() {
      return type;
    }

    public RemoteObject getRemoteObject() {
      if( remoteObject == null ) {
        remoteObject = new RemoteObject( id, processor );
      }
      return remoteObject;
    }
  }

  public ObjectRegistry( ProtocolProcessor processor ) {
    notNull( processor, "processor" );
    this.processor = processor;
    registry = new HashMap<String, RegistryEntry>();
  }

  public void register( String id, Object object, String type ) {
    notNull( id, "id" );
    notNull( object, "object" );
    notNull( type, "type" );
    registry.put( id, new RegistryEntry( id, object, type ) );
  }

  public void unregister( String id ) {
    notNull( id, "id" );
    removeChildren( getObject( id ) );
    registry.remove( id );
  }

  private void removeChildren( Object object ) {
    if( object instanceof Parent ) {
      List<Object> children = ( ( Parent )object ).getChildren();
      for( int i = 0; i < children.size(); i++ ) {
        unregister( getRemoteObjectForObject( children.get( i ) ).getId() );
      }
    }
  }

  public Object getObject( String id ) {
    return getObject( id, Object.class );
  }

  @SuppressWarnings("unchecked")
  public <T> T getObject( String id, Class<T> clazz ) {
    notNull( id, "id" );
    Object result = null;
    RegistryEntry entry = registry.get( id );
    if( entry != null ) {
      result = entry.getObject();
      if( !clazz.isInstance( result ) ) {
        Object[] args = new Object[]{
          clazz.getSimpleName(), result.getClass().getSimpleName()
        };
        String msg = MessageFormat.format( "Object is not an instance of {0}: {1}", args );
        throw new IllegalStateException( msg );
      }
    }
    return ( T )result;
  }

  public String getObjectType( String id ) {
    notNull( id, "id" );
    String result = null;
    RegistryEntry entry = registry.get( id );
    if( entry != null ) {
      result = entry.getType();
    }
    return result;
  }

  public RemoteObject getRemoteObject( String objectId ) {
    notNullOrEmpty( objectId, "objectId" );
    RegistryEntry registryEntry = registry.get( objectId );
    if( registryEntry == null ) {
      throw new IllegalStateException( "No RemoteObject found for " + objectId );
    }
    return registryEntry.getRemoteObject();
  }

  public RemoteObject getRemoteObjectForObject( Object object ) {
    notNull( object, "Object" );
    Set<Entry<String, RegistryEntry>> entrySet = registry.entrySet();
    Iterator<Entry<String, RegistryEntry>> iterator = entrySet.iterator();
    while( iterator.hasNext() ) {
      Entry<String, RegistryEntry> entry = iterator.next();
      RegistryEntry value = entry.getValue();
      if( object.equals( value.getObject() ) ) {
        return value.getRemoteObject();
      }
    }
    throw new IllegalStateException( object + " is not contained in registry." );
  }

}
