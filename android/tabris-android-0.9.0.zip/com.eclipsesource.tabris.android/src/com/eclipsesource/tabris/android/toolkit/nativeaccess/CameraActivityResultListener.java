
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_IMAGE_SELECTION;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.EVENT_IMAGE_SELECTION_ERROR;
import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_IMAGE;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.util.Base64;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.IActivityResultListener;
import com.eclipsesource.tabris.android.toolkit.util.ImageLoader;

public class CameraActivityResultListener implements IActivityResultListener {

  private final TabrisActivity activity;
  private final int requestCode;
  private final RemoteObject remoteObject;
  private final File photoFile;
  private final int width;
  private final int height;
  private ImageLoader imageLoader;

  public CameraActivityResultListener( TabrisActivity activity,
                                       int requestCode,
                                       RemoteObject remoteObject,
                                       File photoFile,
                                       int width,
                                       int height )
  {
    this.activity = activity;
    this.requestCode = requestCode;
    this.remoteObject = remoteObject;
    this.width = width;
    this.height = height;
    this.photoFile = photoFile;
    imageLoader = new ImageLoader();
  }

  public void receivedActivityResult( int requestCode, int resultCode, Intent data ) {
    if( requestCode == this.requestCode ) {
      returnRequestCode();
      removeActivityResultListener();
      if( resultCode == Activity.RESULT_OK ) {
        if( photoFile.exists() ) {
          try {
            byte[] resizedImage = imageLoader.loadImage( photoFile, width, height );
            photoFile.delete();
            sendImageToServer( resizedImage );
            return;
          } catch( Exception e ) {
            sendErrorToServer();
          }
        } else {
          sendErrorToServer();
        }
      }
    }
  }

  private void removeActivityResultListener() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.removeActivityResultListener( this );
  }

  private void returnRequestCode() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    RequestCodePool requestCodePool = toolkit.getRequestCodePool();
    requestCodePool.returnRequestCode( requestCode );
  }

  private void sendImageToServer( byte[] imageData ) {
    String base64EncodedImage = Base64.encodeToString( imageData, Base64.DEFAULT );
    Map<String, Object> properties = new HashMap<String, Object>();
    properties.put( PROP_IMAGE, base64EncodedImage );
    remoteObject.notify( EVENT_IMAGE_SELECTION, properties );
  }

  private void sendErrorToServer() {
    remoteObject.notify( EVENT_IMAGE_SELECTION_ERROR, null );
  }

  /** To be used for testing only. */
  void setImageLoader( ImageLoader imageLoader ) {
    this.imageLoader = imageLoader;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( activity == null )
                                                    ? 0
                                                    : activity.hashCode() );
    result = prime * result + height;
    result = prime * result + ( ( remoteObject == null )
                                                        ? 0
                                                        : remoteObject.hashCode() );
    result = prime * result + ( ( photoFile == null )
                                                     ? 0
                                                     : photoFile.hashCode() );
    result = prime * result + requestCode;
    result = prime * result + width;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    CameraActivityResultListener other = ( CameraActivityResultListener )obj;
    if( activity == null ) {
      if( other.activity != null ) {
        return false;
      }
    } else if( !activity.equals( other.activity ) ) {
      return false;
    }
    if( height != other.height ) {
      return false;
    }
    if( remoteObject == null ) {
      if( other.remoteObject != null ) {
        return false;
      }
    } else if( !remoteObject.equals( other.remoteObject ) ) {
      return false;
    }
    if( photoFile == null ) {
      if( other.photoFile != null ) {
        return false;
      }
    } else if( !photoFile.equals( other.photoFile ) ) {
      return false;
    }
    if( requestCode != other.requestCode ) {
      return false;
    }
    if( width != other.width ) {
      return false;
    }
    return true;
  }

}
