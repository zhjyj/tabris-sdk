/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;


public class ThemeStoreOperator implements IOperator {

  public static final String TYPE = "rwt.theme.ThemeStore";

  private static final String METHOD_LOAD_FALLBACK_THEME = "loadFallbackTheme";
  private static final String METHOD_LOAD_ACTIVE_THEME = "loadActiveTheme";

  private final TabrisActivity activity;

  public ThemeStoreOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    // do nothing
  }

  public void set( SetOperation operation ) {
    // do nothing
  }

  public void listen( ListenOperation operation ) {
    // do nothing
  }

  public void call( CallOperation operation ) {
    // TODO: implementation
    if( operation.getMethod().equals( METHOD_LOAD_FALLBACK_THEME ) ) {
    } else if( operation.getMethod().equals( METHOD_LOAD_ACTIVE_THEME ) ) {
    }
  }

  public void destroy( DestroyOperation operation ) {
    getObjectRegistry().unregister( TYPE );
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

}
