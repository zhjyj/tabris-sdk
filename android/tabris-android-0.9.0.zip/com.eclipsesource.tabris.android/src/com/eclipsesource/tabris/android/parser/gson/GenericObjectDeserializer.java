/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;

public class GenericObjectDeserializer implements JsonDeserializer<GenericObject> {

  public GenericObject deserialize( JsonElement json,
                                    Type typeOfT,
                                    JsonDeserializationContext context ) throws JsonParseException
  {
    GenericObject result = null;
    if( json != null ) {
      result = new GenericObject( toObject( json ) );
    }
    return result;
  }

  public static Object toObject( JsonElement json ) {
    Object result = null;
    if( json.isJsonArray() ) {
      result = createListObject( json );
    } else if( json.isJsonObject() ) {
      result = createMapObject( json );
    } else if( json.isJsonPrimitive() ) {
      result = createPrimitveObject( json );
    }
    return result;
  }

  private static Object createPrimitveObject( JsonElement json ) {
    Object result = null;
    JsonPrimitive primitive = json.getAsJsonPrimitive();
    if( primitive.isBoolean() ) {
      result = primitive.getAsBoolean();
    } else if( primitive.isString() ) {
      result = primitive.getAsString();
    } else if( primitive.isNumber() ) {
      String value = primitive.getAsString();
      try {
        result = Integer.parseInt(value);
      } catch( NumberFormatException exception ) {
        result = Float.parseFloat( value );
      }
    }
    return result;
  }

  private static HashMap<String, Object> createMapObject( JsonElement json ) {
    HashMap<String, Object> result = new HashMap<String, Object>();
    JsonObject jsonObject = json.getAsJsonObject();
    Set<Entry<String, JsonElement>> entries = jsonObject.entrySet();
    for( Entry<String, JsonElement> entry : entries ) {
      result.put( entry.getKey(), toObject( entry.getValue() ) );
    }
    return result;
  }

  private static List<Object> createListObject( JsonElement json ) {
    JsonArray jsonArray = json.getAsJsonArray();
    ArrayList<Object> result = new ArrayList<Object>( jsonArray.size() );
    for( int i = 0; i < jsonArray.size(); i++ ) {
      result.add( toObject( jsonArray.get( i ) ) );
    }
    return result;
  }
}
