/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.validateSetOperation;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.ServerPush;

public class ServerPushOperator implements IOperator {

  public static final String TYPE = "rwt.client.ServerPush";

  private final TabrisActivity activity;

  public ServerPushOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void set( SetOperation operation ) {
    validateSetOperation( operation );
    Properties properties = operation.getProperties();
    applyProperties( operation.getTarget(), properties );
  }

  private ServerPush getServerPush( String target ) {
    ServerPush serverPush = getObjectRegistry().getObject( target, ServerPush.class );
    if( serverPush == null ) {
      serverPush = new ServerPush( activity );
      getObjectRegistry().register( target, serverPush, TYPE );
    }
    return serverPush;
  }

  private void applyProperties( String target, Properties properties ) {
    Boolean active = properties.getBoolean( ProtocolConstants.PROP_ACTIVE );
    if( active != null ) {
      ServerPush serverPush = getServerPush( target );
      serverPush.activate( active );
    }
  }

  public void create( CreateOperation operation ) {
    // The ui callback does not support create operations
  }

  public void listen( ListenOperation operation ) {
    // The ui callback does not support listening
  }

  public void call( CallOperation operation ) {
    // The ui callback does not support call operations
  }

  public void destroy( DestroyOperation operation ) {
    // the ui callback is not destroyed by client code. it always exists.
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

}
