/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;

public interface IOperator {

  String getType();

  void create( CreateOperation operation );

  void set( SetOperation operation );

  void listen( ListenOperation operation );

  void call( CallOperation operation );

  void destroy( DestroyOperation operation );

}
