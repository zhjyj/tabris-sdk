/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;
import java.util.Map.Entry;
import java.util.Set;

import com.eclipsesource.tabris.android.core.model.Head;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class HeadDeserializer implements JsonDeserializer<Head> {

  public Head deserialize( JsonElement json,
                           Type typeOfT,
                           JsonDeserializationContext context ) throws JsonParseException
  {
    Head headers = new Head();
    if( json.isJsonObject() ) {
      JsonObject jsonObject = json.getAsJsonObject();
      Set<Entry<String, JsonElement>> entries = jsonObject.entrySet();
      for( Entry<String, JsonElement> entry : entries ) {
        headers.add( entry.getKey(), GenericObjectDeserializer.toObject( entry.getValue() ) );
      }
    }
    return headers;
  }

}
