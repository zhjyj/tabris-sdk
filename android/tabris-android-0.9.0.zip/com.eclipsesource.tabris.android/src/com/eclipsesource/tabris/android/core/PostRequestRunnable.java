/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;

final class PostRequestRunnable implements Runnable {

  private final PostRequest request;
  private final ProtocolProcessor processor;

  public PostRequestRunnable( PostRequest request, ProtocolProcessor processor ) {
    this.request = request;
    this.processor = processor;
  }

  public void run() {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    IProgressIndicator progressIndicator = toolkit.getProgressIndicator();
    startProgressOnNonSilentRequests( progressIndicator, request );
    ITransportResult transportResult = processor.getTransport().post( request );
    progressIndicator.stop();
    if( transportResult.hasParsableContent() ) {
      parse( toolkit, transportResult );
    } else {
      toolkit.showError( transportResult.getException(), request );
    }
  }

  private void parse( IWidgetToolkit toolkit, ITransportResult transportResult ) {
    try {
      processor.getParser().parse( transportResult.getResult() );
    } catch( Exception e ) {
      toolkit.showError( e, request );
    }
  }

  public String getRequestContent() {
    return request.getContent();
  }

  private void startProgressOnNonSilentRequests( IProgressIndicator progressIndicator,
                                                 PostRequest request )
  {
    if( !request.isSilentRequest() ) {
      progressIndicator.start();
    }
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( processor == null )
                                                     ? 0
                                                     : processor.hashCode() );
    result = prime * result + ( ( request == null )
                                                   ? 0
                                                   : request.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    PostRequestRunnable other = ( PostRequestRunnable )obj;
    if( processor == null ) {
      if( other.processor != null ) {
        return false;
      }
    } else if( !processor.equals( other.processor ) ) {
      return false;
    }
    if( request == null ) {
      if( other.request != null ) {
        return false;
      }
    } else if( !request.equals( other.request ) ) {
      return false;
    }
    return true;
  }

}