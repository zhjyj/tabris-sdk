/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.setter.DisplaySetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.Display;

public class DisplayOperator extends AbstractWidgetOperator {

  public static final String DISPLAY_ID = "w1";
  public static final String TYPE = "rwt.widgets.Display";

  private static final String PROP_RWT_INITIALIZE = "rwt_initialize";
  private static final String PROP_BOUNDS = "bounds";
  private static final String PROP_COLOR_DEPTH = "colorDepth";
  private static final String PROP_DPI = "dpi";
  private static final String PROP_CURSOR_LOCATION = "cursorLocation";

  private final IViewSetter<? extends View> setter;

  public DisplayOperator( TabrisActivity activity ) {
    super( activity );
    setter = new DisplaySetter<Display>( activity );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  public void create( CreateOperation operation ) {
    View display = getActivity().findViewById( R.id.root_layout );
    getObjectRegistry().register( operation.getTarget(), display, DisplayOperator.TYPE );
    sendInitialProperties( getActivity().getRemoteObject( display ) );
  }

  private void sendInitialProperties( RemoteObject remoteObject ) {
    getProcessor().appendHeader( PROP_RWT_INITIALIZE, true );
    remoteObject.set( PROP_BOUNDS, getBounds() );
    remoteObject.set( PROP_COLOR_DEPTH, getColorDepth() );
    remoteObject.set( PROP_DPI, getDpi() );
    remoteObject.set( PROP_CURSOR_LOCATION, getCursorLocation() );
    getProcessor().send();
  }

  private int[] getBounds() {
    IWidgetToolkit widgetToolkit = getWidgetToolkit();
    int width = widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceWidth() );
    int height = widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceHeight() );
    return new int[]{
      0, 0, width, height
    };
  }

  private int getColorDepth() {
    return getWidgetToolkit().getSurfaceColorDepth();
  }

  private int[] getDpi() {
    IWidgetToolkit toolkit = getWidgetToolkit();
    return new int[]{
      toolkit.getSurfaceDpiX(), toolkit.getSurfaceDpiY()
    };
  }

  private int[] getCursorLocation() {
    return new int[]{
      0, 0
    };
  }

}
