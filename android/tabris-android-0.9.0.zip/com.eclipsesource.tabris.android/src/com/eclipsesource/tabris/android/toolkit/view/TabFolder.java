/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.LinkedHashMap;
import java.util.Set;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TabHost;

import com.eclipsesource.tabris.android.TabrisActivity;

public class TabFolder extends TabHost {

  private final LinkedHashMap<TabSpec, String> tabSpecs = new LinkedHashMap<TabSpec, String>();
  private final TabrisActivity activity;

  public TabFolder( Context context ) {
    this( context, null );
  }

  public TabFolder( Context context, AttributeSet attrs ) {
    super( context, attrs );
    this.activity = ( TabrisActivity )context;
  }

  @Override
  public void addView( final View child ) {
    Set<TabSpec> keySet = tabSpecs.keySet();
    boolean viewAdded = false;
    int i = 0;
    for( TabSpec tabSpec : keySet ) {
      String controlWidgetId = tabSpecs.get( tabSpec );
      String childId = activity.getRemoteObject( child ).getId();
      if( controlWidgetId != null && controlWidgetId.equals( childId ) ) {
        addViewOnContentView( child, i );
        viewAdded = true;
      }
      i++;
    }
    if( !viewAdded ) {
      super.addView( child );
    }
  }

  private void addViewOnContentView( final View view, int i ) {
    FrameLayout tabContentView = getTabContentView();
    LinearLayout parent = ( LinearLayout )tabContentView.getChildAt( i );
    parent.removeAllViews();
    parent.addView( view );
  }

  public void addTab( TabSpec tabSpec, String controlWidgetId ) {
    super.addTab( tabSpec );
    tabSpecs.put( tabSpec, controlWidgetId );
  }

  public LinkedHashMap<TabSpec, String> getTabSpecs() {
    return tabSpecs;
  }

}
