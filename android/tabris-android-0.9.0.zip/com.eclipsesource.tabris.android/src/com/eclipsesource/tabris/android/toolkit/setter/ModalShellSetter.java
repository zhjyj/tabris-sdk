/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;

public class ModalShellSetter<T extends ModalShell> extends ShellSetter<T> {

  public ModalShellSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  protected void setBounds( View view, Properties properties ) {
    List<Integer> bounds = properties.getList( ProtocolConstants.PROP_BOUNDS, Integer.class );
    if( bounds != null ) {
      if( bounds.size() != 4 ) {
        throw new IllegalArgumentException( "The bounds properties have to be a 4 element touple" );
      }
      applyBoundsToView( view, translateBoundsForShadow( bounds ) );
      view.requestLayout();
    }
  }

  private List<Integer> translateBoundsForShadow( List<Integer> bounds ) {
    List<Integer> translatedBounds = new ArrayList<Integer>();
    int oldLeft = bounds.get( 0 ).intValue();
    int oldTop = bounds.get( 1 ).intValue();
    translatedBounds.add( oldLeft - IThemeConstants.DIALOG_SHADOW_SIZE );
    translatedBounds.add( oldTop - IThemeConstants.DIALOG_SHADOW_SIZE );
    translatedBounds.add( bounds.get( 2 ) );
    translatedBounds.add( bounds.get( 3 ) );
    return translatedBounds;
  }
}
