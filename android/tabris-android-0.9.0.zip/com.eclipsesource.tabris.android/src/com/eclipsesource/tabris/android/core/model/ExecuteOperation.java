/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class ExecuteOperation extends Operation {

  public static final String ACTION = "executeScript";

  private String scriptType;
  private String content;

  public String getScriptType() {
    return scriptType;
  }

  public void setScriptType( String scriptType ) {
    this.scriptType = scriptType;
  }

  public String getContent() {
    return content;
  }

  public void setContent( String content ) {
    this.content = content;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( content == null )
                                                   ? 0
                                                   : content.hashCode() );
    result = prime * result + ( ( scriptType == null )
                                                      ? 0
                                                      : scriptType.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( !super.equals( obj ) )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    ExecuteOperation other = ( ExecuteOperation )obj;
    if( content == null ) {
      if( other.content != null )
        return false;
    } else if( !content.equals( other.content ) )
      return false;
    if( scriptType == null ) {
      if( other.scriptType != null )
        return false;
    } else if( !scriptType.equals( other.scriptType ) )
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "ExecuteOperation [scriptType=" + scriptType + ", getTarget()=" + getTarget() + "]";
  }

}
