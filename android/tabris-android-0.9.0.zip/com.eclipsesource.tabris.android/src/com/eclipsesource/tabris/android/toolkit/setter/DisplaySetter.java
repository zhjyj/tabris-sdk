/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Display;

public class DisplaySetter<T extends Display> implements IViewSetter<T> {

  private final TabrisActivity activity;

  public DisplaySetter( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void execute( T view, Properties properties ) {
    setFocusControl( properties );
  }

  protected void setFocusControl( Properties properties ) {
    String focusControl = properties.getString( ProtocolConstants.PROP_FOCUS_CONTROL );
    if( focusControl != null ) {
      ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
      View view = objectRegistry.getObject( focusControl, View.class );
      view.requestFocus();
    }
  }

}
