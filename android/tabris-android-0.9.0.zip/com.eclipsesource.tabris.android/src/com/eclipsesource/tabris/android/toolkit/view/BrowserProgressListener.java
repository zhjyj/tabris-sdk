/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class BrowserProgressListener implements IBrowserProgressListener {

  private final TabrisActivity activity;
  private final Browser browser;

  public BrowserProgressListener( TabrisActivity activity, Browser browser ) {
    this.activity = activity;
    this.browser = browser;
  }

  public void pageFinishedLoading() {
    RemoteObject remoteObject = activity.getRemoteObject( browser );
    remoteObject.notify( EVENT_PROGRESS, null );
  }

}
