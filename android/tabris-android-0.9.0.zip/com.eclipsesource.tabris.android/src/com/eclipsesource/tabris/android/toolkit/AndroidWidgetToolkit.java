/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.MessageQueue;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;

import com.eclipsesource.tabris.android.BuildConfig;
import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.LocalizableException;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator;
import com.eclipsesource.tabris.android.toolkit.operator.AppLauncherOperator;
import com.eclipsesource.tabris.android.toolkit.operator.BrowserOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ButtonOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CameraOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CanvasOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ComboOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.operator.GraphicalContextOperator;
import com.eclipsesource.tabris.android.toolkit.operator.GroupOperator;
import com.eclipsesource.tabris.android.toolkit.operator.LabelOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ListOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ProgressBarOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ScaleOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ScrollBarOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ScrolledCompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.SeparatorOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ServerPushOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ShellOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TabFolderOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TabItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TableColumnOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TextOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TextSizeMeasurementOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ThemeStoreOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ToolBarOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ToolItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TreeItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TreeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.VideoOperator;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.FocusTrackingListener;

public class AndroidWidgetToolkit implements IWidgetToolkit {

  private static final int REQUEST_CODE_POOL_SIZE = 100;

  private final TabrisActivity activity;
  private final ListenerRegistry listenerRegistry;
  private final ObjectRegistry objectRegistry;
  private final OperatorRegistry operatorRegistry;
  private final MessageFactory messageFactory;
  private final FocusTrackingListener recordingFocusChangedListener;
  private DisplayMetrics displayMetrics;
  private ErrorDialog errorDialog;
  private IProgressIndicator progressIndicator;
  private Handler handler;
  private OperationsExecutor operationsExecutor;
  private BitmapDrawableCache bitmapCache;
  private final ArrayList<IAppStateListener> appStateListeners;
  private final ArrayList<IActivityResultListener> activityResultListeners;
  private final ArrayList<IOperationsListProcessedListener> operationsListProcessedListeners;
  private final RequestCodePool requestCodePool;

  public AndroidWidgetToolkit( TabrisActivity activity, MessageQueue messageQueue ) {
    this.activity = activity;
    handler = new Handler();
    operationsExecutor = new OperationsExecutor( this, messageQueue );
    errorDialog = new ErrorDialog( activity, this );
    progressIndicator = new ProgressIndicator( activity, this );
    messageFactory = new MessageFactory( activity );
    objectRegistry = new ObjectRegistry( activity.getProcessor() );
    operatorRegistry = new OperatorRegistry();
    initializeOperators();
    initializeBitmapCache();
    populateDisplayMetrics();
    listenerRegistry = new ListenerRegistry();
    recordingFocusChangedListener = new FocusTrackingListener( activity );
    appStateListeners = new ArrayList<IAppStateListener>();
    activityResultListeners = new ArrayList<IActivityResultListener>();
    operationsListProcessedListeners = new ArrayList<IOperationsListProcessedListener>();
    requestCodePool = new RequestCodePool( REQUEST_CODE_POOL_SIZE );
  }

  private void initializeBitmapCache() {
    final int memClass = ( ( ActivityManager )activity.getSystemService( Context.ACTIVITY_SERVICE ) ).getMemoryClass();
    final int cacheSize = 1024 * 1024 * memClass / 8;
    bitmapCache = new BitmapDrawableCache( cacheSize );
  }

  private void initializeOperators() {
    operatorRegistry.register( DisplayOperator.TYPE, new DisplayOperator( activity ) );
    operatorRegistry.register( ShellOperator.TYPE, new ShellOperator( activity ) );
    operatorRegistry.register( CompositeOperator.TYPE, new CompositeOperator( activity ) );
    operatorRegistry.register( GroupOperator.TYPE, new GroupOperator( activity ) );
    operatorRegistry.register( ScrolledCompositeOperator.TYPE,
                               new ScrolledCompositeOperator( activity ) );
    operatorRegistry.register( ButtonOperator.TYPE, new ButtonOperator( activity ) );
    operatorRegistry.register( LabelOperator.TYPE, new LabelOperator( activity ) );
    operatorRegistry.register( TabFolderOperator.TYPE, new TabFolderOperator( activity ) );
    operatorRegistry.register( TabItemOperator.TYPE, new TabItemOperator( activity ) );
    operatorRegistry.register( TreeOperator.TYPE, new TreeOperator( activity ) );
    operatorRegistry.register( TreeItemOperator.TYPE, new TreeItemOperator( activity ) );
    operatorRegistry.register( TableColumnOperator.TYPE, new TableColumnOperator( activity ) );
    operatorRegistry.register( TextOperator.TYPE, new TextOperator( activity ) );
    operatorRegistry.register( ComboOperator.TYPE, new ComboOperator( activity ) );
    operatorRegistry.register( DateTimeOperator.TYPE, new DateTimeOperator( activity ) );
    operatorRegistry.register( ToolBarOperator.TYPE, new ToolBarOperator( activity ) );
    operatorRegistry.register( ToolItemOperator.TYPE, new ToolItemOperator( activity ) );
    operatorRegistry.register( ServerPushOperator.TYPE, new ServerPushOperator( activity ) );
    operatorRegistry.register( CanvasOperator.TYPE, new CanvasOperator( activity ) );
    operatorRegistry.register( GraphicalContextOperator.TYPE,
                               new GraphicalContextOperator( activity ) );
    operatorRegistry.register( GeolocationOperator.TYPE, new GeolocationOperator( activity ) );
    operatorRegistry.register( BrowserOperator.TYPE, new BrowserOperator( activity ) );
    operatorRegistry.register( ListOperator.TYPE, new ListOperator( activity ) );
    operatorRegistry.register( SeparatorOperator.TYPE, new SeparatorOperator( activity ) );
    operatorRegistry.register( ProgressBarOperator.TYPE, new ProgressBarOperator( activity ) );
    operatorRegistry.register( ScaleOperator.TYPE, new ScaleOperator( activity ) );
    operatorRegistry.register( VideoOperator.TYPE, new VideoOperator( activity ) );
    operatorRegistry.register( CameraOperator.TYPE, new CameraOperator( activity ) );
    operatorRegistry.register( ScrollBarOperator.TYPE, new ScrollBarOperator( activity ) );
    operatorRegistry.register( TextSizeMeasurementOperator.TYPE,
                               new TextSizeMeasurementOperator( activity ) );
    operatorRegistry.register( ThemeStoreOperator.TYPE, new ThemeStoreOperator( activity ) );
    operatorRegistry.register( AppLauncherOperator.TYPE, new AppLauncherOperator( activity ) );
  }

  public ObjectRegistry getObjectRegistry() {
    return objectRegistry;
  }

  public OperatorRegistry getOperatorRegistry() {
    return operatorRegistry;
  }

  private void populateDisplayMetrics() {
    displayMetrics = new DisplayMetrics();
    activity.getWindowManager().getDefaultDisplay().getMetrics( displayMetrics );
  }

  public void process( final List<Operation> operations ) {
    if( operations.isEmpty() ) {
      fireOperationsListProcessed();
    } else {
      operationsExecutor.enqueue( operations );
      if( !operationsExecutor.isRunning() ) {
        operationsExecutor.start();
      }
    }
  }

  IOperator getOperator( Operation operation ) {
    ValidationUtil.validateOperation( operation );
    String type;
    if( operation instanceof CreateOperation ) {
      type = ( ( CreateOperation )operation ).getType();
    } else {
      type = objectRegistry.getObjectType( operation.getTarget() );
      if( type == null ) {
        type = operation.getTarget();
      }
    }
    return operatorRegistry.get( type );
  }

  public void showError( final Throwable throwable, TransportRequest request ) {
    Throwable error;
    if( throwable instanceof LocalizableException ) {
      LocalizableException exception = ( LocalizableException )throwable;
      error = new RuntimeException( messageFactory.createMessage( exception.getKey() ), throwable );
    } else {
      error = throwable;
    }
    if( BuildConfig.DEBUG ) {
      Log.e( TabrisActivity.LOG_TAG, error.getMessage(), throwable );
    }
    errorDialog.show( error, request );
  }

  void executeInUiThread( Runnable runnable ) {
    if( !activity.isFinishing() ) {
      handler.post( runnable );
    }
  }

  public void executeDelayedInUiThread( Runnable delayedRunnable, long delay ) {
    if( !activity.isFinishing() ) {
      handler.postDelayed( delayedRunnable, delay );
    }
  }

  public void cancelInUiThread( Runnable runnable ) {
    handler.removeCallbacks( runnable );
  }

  Activity getActivity() {
    return activity;
  }

  public int getSurfaceWidth() {
    View rootLayout = activity.findViewById( R.id.root_layout );
    return rootLayout.getWidth();
  }

  public int getSurfaceHeight() {
    View rootLayout = activity.findViewById( R.id.root_layout );
    return rootLayout.getHeight();
  }

  public int getSurfaceDpiX() {
    return Math.round( displayMetrics.xdpi );
  }

  public int getSurfaceDpiY() {
    return Math.round( displayMetrics.ydpi );
  }

  public int getSurfaceColorDepth() {
    // TODO mpost find a proper way to determine the color depth of the
    // surface
    return 24;
  }

  public float divideByDensityFactor( float value ) {
    return value / displayMetrics.density;
  }

  public int divideByDensityFactor( int value ) {
    return Math.round( value / displayMetrics.density );
  }

  public int multiplyByDensityFactor( int value ) {
    return Math.round( value * displayMetrics.density );
  }

  public float multiplyByDensityFactor( float value ) {
    return value * displayMetrics.density;
  }

  public void dispose() {
    ServerPush uicb = objectRegistry.getObject( ServerPushOperator.TYPE, ServerPush.class );
    if( uicb != null ) {
      uicb.activate( false );
    }
    handler.removeCallbacksAndMessages( 0 );
    bitmapCache.clear();
  }

  public ListenerRegistry getListenerRegistry() {
    return listenerRegistry;
  }

  /** Used for testing only. */
  void setHandler( Handler handler ) {
    this.handler = handler;
  }

  /** Used for testing only. */
  void setBitmapCache( BitmapDrawableCache bitmapCache ) {
    this.bitmapCache = bitmapCache;
  }

  /** Used for testing only. */
  public void setErrorDialog( ErrorDialog errorDialog ) {
    this.errorDialog = errorDialog;
  }

  /** Used for testing only. */
  void setProgressIndicator( IProgressIndicator progressIndicator ) {
    this.progressIndicator = progressIndicator;
  }

  /** Used for testing only. */
  void setOperationsExecutor( OperationsExecutor operationsExecutor ) {
    this.operationsExecutor = operationsExecutor;
  }

  public IProgressIndicator getProgressIndicator() {
    return progressIndicator;
  }

  public float getDensityFactor() {
    return displayMetrics.density;
  }

  public int getDensityDpi() {
    return displayMetrics.densityDpi;
  }

  public BitmapDrawableCache getBitmapCache() {
    return bitmapCache;
  }

  public FocusTrackingListener getFocusTrackingListener() {
    return recordingFocusChangedListener;
  }

  public void addAppStateListener( IAppStateListener listener ) {
    appStateListeners.add( listener );
  }

  public void removeAppStateListener( IAppStateListener listener ) {
    appStateListeners.remove( listener );
  }

  public void appStateChanged( AppState state ) {
    for( int i = 0; i < appStateListeners.size(); i++ ) {
      appStateListeners.get( i ).stateChanged( state );
    }
  }

  /** To be used for testing only. */
  ArrayList<IAppStateListener> getAppStateListeners() {
    return appStateListeners;
  }

  public void addActivityResultListener( IActivityResultListener listener ) {
    activityResultListeners.add( listener );
  }

  public void removeActivityResultListener( IActivityResultListener listener ) {
    activityResultListeners.remove( listener );
  }

  public void receivedActivityResult( int requestCode, int resultCode, Intent data ) {
    for( int i = 0; i < activityResultListeners.size(); i++ ) {
      activityResultListeners.get( i ).receivedActivityResult( requestCode, resultCode, data );
    }
  }

  /** To be used for testing only. */
  ArrayList<IActivityResultListener> getActivityResultListeners() {
    return activityResultListeners;
  }

  public RequestCodePool getRequestCodePool() {
    return requestCodePool;
  }

  public void addOperationsListProcessedListener( IOperationsListProcessedListener listener ) {
    operationsListProcessedListeners.add( listener );
  }

  public void removeOperationsListProcessedListener( IOperationsListProcessedListener listener ) {
    operationsListProcessedListeners.remove( listener );
  }

  public void fireOperationsListProcessed() {
    for( int i = 0; i < operationsListProcessedListeners.size(); i++ ) {
      operationsListProcessedListeners.get( i ).listProcessed();
    }
  }

  /** To be used for testing only. */
  ArrayList<IOperationsListProcessedListener> getOperationsListProcessedListener() {
    return operationsListProcessedListeners;
  }

}
