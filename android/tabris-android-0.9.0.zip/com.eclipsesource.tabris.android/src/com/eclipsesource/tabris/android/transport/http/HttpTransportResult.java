/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.transport.http;

import java.io.InputStream;

import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.TransportException;

public class HttpTransportResult implements ITransportResult {

  private InputStream inputStream;

  private Exception exception;

  public InputStream getResult() {
    return inputStream;
  }

  public void setResult( InputStream inputStream ) {
    this.inputStream = inputStream;
  }

  public boolean hasException() {
    return exception != null;
  }

  private boolean isParsable() {
    if( exception instanceof TransportException ) {
      TransportException transportException = ( TransportException )exception;
      if( transportException.getStatusCode() == 403 ) {
        return true;
      }
    }
    return false;
  }

  public Exception getException() {
    return exception;
  }

  public void setException( Exception exception ) {
    this.exception = exception;
  }

  public boolean hasParsableContent() {
    return !hasException() || isParsable();
  }
}
