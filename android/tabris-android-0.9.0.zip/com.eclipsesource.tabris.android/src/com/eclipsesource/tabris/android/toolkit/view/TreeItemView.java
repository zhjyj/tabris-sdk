/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.ViewGroup;

/**
 * The {@link TreeItemView} acts as a place holder for {@link TreeView} content.
 */
public class TreeItemView extends ViewGroup {

  private TreeItemView treeItemParent;
  private final ArrayList<TreeItemView> children;
  private TreeView treeView;
  private BitmapDrawable image;
  private List<String> text;
  private List<Integer> foregroundCellColors;
  private List<Integer> backgroundCellColors;
  private int itemCount;

  public TreeItemView( Context context ) {
    super( context );
    children = new ArrayList<TreeItemView>();
  }

  @Override
  protected void onLayout( boolean changed, int l, int t, int r, int b ) {
    // we don't need to perform any layout operation as we are not attached to a
    // parent view. The TreeItemView acts as a place holder for TreeView
    // content.
  }

  @Override
  public void addView( View view ) {
    if( view instanceof TreeItemView ) {
      TreeItemView treeItem = ( TreeItemView )view;
      children.add( treeItem );
      treeItem.setTreeItemParent( this );
      treeItem.setTreeView( getTreeView() );
      getTreeView().refreshTree();
    } else {
      throw new UnsupportedOperationException( "A TreeItemView can only accept TreeItems as children. Trying to add "
                                               + view.getClass().getName() );
    }
  }

  public TreeView getTreeView() {
    return this.treeView;
  }

  void setTreeView( TreeView treeView ) {
    this.treeView = treeView;
  }

  public ArrayList<TreeItemView> getChildren() {
    return children;
  }

  @Override
  public void removeViewAt( int index ) {
    if( index > -1 ) {
      children.remove( index );
      getTreeView().refreshTree();
    }
  }

  @Override
  public void removeView( View view ) {
    removeViewAt( children.indexOf( view ) );
  }

  @Override
  public int indexOfChild( View child ) {
    return children.indexOf( child );
  }

  @Override
  public TreeItemView getChildAt( int index ) {
    return children.get( index );
  }

  protected View findViewWithTagTraversal( Object tag ) {
    if( tag == null ) {
      throw new IllegalArgumentException( "Can not search for null tag" );
    }
    return findTreeItem( this, tag );
  }

  private static TreeItemView findTreeItem( TreeItemView treeItemView, Object tag ) {
    if( tag.equals( treeItemView.getTag() ) ) {
      return treeItemView;
    }
    for( int i = 0; i < treeItemView.children.size(); i++ ) {
      TreeItemView validChild = findTreeItem( treeItemView.children.get( i ), tag );
      if( validChild != null ) {
        return validChild;
      }
    }
    return null;
  }

  public List<String> getTexts() {
    return text;
  }

  public void setTexts( List<String> texts ) {
    this.text = texts;
  }

  public List<Integer> getForegroundCellColors() {
    return foregroundCellColors;
  }

  public void setForegroundCellColors( List<Integer> foregroundCellColors ) {
    this.foregroundCellColors = foregroundCellColors;
  }

  public List<Integer> getBackgroundCellColors() {
    return backgroundCellColors;
  }

  public void setBackgroundCellColors( List<Integer> backgroundCellColors ) {
    this.backgroundCellColors = backgroundCellColors;
  }

  public void setImage( BitmapDrawable image ) {
    this.image = image;
  }

  public BitmapDrawable getImage() {
    return image;
  }

  public TreeItemView getTreeItemParent() {
    return treeItemParent;
  }

  private void setTreeItemParent( TreeItemView treeItemParent ) {
    this.treeItemParent = treeItemParent;
  }

  public void setItemCount( int itemCount ) {
    this.itemCount = itemCount;
    getTreeView().refreshTree();
  }

  /**
   * Gets the designated number of children in the {@link TreeItemView} when
   * this item exists in a virtual tree.
   * <p>
   * The number is not the physical number of children currently in the item.
   * Use {@link #getChildren()} to get the existing number children in the item.
   * 
   * @return the number of allocated slots for children
   */
  public int getItemCount() {
    return itemCount;
  }

  /**
   * Determines whether this {@link TreeItemView} has children. It can either
   * have children because it has physical children in its
   * {@link #getChildren()} list or it is a virtual node that has children
   * defined via {@link #getItemCount()}.
   * 
   * @return <code>true</code> when this {@link TreeItemView} has children or
   *         <code>false</code> otherwise
   */
  public boolean hasChildren() {
    return !children.isEmpty() || itemCount > 0;
  }

}