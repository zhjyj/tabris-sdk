/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.PROP_TOP_INDEX;
import static com.eclipsesource.tabris.android.toolkit.util.ParamCheck.notNull;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class ScrollListener implements OnScrollListener {

  private int firstVisibleItem;
  private final TabrisActivity activity;

  public ScrollListener( TabrisActivity activity ) {
    notNull( activity, "Activity" );
    this.activity = activity;
  }

  public void onScrollStateChanged( AbsListView view, int scrollState ) {
    if( scrollState == SCROLL_STATE_IDLE ) {
      RemoteObject remoteObject = activity.getRemoteObject( view );
      remoteObject.set( PROP_TOP_INDEX, firstVisibleItem );
    }
  }

  public void onScroll( AbsListView view,
                        int firstVisibleItem,
                        int visibleItemCount,
                        int totalItemCount )
  {
    this.firstVisibleItem = firstVisibleItem;
  }
}
