/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class ListenerHolder<T> {

  private final ArrayList<T> listeners;

  public ListenerHolder() {
    listeners = new ArrayList<T>();
  }

  public void addListener( T listener ) {
    ValidationUtil.checkNullArg( this, listener, Object.class );
    listeners.add( listener );
  }

  public void removeListener( T listener ) {
    listeners.remove( listener );
  }

  public void removeListeners( Class<? extends T> listenerClass ) {
    for( int i = listeners.size() - 1; i >= 0; i-- ) {
      T listener = listeners.get( i );
      if( listener.getClass().equals( listenerClass ) ) {
        listeners.remove( listener );
      }
    }
  }

  public boolean contains( Class<? extends T> listenerClass ) {
    return findListener( listenerClass ) != null;
  }

  public T findListener( Class<? extends T> listenerClass ) {
    T result = null;
    ValidationUtil.checkNullArg( this, listenerClass, Class.class );
    for( int i = listeners.size() - 1; i >= 0; i-- ) {
      T listener = listeners.get( i );
      if( listenerClass.isInstance( listener ) ) {
        if( result == null ) {
          result = listener;
        } else {
          throw new IllegalStateException( "Found two matching listeners for " + listenerClass );
        }
      }
    }
    return result;
  }

  public int getSize() {
    return listeners.size();
  }

  public ArrayList<T> getListeners() {
    return listeners;
  }

}
