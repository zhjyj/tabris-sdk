/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.core.model;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;


public class Head {

  public static final String PROP_REQUEST_COUNTER = "requestCounter";
  public static final String PROP_RWT_INITIALIZE = "rwt_initialize";
  public static final String PROP_ERROR = "error";
  public static final String PROP_MESSAGE = "message";
  public static final String PROP_URL = "url";
  public static final String PROP_REDIRECT = "redirect";
  public static final String ERROR_SESSION_TIMEOUT = "session timeout";

  private static final String NOT_INSTANCE_TEXT = "Property ''{0}'' is not an instance of {1}: {2}";

  private final Map<String, Object> headersMap;

  public Head() {
    headersMap = new HashMap<String, Object>();
  }

  public boolean hasHeader( String key ) {
    ParamCheck.notNull( key, "key" );
    return headersMap.containsKey( key );
  }

  public void add( String key, Object value ) {
    ParamCheck.notNull( key, "key" );
    headersMap.put( key, value );
  }

  public Map<String, Object> getAll() {
    return Collections.unmodifiableMap( headersMap );
  }

  public void clear() {
    headersMap.clear();
  }

  public String getString( String key ) {
    return getAs( key, String.class );
  }

  public Integer getInteger( String key ) {
    return getAs( key, Integer.class );
  }

  public Boolean getBoolean( String key ) {
    return getAs( key, Boolean.class );
  }

  @Override
  public int hashCode() {
    return headersMap.hashCode();
  }

  @Override
  public boolean equals( Object object ) {
    boolean result = false;
    if( object == this ) {
      result = true;
    } else if( object.getClass() == Head.class ) {
      Head other = ( Head )object;
      result = headersMap.equals( other.headersMap );
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  private <T> T getAs( String key, Class<T> clazz ) {
    ParamCheck.notNull( key, "key" );
    T result = null;
    Object value = headersMap.get( key );
    if( value != null ) {
      if( clazz.isInstance( value ) ) {
        result = ( T )value;
      } else {
        Object[] args = new Object[] { key, clazz.getSimpleName(), value.getClass().getSimpleName() };
        String msg = MessageFormat.format( NOT_INSTANCE_TEXT, args );
        throw new IllegalStateException( msg );
      }
    }
    return result;
  }

}
