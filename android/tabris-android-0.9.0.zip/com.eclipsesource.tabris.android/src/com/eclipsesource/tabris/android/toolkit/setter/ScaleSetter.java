/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Scale;

public class ScaleSetter<T extends Scale> extends ViewSetter<T> {

  public ScaleSetter( TabrisActivity activity ) {
    super( activity );
  }

  private final int FIXED_HEIGHT = 32;

  @Override
  public void execute( T scale, Properties properties ) {
    super.execute( scale, properties );
    setMinimum( scale, properties );
    setMaximum( scale, properties );
  }

  private void setMinimum( T scale, Properties properties ) {
    Integer minimum = properties.getInteger( ProtocolConstants.PROP_MINIMUM );
    if( minimum != null ) {
      scale.setMin( minimum );
    }
  }

  private void setMaximum( T scale, Properties properties ) {
    Integer maximum = properties.getInteger( ProtocolConstants.PROP_MAXIMUM );
    if( maximum != null ) {
      scale.setMax( maximum );
    }
  }

  @Override
  protected void setSelection( View view, Properties properties ) {
    Integer selection = properties.getInteger( ProtocolConstants.PROP_SELECTION );
    if( selection != null ) {
      ( ( Scale )view ).setProgress( selection.intValue() );
    }
  }

  @Override
  protected List<Integer> adjustBounds( View view, List<Integer> bounds ) {
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    newBounds.add( bounds.get( 0 ) );
    newBounds.add( bounds.get( 1 ) + bounds.get( 3 ) / 2 - FIXED_HEIGHT / 2 );
    newBounds.add( bounds.get( 2 ) );
    newBounds.add( FIXED_HEIGHT );
    return newBounds;
  }

}