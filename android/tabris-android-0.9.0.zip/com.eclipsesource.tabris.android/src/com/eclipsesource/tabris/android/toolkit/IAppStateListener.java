
package com.eclipsesource.tabris.android.toolkit;

public interface IAppStateListener {

  void stateChanged( AppState state );

}