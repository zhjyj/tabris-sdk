/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ToolItemSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.eclipsesource.tabris.android.toolkit.view.SeparatorToolItem;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;

public class ToolItemOperator extends LabelOperator {

  public static final String TYPE = "rwt.widgets.ToolItem";

  private static final String STYLE_SEPARATOR = "SEPARATOR";
  private static final String STYLE_PUSH = "PUSH";

  private final IViewSetter<? extends View> setter;

  public ToolItemOperator( TabrisActivity activity ) {
    super( activity );
    setter = new ToolItemSetter<ToolItem>( activity );
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  @Override
  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List<String> style = operation.getProperties().getList( ProtocolConstants.PROP_STYLE, String.class );
    ToolItem toolItem = null;
    if( style != null ) {
      if( style.contains( STYLE_PUSH ) ) {
        toolItem = new PushToolItem( getActivity() );
      } else if( style.contains( STYLE_SEPARATOR ) ) {
        toolItem = new SeparatorToolItem( getActivity() );
      }
    }
    if( toolItem != null ) {
      initiateNewView( operation, toolItem );
    }
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    super.attachSelectionListener( operation );
    setBackgroundResource( operation, R.drawable.item_background_holo_dark );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    super.removeSelectionListener( operation );
    setBackgroundResource( operation, R.drawable.item_background_holo_dark_no_selection );
  }

  private void setBackgroundResource( ListenOperation operation, int drawableResId ) {
    final View view = findViewByTarget( operation );
    if( view instanceof PushToolItem ) {
      // temporarily cashing the paddings is required because the paddings of
      // the new drawable are ignored
      int bottom = view.getPaddingBottom();
      int top = view.getPaddingTop();
      int right = view.getPaddingRight();
      int left = view.getPaddingLeft();
      view.setBackgroundResource( drawableResId );
      view.setPadding( left, top, right, bottom );
    }
  }

  @Override
  public String getType() {
    return TYPE;
  }

}
