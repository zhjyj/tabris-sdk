/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.util.ValidationUtil.*;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.TextViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class LabelOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Label";

  private final IViewSetter<? extends View> setter;

  public LabelOperator( TabrisActivity activity ) {
    super( activity );
    setter = new TextViewSetter<TextView>( activity );
  }

  public void create( CreateOperation operation ) {
    validateCreateOperation( getActivity(), operation );
    TextView textView = new TextView( getActivity() );
    textView.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.LABEL_TEXT_SIZE );
    textView.setIncludeFontPadding( false );
    initiateNewView( operation, textView );
  }

  public String getType() {
    return TYPE;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected IViewSetter<View> getViewSetter( View view ) {
    return ( IViewSetter<View> )setter;
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null || !( view instanceof TextView ) ) {
      throw new IllegalArgumentException( "Could not find TextView "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    BitmapDrawableCache cache = getProcessor().getWidgetToolkit().getBitmapCache();
    cache.decreaseReferenceCount( getTextViewSetter().getBitmapDrawable( ( TextView )view ) );
    super.destroy( operation );
  }

  @SuppressWarnings("unchecked")
  protected TextViewSetter<TextView> getTextViewSetter() {
    return ( TextViewSetter<TextView> )setter;
  }
}
