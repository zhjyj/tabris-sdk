/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import com.eclipsesource.tabris.android.core.util.StringUtil;

public class GetRequest extends TransportRequest {

  public GetRequest() {
    this( StringUtil.EMPTY_STRING );
  }

  public GetRequest( String path ) {
    super( path );
  }

}
