/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class MoveToGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "moveTo";

  public MoveToGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 3 );
    float x = getScaledFloat( properties, 1 );
    float y = getScaledFloat( properties, 2 );
    gc.getPath().moveTo( x, y );
  }

}
