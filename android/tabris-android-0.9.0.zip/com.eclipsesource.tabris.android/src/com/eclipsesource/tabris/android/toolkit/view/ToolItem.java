/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout.LayoutParams;

public class ToolItem extends Button {

  private ToolBar toolBar;

  public ToolItem( Context context ) {
    super( context );
  }

  public void updateAppearance() {
    // to be overriden by subclasses
  }

  public LayoutParams createLayoutParams() {
    return new LayoutParams( LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT );
  }

  public void setHorizontalSpacing( int itemSpacing ) {
    setPadding( itemSpacing, 0, itemSpacing, 0 );
  }

  public void setParentToolBar( ToolBar toolBar ) {
    this.toolBar = toolBar;
  }

  public ToolBar getParentToolBar() {
    return toolBar;
  }

}
