/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.parser.SessionIDExtractor;
import com.eclipsesource.tabris.android.toolkit.util.ParamCheck;

public class ProtocolProcessor implements IProtocolParserCallback {

  private ITransport transport;
  private IProtocolParser parser;
  private IWidgetToolkit widgetToolkit;
  private long sessionStartTime;
  private ExecutorService requestThreadPool;
  private final ReentrantReadWriteLock shutdownLock;
  private final Head currentHead;
  private final List<Operation> operationsQueue;
  private Timer sendTimer;
  private boolean sendTimerRunning;
  private final Object lock;

  public ProtocolProcessor() {
    requestThreadPool = Executors.newSingleThreadExecutor();
    shutdownLock = new ReentrantReadWriteLock();
    currentHead = new Head();
    operationsQueue = new ArrayList<Operation>();
    sendTimer = new Timer();
    lock = new Object();
  }

  public void startSession() {
    verify();
    parser.addProtocolParserCallback( this );
    sessionStartTime = System.currentTimeMillis();
    sendInitialGetRequest( new GetRequest( "" ), parser );
  }

  private void sendInitialGetRequest( GetRequest getRequest, IProtocolParser parser ) {
    shutdownLock.readLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new InitialGetRequestRunnable( getRequest, this, parser ) );
      }
    } finally {
      shutdownLock.readLock().unlock();
    }
  }

  /**
   * Executes the {@link PostRequest} in an asynchronous fashion. The call
   * returns immediately.
   * 
   * @param request the {@link PostRequest} to execute
   */
  public void processPostRequest( PostRequest request ) {
    attachHeaders( request );
    shutdownLock.readLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new PostRequestRunnable( request, this ) );
      }
    } finally {
      shutdownLock.readLock().unlock();
    }
  }

  public void appendHeader( String name, Object value ) {
    ParamCheck.notNullOrEmpty( name, "name" );
    synchronized( lock ) {
      currentHead.add( name, value );
    }
  }

  public void appendOperation( Operation operation ) {
    ParamCheck.notNull( operation, "operation" );
    synchronized( lock ) {
      operationsQueue.add( operation );
    }
  }

  public void send() {
    if( !sendTimerRunning && sendTimer != null ) {
      sendTimerRunning = true;

      sendTimer.schedule( new TimerTask() {

        @Override
        public void run() {
          sendImmediate();
          sendTimerRunning = false;
        }
      }, 60 );
    }
  }

  public void sendImmediate() {
    synchronized( lock ) {
      List<Operation> optimizedOperations = optimizeSetOperations( operationsQueue );
      PostRequest request = new PostRequest();
      request.setContent( getParser().createMessage( optimizedOperations, currentHead.getAll() ) );
      processPostRequest( request );
      currentHead.clear();
      operationsQueue.clear();
    }
  }

  List<Operation> optimizeSetOperations( List<Operation> operations ) {
    List<Operation> result = new ArrayList<Operation>();
    SetOperation lastSetOperation = null;
    for( Operation operation : operations ) {
      if( operation instanceof SetOperation ) {
        SetOperation currentSetOperation = ( SetOperation )operation;
        if( lastSetOperation == null ) {
          lastSetOperation = currentSetOperation;
        } else if( lastSetOperation.getTarget().equals( currentSetOperation.getTarget() ) ) {
          Map<String, Object> properties = currentSetOperation.getProperties().getAll();
          lastSetOperation.getProperties().add( properties );
        } else {
          result.add( lastSetOperation );
          lastSetOperation = currentSetOperation;
        }
      } else {
        if( lastSetOperation != null ) {
          result.add( lastSetOperation );
          lastSetOperation = null;
        }
        result.add( operation );
      }
    }
    if( lastSetOperation != null ) {
      result.add( lastSetOperation );
    }
    return result;
  }

  private void attachHeaders( PostRequest request ) {
    Integer requestCounter = currentHead.getInteger( Head.PROP_REQUEST_COUNTER );
    if( requestCounter != null ) {
      request.addParam( Head.PROP_REQUEST_COUNTER, String.valueOf( requestCounter ) );
    }
  }

  public ITransportResult processGetRequest( GetRequest request ) {
    ITransportResult transportResult = transport.get( request );
    if( transportResult.hasException() && !request.isSilentRequest() ) {
      showError( transportResult.getException() );
    }
    return transportResult;
  }

  private void verify() {
    if( parser == null ) {
      throw new IllegalStateException( "The IProtocolParser can not be null" );
    }
    if( widgetToolkit == null ) {
      throw new IllegalStateException( "The IWidgetToolkit can not be null" );
    }
    if( transport == null ) {
      throw new IllegalStateException( "The ITransport can not be null" );
    }
  }

  private void showError( final Exception exception ) {
    widgetToolkit.showError( exception, null );
  }

  public ITransport getTransport() {
    return transport;
  }

  public void setTransport( ITransport transport ) {
    this.transport = transport;
  }

  public IProtocolParser getParser() {
    return parser;
  }

  public void setParser( IProtocolParser parser ) {
    this.parser = parser;
  }

  public IWidgetToolkit getWidgetToolkit() {
    return widgetToolkit;
  }

  public void setWidgetToolkit( IWidgetToolkit widgetToolkit ) {
    this.widgetToolkit = widgetToolkit;
  }

  public void operationsFound( final List<Operation> operations ) {
    try {
      widgetToolkit.process( operations );
    } catch( Exception e ) {
      showError( e );
    }
  }

  public void headFound( Head head ) {
    if( head.hasHeader( Head.PROP_REQUEST_COUNTER ) ) {
      appendHeader( Head.PROP_REQUEST_COUNTER, head.getInteger( Head.PROP_REQUEST_COUNTER ) );
    }
    handleURL( head );
    handleError( head );
  }

  private void handleURL( Head head ) {
    if( head.hasHeader( Head.PROP_URL ) ) {
      String url = head.getString( Head.PROP_URL );
      SessionIDExtractor sessionIDExtractor = new SessionIDExtractor();
      transport.setSessionId( sessionIDExtractor.extract( url ) );
    }
  }

  private void handleError( Head head ) {
    if( head.hasHeader( Head.PROP_ERROR ) ) {
      String error = head.getString( Head.PROP_ERROR );
      if( Head.ERROR_SESSION_TIMEOUT.equals( error ) ) {
        LocalizableException exception = new LocalizableException( LocalizableException.SESSION_TIMEOUT );
        widgetToolkit.showError( exception, null );
      }
    }
  }

  public long getSessionTime() {
    if( sessionStartTime == 0 ) {
      return 0;
    } else {
      return System.currentTimeMillis() - sessionStartTime;
    }
  }

  /** Should only be used for testing. */
  void setRequestThreadPool( ExecutorService postThreadPool ) {
    this.requestThreadPool = postThreadPool;
  }

  /** Should only be used for testing. */
  void setSendTimer( Timer sendTimer ) {
    this.sendTimer = sendTimer;
  }

  public void shutdown() {
    shutdownLock.writeLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.shutdownNow();
        requestThreadPool = null;
      }
    } finally {
      shutdownLock.writeLock().unlock();
    }
    if( transport != null ) {
      transport.dispose();
    }
    if( widgetToolkit != null ) {
      widgetToolkit.dispose();
    }
    sendTimer.cancel();
    sendTimer.purge();
    sendTimer = null;
  }
}
