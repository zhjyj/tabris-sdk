/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public interface IGcOperation {

  void execute( GraphicalContext gc, List<?> properties );

  String getOperation();

}
