/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Canvas;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class StrokeTextGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "strokeText";

  public StrokeTextGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  public StrokeTextGcOperation( String op, TabrisActivity activity ) {
    super( op, activity );
  }

  public void execute( final GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 7 );
    String text = ( String )properties.get( 1 );
    float x = getScaledFloat( properties, 5 );
    float y = getScaledFloat( properties, 6 );

    TextPaint textPaint = new TextPaint( gc.getPaint() );
    textPaint.setColor( gc.getStrokeColor() );
    textPaint.setStrokeWidth( 0 );
    int alpha = gc.getPaint().getAlpha();
    textPaint.setAlpha( alpha );
    StaticLayout textLayout = createTextLayout( text, textPaint );
    beforeDrawText( gc, x, y, textLayout );
    Canvas canvas = gc.getCanvas();
    canvas.save();
    canvas.translate( x, y );
    textLayout.draw( canvas );
    canvas.restore();
  }

  protected StaticLayout createTextLayout( String text, TextPaint textPaint ) {
    return new StaticLayout( text,
                             textPaint,
                             Integer.MAX_VALUE,
                             Alignment.ALIGN_NORMAL,
                             1.0f,
                             0.0f,
                             false );
  }

  protected void beforeDrawText( GraphicalContext gc,
                                 float scaledX,
                                 float scaledY,
                                 StaticLayout textLayout )
  {
    // to be implemented by subclasses
  }

}
