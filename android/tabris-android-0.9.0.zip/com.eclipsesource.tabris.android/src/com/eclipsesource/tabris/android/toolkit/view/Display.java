/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.operator.ProtocolConstants.*;

import java.util.Arrays;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;

public class Display extends FrameLayout {

  private boolean sessionRunning;

  public Display( Context context ) {
    super( context );
  }

  public Display( Context context, AttributeSet attrSet ) {
    super( context, attrSet );
  }

  @Override
  public void onSizeChanged( int w, int h, int oldw, int oldh ) {
    super.onSizeChanged( w, h, oldw, oldh );
    TabrisActivity activity = ( TabrisActivity )getContext();
    ProtocolProcessor processor = activity.getProcessor();
    if( !sessionRunning ) {
      if( getAutoStartSessionFromIntent( activity ) ) {
        try {
          processor.startSession();
        } catch( Throwable t ) {
          activity.closeActivity( t );
        }
        sessionRunning = true;
      }
    } else {
      processDisplaySizeChanged( activity, w, h );
    }
  }

  private void processDisplaySizeChanged( TabrisActivity activity, final int width, final int height )
  {
    updateShellDimensions( width, height );
    sendDisplayScaleMessage( activity, width, height );
  }

  private void sendDisplayScaleMessage( TabrisActivity activity, final int width, final int height )
  {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    int scaledWidth = toolkit.divideByDensityFactor( width );
    int scaledHeight = toolkit.divideByDensityFactor( height );
    RemoteObject remoteObject = activity.getRemoteObject( this );
    remoteObject.set( PROP_BOUNDS, Arrays.asList( 0, 0, scaledWidth, scaledHeight ) );
    remoteObject.getProcessor().send();
  }

  private void updateShellDimensions( final int width, final int height ) {
    for( int i = 0; i < getChildCount(); i++ ) {
      View view = getChildAt( i );
      if( view instanceof Shell && ( ( Shell )view ).isMaximized() ) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = width;
        params.height = height;
      }
    }
  }

  private boolean getAutoStartSessionFromIntent( Activity activity ) {
    return activity.getIntent().getBooleanExtra( TabrisActivity.AUTO_START_SESSION, true );
  }

  public boolean isSessionRunning() {
    return sessionRunning;
  }

  /** To be used for testing only. */
  void setSessionRunning( boolean sessionRunning ) {
    this.sessionRunning = sessionRunning;
  }

}
