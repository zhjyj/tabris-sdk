/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.TextSizeMeasurement;


public class TextSizeMeasurementOperator implements IOperator {

  public static final String TYPE = "rwt.client.TextSizeMeasurement";

  private static final String METHOD_MEASURE_ITEMS = "measureItems";
  private static final String PROP_ITEMS = "items";

  private final TabrisActivity activity;

  public TextSizeMeasurementOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    // do nothing
  }

  public void set( SetOperation operation ) {
    // do nothing
  }

  public void listen( ListenOperation operation ) {
    // do nothing
  }

  public void call( CallOperation operation ) {
    if( operation.getMethod().equals( METHOD_MEASURE_ITEMS ) ) {
      Properties properties = operation.getProperties();
      getInstance().measureItems( properties.getMatrix( PROP_ITEMS, Object.class ) );
    }
  }

  public void destroy( DestroyOperation operation ) {
    getObjectRegistry().unregister( TYPE );
  }

  private TextSizeMeasurement getInstance() {
    ObjectRegistry objectRegistry = getObjectRegistry();
    TextSizeMeasurement result = objectRegistry.getObject( TYPE, TextSizeMeasurement.class );
    if( result == null ) {
      result = new TextSizeMeasurement( activity );
      objectRegistry.register( TYPE, result, TYPE );
      RemoteObject remoteObject = objectRegistry.getRemoteObject( TYPE );
    }
    return result;
  }

  private ObjectRegistry getObjectRegistry() {
    return activity.getProcessor().getWidgetToolkit().getObjectRegistry();
  }

}
