/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.List;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.Parent;

public class ObservableScrollView extends Composite implements Parent {

  private final TabrisActivity activity;
  private ObservableHorizontalScrollView horizontalScroll;
  private ObservableVerticalScrollView verticalScroll;
  private final List<Object> chldren;

  public ObservableScrollView( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
    this.chldren = new ArrayList<Object>();
  }

  public void createNestedScrollViews() {
    verticalScroll = new ObservableVerticalScrollView( activity, this );
    verticalScroll.setTag( getTag() );
    verticalScroll.getScrollSupport().setDirection( ScrollSupportDirection.Y );
    super.addView( verticalScroll );
    horizontalScroll = new ObservableHorizontalScrollView( activity, this );
    horizontalScroll.setTag( getTag() );
    horizontalScroll.getScrollSupport().setDirection( ScrollSupportDirection.X );
    verticalScroll.addView( horizontalScroll );
  }

  public ObservableHorizontalScrollView getHorizontalScroll() {
    return horizontalScroll;
  }

  public ObservableVerticalScrollView getVerticalScroll() {
    return verticalScroll;
  }

  @Override
  public void addView( View child ) {
    horizontalScroll.addView( child );
  }

  @Override
  public void removeViewAt( int index ) {
    horizontalScroll.removeViewAt( index );
  }

  @Override
  public void removeView( View view ) {
    ViewGroup viewGroup = ( ViewGroup )view.getParent();
    viewGroup.removeViewAt( viewGroup.indexOfChild( view ) );
  }

  public void addChild( Object child ) {
    chldren.add( child );
  }

  public List<Object> getChildren() {
    return chldren;
  }

}
