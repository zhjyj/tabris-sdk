/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAnimationSet;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowScaleAnimation;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowTranslateAnimation;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowView;

@SuppressWarnings({
  "unchecked", "rawtypes"
})
@RunWith(RobolectricTestRunner.class)
public class BoundsAnimationSupport_Test {

  private BoundsAnimationSupport animSupport;
  private ViewSetter viewSetter;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    animSupport = new BoundsAnimationSupport();
    viewSetter = mock( ViewSetter.class );
    toolkit = mock( IWidgetToolkit.class );
    ProtocolProcessor protocolProcessor = mock( ProtocolProcessor.class );
    when( protocolProcessor.getWidgetToolkit() ).thenReturn( toolkit );
    when( viewSetter.getProcessor() ).thenReturn( protocolProcessor );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testApplyBoundsAnimationNullArg1() {
    BoundsAnimationSupport animSupport = new BoundsAnimationSupport();
    animSupport.applyBoundsAnimations( null, mock( View.class ), mock( List.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testApplyBoundsAnimationNullArg2() {
    BoundsAnimationSupport animSupport = new BoundsAnimationSupport();
    animSupport.applyBoundsAnimations( mock( ViewSetter.class ), null, mock( List.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testApplyBoundsAnimationNullArg3() {
    BoundsAnimationSupport animSupport = new BoundsAnimationSupport();
    animSupport.applyBoundsAnimations( mock( ViewSetter.class ), mock( View.class ), null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testApplyBoundsAnimationIllegalBounds() {
    BoundsAnimationSupport animSupport = new BoundsAnimationSupport();
    List<Integer> bounds = Arrays.asList( 2, 3, 4 );
    animSupport.applyBoundsAnimations( mock( ViewSetter.class ), mock( View.class ), bounds );
  }

  @Test
  public void testApplyBoundsAnimationTranslateOnly() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowTranslateAnimation.class );
    List<Integer> bounds = Arrays.asList( 200, 300, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 400 );
    when( toolkit.multiplyByDensityFactor( 300 ) ).thenReturn( 600 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 200 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 100, 300, 100, 300 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    TranslateAnimation anim = ( TranslateAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowTranslateAnimation shadowTranslateAnim = ( TabrisShadowTranslateAnimation )Robolectric.shadowOf( anim );
    assertTranslationDelta( shadowTranslateAnim, 300, 500 );
  }

  private ShadowView setBoundsOnShadowView( View view, int left, int right, int top, int bottom ) {
    ShadowView shadowView = Robolectric.shadowOf( view );
    shadowView.setLeft( left );
    shadowView.setRight( right );
    shadowView.setTop( top );
    shadowView.setBottom( bottom );
    return shadowView;
  }

  @Test
  public void testApplyBoundsAnimationTranslateToZero() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowTranslateAnimation.class );
    List<Integer> bounds = Arrays.asList( 0, 0, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 0 ) ).thenReturn( 0 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 100, 200, 50, 150 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    TranslateAnimation anim = ( TranslateAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowTranslateAnimation shadowTranslateAnim = ( TabrisShadowTranslateAnimation )Robolectric.shadowOf( anim );
    assertTranslationDelta( shadowTranslateAnim, -100, -50 );
  }

  @Test
  public void testApplyBoundsAnimationTranslateFromZero() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowTranslateAnimation.class );
    List<Integer> bounds = Arrays.asList( 200, 300, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 200 );
    when( toolkit.multiplyByDensityFactor( 300 ) ).thenReturn( 300 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 0, 100, 0, 100 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    TranslateAnimation anim = ( TranslateAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowTranslateAnimation shadowTranslateAnim = ( TabrisShadowTranslateAnimation )Robolectric.shadowOf( anim );
    assertTranslationDelta( shadowTranslateAnim, 200, 300 );
  }

  private void assertTranslationDelta( TabrisShadowTranslateAnimation shadowTranslateAnim,
                                       int deltaX,
                                       int deltaY )
  {
    assertEquals( 0, shadowTranslateAnim.getFromXDelta(), 0 );
    assertEquals( deltaX, shadowTranslateAnim.getToXDelta(), 0 );
    assertEquals( 0, shadowTranslateAnim.getFromYDelta(), 0 );
    assertEquals( deltaY, shadowTranslateAnim.getToYDelta(), 0 );
  }

  private void assertScaleFactor( TabrisShadowScaleAnimation shadowScaleAnim,
                                  int scaleWidth,
                                  int scaleHeight )
  {
    assertEquals( 1, shadowScaleAnim.getFromX(), 0 );
    assertEquals( scaleWidth, shadowScaleAnim.getToX(), 0 );
    assertEquals( 1, shadowScaleAnim.getFromY(), 0 );
    assertEquals( scaleHeight, shadowScaleAnim.getToY(), 0 );
  }

  @Test
  public void testApplyBoundsAnimationScaleOnly() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowScaleAnimation.class );
    List<Integer> bounds = Arrays.asList( 200, 300, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 200 );
    when( toolkit.multiplyByDensityFactor( 300 ) ).thenReturn( 300 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 200, 250, 300, 350 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    ScaleAnimation anim = ( ScaleAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowScaleAnimation shadowScaleAnim = ( TabrisShadowScaleAnimation )Robolectric.shadowOf( anim );
    assertScaleFactor( shadowScaleAnim, 2, 2 );
  }

  @Test
  public void testApplyBoundsAnimationScaleToZero() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowScaleAnimation.class );
    List<Integer> bounds = Arrays.asList( 200, 200, 0, 0 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 200 );
    when( toolkit.multiplyByDensityFactor( 0 ) ).thenReturn( 0 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 200, 300, 200, 300 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    ScaleAnimation anim = ( ScaleAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowScaleAnimation shadowScaleAnim = ( TabrisShadowScaleAnimation )Robolectric.shadowOf( anim );
    assertScaleFactor( shadowScaleAnim, 0, 0 );
  }

  @Test
  public void testApplyBoundsAnimationScaleFromZero() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowScaleAnimation.class );
    List<Integer> bounds = Arrays.asList( 200, 200, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 200 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 200, 200, 200, 200 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    ScaleAnimation anim = ( ScaleAnimation )shadowView.getAnimation();
    assertTrue( anim.hasStarted() );
    TabrisShadowScaleAnimation shadowScaleAnim = ( TabrisShadowScaleAnimation )Robolectric.shadowOf( anim );
    assertScaleFactor( shadowScaleAnim, 100, 100 );
  }

  @Test
  public void testApplyBoundsAnimationScaleAndTranslate() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowScaleAnimation.class );
    Robolectric.bindShadowClass( TabrisShadowTranslateAnimation.class );
    Robolectric.bindShadowClass( TabrisShadowAnimationSet.class );
    List<Integer> bounds = Arrays.asList( 200, 300, 100, 100 );
    when( toolkit.multiplyByDensityFactor( 200 ) ).thenReturn( 200 );
    when( toolkit.multiplyByDensityFactor( 300 ) ).thenReturn( 300 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    View view = new View( new Activity() );
    ShadowView shadowView = setBoundsOnShadowView( view, 100, 150, 200, 250 );

    assertNull( shadowView.getAnimation() );

    animSupport.applyBoundsAnimations( viewSetter, view, bounds );

    AnimationSet animSet = ( AnimationSet )shadowView.getAnimation();
    assertTrue( animSet.hasStarted() );
    List<Animation> animations = animSet.getAnimations();
    assertEquals( 2, animations.size() );
    // the order of animations has to be: scale, translate
    TabrisShadowScaleAnimation shadowScaleAnim = ( TabrisShadowScaleAnimation )Robolectric.shadowOf( animations.get( 0 ) );
    assertScaleFactor( shadowScaleAnim, 2, 2 );
    TabrisShadowTranslateAnimation shadowTranslateAnim = ( TabrisShadowTranslateAnimation )Robolectric.shadowOf( animations.get( 1 ) );
    assertTranslationDelta( shadowTranslateAnim, 100, 100 );
  }
}
