/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolBarOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String TOOLBAR_ID = "w3";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( TOOLBAR_ID );
    activity.setContentView( R.layout.protocol );
    parentLayout = new FrameLayout( activity );
    toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );

    assertTrue( operator.getViewSetter( mock( ToolBar.class ) ) instanceof ViewSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarNoProps() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateToolBarNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TOOLBAR_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateToolBarOk() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    verify( toolkit.getObjectRegistry() ).register( eq( TOOLBAR_ID ),
                                                    any( ToolBar.class ),
                                                    eq( "rwt.widgets.ToolBar" ) );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( TOOLBAR_ID );
    op.setType( "rwt.widgets.ToolBar" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateToolBarWrongBounds() throws Exception {
    AbstractWidgetOperator operator = new ToolBarOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "bounds", Arrays.asList( 10, 20, 30 ) );

    operator.create( op );
  }

  @Test
  public void testGetType() throws Exception {
    ToolBarOperator op = new ToolBarOperator( new TabrisActivity() );
    assertEquals( ToolBarOperator.TYPE, op.getType() );
  }

}