/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Head;
import com.eclipsesource.tabris.android.core.model.NotifyOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.parser.gson.GsonProtocolParser;
import com.eclipsesource.tabris.android.toolkit.IProgressIndicator;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProtocolProcessor_Test {

  private ProtocolProcessor protocolProcessor;

  @Before
  public void setUp() {
    protocolProcessor = new ProtocolProcessor();
  }

  @Test
  public void testCreateProcolProcessor() {
    protocolProcessor = new ProtocolProcessor();
    assertNotNull( protocolProcessor );
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionParserNull() throws Exception {
    ITransport transport = mock( ITransport.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    protocolProcessor.setTransport( transport );
    protocolProcessor.setWidgetToolkit( toolkit );

    protocolProcessor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionTransportNull() throws Exception {
    IProtocolParser transport = mock( IProtocolParser.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    protocolProcessor.setParser( transport );
    protocolProcessor.setWidgetToolkit( toolkit );

    protocolProcessor.startSession();
  }

  @Test(expected = IllegalStateException.class)
  public void testInitiateSessionToolkitNull() throws Exception {
    IProtocolParser parser = mock( IProtocolParser.class );
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setParser( parser );
    protocolProcessor.setTransport( transport );

    protocolProcessor.startSession();
  }

  @Test
  public void testSendInitialGetRequest() throws Exception {
    ExecutorService executerService = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( executerService );
    protocolProcessor.setTransport( mock( ITransport.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    protocolProcessor.setWidgetToolkit( toolkit );
    protocolProcessor.setParser( mock( IProtocolParser.class ) );

    protocolProcessor.startSession();

    verify( executerService ).execute( any( InitialGetRequestRunnable.class ) );
  }

  @Test
  public void testSendInitialPostRequest() throws Exception {
    TabrisActivity activity = mock( TabrisActivity.class );
    when( activity.findViewById( R.id.root_layout ) ).thenReturn( mock( View.class ) );
    when( activity.getProcessor() ).thenReturn( protocolProcessor );
    ExecutorService executorService = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( executorService );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    protocolProcessor.setWidgetToolkit( toolkit );
    protocolProcessor.setParser( new GsonProtocolParser() );
    when( toolkit.getSurfaceWidth() ).thenReturn( 480 );
    when( toolkit.getSurfaceHeight() ).thenReturn( 800 );
    when( toolkit.getSurfaceDpiX() ).thenReturn( 320 );
    when( toolkit.getSurfaceDpiY() ).thenReturn( 320 );
    when( toolkit.getSurfaceColorDepth() ).thenReturn( 24 );
    when( toolkit.divideByDensityFactor( 800 ) ).thenReturn( 400 );
    when( toolkit.divideByDensityFactor( 480 ) ).thenReturn( 240 );
    when( toolkit.getObjectRegistry() ).thenReturn( mock( ObjectRegistry.class ) );
    RemoteObject remoteObject = new RemoteObject( "w1", protocolProcessor );
    when( activity.getRemoteObject( any( Display.class ) ) ).thenReturn( remoteObject );

    DisplayOperator operator = new DisplayOperator( activity );
    CreateOperation operation = new CreateOperation();
    operation.setTarget( "w1" );
    operation.setType( "rwt.widgets.Display" );
    operator.create( operation );
    UiTestUtil.waitForRequest();

    ArgumentCaptor<PostRequestRunnable> captor = ArgumentCaptor.forClass( PostRequestRunnable.class );
    verify( executorService ).execute( captor.capture() );
    String expected = "{\"head\":{\"rwt_initialize\":true},"
                      + "\"operations\":[[\"set\",\"w1\","
                      + "{\"bounds\":[0,0,240,400],\"cursorLocation\":[0,0],\"colorDepth\":24,\"dpi\":[320,320]}]]}";
    assertEquals( expected, captor.getValue().getRequestContent() );
  }

  @Test
  public void testProcessGetRequestOk() throws Exception {
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( false );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( eq( request ) ) ).thenReturn( result );

    ITransportResult transportResult = protocolProcessor.processGetRequest( request );

    verify( transport ).get( request );
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessGetRequestFail() throws Exception {
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setTransport( transport );
    ITransportResult result = mock( ITransportResult.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    protocolProcessor.setWidgetToolkit( toolkit );
    when( result.hasException() ).thenReturn( true );
    when( result.getException() ).thenReturn( any( Exception.class ) );
    GetRequest request = new GetRequest( "/path" );
    when( transport.get( request ) ).thenReturn( result );

    ITransportResult transportResult = protocolProcessor.processGetRequest( request );

    verify( transport ).get( request );
    verify( transportResult ).getException();
    assertSame( result, transportResult );
  }

  @Test
  public void testProcessPostRequest() throws Exception {
    ExecutorService executorService = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( executorService );
    Head head = new Head();
    head.add( "requestCounter", 123 );
    protocolProcessor.headFound( head );
    PostRequest request = new PostRequest();

    protocolProcessor.processPostRequest( request );

    Map<String, String> parameters = request.getParams();
    assertEquals( "123", parameters.get( "requestCounter" ) );
    verify( executorService ).execute( any( PostRequestRunnable.class ) );
  }

  @Test
  public void testSetGetTransport() {
    ITransport transport = mock( ITransport.class );

    protocolProcessor.setTransport( transport );

    assertSame( protocolProcessor.getTransport(), transport );
  }

  @Test
  public void testSetGetParser() {
    IProtocolParser parser = mock( IProtocolParser.class );

    protocolProcessor.setParser( parser );

    assertSame( protocolProcessor.getParser(), parser );
  }

  @Test
  public void testSetGetToolkit() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );

    protocolProcessor.setWidgetToolkit( toolkit );

    assertSame( protocolProcessor.getWidgetToolkit(), toolkit );
  }

  @Test
  public void testGetSessionTime() throws Exception {
    ITransport transport = mock( ITransport.class );
    ITransportResult getResult = mock( ITransportResult.class );
    when( getResult.getResult() ).thenReturn( new ByteArrayInputStream( "".getBytes() ) );
    when( transport.get( any( GetRequest.class ) ) ).thenReturn( getResult );
    ITransportResult transportResult = mock( ITransportResult.class );
    when( transportResult.hasException() ).thenReturn( false );
    when( transport.post( any( PostRequest.class ) ) ).thenReturn( transportResult );
    protocolProcessor.setTransport( transport );
    protocolProcessor.setParser( mock( IProtocolParser.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getProgressIndicator() ).thenReturn( mock( IProgressIndicator.class ) );
    protocolProcessor.setWidgetToolkit( toolkit );

    assertEquals( 0, protocolProcessor.getSessionTime() );
    protocolProcessor.startSession();
    Thread.sleep( 1 );

    assertTrue( protocolProcessor.getSessionTime() > 0 );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundNull() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    protocolProcessor.setWidgetToolkit( toolkit );

    protocolProcessor.operationsFound( null );

    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundError() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    doThrow( NullPointerException.class ).when( toolkit ).process( any( ArrayList.class ) );
    protocolProcessor.setWidgetToolkit( toolkit );

    protocolProcessor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testOperationFoundOk() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    protocolProcessor.setWidgetToolkit( toolkit );

    protocolProcessor.operationsFound( mock( ArrayList.class ) );

    verify( toolkit ).process( any( ArrayList.class ) );
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testHeadSessionTimeoutFoundOk() {
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    protocolProcessor.setWidgetToolkit( toolkit );
    Head head = mock( Head.class );
    when( head.hasHeader( Head.PROP_ERROR ) ).thenReturn( true );
    when( head.getString( Head.PROP_ERROR ) ).thenReturn( Head.ERROR_SESSION_TIMEOUT );

    protocolProcessor.headFound( head );

    verify( toolkit ).showError( eq( new LocalizableException( LocalizableException.SESSION_TIMEOUT ) ),
                                 any( TransportRequest.class ) );
  }

  @Test
  public void testShutdown() throws Exception {
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setTransport( transport );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    protocolProcessor.setWidgetToolkit( toolkit );
    ExecutorService threadPool = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( threadPool );
    Timer sendTimer = mock( Timer.class );
    protocolProcessor.setSendTimer( sendTimer );

    protocolProcessor.shutdown();

    verify( transport ).dispose();
    verify( toolkit ).dispose();
    verify( threadPool ).shutdownNow();
    InOrder order = inOrder( sendTimer );
    order.verify( sendTimer ).cancel();
    order.verify( sendTimer ).purge();
  }

  @Test
  public void testMultipleOperationsSendOneRequest() throws Exception {
    ExecutorService executorService = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( executorService );
    protocolProcessor.setParser( mock( IProtocolParser.class ) );
    RemoteObject remoteObject = new RemoteObject( "w3", protocolProcessor );

    remoteObject.notify( "Selection", null );
    remoteObject.call( "close", null );
    UiTestUtil.waitForRequest();

    verify( executorService ).execute( any( Runnable.class ) );
  }

  @Test
  public void testOptimizeSetOperations_WithoutOptimizations() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = protocolProcessor.optimizeSetOperations( operations );

    assertEquals( operations, optimizedOpertations );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Start() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = protocolProcessor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 0 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_Middle() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );

    List<Operation> optimizedOpertations = protocolProcessor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 1 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  @Test
  public void testOptimizeSetOperations_WithOptimizations_End() throws Exception {
    List<Operation> operations = new ArrayList<Operation>();
    operations.add( createSetOperation( "w3", "p2", "2" ) );
    operations.add( createNotifyOperation( "w4", "Selection" ) );
    operations.add( createSetOperation( "w5", "p3", "3" ) );
    operations.add( createSetOperation( "w2", "p1", "1" ) );
    operations.add( createSetOperation( "w2", "p11", "11" ) );

    List<Operation> optimizedOpertations = protocolProcessor.optimizeSetOperations( operations );

    assertEquals( 4, optimizedOpertations.size() );
    SetOperation operation = ( SetOperation )optimizedOpertations.get( 3 );
    Properties operationProperties = operation.getProperties();
    assertEquals( "1", operationProperties.getString( "p1" ) );
    assertEquals( "11", operationProperties.getString( "p11" ) );
  }

  private SetOperation createSetOperation( String target, String propertyName, String propertyValue )
  {
    SetOperation result = new SetOperation();
    result.setTarget( target );
    Properties properties = new Properties();
    properties.add( propertyName, propertyValue );
    result.setProperties( properties );
    return result;
  }

  private NotifyOperation createNotifyOperation( String target, String eventType ) {
    NotifyOperation result = new NotifyOperation();
    result.setTarget( target );
    result.setEventType( eventType );
    return result;
  }

  @Test
  public void testShouldNotSendRequestAfterShutdown() throws Exception {
    ITransport transport = mock( ITransport.class );
    protocolProcessor.setTransport( transport );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    ExecutorService threadPool = mock( ExecutorService.class );
    protocolProcessor.setRequestThreadPool( threadPool );
    protocolProcessor.setWidgetToolkit( toolkit );
    protocolProcessor.setParser( mock( IProtocolParser.class ) );
    Timer sendTimer = spy( new Timer() );
    protocolProcessor.setSendTimer( sendTimer );

    protocolProcessor.send();
    UiTestUtil.waitForRequest();
    protocolProcessor.shutdown();
    protocolProcessor.send();
    UiTestUtil.waitForRequest();

    verify( sendTimer, times( 1 ) ).schedule( any( TimerTask.class ), anyInt() );
  }

}
