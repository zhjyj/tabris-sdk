/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.DisplaySetter;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DisplayOperator_Test {

  private TabrisActivity activity;
  private ObjectRegistry objectRegistry;
  private DisplayOperator operator;
  private View display;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    activity = mock( TabrisActivity.class );
    processor = mock( ProtocolProcessor.class );
    when( activity.getProcessor() ).thenReturn( processor );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    objectRegistry = new ObjectRegistry( activity.getProcessor() );
    when( toolkit.getObjectRegistry() ).thenReturn( objectRegistry );
    display = mock( View.class );
    RemoteObject remoteObject = mock( RemoteObject.class );
    when( activity.getRemoteObject( display ) ).thenReturn( remoteObject );
    when( activity.findViewById( R.id.root_layout ) ).thenReturn( display );
    operator = new DisplayOperator( activity );
  }

  @Test
  public void testViewSetter() throws Exception {
    assertTrue( operator.getViewSetter( mock( Display.class ) ) instanceof DisplaySetter );
  }

  @Test
  public void testGetType() throws Exception {
    assertEquals( DisplayOperator.TYPE, operator.getType() );
  }

  @Test
  public void testCreateDisplayOK() throws Exception {
    operator.create( createOperation() );

    assertNotNull( objectRegistry.getObject( DisplayOperator.DISPLAY_ID ) );
    verify( processor ).send();
  }

  private CreateOperation createOperation() {
    CreateOperation result = new CreateOperation();
    result.setTarget( "w1" );
    result.setType( "rwt.widgets.Display" );
    return result;
  }

}
