/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SessionIDExtractor_Test {

  @Test
  public void testNoSessionID() {
    SessionIDExtractor extractor = new SessionIDExtractor();

    String result = extractor.extract( "foo" );

    assertEquals( null, result );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullSnippet() {
    SessionIDExtractor extractor = new SessionIDExtractor();

    extractor.extract( null );
  }

  @Test
  public void testSessionIDOK() {
    SessionIDExtractor extractor = new SessionIDExtractor();

    String result = extractor.extract( "foo jsessionid=12345" );

    assertEquals( "12345", result );
  }

}
