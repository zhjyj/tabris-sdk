/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.widget.CompoundButton;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowCompoundButton;

@Implements(CompoundButton.class)
public class TabrisShadowCompoundButton extends ShadowCompoundButton {

  private int mMaxLines;

  @Implementation
  public void setMaxLines( int maxLines ) {
    mMaxLines = maxLines;
  }

  @Implementation
  public void setLines( int lines ) {
    mMaxLines = lines;
  }

  public int getLines() {
    return mMaxLines;
  }
}
