/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.graphics.drawable.ColorDrawable;

import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowColorDrawable;

@Implements(ColorDrawable.class)
public class TabrisShadowColorDrawable extends ShadowColorDrawable {

  private int color;

  @Override
  public void __constructor__( int color ) {
    super.__constructor__( color );
    this.color = color;
  }

  public int getColor() {
    return color;
  }

}
