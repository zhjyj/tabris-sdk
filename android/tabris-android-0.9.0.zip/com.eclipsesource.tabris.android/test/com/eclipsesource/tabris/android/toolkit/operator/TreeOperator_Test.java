/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.os.MessageQueue;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.TreeViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ExpansionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.SelectionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

@RunWith(TabrisTestRunner.class)
public class TreeOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String TREE_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentView;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = new ProtocolProcessor();
    activity.setProcessor( processor );
    processor.setWidgetToolkit( new AndroidWidgetToolkit( activity, mock( MessageQueue.class ) ) );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentView = new FrameLayout( activity );
    parentView.setTag( new RemoteObject( PARENT_ID, processor ) );
    rootLayout.addView( parentView );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );

    assertTrue( operator.getViewSetter( mock( TreeView.class ) ) instanceof TreeViewSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new TreeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoProps() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeNoParentFound() throws Exception {
    TabrisActivity activity = UiTestUtil.createActivity();
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, activity.getProcessor() ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateTreeOk() throws Exception {
    register( PARENT_ID, parentView, "FrameLayout" );
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    getCreatedValidatedView();
  }

  private TreeView getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, TREE_ID );
    assertTrue( view instanceof TreeView );
    assertEquals( TREE_ID, activity.getRemoteObject( view ).getId() );
    assertHasListenerRegisteredViaCompositeListener( ( TreeView )view,
                                                     ExpansionTreeItemClickListener.class );
    return ( TreeView )view;
  }

  private void assertHasListenerRegisteredViaCompositeListener( TreeView treeView,
                                                                Class<? extends OnItemClickListener> listenerClass )
  {
    OnItemClickListener onItemClickListener = treeView.getOnItemClickListener();
    assertEquals( CompositeItemClickListener.class, onItemClickListener.getClass() );
    assertTrue( ( ( CompositeItemClickListener )onItemClickListener ).contains( listenerClass ) );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    op.setType( "rwt.widgets.Grid" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testGetType() throws Exception {
    TreeOperator op = new TreeOperator( new TabrisActivity() );
    assertEquals( TreeOperator.TYPE, op.getType() );
  }

  @Test
  public void testAttachSelectionListener() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    treeView.setOnItemClickListener( new CompositeItemClickListener() );
    register( TREE_ID, treeView, "rwt.widgets.Grid" );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    Properties props = new Properties();
    props.add( "Selection", true );
    listenOp.setProperties( props );

    op.listen( listenOp );

    assertHasListenerRegisteredViaCompositeListener( treeView, SelectionTreeItemClickListener.class );
  }

  @Test
  public void testAttachSelectionListenerNull() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    register( TREE_ID, treeView, "rwt.widgets.Grid" );
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    treeView.setOnItemClickListener( compListener );
    parentView.addView( treeView );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    listenOp.setProperties( new Properties() );

    op.listen( listenOp );

    assertEquals( 0, compListener.getSize() );
  }

  @Test
  public void testRemoveSelectionListener() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    register( TREE_ID, treeView, "rwt.widgets.Grid" );
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    compListener.addListener( new SelectionTreeItemClickListener( activity ) );
    treeView.setOnItemClickListener( compListener );
    parentView.addView( treeView );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    Properties props = new Properties();
    props.add( "Selection", false );
    listenOp.setProperties( props );

    assertHasListenerRegisteredViaCompositeListener( treeView, SelectionTreeItemClickListener.class );

    op.listen( listenOp );

    assertEquals( 0, compListener.getSize() );
  }

  @Test
  public void testCreateTreeWithStyleVirtual() throws Exception {
    register( PARENT_ID, parentView, "FrameLayout" );
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( TreeOperator.STYLE_VIRTUAL ) );

    operator.create( op );

    TreeView treeView = getCreatedValidatedView();
    assertTrue( treeView.hasVirtualTreeSupport() );
  }

  private void register( String id, Object object, String type ) {
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( id, object, type );
  }
}
