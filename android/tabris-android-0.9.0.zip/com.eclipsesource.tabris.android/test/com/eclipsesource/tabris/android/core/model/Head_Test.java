/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.core.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;


public class Head_Test {

  private Head headers;

  @Before
  public void setUp() {
    headers = new Head();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAdd_NullKey() throws Exception {
    headers.add( null, "bar" );
  }

  @Test
  public void testGetString_OK() throws Exception {
    headers.add( "foo", "bar" );

    assertEquals( "bar", headers.getString( "foo" ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetString_NullKey() throws Exception {
    headers.getString( null );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetString_NotString() throws Exception {
    headers.add( "foo", true );

    headers.getString( "foo" );
  }

  @Test
  public void testGetString_Missing() throws Exception {
    assertNull( headers.getString( "foo" ) );
  }

  @Test
  public void testGetBoolean_OK() throws Exception {
    headers.add( "foo", true );

    assertTrue( headers.getBoolean( "foo" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetBoolean_NotBoolean() throws Exception {
    headers.add( "foo", "bar" );

    headers.getBoolean( "foo" );
  }

  @Test
  public void testGetInteger_OK() throws Exception {
    headers.add( "foo", 5 );

    assertEquals( Integer.valueOf( 5 ), headers.getInteger( "foo" ) );
  }

  @Test(expected = IllegalStateException.class)
  public void testGetInteger_NotInteger() throws Exception {
    headers.add( "foo", "bar" );

    headers.getInteger( "foo" );
  }

  @Test
  public void testGetAll() throws Exception {
    headers.add( "prop1", "bar" );
    headers.add( "prop2", 2 );
    headers.add( "prop3", true );

    Map<String, Object> allHeaders = headers.getAll();

    assertEquals( "bar", allHeaders.get( "prop1" ) );
    assertEquals( 2, allHeaders.get( "prop2" ) );
    assertEquals( true, allHeaders.get( "prop3" ) );
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testGetAll_Unmodifiable() throws Exception {
    headers.add( "prop1", "bar" );
    headers.add( "prop2", 2 );
    headers.add( "prop3", true );

    Map<String, Object> allHeaders = headers.getAll();

    allHeaders.put( "prop1", "foo" );
  }

  @Test
  public void testHasHeader_Exists() throws Exception {
    headers.add( "foo", "bar" );

    assertTrue( headers.hasHeader( "foo" ) );
  }

  @Test
  public void testHasheader_NotExists() throws Exception {
    assertFalse( headers.hasHeader( "foo" ) );
  }

  @Test
  public void testHasHeader_NullValue() throws Exception {
    headers.add( "foo", null );

    assertTrue( headers.hasHeader( "foo" ) );
  }

  @Test
  public void testClear() throws Exception {
    headers.add( "foo", "bar" );

    headers.clear();

    assertFalse( headers.hasHeader( "foo" ) );
  }

}
