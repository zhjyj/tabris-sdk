/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.DATE_FORMAR_MONTH;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.DATE_FORMAT_DAY;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.DATE_FORMAT_LONG;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.DATE_FORMAT_SHORT;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.DATE_FORMAT_YEAR;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.STYLE_DATE;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.STYLE_LONG;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.STYLE_MEDIUM;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.STYLE_SHORT;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.STYLE_TIME;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.TIME_FORMAT_MEDIUM_AND_LONG;
import static com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator.TIME_FORMAT_SHORT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.AlertDialog;
import android.util.SparseArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SpinnerSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeDatePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeTimePickerDialog;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeSpinnerDialog;

@RunWith(TabrisTestRunner.class)
public class DateTimeOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String DATE_TIME_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, mock( ProtocolProcessor.class ) ) );
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( PARENT_ID, parentLayout, "FrameLayout" );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );

    assertTrue( operator.getViewSetter( mock( DateTimeSpinner.class ) ) instanceof SpinnerSetter );
  }

  @Test
  public void testGetType() {
    DateTimeOperator op = new DateTimeOperator( activity );

    assertEquals( DateTimeOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    DateTimeOperator operator = new DateTimeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeNoProps() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateDateTimeNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( DATE_TIME_ID );
    Properties props = new Properties();
    props.add( "parent", "unknownParent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithDateOk() throws Exception {
    List<String> style = Arrays.asList( DateTimeOperator.STYLE_DATE );
    DateTimeChangedListener listener = createAndAssertDateTime( style,
                                                                         DateTimeDatePickerDialog.class );
    assertValidDateValues( listener.getDateValues() );
  }

  @Test
  public void testCreateDateTimeWithTimeOk() throws Exception {
    List<String> style = Arrays.asList( DateTimeOperator.STYLE_TIME );
    DateTimeChangedListener listener = createAndAssertDateTime( style,
                                                                         DateTimeTimePickerDialog.class );
    assertValidTimeValues( listener.getDateValues() );
  }

  private DateTimeChangedListener createAndAssertDateTime( List<String> style,
                                                                    Class<? extends AlertDialog> dialog )
  {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", style );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertEquals( DATE_TIME_ID, activity.getRemoteObject( view ).getId() );
    assertTrue( view instanceof DateTimeSpinner );
    DateTimeSpinner spinner = ( DateTimeSpinner )view;
    assertTrue( spinner.getDialog().getClass().equals( dialog ) );
    DateTimeChangedListener listener = spinner.getListeners()
      .get( 0 );
    assertEquals( DateTimeChangedListener.class, listener.getClass() );
    return listener;
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testCreateDateTimeWithStyleCalendar() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( "CALENDAR" ) );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithStyleDateShort() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_DATE, STYLE_SHORT, DATE_FORMAT_SHORT );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeWithStyleDateMediumWrong1() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    Properties props = op.getProperties();
    props.add( "style", Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.add( "dateSeparator", "," );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeWithStyleDateMediumWrong2() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    Properties props = op.getProperties();
    props.add( "style", Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.add( "datePattern", "DMY" );

    operator.create( op );
  }

  @Test
  public void testCreateDateTimeWithStyleDateMedium() throws Exception {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    Properties props = op.getProperties();
    String dateSeparator = ",";
    props.add( "style", Arrays.asList( STYLE_DATE, STYLE_MEDIUM ) );
    props.add( "datePattern", "YDM" );
    props.add( "dateSeparator", dateSeparator );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertTrue( view instanceof DateTimeSpinner );
    String targetFormat = DATE_FORMAT_YEAR
                          + dateSeparator
                          + DATE_FORMAT_DAY
                          + dateSeparator
                          + DATE_FORMAR_MONTH;
    assertEquals( targetFormat, ( ( DateTimeSpinner )view ).getDateFormat() );
  }

  @Test
  public void testCreateDateTimeWithStyleDateLong() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_DATE, STYLE_LONG, DATE_FORMAT_LONG );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeShort() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_SHORT, TIME_FORMAT_SHORT );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeMedium() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_MEDIUM, TIME_FORMAT_MEDIUM_AND_LONG );
  }

  @Test
  public void testCreateDateTimeWithStyleTimeLong() throws Exception {
    verifyDateTimeCreatedWithCorrectFormat( STYLE_TIME, STYLE_LONG, TIME_FORMAT_MEDIUM_AND_LONG );
  }

  private void verifyDateTimeCreatedWithCorrectFormat( String dateTimeStyle,
                                                       String format,
                                                       String referenceformat )
  {
    AbstractWidgetOperator operator = new DateTimeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( dateTimeStyle, format ) );

    operator.create( op );
    View view = UiTestUtil.findViewById( activity, DATE_TIME_ID );
    assertTrue( view instanceof DateTimeSpinner );
    assertEquals( referenceformat, ( ( DateTimeSpinner )view ).getDateFormat() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( DATE_TIME_ID );
    op.setType( "rwt.widgets.DateTime" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  private void assertValidDateValues( SparseArray<String> dateValues ) {
    assertEquals( "year", dateValues.get( Calendar.YEAR ) );
    assertEquals( "month", dateValues.get( Calendar.MONTH ) );
    assertEquals( "day", dateValues.get( Calendar.DAY_OF_MONTH ) );
  }

  private void assertValidTimeValues( SparseArray<String> dateValues ) {
    assertEquals( "hours", dateValues.get( Calendar.HOUR_OF_DAY ) );
    assertEquals( "minutes", dateValues.get( Calendar.MINUTE ) );
    assertEquals( "seconds", dateValues.get( Calendar.SECOND ) );
  }

  private DateTimeSpinner createDateTimeSpinnerAndAttachToParent( IDateTimeSpinnerDialog dialog ) {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             android.R.layout.simple_spinner_dropdown_item );
    DateTimeSpinner spinner = new DateTimeSpinner( activity, adapter, dialog, "" );
    ObjectRegistry objectRegistry = activity.getProcessor().getWidgetToolkit().getObjectRegistry();
    objectRegistry.register( DATE_TIME_ID, spinner, "rwt.widgets.DateTime" );
    parentLayout.addView( spinner );
    return spinner;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetYearRangeToLow() throws Exception {
    Properties props = new Properties();
    props.add( "year", 1899 );
    executeSetOp( props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetYearRangeToHigh() throws Exception {
    Properties props = new Properties();
    props.add( "year", 2101 );
    executeSetOp( props );
  }

  @Test
  public void testSetYearTo1900() throws Exception {
    Properties props = new Properties();
    props.add( "year", 1900 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setYear( 1900 );
  }

  @Test
  public void testSetYearTo2100() throws Exception {
    Properties props = new Properties();
    props.add( "year", 2100 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setYear( 2100 );
  }

  @Test
  public void testSetMonthTo2() throws Exception {
    Properties props = new Properties();
    props.add( "month", 2 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setMonth( 2 );
  }

  @Test
  public void testSetDayTo3() throws Exception {
    Properties props = new Properties();
    props.add( "day", 3 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setDay( 3 );
  }

  @Test
  public void testSetHoursTo4() throws Exception {
    Properties props = new Properties();
    props.add( "hours", 4 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setHours( 4 );
  }

  @Test
  public void testSetMinutesTo5() throws Exception {
    Properties props = new Properties();
    props.add( "minutes", 5 );
    IDateTimeSpinnerDialog dialog = executeSetOp( props );
    verify( dialog ).setMinutes( 5 );
  }

  private IDateTimeSpinnerDialog executeSetOp( Properties props ) {
    IDateTimeSpinnerDialog dialog = mock( IDateTimeSpinnerDialog.class );
    createDateTimeSpinnerAndAttachToParent( dialog );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( DATE_TIME_ID );
    setOp.setProperties( props );
    DateTimeOperator operator = new DateTimeOperator( activity );

    operator.set( setOp );

    return dialog;
  }
}
