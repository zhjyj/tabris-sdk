/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.InputStream;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.transport.TransportRequest;
import com.eclipsesource.tabris.android.toolkit.ProgressIndicator;

public class PostRequestRunnable_Test {

  private ITransportResult result;
  private ITransport transport;
  private IWidgetToolkit toolkit;
  private IProtocolParser parser;
  private ProgressIndicator progressIndicator;

  @Before
  public void setUp() {
    result = mock( ITransportResult.class );
    transport = mock( ITransport.class );
    toolkit = mock( IWidgetToolkit.class );
    progressIndicator = mock( ProgressIndicator.class );
    when( toolkit.getProgressIndicator() ).thenReturn( progressIndicator );
    parser = mock( IProtocolParser.class );
  }

  private ProtocolProcessor setUpProtocolProcessor() {
    ProtocolProcessor processor = new ProtocolProcessor();
    processor.setTransport( transport );
    processor.setWidgetToolkit( toolkit );
    processor.setParser( parser );
    return processor;
  }

  @Test
  public void testProcessPostRequestOk() throws Exception {
    ProtocolProcessor processor = setUpProtocolProcessor();
    when( result.hasException() ).thenReturn( false );
    when( result.hasParsableContent() ).thenReturn( true );
    PostRequest request = new PostRequest();
    when( transport.post( request ) ).thenReturn( result );

    PostRequestRunnable runnable = new PostRequestRunnable( request, processor );
    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( request );
    verify( parser ).parse( any( InputStream.class ) );
  }

  private void verifyProgressIndication() {
    verify( toolkit ).getProgressIndicator();
    verify( progressIndicator ).start();
    verify( progressIndicator ).stop();
  }

  @Test
  public void testProcessPostRequestTransportFail() throws Exception {
    ProtocolProcessor processor = setUpProtocolProcessor();
    ITransportResult result = mock( ITransportResult.class );
    when( result.hasException() ).thenReturn( true );
    PostRequest request = new PostRequest();
    when( transport.post( request ) ).thenReturn( result );
    PostRequestRunnable runnable = new PostRequestRunnable( request, processor );

    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( any( PostRequest.class ) );
    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }

  @Test
  public void testInitiateSessionParseFail() throws Exception {
    when( result.hasException() ).thenReturn( false );
    PostRequest request = new PostRequest();
    when( transport.post( request ) ).thenReturn( result );
    doThrow( ParseException.class ).when( parser ).parse( any( InputStream.class ) );
    ProtocolProcessor processor = setUpProtocolProcessor();
    PostRequestRunnable runnable = new PostRequestRunnable( request, processor );

    runnable.run();

    verifyProgressIndication();
    verify( transport ).post( any( PostRequest.class ) );
    verify( toolkit ).showError( any( Exception.class ), any( TransportRequest.class ) );
  }
}
