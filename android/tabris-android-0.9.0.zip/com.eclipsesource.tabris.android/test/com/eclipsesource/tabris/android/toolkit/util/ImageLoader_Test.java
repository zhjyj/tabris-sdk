
package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImageLoader_Test {

  @Test
  public void shouldReturnFileAsByteArray() throws Exception {
    ImageLoader loader = new ImageLoader();
    byte[] data = new byte[]{
      1, 2, 3
    };
    File file = createTmpFile( data );

    byte[] result = loader.loadImage( file, 0, 0 );

    assertArrayEquals( data, result );
  }

  private File createTmpFile( byte[] data ) throws IOException, FileNotFoundException {
    File file = File.createTempFile( "file", null );
    file.deleteOnExit();
    FileOutputStream fos = new FileOutputStream( file );
    fos.write( data );
    fos.close();
    return file;
  }

  @Test
  public void shouldDecodeImageHorizontally() throws Exception {
    ImageLoader loader = new ImageLoader();
    File file = new File( "../com.eclipsesource.tabris.android.test/test-data/tabris_icon_horizontal.png" );

    byte[] result = loader.loadImage( file, 30, 20 );

    assertTrue( result.length > 0 );
  }

  @Test
  public void shouldDecodeImageVertically() throws Exception {
    ImageLoader loader = new ImageLoader();
    File file = new File( "../com.eclipsesource.tabris.android.test/test-data/tabris_icon_vertical.png" );

    byte[] result = loader.loadImage( file, 20, 30 );

    assertTrue( result.length > 0 );
  }
}
