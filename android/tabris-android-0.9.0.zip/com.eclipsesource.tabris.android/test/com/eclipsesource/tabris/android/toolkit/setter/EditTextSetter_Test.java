/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static android.text.InputType.TYPE_CLASS_NUMBER;
import static android.text.InputType.TYPE_CLASS_PHONE;
import static android.text.InputType.TYPE_CLASS_TEXT;
import static android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;
import static android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
import static android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
import static android.text.InputType.TYPE_TEXT_VARIATION_URI;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_ASCII;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_DECIMAL;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_EMAIL;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_NUMBER;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_NUMBERSANDPUNCTUATION;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_PHONE;
import static com.eclipsesource.tabris.android.toolkit.setter.EditTextSetter.VARIANT_KEYBOARD_URL;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.text.InputFilter.LengthFilter;
import android.widget.EditText;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowEditText;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class EditTextSetter_Test {

  @Test
  public void testSetEnabledFalse() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    Properties props = new Properties();
    props.add( "enabled", false );

    setter.execute( editText, props );

    verify( editText ).setEnabled( false );
    verify( editText ).setFocusable( false );
  }

  @Test
  public void testSetEnabledTrue() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    Properties props = new Properties();
    props.add( "enabled", true );

    setter.execute( editText, props );

    verify( editText ).setEnabled( true );
    verify( editText ).setFocusable( true );
  }

  @Test
  public void testSetEditableFalse() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    Properties properties = new Properties();
    properties.add( "editable", false );

    setter.execute( editText, properties );

    verify( editText ).setFocusable( false );
  }

  @Test
  public void testSetEditableTrue() {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    Properties properties = new Properties();
    properties.add( "editable", true );

    setter.execute( editText, properties );

    verify( editText ).setFocusable( true );
  }

  @Test
  public void testSetTextLimit() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TabrisActivity activity = new TabrisActivity();
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( activity );
    EditText editText = new EditText( activity );
    Properties properties = new Properties();
    properties.add( "textLimit", 5 );

    setter.execute( editText, properties );

    assertTrue( editText.getFilters()[ 0 ] instanceof LengthFilter );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToASCII() throws Exception {
    changeInputType( VARIANT_KEYBOARD_ASCII, TYPE_CLASS_TEXT );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToDecimal() throws Exception {
    changeInputType( VARIANT_KEYBOARD_DECIMAL, TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_DECIMAL );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToEmail() throws Exception {
    changeInputType( VARIANT_KEYBOARD_EMAIL, TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_EMAIL_ADDRESS );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToNumber() throws Exception {
    changeInputType( VARIANT_KEYBOARD_NUMBER, TYPE_CLASS_NUMBER );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToNumberAndPunctuation() throws Exception {
    changeInputType( VARIANT_KEYBOARD_NUMBERSANDPUNCTUATION, TYPE_CLASS_NUMBER
                                                             | TYPE_NUMBER_FLAG_DECIMAL );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToPhone() throws Exception {
    changeInputType( VARIANT_KEYBOARD_PHONE, TYPE_CLASS_PHONE );
  }

  @Test
  public void testCustomVariantShouldChangeInputTypeToUrl() throws Exception {
    changeInputType( VARIANT_KEYBOARD_URL, TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_URI );
  }

  private void changeInputType( String customVariant, int targetInputType ) {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    Properties properties = new Properties();
    properties.add( "customVariant", customVariant );

    setter.execute( editText, properties );

    assertEquals( targetInputType, editText.getInputType() );
  }

  @Test
  public void testCustomVariantShouldNotChangeInputType() throws Exception {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = mock( EditText.class );
    Properties properties = new Properties();
    properties.add( "customVariant", "someCustomVariant" );

    setter.execute( editText, properties );

    verify( editText, never() ).setInputType( anyInt() );
  }

  @Test
  public void testSettingKeyboardTypeShouldKeepOtherInputTypeFlags() throws Exception {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    int initialInputType = TYPE_TEXT_FLAG_NO_SUGGESTIONS;
    editText.setInputType( initialInputType );
    Properties properties = new Properties();
    properties.add( "customVariant", VARIANT_KEYBOARD_DECIMAL );

    setter.execute( editText, properties );

    int inputType = editText.getInputType();
    assertTrue( isFlagSet( inputType, initialInputType ) );
    assertTrue( isFlagSet( inputType, TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_DECIMAL ) );
  }

  @Test
  public void testSettingKeyboardTypeShouldRemovePreviousKeyboardTypeFlags() throws Exception {
    int initalInputType = TYPE_CLASS_NUMBER | TYPE_NUMBER_FLAG_DECIMAL;
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    editText.setInputType( initalInputType );
    editText.setTag( R.id.custom_variant, VARIANT_KEYBOARD_DECIMAL );
    Properties properties = new Properties();
    properties.add( "customVariant", VARIANT_KEYBOARD_ASCII );

    setter.execute( editText, properties );

    int inputType = editText.getInputType();
    assertTrue( isFlagSet( inputType, TYPE_CLASS_TEXT ) );
    assertTrue( !isFlagSet( inputType, initalInputType ) );
  }

  private boolean isFlagSet( int inputType, int flag ) {
    return ( inputType & flag ) == flag;
  }

  @Test
  public void testSetSelectionShouldChangeSelection() throws Exception {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    Properties properties = new Properties();
    properties.add( "selection", Arrays.asList( 2, 3 ) );

    setter.execute( editText, properties );

    assertEquals( editText.getSelectionStart(), 2 );
    assertEquals( editText.getSelectionEnd(), 3 );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetSelectionWithIllegalLengthShouldThrowException() throws Exception {
    EditTextSetter<EditText> setter = new EditTextSetter<EditText>( new TabrisActivity() );
    EditText editText = new EditText( new TabrisActivity() );
    Properties properties = new Properties();
    properties.add( "selection", Arrays.asList( 2, 3, 4 ) );

    setter.execute( editText, properties );
  }
}
