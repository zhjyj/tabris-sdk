package com.eclipsesource.tabris.android.parser.gson;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.Properties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class PropertiesSerializer_Test {
  
  private Gson gson;

  @Before
  public void setUp() {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesSerializer() );
    gson = gsonBuilder.create();
  }
  
  @Test
  public void testStringProperties() {
    Properties properties = new Properties();
    properties.add( "foo", "bar" );
    
    String json = gson.toJson( properties );
    
    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    assertEquals( "bar", actualProperties.getString( "foo" ) );
  }
  
  @Test
  public void testIntProperties() {
    Properties properties = new Properties();
    properties.add( "foo", 23 );
    
    String json = gson.toJson( properties );
    
    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    assertEquals( Integer.valueOf( 23 ), actualProperties.getInteger( "foo" ) );
  }
  
  @Test
  public void testFloatProperties() {
    Properties properties = new Properties();
    properties.add( "foo", 23.23F );
    
    String json = gson.toJson( properties );
    
    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    assertEquals( Float.valueOf( 23.23F ), actualProperties.getFloat( "foo" ) );
  }
  
  @Test
  public void testBooleanProperties() {
    Properties properties = new Properties();
    properties.add( "foo", true );
    
    String json = gson.toJson( properties );
    
    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    assertEquals( true, actualProperties.getBoolean( "foo" ) );
  }
  
  @Test
  public void testListProperties() {
    Properties properties = new Properties();
    List<Object> list = new ArrayList<Object>();
    list.add( "foo" );
    list.add( 23 );
    properties.add( "foo", list );
    
    String json = gson.toJson( properties );

    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    List<Object> actualList = actualProperties.getList( "foo", Object.class );
    assertEquals( 2, actualList.size() );
    assertEquals( "foo", actualList.get( 0 ) );
    assertEquals( Integer.valueOf( 23 ), actualList.get( 1 ) );
  }
  
  @Test
  public void testMatrixProperties() {
    Properties properties = new Properties();
    List<Object> list = new ArrayList<Object>();
    list.add( "foo" );
    list.add( 23 );
    ArrayList<Object> parentList = new ArrayList<Object>();
    parentList.add( list );
    properties.add( "foo", parentList );
    
    String json = gson.toJson( properties );
    
    Properties actualProperties = deserializeProperties( json );
    assertEquals( 1, actualProperties.getAll().size() );
    List<List<Object>> actualParentList = actualProperties.getMatrix( "foo", Object.class );
    assertEquals( 1, actualParentList.size() );
    List<Object> actualList = actualParentList.get( 0 );
    assertEquals( "foo", actualList.get( 0 ) );
    assertEquals( Integer.valueOf( 23 ), actualList.get( 1 ) );
  }
  
  private Properties deserializeProperties( String json ) {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter( Properties.class, new PropertiesDeserializer() );
    Gson deserializer = gsonBuilder.create();
    return deserializer.fromJson( json, Properties.class );
  }

}
