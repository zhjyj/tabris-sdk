/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.view.View;
import android.view.View.OnSystemUiVisibilityChangeListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;

@Implements(FrameLayout.class)
public class TabrisShadowFrameLayout extends ShadowFrameLayout {

  private View.OnLongClickListener onLongClickListener;
  private OnSystemUiVisibilityChangeListener onSystemUiVisibilityChangeListener;
  private int systemUiVisibility;

  @Override
  @Implementation
  public void addView( View child ) {
    child.setLayoutParams( generateDefaultLayoutParams() );
    super.addView( child );
  }

  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams( LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT );
  }

  @Implementation
  public void removeView( View child ) {
    int childIndex = indexOfChild( child );
    removeViewAt( childIndex );
  }

  @Override
  @Implementation
  public void setOnLongClickListener( View.OnLongClickListener onLongClickListener ) {
    super.setOnLongClickListener( onLongClickListener );
    this.onLongClickListener = onLongClickListener;
  }

  public View.OnLongClickListener getOnLongClickListener() {
    return this.onLongClickListener;
  }

  @Implementation
  public void setOnSystemUiVisibilityChangeListener( OnSystemUiVisibilityChangeListener l ) {
    onSystemUiVisibilityChangeListener = l;
  }

  public OnSystemUiVisibilityChangeListener getOnSystemUiVisibilityChangeListener() {
    return onSystemUiVisibilityChangeListener;
  }

  @Implementation
  public void setSystemUiVisibility( int visibility ) {
    systemUiVisibility = visibility;
  }

  public int getSystemUiVisibility() {
    return systemUiVisibility;
  }
}
