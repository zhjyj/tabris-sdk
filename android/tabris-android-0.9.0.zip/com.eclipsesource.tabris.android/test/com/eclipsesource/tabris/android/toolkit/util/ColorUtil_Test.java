/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.ColorFilter;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.Drawable;

import com.eclipsesource.tabris.android.test.shadow.TabrisShadowColorMatrix;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ColorUtil_Test {

  @Test
  public void testApplColorFilter() {
    Drawable drawable = mock( Drawable.class );

    ColorUtil.applyColorFilter( drawable, 1f, 2f, 3f );

    verify( drawable ).setColorFilter( any( ColorMatrixColorFilter.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntNullArg() throws Exception {
    ColorUtil.colorToupleToInt( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToInt2Values() throws Exception {
    ColorUtil.colorToupleToInt( Arrays.asList( 10, 20 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntIllegal5Values() throws Exception {
    ColorUtil.colorToupleToInt( Arrays.asList( 10, 20, 30, 40, 50 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorToIntOutOfRange() throws Exception {
    ColorUtil.colorToupleToInt( Arrays.asList( -1, 256, Integer.MAX_VALUE, Integer.MIN_VALUE ) );
  }

  @Test
  public void testColorToIntValidThreeTouple() throws Exception {
    int color = ColorUtil.colorToupleToInt( Arrays.asList( 1, 255, 128 ) );

    assertEquals( 255, getInt( color, ColorUtil.COLOR_COMP_A ) );
    assertEquals( 1, getInt( color, ColorUtil.COLOR_COMP_R ) );
    assertEquals( 255, getInt( color, ColorUtil.COLOR_COMP_G ) );
    assertEquals( 128, getInt( color, ColorUtil.COLOR_COMP_B ) );
  }

  @Test
  public void testColorToIntValidFourTouple() throws Exception {
    int color = ColorUtil.colorToupleToInt( Arrays.asList( 1, 255, 128, 0 ) );

    assertEquals( 0, getInt( color, ColorUtil.COLOR_COMP_A ) );
    assertEquals( 1, getInt( color, ColorUtil.COLOR_COMP_R ) );
    assertEquals( 255, getInt( color, ColorUtil.COLOR_COMP_G ) );
    assertEquals( 128, getInt( color, ColorUtil.COLOR_COMP_B ) );
  }

  @Test
  public void testEqualsColorFilters() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowColorMatrix.class );
    ColorFilter filter1 = ColorUtil.createColorFilter( 0.1f, 0.2f, 0.3f );
    ColorFilter filter2 = ColorUtil.createColorFilter( 0.1f, 0.2f, 0.3f );

    assertEquals( filter1, filter2 );
    assertEquals( filter1.hashCode(), filter2.hashCode() );
  }

  @Test
  public void testNonEqualsColorFilters() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowColorMatrix.class );
    ColorFilter filter1 = ColorUtil.createColorFilter( 0.1f, 0.2f, 0.3f );
    ColorFilter filter2 = ColorUtil.createColorFilter( 0.3f, 0.2f, 0.1f );

    assertFalse( filter1.equals( filter2 ) );
    assertFalse( filter1.hashCode() == filter2.hashCode() );
  }

  private int getInt( int value, int component ) {
    return value >> component & 0xff;
  }
}
