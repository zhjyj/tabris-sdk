/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.GroupSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;

@RunWith(RobolectricTestRunner.class)
public class GroupOperator_Test {

  private static final String GROUP_ID = "w3";
  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( GROUP_ID );
    activity.setContentView( R.layout.protocol );
    toolkit = activity.getProcessor().getWidgetToolkit();
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( new RemoteObject( PARENT_ID, mock( ProtocolProcessor.class ) ) );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getListenerRegistry() ).thenReturn( new ListenerRegistry() );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );

    assertTrue( operator.getViewSetter( mock( Group.class ) ) instanceof GroupSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new GroupOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    GroupOperator operator = new GroupOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateGroupNoProps() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateGroupNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateGroupNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateGroupParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateGroupOk() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = createValidCreateOperation();
    UiTestUtil.mockToolkitDivideIdentity( activity, 8, 14, 18, 38 );

    operator.create( op );

    ArgumentCaptor<Group> captor = ArgumentCaptor.forClass( Group.class );
    verify( toolkit.getObjectRegistry() ).register( eq( GROUP_ID ), captor.capture(), eq( "rwt.widgets.Group" ) );
    assertNotNull( captor.getValue() );
    ShadowFrameLayout shadowComp = Robolectric.shadowOf( captor.getValue() );
    CompositeTouchListener listener = ( CompositeTouchListener )shadowComp.getOnTouchListener();
    assertEquals( CompositeTouchListener.class, listener.getClass() );
    assertEquals( ConsumingTouchListener.class,
                  listener.findListener( ConsumingTouchListener.class ).getClass() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    op.setType( "rwt.widgets.Group" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testGetType() throws Exception {
    GroupOperator op = new GroupOperator( new TabrisActivity() );
    assertEquals( GroupOperator.TYPE, op.getType() );
  }
}
