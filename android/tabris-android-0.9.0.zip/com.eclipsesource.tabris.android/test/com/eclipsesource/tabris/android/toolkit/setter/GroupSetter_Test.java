/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.TextView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowTextView;
import com.xtremelabs.robolectric.shadows.ShadowView;

@RunWith(RobolectricTestRunner.class)
public class GroupSetter_Test {

  private static final String TEXT_STRING = "abc";

  @Test
  public void testSetTextOk() {
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    GroupSetter<Group> setter = new GroupSetter<Group>( activity );
    Group group = new Group( activity );
    Properties properties = new Properties();
    properties.add( "text", TEXT_STRING );
    UiTestUtil.mockToolkitDivideIdentity( activity, 8, 14, 18, 38 );

    setter.execute( group, properties );

    TextView textView = ( TextView )group.getChildAt( 1 );
    assertEquals( TEXT_STRING, textView.getText() );
  }

  @Test
  public void testSetForeground() {
    TabrisActivity activity = UiTestUtil.createActivityWithoutOnCreate();
    GroupSetter<Group> setter = new GroupSetter<Group>( activity );
    Group group = new Group( activity );
    Properties properties = new Properties();
    List<Integer> colorTouple = Arrays.asList( 10, 20, 30, 40 );
    properties.add( "foreground", colorTouple );
    UiTestUtil.mockToolkitDivideIdentity( activity, 8, 14, 18, 38 );

    setter.execute( group, properties );

    int color = ColorUtil.colorToupleToInt( colorTouple );
    TextView titleTextView = ( TextView )group.getChildAt( 1 );
    ShadowTextView shadowTitleTextView = Robolectric.shadowOf( titleTextView );
    assertEquals( new Integer( color ), shadowTitleTextView.getTextColorHexValue() );
    View separatorView = group.getChildAt( 0 );
    ShadowView shadowSeparatorView = Robolectric.shadowOf( separatorView );
    assertEquals( color, shadowSeparatorView.getBackgroundColor() );
  }

}
