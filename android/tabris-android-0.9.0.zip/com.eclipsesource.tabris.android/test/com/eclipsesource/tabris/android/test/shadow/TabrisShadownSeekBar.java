/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.SeekBar;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowSeekBar;

@Implements(SeekBar.class)
public class TabrisShadownSeekBar extends ShadowSeekBar {

  private int max;
  private boolean indeterminate;
  private int defStyle;

  @Override
  public void __constructor__( Context context, AttributeSet attributeSet, int defStyle ) {
    super.__constructor__( context, attributeSet, defStyle );
    this.defStyle = defStyle;
  }

  @Override
  @Implementation
  public void setMax( int max ) {
    this.max = max;
  }

  @Override
  @Implementation
  public int getMax() {
    return max;
  }

  @Implementation
  public synchronized void setIndeterminate( boolean indeterminate ) {
    this.indeterminate = indeterminate;
  }

  @Implementation
  public synchronized boolean isIndeterminate() {
    return indeterminate;
  }

  public int getDefStyle() {
    return defStyle;
  }
}
