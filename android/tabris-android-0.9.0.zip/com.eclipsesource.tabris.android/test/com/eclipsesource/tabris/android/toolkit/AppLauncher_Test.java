
package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class AppLauncher_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorShouldNotAcceptNullActivity() {
    new AppLauncher( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOpenBrowserShouldNotAcceptNullURL() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openBrowser( null );
  }

  @Test
  public void testOpenBrowserShouldStartIntent() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openBrowser( "http://google.com" );

    Intent intent = new Intent( Intent.ACTION_VIEW );
    intent.setData( Uri.parse( "http://google.com" ) );
    verify( activity ).startActivity( intent );
  }

  @Test
  public void testOpenMailShouldStartIntentWithToCcSubjectPlainBody() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openMail( "to", "cc", "subject", "body", false );

    Intent intent = getStartedIntent( activity );
    assertEquals( "text/plain", intent.getType() );
    assertArrayEquals( new String[]{
      "to"
    }, intent.getStringArrayExtra( Intent.EXTRA_EMAIL ) );
    assertArrayEquals( new String[]{
      "cc"
    }, intent.getStringArrayExtra( Intent.EXTRA_CC ) );
    assertEquals( "subject", intent.getStringExtra( Intent.EXTRA_SUBJECT ) );
    assertEquals( "body", intent.getStringExtra( Intent.EXTRA_TEXT ) );
  }

  @Test
  public void testOpenMailShouldStartIntentWithHtmlBody() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openMail( "to", "cc", "subject", "<b>body</b>", true );

    Intent intent = getStartedIntent( activity );
    assertEquals( "text/plain", intent.getType() );
    assertEquals( "<b>body</b>", intent.getCharSequenceExtra( Intent.EXTRA_TEXT ).toString() );
  }

  @Test
  public void testOpenPhoneShouldStartDialIntent() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openPhone( null );

    Intent intent = new Intent( Intent.ACTION_DIAL );
    activity.startActivity( intent );
  }

  @Test
  public void testOpenPhoneShouldStartCallIntentWithNumber() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openPhone( "12345" );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_CALL, intent.getAction() );
    assertEquals( "tel:12345", intent.getData().toString() );
  }

  @Test
  public void testOpenMapsShouldStartMapsIntentWithCoordinates() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openMaps( "123", "456" );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "geo:123,456?z=14", intent.getData().toString() );
  }

  @Test
  public void testOpenMapsShouldStartMapsIntentWithCoordinatesAndZoom() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openMaps( "123", "456", 3 );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "geo:123,456?z=3", intent.getData().toString() );
  }

  @Test
  public void testOpenMapsShouldStartMapsIntentWithQuery() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openMaps( "Karlsruhe, Germany" );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "geo:0,0?q=Karlsruhe, Germany", intent.getData().toString() );
  }

  @Test
  public void testOpenSmsWithNullArgsShouldStartSmsIntent() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openSms( null, null );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "sms:", intent.getData().toString() );
    assertNull( intent.getStringExtra( "sms_body" ) );
  }

  @Test
  public void testOpenSmsWithShouldStartSmsIntentWithNumberAndText() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openSms( "5551234", "Hello World!" );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "sms:5551234", intent.getData().toString() );
    assertEquals( "Hello World!", intent.getStringExtra( "sms_body" ) );
  }

  @Test
  public void testOpenUrlShouldStartViewIntent() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openUrl( "http://url.com" );

    Intent intent = getStartedIntent( activity );
    assertEquals( Intent.ACTION_VIEW, intent.getAction() );
    assertEquals( "http://url.com", intent.getData().toString() );
  }

  @Test
  public void testOpenUrlWithNullUrlShouldNotStartViewIntent() throws Exception {
    Activity activity = mock( Activity.class );
    AppLauncher appLauncher = new AppLauncher( activity );

    appLauncher.openUrl( null );

    verify( activity, never() ).startActivity( any( Intent.class ) );
  }

  private Intent getStartedIntent( Activity activity ) {
    ArgumentCaptor<Intent> captor = ArgumentCaptor.forClass( Intent.class );
    verify( activity ).startActivity( captor.capture() );
    return captor.getValue();
  }

}
