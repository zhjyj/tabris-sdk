/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.CanvasSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;

@RunWith(RobolectricTestRunner.class)
public class CanvasOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String CANVAS_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFieldsWithObjectId( CANVAS_ID );
    toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getListenerRegistry() ).thenReturn( new ListenerRegistry() );
    parentLayout = new FrameLayout( activity );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getObjectRegistry().getObject( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test
  public void testViewSetter() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );

    assertTrue( operator.getViewSetter( mock( Canvas.class ) ) instanceof CanvasSetter );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new CanvasOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCanvasNoProps() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCanvasNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCanvasNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( CANVAS_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( CANVAS_ID );
    op.setType( "rwt.widgets.Canvas" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    ArgumentCaptor<View> captor = ArgumentCaptor.forClass( View.class );
    verify( toolkit.getObjectRegistry() ).register( eq( CANVAS_ID ),
                                                    captor.capture(),
                                                    eq( "rwt.widgets.Canvas" ) );
    View view = captor.getValue();
    assertTrue( view instanceof Canvas );
    assertEquals( CANVAS_ID, activity.getRemoteObject( view ).getId() );
    ShadowFrameLayout shadowComp = Robolectric.shadowOf( ( Canvas )view );
    CompositeTouchListener listener = ( CompositeTouchListener )shadowComp.getOnTouchListener();
    assertEquals( CompositeTouchListener.class, listener.getClass() );
  }

  @Test
  public void testDestroy() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    Canvas canvas = new Canvas( activity );
    canvas.setTag( new RemoteObject( CANVAS_ID, mock( ProtocolProcessor.class ) ) );
    canvas.initCanvas( 100, 100 );
    parentLayout.addView( canvas );

    Bitmap bitmap = canvas.getBitmap();
    assertNotNull( bitmap );

    when( toolkit.getObjectRegistry().getObject( CANVAS_ID, Canvas.class ) ).thenReturn( canvas );
    when( toolkit.getObjectRegistry().getObject( CANVAS_ID, View.class ) ).thenReturn( canvas );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( CANVAS_ID );

    operator.destroy( destroyOperation );

    assertTrue( bitmap.isRecycled() );
    assertNull( canvas.getBitmap() );
  }

  @Test
  public void testGetType() throws Exception {
    CanvasOperator op = new CanvasOperator( new TabrisActivity() );
    assertEquals( CanvasOperator.TYPE, op.getType() );
  }

}
