/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Properties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.remote.RemoteObject;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.ObjectRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ObservableHorizontalScrollViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ObservableVerticalScrollViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.FocusTrackingListener;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupportDirection;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ScrolledCompositeOperator_Test {

  private static final String H_SCROLL = "H_SCROLL";
  private static final String V_SCROLL = "V_SCROLL";

  private static final String COMP_ID = "w3";

  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.getListenerRegistry() ).thenReturn( mock( ListenerRegistry.class ) );
    when( toolkit.getFocusTrackingListener() ).thenReturn( mock( FocusTrackingListener.class ) );
    FrameLayout parentLayout = new FrameLayout( activity );
    ObjectRegistry objectRegistry = new ObjectRegistry( activity.getProcessor() );
    when( toolkit.getObjectRegistry() ).thenReturn( objectRegistry );
    objectRegistry.register( PARENT_ID, parentLayout, "FrameLayout" );
  }

  @Test
  public void testViewSetterHorizontal() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    IViewSetter<View> setter = operator.getViewSetter( mock( ObservableHorizontalScrollView.class ) );
    assertTrue( setter instanceof ObservableHorizontalScrollViewSetter );
  }

  @Test
  public void testViewSetterVertical() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    IViewSetter<View> setter = operator.getViewSetter( mock( ObservableVerticalScrollView.class ) );
    assertTrue( setter instanceof ObservableVerticalScrollViewSetter );
  }

  @Test
  public void testViewSetterVerticalScrollBoth() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    IViewSetter<View> setter = operator.getViewSetter( mock( ObservableScrollView.class ) );
    assertTrue( setter instanceof CompositeSetter );
  }

  @Test
  public void testViewSetterSameInstance() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    IViewSetter<View> setter1 = operator.getViewSetter( mock( ObservableScrollView.class ) );
    IViewSetter<View> setter2 = operator.getViewSetter( mock( ObservableScrollView.class ) );
    assertSame( setter1, setter2 );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoProps() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoStyleInProps() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    Properties props = new Properties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    Properties props = new Properties();
    props.add( "parent", "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( new RemoteObject( buttonId, mock( ProtocolProcessor.class ) ) );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    Properties props = new Properties();
    props.add( "parent", buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateHorizontalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( H_SCROLL ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableHorizontalScrollView );
    assertEquals( COMP_ID, activity.getRemoteObject( view ).getId() );
  }

  @Test
  public void testCreateVerticalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( V_SCROLL ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableVerticalScrollView );
    assertEquals( COMP_ID, activity.getRemoteObject( view ).getId() );
  }

  @Test
  public void testCreateVerticalHorizontalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( V_SCROLL, H_SCROLL ) );

    operator.create( op );

    
    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableScrollView );
    assertEquals( COMP_ID, activity.getRemoteObject( view ).getId() );
    ObservableScrollView scrollView = ( ObservableScrollView )view;
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    assertEquals( ObservableVerticalScrollView.class, verticalScroll.getClass() );
    assertEquals( ScrollSupportDirection.Y, verticalScroll.getScrollSupport().getDirection() );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    assertEquals( ObservableHorizontalScrollView.class, horizontalScroll.getClass() );
    assertEquals( ScrollSupportDirection.X, horizontalScroll.getScrollSupport().getDirection() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    op.setType( "rwt.widgets.ScrolledComposite" );
    Properties props = new Properties();
    props.add( "parent", PARENT_ID );
    props.add( "style", Arrays.asList( V_SCROLL ) );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeWrongBounds() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().add( "style", Arrays.asList( V_SCROLL ) );
    op.getProperties().add( "bounds", Arrays.asList( 10, 20, 30 ) );

    operator.create( op );
  }

  @Test
  public void testCreateAndInitiateView() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    FrameLayout layout = UiTestUtil.findObjectById( activity, COMP_ID, FrameLayout.class );
    FrameLayout parent = ( FrameLayout )layout.getParent();
    assertEquals( PARENT_ID, activity.getRemoteObject( parent ).getId() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullOp() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    operator.set( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullTarget() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    SetOperation operation = new SetOperation();
    operation.setProperties( new Properties() );
    operator.set( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullProperties() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( COMP_ID );
    operator.set( operation );
  }

  @Test
  public void testGetType() throws Exception {
    ScrolledCompositeOperator op = new ScrolledCompositeOperator( new TabrisActivity() );
    assertEquals( ScrolledCompositeOperator.TYPE, op.getType() );
  }
}
