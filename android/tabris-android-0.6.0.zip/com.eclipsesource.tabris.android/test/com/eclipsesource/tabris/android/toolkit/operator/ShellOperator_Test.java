/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapFactory;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowFrameLayout;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ShellOperator_Test {

  private static final String TITLE_TEXT = "title text";
  private static final String MODAL_SHELL_STYLE = "APPLICATION_MODAL";
  private static final String SHELL1_ID = "w2";
  private static final String SHELL2_ID = "w3";

  private UiActivity activity;
  private ShellOperator operator;
  private ShellAnimationSupport animSupportMock;
  private Shell shell;
  private Shell shell2;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    Robolectric.bindShadowClass( TabrisShadowFrameLayout.class );
    activity = UiTestUtil.createUiActivity();
    toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    activity.getProcessor().setWidgetToolkit( toolkit );
    operator = new ShellOperator( activity ) {

      @Override
      protected void setBackgroundColor( Shell shellLayout ) {
        // We don't set the background color because robolectric is not able to
        // load the set color which is stored as a <drawable> in the colors.xml.
      }
    };
    animSupportMock = mock( ShellAnimationSupport.class );
    shell = new Shell( activity, animSupportMock );
    shell.setTag( SHELL1_ID );
    shell.setLayoutParams( new MarginLayoutParams( LayoutParams.WRAP_CONTENT,
                                                   LayoutParams.WRAP_CONTENT ) );
    shell2 = new Shell( activity, animSupportMock );
    shell2.setTag( SHELL2_ID );
    shell2.setLayoutParams( new MarginLayoutParams( LayoutParams.WRAP_CONTENT,
                                                    LayoutParams.WRAP_CONTENT ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    ShellOperator operator = new ShellOperator( new UiActivity() );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    ShellOperator operator = new ShellOperator( new UiActivity() );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( new UiActivity() );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test
  public void testCreateOk() throws Exception {
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 1, view.getChildCount() );
    FrameLayout shell = ( FrameLayout )view.getChildAt( 0 );
    assertEquals( SHELL1_ID, shell.getTag() );
    assertTrue( "new Shells should be able to have the focus", shell.isFocusable() );
    assertTrue( "new Shells should have the focus", shell.hasFocus() );
    assertEquals( shell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( shell ), eq( props ) );
  }

  @Test
  public void testCreateWithImageOk() throws Exception {
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    props.setImage( new ArrayList<String>( Arrays.asList( "image" ) ) );
    createOp.setProperties( props );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 1, view.getChildCount() );
    FrameLayout shell = ( FrameLayout )view.getChildAt( 0 );
    assertEquals( SHELL1_ID, shell.getTag() );
    assertTrue( "new Shells should be able to have the focus", shell.isFocusable() );
    assertTrue( "new Shells should have the focus", shell.hasFocus() );
    assertEquals( shell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( shell ), eq( props ) );
  }

  @Test
  public void testCreateWithTitleAndImageOk() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    props.setStyle( new ArrayList<String>( Arrays.asList( "TITLE" ) ) );
    props.setText( TITLE_TEXT );
    props.setImage( Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    createOp.setProperties( props );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    activity.setProcessor( processor );
    when( processor.processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    IWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( transportResult.getResult() ).thenReturn( inputImage );
    operator = new ShellOperator( activity );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout root = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( root );
    assertEquals( 1, root.getChildCount() );
    FrameLayout shell = ( FrameLayout )root.getChildAt( 0 );
    assertTitleCorrect( shell, true, TITLE_TEXT );
    assertEquals( SHELL1_ID, shell.getTag() );
    assertTrue( "new Shells should be able to have the focus", shell.isFocusable() );
    assertTrue( "new Shells should have the focus", shell.hasFocus() );
    assertEquals( shell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( shell ), eq( props ) );
  }

  private void assertTitleCorrect( FrameLayout shell, boolean isDefaultIcon, String titleText ) {
    ViewGroup titleView = ( ViewGroup )shell.getChildAt( 0 );
    assertNotNull( titleView );
    assertEquals( 3, titleView.getChildCount() );
    assertEquals( titleText, ( ( TextView )titleView.findViewById( R.id.alertTitle ) ).getText() );
  }

  @Test
  public void testCreateModalWithTitleOk() throws Exception {
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    props.setStyle( new ArrayList<String>( Arrays.asList( "TITLE", "APPLICATION_MODAL" ) ) );
    createOp.setProperties( props );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    when( processor.getWidgetToolkit() ).thenReturn( mock( AndroidWidgetToolkit.class ) );
    operator = new ShellOperator( activity );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 2, view.getChildCount() );
    FrameLayout modalShell = ( FrameLayout )view.getChildAt( 1 );
    assertTitleCorrect( ( FrameLayout )modalShell.getChildAt( 0 ), false, "" );
    assertEquals( SHELL1_ID, modalShell.getTag() );
    assertTrue( "new Shells should be able to have the focus", modalShell.isFocusable() );
    assertTrue( "new Shells should have the focus", modalShell.hasFocus() );
    assertEquals( modalShell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( modalShell ), eq( props ) );
  }

  @Test
  public void testCreateModalWithTitleAndImageOk() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    props.setStyle( new ArrayList<String>( Arrays.asList( "TITLE", "APPLICATION_MODAL" ) ) );
    props.setText( TITLE_TEXT );
    props.setImage( Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    createOp.setProperties( props );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    activity.setProcessor( processor );
    when( processor.processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    IWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( transportResult.getResult() ).thenReturn( inputImage );
    operator = new ShellOperator( activity );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 2, view.getChildCount() );
    FrameLayout modalShell = ( FrameLayout )view.getChildAt( 1 );
    assertTitleCorrect( ( FrameLayout )modalShell.getChildAt( 0 ), true, TITLE_TEXT );
    assertEquals( SHELL1_ID, modalShell.getTag() );
    assertTrue( "new Shells should be able to have the focus", modalShell.isFocusable() );
    assertTrue( "new Shells should have the focus", modalShell.hasFocus() );
    assertEquals( modalShell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( modalShell ), eq( props ) );
  }

  @Test
  public void testCreateModalOk() throws Exception {
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateProperties props = new CreateProperties();
    ArrayList<String> styles = new ArrayList<String>();
    styles.add( MODAL_SHELL_STYLE );
    props.setStyle( styles );
    createOp.setProperties( props );
    SetterManager setterUtilMock = mock( SetterManager.class );
    operator.setSetterManager( setterUtilMock );

    operator.create( createOp );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 2, view.getChildCount() );
    FrameLayout shell = ( FrameLayout )view.getChildAt( 1 );
    assertEquals( SHELL1_ID, shell.getTag() );
    assertTrue( "new Shells should be able to have the focus", shell.isFocusable() );
    assertTrue( "new Shells should have the focus", shell.hasFocus() );
    assertEquals( shell.getLayoutParams().getClass(), FrameLayout.LayoutParams.class );
    verify( setterUtilMock ).execute( eq( activity ), eq( shell ), eq( props ) );
  }

  @Test
  public void testDestroyModal() throws Exception {
    ModalShell shell = new ModalShell( activity, animSupportMock );
    shell.setTag( SHELL1_ID );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( SHELL1_ID );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    shell.dimBackground( activity, rootLayout );
    rootLayout.addView( shell );
    when( toolkit.findObjectById( SHELL1_ID, View.class ) ).thenReturn( shell );
    operator.setShellAnimationSupport( animSupportMock );

    assertEquals( shell, rootLayout.findViewWithTag( SHELL1_ID ) );

    operator.destroy( destroyOperation );

    assertNull( rootLayout.findViewWithTag( SHELL1_ID ) );
    assertEquals( 0, rootLayout.getChildCount() );
  }

  @Test
  public void testCreateTwoShells() throws Exception {
    CreateOperation createOp = new CreateOperation();
    createOp.setTarget( SHELL1_ID );
    createOp.setType( ShellOperator.TYPE );
    CreateOperation createOp2 = new CreateOperation();
    createOp2.setTarget( SHELL2_ID );
    createOp2.setType( ShellOperator.TYPE );

    operator.create( createOp );
    operator.create( createOp2 );

    FrameLayout view = ( FrameLayout )activity.findViewById( R.id.root_layout );
    assertNotNull( view );
    assertEquals( 2, view.getChildCount() );
    FrameLayout shell = ( FrameLayout )view.getChildAt( 0 );
    assertEquals( SHELL1_ID, shell.getTag() );
    shell = ( FrameLayout )view.getChildAt( 1 );
    assertEquals( SHELL2_ID, shell.getTag() );
  }

  @Test
  public void testGetType() throws Exception {
    ShellOperator op = new ShellOperator( new UiActivity() );
    assertEquals( ShellOperator.TYPE, op.getType() );
  }

  @Test
  public void testDestroy() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( SHELL1_ID );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    rootLayout.addView( shell );
    BitmapDrawable prevBitmapDrawable = mock( BitmapDrawable.class );
    shell.setBackgroundDrawable( prevBitmapDrawable );
    when( toolkit.findObjectById( SHELL1_ID, View.class ) ).thenReturn( shell );
    operator.setShellAnimationSupport( animSupportMock );

    assertEquals( shell, rootLayout.findViewWithTag( SHELL1_ID ) );

    operator.destroy( destroyOperation );

    assertNull( rootLayout.findViewWithTag( SHELL1_ID ) );
    verify( activity.getProcessor().getWidgetToolkit().getBitmapCache() ).decreaseReferenceCount( prevBitmapDrawable );
  }

  @Test
  public void testDestroyMaximized() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( SHELL1_ID );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    rootLayout.addView( shell );
    shell.setMode( Shell.MAXIMIZED );
    when( toolkit.findObjectById( SHELL1_ID, View.class ) ).thenReturn( shell );
    operator.setShellAnimationSupport( animSupportMock );

    assertEquals( shell, rootLayout.findViewWithTag( SHELL1_ID ) );

    operator.destroy( destroyOperation );

    assertNull( rootLayout.findViewWithTag( SHELL1_ID ) );
    verify( animSupportMock ).playShellAnimations( eq( shell ), anyInt(), anyInt(), eq( activity ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNullOperation() throws Exception {
    operator.destroy( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNoTarget() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    operator.destroy( destroyOperation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyTargetDoesNotExist() throws Exception {
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( SHELL1_ID );

    assertNull( rootLayout.findViewWithTag( SHELL1_ID ) );

    operator.destroy( destroyOperation );
  }

}
