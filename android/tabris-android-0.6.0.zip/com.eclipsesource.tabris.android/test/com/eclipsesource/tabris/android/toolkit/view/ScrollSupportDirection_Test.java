/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.ScrollSupportDirection;

public class ScrollSupportDirection_Test {

  @Test
  public void testX() {
    assertTrue( ScrollSupportDirection.X.supportsX() );
    assertFalse( ScrollSupportDirection.X.supportsY() );
  }

  @Test
  public void testY() {
    assertFalse( ScrollSupportDirection.Y.supportsX() );
    assertTrue( ScrollSupportDirection.Y.supportsY() );
  }

  @Test
  public void testXandY() {
    assertTrue( ScrollSupportDirection.X_AND_Y.supportsX() );
    assertTrue( ScrollSupportDirection.X_AND_Y.supportsY() );
  }

}
