/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import android.view.View;
import android.widget.AdapterView;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.RecordingSpinnerItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.state.ListVisibleState;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectedItemState;

public class RecordingOnItemSelectedListener_Test {

  private static final String WIDGET_ID = "w23";

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    new RecordingSpinnerItemSelectedListener( null );
  }

  @Test
  public void testRecordState() {
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingSpinnerItemSelectedListener listener = new RecordingSpinnerItemSelectedListener( stateRecorder );
    AdapterView<?> parent = mock( AdapterView.class );
    when( parent.getTag() ).thenReturn( WIDGET_ID );
    ListVisibleState state1 = new ListVisibleState( WIDGET_ID, false );
    SelectedItemState state2 = new SelectedItemState( WIDGET_ID, 12 );

    listener.onItemSelected( parent, mock( View.class ), 12, 34 );

    verify( stateRecorder ).recordState( state1 );
    verify( stateRecorder ).recordState( state2 );
  }
}
