/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ShellAnimationSupport_Test {

  private UiActivity activity;
  private Shell shell;

  class TestShellAnimationSupport extends ShellAnimationSupport {

    View previousView;
    int prevViewAnim;
    UiActivity activity;

    @Override
    int getAnimIdFromStyle( Context context, int styleAttrId, int attrId ) {
      // shadow out low level Android stuff to make super class testable
      return 42;
    }

    @Override
    void playAnimation( View previousView, int prevViewAnim, UiActivity activity ) {
      this.prevViewAnim = prevViewAnim;
    }
  }

  @Test
  public void testPlayOneShellAnimation() {
    TestShellAnimationSupport animSupport = new TestShellAnimationSupport();
    activity = UiTestUtil.createUiActivity();
    shell = createShell();
    shell.setMode( Shell.MAXIMIZED );

    animSupport.playShellAnimations( shell, 1, 2, activity );

    assertEquals( 1, animSupport.prevViewAnim );
  }

  private Shell createShell() {
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    return new Shell( activity, animSupportMock );
  }

  @Test
  public void testFindPreviousView() {
    TestShellAnimationSupport animSupport = new TestShellAnimationSupport();
    activity = UiTestUtil.createUiActivity();
    Display display = new Display( activity );
    Shell shell1 = createShell();
    Shell shell2 = createShell();
    display.addView( shell1 );
    display.addView( shell2 );

    View prevShell = animSupport.findPreviousView( shell2, activity );

    assertEquals( shell1, prevShell );
  }

  @Test
  public void testFindPreviousViewInMixedSet() {
    TestShellAnimationSupport animSupport = new TestShellAnimationSupport();
    activity = UiTestUtil.createUiActivity();
    Display display = new Display( activity );
    Shell shell1 = createShell();
    View view = new View( activity );
    Shell shell2 = createShell();
    display.addView( shell1 );
    display.addView( view );
    display.addView( shell2 );

    View prevShell = animSupport.findPreviousView( shell2, activity );

    assertEquals( shell1, prevShell );
  }

  private int getAnimIdFromWindowAnimStyle( Context context, int attrId ) {
    int attrResId = ThemeUtil.getAttrResId( context, android.R.attr.windowAnimationStyle );
    TypedArray animationArray = context.obtainStyledAttributes( attrResId, new int[]{
      attrId
    } );
    int animResId = animationArray.getResourceId( 0, 0 );
    animationArray.recycle();
    return animResId;
  }

  @Test
  @Ignore("Can not easily load anim res id from attr with robolectric")
  public void testPlayAnimationsOnTopLevelShell() throws Exception {
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    rootLayout.addView( shell );
    ShellAnimationSupport animSupport = mock( ShellAnimationSupport.class );

    animSupport.playShellAnimations( shell,
                                     android.R.attr.activityOpenEnterAnimation,
                                     android.R.attr.activityOpenExitAnimation,
                                     activity );

    int openEnterAnimId = getAnimIdFromWindowAnimStyle( activity,
                                                        android.R.attr.activityOpenEnterAnimation );
    assertEquals( AnimationUtils.loadAnimation( activity, openEnterAnimId ), shell.getAnimation() );
  }

}
