/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.toolkit.IMethod;
import com.eclipsesource.tabris.android.toolkit.method.MeasureStringsMethod;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DisplayOperator_Test {

  private static final String DISPLAY_ID = "w1";

  @Test
  public void testGetType() throws Exception {
    DisplayOperator op = new DisplayOperator( UiTestUtil.createUiActivity(),
                                              mock( MeasureStringsMethod.class ) );
    assertEquals( DisplayOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateWithNull() {
    DisplayOperator operator = new DisplayOperator( UiTestUtil.createUiActivity(),
                                                    mock( MeasureStringsMethod.class ) );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithNullArgs() throws Exception {
    DisplayOperator op = new DisplayOperator( new UiActivity(), mock( MeasureStringsMethod.class ) );

    op.call( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithNullTarget() throws Exception {
    DisplayOperator op = new DisplayOperator( new UiActivity(), mock( MeasureStringsMethod.class ) );

    op.call( new CallOperation() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCallWithNullProperties() throws Exception {
    DisplayOperator op = new DisplayOperator( new UiActivity(), mock( MeasureStringsMethod.class ) );
    CallOperation operation = new CallOperation();
    operation.setTarget( DISPLAY_ID );

    op.call( operation );
  }

  @Test(expected = IllegalAccessError.class)
  public void testCallUnknownMethod() throws Exception {
    DisplayOperator op = new DisplayOperator( UiTestUtil.createUiActivity(),
                                              mock( MeasureStringsMethod.class ) );
    op.setMethods( new HashMap<String, IMethod>() );
    CallOperation operation = new CallOperation();
    operation.setTarget( DISPLAY_ID );
    operation.setMethod( "unknownMethod" );
    operation.setProperties( new CallProperties() );

    op.call( operation );
  }

  @Test
  public void testCallFunction() throws Exception {
    DisplayOperator op = new DisplayOperator( UiTestUtil.createUiActivity(),
                                              mock( MeasureStringsMethod.class ) );
    HashMap<String, IMethod> methods = new HashMap<String, IMethod>();
    IMethod method = mock( IMethod.class );
    methods.put( "method", method );
    op.setMethods( methods );
    CallOperation operation = new CallOperation();
    operation.setTarget( DISPLAY_ID );
    operation.setMethod( "method" );
    CallProperties properties = new CallProperties();
    properties.put( "key", 123 );
    operation.setProperties( properties );

    op.call( operation );

    verify( method ).call( properties );
  }
}
