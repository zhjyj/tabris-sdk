/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolBar_Test {

  private UiActivity activity;

  @Before
  public void setup() {
    activity = new UiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( mock( IWidgetToolkit.class ) );
    activity.setProcessor( processor );
  }

  @Test
  public void testCreateOk() {
    ToolBar toolBar = new ToolBar( activity );

    assertEquals( 2, toolBar.getChildCount() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddViewNull() throws Exception {
    ToolBar toolBar = new ToolBar( activity );

    toolBar.addView( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddViewNoneToolItem() throws Exception {
    ToolBar toolBar = new ToolBar( activity );

    toolBar.addView( mock( View.class ) );
  }

  @Test
  public void testAddView() throws Exception {
    ToolBar toolBar = new ToolBar( activity );
    ToolItem toolItem = new ToolItem( activity );
    ToolItem spyToolItem = spy( toolItem );

    toolBar.addView( spyToolItem );

    ViewGroup rightLayout = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( rightLayout.getChildAt( 0 ), spyToolItem );
    verify( spyToolItem ).setHorizontalSpacing( anyInt() );
    verify( spyToolItem ).updateAppearance();
    verify( spyToolItem ).setParentToolBar( toolBar );
  }

  @Test
  public void testAddViewWithCustomVariantTitle() throws Exception {
    ToolBar toolBar = new ToolBar( activity );
    ToolItem toolItem = new ToolItem( activity );
    toolItem.setTag( R.id.custom_variant, ICustomVariants.TITLE );
    ToolItem spyToolItem = spy( toolItem );

    toolBar.addView( spyToolItem );

    ViewGroup leftLayout = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( leftLayout.getChildAt( 0 ), spyToolItem );
    verify( spyToolItem ).setHorizontalSpacing( anyInt() );
    verify( spyToolItem ).updateAppearance();
    verify( spyToolItem ).setParentToolBar( toolBar );
  }

}
