/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.ToggleButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ButtonOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingCheckedChangedListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ButtonOperator_Test {

  private static final String BUTTON_ID = "w3";
  private static final String PARENT_ID = "w1";

  private UiActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentView;

  @Before
  public void setup() {
    activity = new UiActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getStateRecorder() ).thenReturn( mock( StateRecorder.class ) );
    activity.setProcessor( processor );
    toolkit = new AndroidWidgetToolkit( activity );
    parentView = new FrameLayout( activity );
    toolkit.registerObjectById( PARENT_ID, parentView );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ButtonOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ButtonOperator operator = new ButtonOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateButtonNoProps() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateButtonNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateButtonNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateButtonParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( buttonId );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateButtonOkDefault() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    getCreatedValidatedButton();
  }

  @Test
  public void testCreateButtonStyleCheck() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( ButtonOperator.STYLE_CHECK ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertEquals( CheckBox.class, view.getClass() );
    assertEquals( BUTTON_ID, view.getTag() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .getListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( RecordingCheckedChangedListener.class ) );
  }

  @Test
  public void testCreateButtonStyleRadio() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( ButtonOperator.STYLE_RADIO ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertEquals( RadioButton.class, view.getClass() );
    assertEquals( BUTTON_ID, view.getTag() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .getListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( RecordingCheckedChangedListener.class ) );
  }

  @Test
  public void testCreateButtonStylePush() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( ButtonOperator.STYLE_PUSH ) );

    operator.create( op );

    getCreatedValidatedButton();
  }

  @Test
  public void testCreateButtonStyleToggle() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( ButtonOperator.STYLE_TOGGLE ) );
    String text = "Hello";
    op.getProperties().setText( text );

    operator.create( op );

    ToggleButton view = UiTestUtil.findObjectById( activity, BUTTON_ID, ToggleButton.class );
    assertEquals( ToggleButton.class, view.getClass() );
    assertEquals( BUTTON_ID, view.getTag() );
    // Robolectric does not have a shadow object for ToggleButton so
    // we can not check if the text on/off has been set.
    // assertEquals( text, view.getTextOn() );
    // assertEquals( text, view.getTextOff() );
    CompositeCheckedChangedListener listener = toolkit.getListenerRegistry()
      .getListener( BUTTON_ID, CompositeCheckedChangedListener.class );
    assertNotNull( listener );
    assertTrue( listener.contains( RecordingCheckedChangedListener.class ) );
  }

  private Button getCreatedValidatedButton() {
    View view = UiTestUtil.findViewById( activity, BUTTON_ID );
    assertTrue( view instanceof Button );
    assertEquals( BUTTON_ID, view.getTag() );
    return ( Button )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( BUTTON_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateAndInitiateView() throws Exception {
    AbstractWidgetOperator operator = new ButtonOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Button view = UiTestUtil.findObjectById( activity, BUTTON_ID, Button.class );
    assertEquals( parentView, view.getParent() );
  }

  @Test
  public void testGetType() throws Exception {
    ButtonOperator op = new ButtonOperator( new UiActivity() );
    assertEquals( ButtonOperator.TYPE, op.getType() );
  }
}
