/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;

import android.graphics.Paint;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.AlphaGcOperation;

public class AlphaGcOperation_Test {

  @Test
  @SuppressWarnings("unchecked")
  public void testExecute() {
    AlphaGcOperation op = new AlphaGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    Paint paint = mock( Paint.class );
    when( gc.getPaint() ).thenReturn( paint );

    op.execute( gc, Arrays.asList( op.getOperation(), 0.6f ) );

    verify( paint ).setAlpha( Math.round( 0.6f * 255 ) );
  }
}
