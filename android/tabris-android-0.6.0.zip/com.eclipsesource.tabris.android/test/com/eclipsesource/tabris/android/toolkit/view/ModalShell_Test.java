/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.widget.Button;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ModalShell_Test {

  ModalShell shell;

  class ModalShellUnderTest extends ModalShell {

    public ModalShellUnderTest( UiActivity context, ShellAnimationSupport animSupport ) {
      super( context, animSupport );
    }

    Composite getContent() {
      return content;
    }

    Composite injectContentSpy() {
      Composite contentSpy = spy( content );
      content = contentSpy;
      return contentSpy;
    }

  }

  @Test
  public void testAnimatedIfShown() throws Exception {
    UiActivity activity = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShell shell = new ModalShell( activity, animSupportMock );

    shell.playShowAnimation( activity );

    verify( animSupportMock ).playModalShellAnimation( any( Shell.class ),
                                                       eq( android.R.attr.windowEnterAnimation ),
                                                       eq( activity ) );
  }

  @Test
  public void testAnimatedIfHidden() throws Exception {
    UiActivity activityMock = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShell shell = new ModalShell( activityMock, animSupportMock );

    shell.playHideAnimation( activityMock );

    verify( animSupportMock ).playModalShellAnimation( any( Shell.class ),
                                                       eq( android.R.attr.windowExitAnimation ),
                                                       eq( activityMock ) );
  }

  @Test
  public void testAddView() throws Exception {
    UiActivity context = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShellUnderTest shell = new ModalShellUnderTest( context, animSupportMock );
    Button child = new Button( context );

    shell.addView( child );

    assertSame( child, shell.getContent().getChildAt( 0 ) );
  }

  @Test
  public void testIndexOfChild() throws Exception {
    UiActivity context = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShellUnderTest shell = new ModalShellUnderTest( context, animSupportMock );
    Button child = new Button( context );
    Button nonChild = new Button( context );
    shell.addView( child );

    int childIndex = shell.indexOfChild( child );

    assertEquals( 0, childIndex );

    int nonChildIndex = shell.indexOfChild( nonChild );

    assertEquals( -1, nonChildIndex );
  }

  @Test
  public void testRemoveView() throws Exception {
    UiActivity context = UiTestUtil.createUiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShellUnderTest shell = new ModalShellUnderTest( context, animSupportMock );
    Button child = new Button( context );
    assertEquals( 0, shell.getContent().getChildCount() );

    shell.addView( child );

    assertEquals( 1, shell.getContent().getChildCount() );

    int index = shell.getContent().indexOfChild( child );
    shell.removeViewAt( index );

    assertEquals( 0, shell.getContent().getChildCount() );
  }

  @Test
  public void testBringChildToFront() throws Exception {
    UiActivity context = UiTestUtil.createUiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    ModalShellUnderTest shell = new ModalShellUnderTest( context, animSupportMock );
    Button child = new Button( context );
    shell.addView( child );
    assertEquals( 1, shell.getContent().getChildCount() );
    Composite contentSpy = shell.injectContentSpy();

    shell.bringChildToFront( child );

    verify( contentSpy ).bringChildToFront( eq( child ) );
  }
}
