/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.util.Arrays;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.BeginPathGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;

public class BeginPathGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new BeginPathGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );

    op.execute( gc, Arrays.asList( op.getOperation() ) );

    verify( gc ).createNewPath();
  }
}
