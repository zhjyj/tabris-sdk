/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;

import android.graphics.Paint;
import android.graphics.Paint.Join;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.LineJoinGcOperation;

public class LineJoinGcOperation_Test {

  @Test
  public void testExecuteButt() {
    Paint paint = createAndExecute( "round" );

    verify( paint ).setStrokeJoin( Join.ROUND );
  }

  @Test
  public void testExecuteRound() {
    Paint paint = createAndExecute( "miter" );

    verify( paint ).setStrokeJoin( Join.MITER );
  }

  @Test
  public void testExecuteSquare() {
    Paint paint = createAndExecute( "bevel" );

    verify( paint ).setStrokeJoin( Join.BEVEL );
  }

  private Paint createAndExecute( String strokeCap ) {
    IGcOperation op = new LineJoinGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    Paint paint = mock( Paint.class );
    when( gc.getPaint() ).thenReturn( paint );

    op.execute( gc, Arrays.asList( op.getOperation(), strokeCap ) );
    return paint;
  }

}
