/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.LinearGradiant;
import com.eclipsesource.tabris.android.toolkit.view.gc.CreateLinearGradiantGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CreateLinearGradiantGcOperation_Test {

  @Test
  @SuppressWarnings("unchecked")
  public void testExecute() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 10f ) ).thenReturn( 20f );
    when( toolkit.multiplyByDensityFactor( 20f ) ).thenReturn( 40f );
    when( toolkit.multiplyByDensityFactor( 30f ) ).thenReturn( 60f );
    when( toolkit.multiplyByDensityFactor( 40f ) ).thenReturn( 80f );
    IGcOperation op = new CreateLinearGradiantGcOperation( activity );
    GraphicalContext gc = mock( GraphicalContext.class );
    LinearGradiant linearGradiant = mock( LinearGradiant.class );
    when( gc.getLinearGradient() ).thenReturn( linearGradiant );

    op.execute( gc, Arrays.asList( op.getOperation(), 10f, 20f, 30f, 40f ) );

    verify( linearGradiant ).setCoords( 20f, 60f, 40f, 80f );
  }

}
