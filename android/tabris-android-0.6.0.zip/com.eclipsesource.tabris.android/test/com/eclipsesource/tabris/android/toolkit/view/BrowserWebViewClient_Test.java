/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.webkit.WebView;

import com.eclipsesource.tabris.android.toolkit.view.BrowserWebViewClient;
import com.eclipsesource.tabris.android.toolkit.view.IBrowserProgressListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BrowserWebViewClient_Test {

  private static final String WIDGET_ID = "w34";

  @Test
  public void testSetAndNotifyProgressListener() {
    BrowserWebViewClient client = new BrowserWebViewClient( WIDGET_ID );
    IBrowserProgressListener progressListener = mock( IBrowserProgressListener.class );
    client.setProgressListener( progressListener );

    client.onPageFinished( mock( WebView.class ), "http://url.com" );

    verify( progressListener ).pageFinishedLoading( WIDGET_ID );
  }
}
