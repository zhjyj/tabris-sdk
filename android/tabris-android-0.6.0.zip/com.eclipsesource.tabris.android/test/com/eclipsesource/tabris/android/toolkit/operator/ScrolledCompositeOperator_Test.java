/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ScrolledCompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ShellOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupportDirection;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ScrolledCompositeOperator_Test {

  private static final String H_SCROLL = "H_SCROLL";
  private static final String V_SCROLL = "V_SCROLL";

  private static final String COMP_ID = "w3";

  private static final String PARENT_ID = "w1";

  private UiActivity activity;

  @Before
  public void setup() {
    activity = UiTestUtil.createUiActivity();
    FrameLayout parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    activity.getProcessor().getWidgetToolkit().registerObjectById( PARENT_ID, parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoProps() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoStyleInProps() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCompositeParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( buttonId );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateHorizontalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( H_SCROLL ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableHorizontalScrollView );
    assertEquals( COMP_ID, view.getTag() );
  }

  @Test
  public void testCreateVerticalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( V_SCROLL ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableVerticalScrollView );
    assertEquals( COMP_ID, view.getTag() );
  }

  @Test
  public void testCreateVerticalHorizontalCompositeOk() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( V_SCROLL, H_SCROLL ) );

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMP_ID );
    assertTrue( view instanceof ObservableScrollView );
    assertEquals( COMP_ID, view.getTag() );
    ObservableScrollView scrollView = ( ObservableScrollView )view;
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    assertEquals( ObservableVerticalScrollView.class, verticalScroll.getClass() );
    assertEquals( ScrollSupportDirection.Y, verticalScroll.getScrollSupport().getDirection() );
    assertEquals( COMP_ID, verticalScroll.getTag() );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    assertEquals( ObservableHorizontalScrollView.class, horizontalScroll.getClass() );
    assertEquals( ScrollSupportDirection.X, horizontalScroll.getScrollSupport().getDirection() );
    assertEquals( COMP_ID, horizontalScroll.getTag() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( COMP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    props.setStyle( Arrays.asList( V_SCROLL ) );
    op.setProperties( props );
    return op;
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCompositeWrongBounds() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( V_SCROLL ) );
    op.getProperties().setBounds( Arrays.asList( 10, 20, 30 ) );

    operator.create( op );
  }

  @Test
  public void testCreateAndInitiateView() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    FrameLayout layout = UiTestUtil.findObjectById( activity, COMP_ID, FrameLayout.class );
    FrameLayout parent = ( FrameLayout )layout.getParent();
    assertEquals( PARENT_ID, parent.getTag() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullOp() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    operator.set( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullTarget() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    SetOperation operation = new SetOperation();
    operation.setProperties( new SetProperties() );
    operator.set( operation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetOnCompositeNullProperties() throws Exception {
    AbstractWidgetOperator operator = new ScrolledCompositeOperator( activity );
    SetOperation operation = new SetOperation();
    operation.setTarget( COMP_ID );
    operator.set( operation );
  }

  @Test
  public void testGetType() throws Exception {
    ScrolledCompositeOperator op = new ScrolledCompositeOperator( new UiActivity() );
    assertEquals( ScrolledCompositeOperator.TYPE, op.getType() );
  }
}
