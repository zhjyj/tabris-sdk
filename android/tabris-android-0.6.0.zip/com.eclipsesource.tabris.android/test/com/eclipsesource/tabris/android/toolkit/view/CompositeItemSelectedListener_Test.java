/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

public class CompositeItemSelectedListener_Test {

  @Test
  @SuppressWarnings("rawtypes")
  public void testNotifyOnItemClick() {
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    OnItemClickListener listener1 = mock( OnItemClickListener.class );
    OnItemClickListener listener2 = mock( OnItemClickListener.class );
    compListener.addListener( listener1 );
    compListener.addListener( listener2 );
    AdapterView parent = mock( AdapterView.class );
    View view = mock( View.class );

    compListener.onItemClick( parent, view, 1, 2 );

    verify( listener1 ).onItemClick( parent, view, 1, 2 );
    verify( listener2 ).onItemClick( parent, view, 1, 2 );
  }

}
