/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.R;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.setter.SpinnerSetter;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SpinnerSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();

    setter.execute( mock( UiActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();

    setter.execute( mock( UiActivity.class ), mock( Spinner.class ), null );
  }

  @Test
  public void testSetItemsNull() {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>( activity,
                                                                    R.layout.simple_spinner_dropdown_item );
    spinner.setAdapter( spinnerAdapter );

    setter.execute( activity, spinner, new SetProperties() );

    assertEquals( 0, spinnerAdapter.getCount() );
  }

  @Test
  public void testSetItems() {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    spinner.setAdapter( adapter );
    SetProperties props = new SetProperties();
    props.setItems( Arrays.asList( "1", "2", "3" ) );

    setter.execute( activity, spinner, props );

    assertEquals( 3, adapter.getCount() );
    assertEquals( "1", adapter.getItem( 0 ) );
    assertEquals( "2", adapter.getItem( 1 ) );
    assertEquals( "3", adapter.getItem( 2 ) );
  }

  @Test
  public void testSetItemsAndOverride() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    adapter.add( "1" );
    adapter.add( "2" );
    adapter.add( "3" );
    spinner.setAdapter( adapter );
    SetProperties props = new SetProperties();
    props.setItems( Arrays.asList( "a", "b", "c", "d" ) );

    setter.execute( activity, spinner, props );

    assertEquals( 4, adapter.getCount() );
    assertEquals( "a", adapter.getItem( 0 ) );
    assertEquals( "b", adapter.getItem( 1 ) );
    assertEquals( "c", adapter.getItem( 2 ) );
    assertEquals( "d", adapter.getItem( 3 ) );
  }

  @Test
  public void testSetSelectionIndexNull() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    spinner.setAdapter( new ArrayAdapter<String>( activity, R.layout.simple_spinner_dropdown_item ) );
    SetProperties props = new SetProperties();

    setter.execute( activity, spinner, props );

    assertEquals( 0, spinner.getSelectedItemPosition() );
  }

  /**
   * Android does not support an empty selection on a Spinner so we can not set
   * "-1" as an "empty" selection. We explicitly set the selection to the first
   * element.
   */
  @Test
  public void testSetSelectionRemoveSelectedItem() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( activity,
                                                             R.layout.simple_spinner_dropdown_item );
    adapter.add( "1" );
    adapter.add( "2" );
    adapter.add( "3" );
    spinner.setAdapter( adapter );
    spinner.setSelection( 3 );
    SetProperties props = new SetProperties();
    props.setItems( Arrays.asList( "1", "2" ) );
    props.setSelectionIndex( -1 );

    setter.execute( activity, spinner, props );

    assertEquals( 0, spinner.getSelectedItemPosition() );
  }

  @Test
  public void testSetSelectionIndex() throws Exception {
    SpinnerSetter<Spinner> setter = new SpinnerSetter<Spinner>();
    UiActivity activity = new UiActivity();
    Spinner spinner = new Spinner( activity );
    spinner.setAdapter( new ArrayAdapter<String>( activity,
                                                  R.layout.simple_spinner_dropdown_item,
                                                  Arrays.asList( "1", "2", "3" ) ) );
    SetProperties props = new SetProperties();
    props.setSelectionIndex( 1 );

    setter.execute( activity, spinner, props );

    assertEquals( 1, spinner.getSelectedItemPosition() );
  }
}
