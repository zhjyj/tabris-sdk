/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.LabelOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ListOperator;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListOperator_Test {

  private static final String PARENT_ID = "w1";

  private static final String LIST_VIEW_ID = "w3";

  private UiActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = new UiActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );

    rootLayout.addView( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ListOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ListOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoProps() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewParentNotFrameLayout() throws Exception {
    String listViewId = "ListView";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    ListView listView = new ListView( activity );
    listView.setTag( listViewId );
    rootLayout.addView( listView );

    AbstractWidgetOperator operator = new LabelOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( listViewId );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateListViewOk() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    View view = parentLayout.findViewWithTag( LIST_VIEW_ID );
    verify( toolkit ).registerObjectById( eq( LIST_VIEW_ID ), eq( view ) );
    assertTrue( view instanceof List );
    assertEquals( LIST_VIEW_ID, view.getTag() );
    assertNull( ( ( List )view ).getOnItemSelectedListener() );
  }

  @Test
  public void testGetType() {
    ListOperator listOperator = new ListOperator( new UiActivity() );

    String type = listOperator.getType();

    assertEquals( "rwt.widgets.List", type );
  }

}
