/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateDateTimeChangedListener;

public class ImmediateDateTimeChangedListener_Test {

  private static final String WIDGET_ID = "widgetId";

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testCreateNullProtocolProcessor() {
    new ImmediateDateTimeChangedListener( null, mock( HashMap.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNullDateValues() {
    new ImmediateDateTimeChangedListener( mock( ProtocolProcessor.class ), null );
  }

  @Test
  public void testNotifyProtocolProcessor() {
    HashMap<Integer, String> dateValues = new HashMap<Integer, String>();
    dateValues.put( Calendar.YEAR, IProtocolConstants.DATE_TIME_YEAR );
    dateValues.put( Calendar.MONTH, IProtocolConstants.DATE_TIME_MONTH );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    ImmediateDateTimeChangedListener listener = new ImmediateDateTimeChangedListener( processor,
                                                                                      dateValues );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime();
    when( spinner.getDate() ).thenReturn( date );
    when( spinner.getTag() ).thenReturn( WIDGET_ID );

    listener.dateTimeChanged( spinner );

    PostRequest request = createPostRequest( dateValues, calendar );
    verify( processor ).processPostRequest( request );
  }

  private PostRequest createPostRequest( HashMap<Integer, String> dateValues, Calendar calendar ) {
    PostRequest request = new PostRequest();
    Set<Entry<Integer, String>> entrySet = dateValues.entrySet();
    for( Entry<Integer, String> entry : entrySet ) {
      request.addParam( WIDGET_ID + entry.getValue(),
                        String.valueOf( calendar.get( entry.getKey() ) ) );
    }
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, WIDGET_ID );
    return request;
  }
}
