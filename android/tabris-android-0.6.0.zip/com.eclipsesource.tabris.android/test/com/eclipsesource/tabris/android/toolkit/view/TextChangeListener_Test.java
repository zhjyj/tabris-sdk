/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.text.Editable;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.TextChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.state.TextState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TextChangeListener_Test {

  private static final String EDIT_TEXT_ID = "w3";

  private UiActivity activity;
  private ProtocolProcessor processor;
  private StateRecorder stateRecorder;

  @Before
  public void setUp() {
    activity = new UiActivity();
    processor = mock( ProtocolProcessor.class );
    stateRecorder = mock( StateRecorder.class );
    when( processor.getStateRecorder() ).thenReturn( stateRecorder );
    activity.setProcessor( processor );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreationWithNullView() {
    new TextChangeListener( null, stateRecorder );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreationWithNullStateRecorder() {
    new TextChangeListener( "someTag", null );
  }

  @Test
  public void testAfterTextChanged() {
    String editTextTag = EDIT_TEXT_ID;
    TextChangeListener textChangeListener = new TextChangeListener( editTextTag, stateRecorder );
    Editable s = mock( Editable.class );
    IState state = new TextState( EDIT_TEXT_ID, s.toString() );

    textChangeListener.afterTextChanged( s );

    verify( stateRecorder ).recordState( state );
  }
}
