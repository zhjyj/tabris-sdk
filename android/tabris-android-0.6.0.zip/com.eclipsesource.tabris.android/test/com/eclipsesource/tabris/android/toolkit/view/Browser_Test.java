/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.webkit.WebSettings;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.BrowserJSCallback;
import com.eclipsesource.tabris.android.toolkit.view.BrowserViewListener;
import com.eclipsesource.tabris.android.toolkit.view.BrowserWebChromeClient;
import com.eclipsesource.tabris.android.toolkit.view.BrowserWebViewClient;
import com.eclipsesource.tabris.android.toolkit.view.IBrowserProgressListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowWebView;

@RunWith(RobolectricTestRunner.class)
public class Browser_Test {

  @Test
  public void testInit() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );

    browser.init();

    WebSettings settings = browser.getSettings();
    assertTrue( settings.getJavaScriptEnabled() );
    ShadowWebView shadowBrowser = Robolectric.shadowOf( browser );
    Object jsInterface = shadowBrowser.getJavascriptInterface( "androidCallback" );
    assertTrue( jsInterface instanceof BrowserJSCallback );
    assertTrue( shadowBrowser.getWebViewClient() instanceof BrowserWebViewClient );
    assertTrue( shadowBrowser.getWebChromeClient() instanceof BrowserWebChromeClient );
    assertTrue( shadowBrowser.getOnTouchListener() instanceof BrowserViewListener );
  }

  @Test
  public void testSetProgressListener() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    BrowserWebViewClient webViewClient = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( webViewClient );
    IBrowserProgressListener listener = mock( IBrowserProgressListener.class );

    browser.setProgressListener( listener );

    verify( webViewClient ).setProgressListener( listener );
  }

  @Test
  public void testExecuteScript() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    Browser spyBrowser = spy( browser );

    spyBrowser.executeScript( "javascriptCode" );

    verify( spyBrowser ).loadUrl( "javascript:androidCallback.setResult(javascriptCode);" );
  }

  @Test
  public void testExecuteScriptSantized() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    Browser spyBrowser = spy( browser );

    spyBrowser.executeScript( "javascriptCode;" );

    verify( spyBrowser ).loadUrl( "javascript:androidCallback.setResult(javascriptCode);" );
  }
}
