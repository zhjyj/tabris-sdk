/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.test;

import static org.mockito.Mockito.*;
import android.content.Intent;
import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;

public class UiTestUtil {

  public static UiActivity createUiActivity() {
    UiActivity uiActivity = createUiActivityWithoutOnCreate();
    uiActivity.onCreate( null );
    return uiActivity;
  }

  public static UiActivity createUiActivityWithMockedFields() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    ListenerRegistry listenerRegistry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    StateRecorder stateRecorder = mock( StateRecorder.class );
    when( processor.getStateRecorder() ).thenReturn( stateRecorder );
    when( processor.getParser() ).thenReturn( mock( IProtocolParser.class ) );
    UiActivity uiActivity = new UiActivity();
    uiActivity.setProcessor( processor );
    return uiActivity;
  }

  public static UiActivity createUiActivityWithoutOnCreate() {
    UiActivity activity = createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    return activity;
  }

  public static void mockToolkitMultiply( UiActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivide( UiActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.divideByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivideIdentity( UiActivity activity, int... numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( int i : numbers ) {
      when( toolkit.divideByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static <T> T findObjectById( UiActivity activity, String id, Class<? extends T> clazz ) {
    return activity.getProcessor().getWidgetToolkit().findObjectById( id, clazz );
  }

  public static View findViewById( UiActivity activity, String id ) {
    return findObjectById( activity, id, View.class );
  }
}
