/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.widget.FrameLayout;
import android.widget.TabHost;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowTabHost;

@Implements(TabHost.class)
public class TabrisShadowTabHost extends ShadowTabHost {

  /**
   * Get the FrameLayout which holds tab content
   */
  @Implementation
  public FrameLayout getTabContentView() {
    return ( FrameLayout )findViewById( android.R.id.tabcontent );
  }
}
