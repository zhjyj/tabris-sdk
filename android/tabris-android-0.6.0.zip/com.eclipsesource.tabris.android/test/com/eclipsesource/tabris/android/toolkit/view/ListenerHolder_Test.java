/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import android.widget.AdapterView.OnItemSelectedListener;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateSpinnerItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.ListenerHolder;
import com.eclipsesource.tabris.android.toolkit.view.RecordingSpinnerItemSelectedListener;

public class ListenerHolder_Test {

  @Test
  public void testAddRemoveListener() {
    ListenerHolder<Object> holder = new ListenerHolder<Object>();
    OnItemSelectedListener listener1 = mock( OnItemSelectedListener.class );
    OnItemSelectedListener listener2 = mock( OnItemSelectedListener.class );

    assertEquals( 0, holder.getSize() );
    holder.addListener( listener1 );
    assertEquals( 1, holder.getSize() );
    holder.addListener( listener2 );
    assertEquals( 2, holder.getSize() );

    holder.removeListener( listener1 );
    assertEquals( 1, holder.getSize() );
    holder.removeListener( listener2 );
    assertEquals( 0, holder.getSize() );
  }

  @Test
  public void testRemoveMultipleListener1() throws Exception {
    ListenerHolder<Object> holder = new ListenerHolder<Object>();
    OnItemSelectedListener listener1 = new RecordingSpinnerItemSelectedListener( mock( StateRecorder.class ) );
    OnItemSelectedListener listener2 = new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) );
    OnItemSelectedListener listener3 = new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) );
    holder.addListener( listener1 );
    holder.addListener( listener2 );
    holder.addListener( listener3 );

    holder.removeListeners( RecordingSpinnerItemSelectedListener.class );

    assertEquals( 2, holder.getSize() );
  }

  @Test
  public void testRemoveMultipleListener2() throws Exception {
    ListenerHolder<Object> holder = new ListenerHolder<Object>();
    OnItemSelectedListener listener1 = new RecordingSpinnerItemSelectedListener( mock( StateRecorder.class ) );
    OnItemSelectedListener listener2 = new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) );
    OnItemSelectedListener listener3 = new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) );
    holder.addListener( listener1 );
    holder.addListener( listener2 );
    holder.addListener( listener3 );

    holder.removeListeners( ImmediateSpinnerItemSelectedListener.class );

    assertEquals( 1, holder.getSize() );
  }

  @Test
  public void testContainsFound() throws Exception {
    ListenerHolder<Object> holder = new ListenerHolder<Object>();
    String str = new String();
    holder.addListener( str );
    Integer integer = new Integer( 12 );
    holder.addListener( integer );

    assertTrue( holder.contains( String.class ) );
  }

  @Test
  public void testContainsNotFound() throws Exception {
    ListenerHolder<Object> holder = new ListenerHolder<Object>();
    String str = new String();
    holder.addListener( str );
    Integer integer = new Integer( 12 );
    holder.addListener( integer );

    assertFalse( holder.contains( Character.class ) );
  }

}
