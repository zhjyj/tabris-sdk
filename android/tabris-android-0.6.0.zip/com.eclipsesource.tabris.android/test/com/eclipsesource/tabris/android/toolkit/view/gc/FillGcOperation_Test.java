/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;

import android.graphics.Paint.Style;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeGcOperation;

public class FillGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new StrokeGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );

    op.execute( gc, Arrays.asList( op.getOperation() ) );

    verify( gc ).setStyle( Style.STROKE );
    verify( gc ).drawCurrentPath();
  }

}
