/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollYState;

public class ScrollYState_Test {

  @Test
  public void testGenerateKey() {
    ScrollYState state = new ScrollYState( "w4" );

    assertEquals( "w4" + IProtocolConstants.SCROLL_Y_POSTFIX, state.generateKey() );
  }

  @Test
  public void testGenerateValue() {
    ScrollYState state = new ScrollYState( "w4" );
    state.setScrollY( 400 );

    assertEquals( "400", state.generateValue() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetWidgetIdNull() {
    ScrollYState state = new ScrollYState( "" );
    state.setWidgetId( null );
  }

}
