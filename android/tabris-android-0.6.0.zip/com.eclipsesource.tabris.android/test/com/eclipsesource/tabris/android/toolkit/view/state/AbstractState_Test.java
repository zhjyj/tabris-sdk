/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.toolkit.view.state.AbstractState;

public class AbstractState_Test {

  private class TestState extends AbstractState {

    public TestState( String widgetID ) {
      super( widgetID );
    }

    @Override
    public String generateKey() {
      return null;
    }

    @Override
    public String generateValue() {
      return null;
    }

  }

  private class OtherTestState extends AbstractState {

    public OtherTestState( String widgetID ) {
      super( widgetID );
    }

    @Override
    public String generateKey() {
      return null;
    }

    @Override
    public String generateValue() {
      return null;
    }

  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateWithNull() {
    new TestState( null );
  }

  @Test
  public void testEquals() {
    IState state = new TestState( "testWidgetID" );
    IState otherState = new TestState( "testWidgetID" );

    assertEquals( state, otherState );
  }

  @Test
  public void testNotEqualsDifferentClass() {
    IState state = new TestState( "testWidgetID" );
    IState otherState = new OtherTestState( "testWidgetID" );

    assertFalse( state.equals( otherState ) );
    assertFalse( otherState.equals( state ) );
  }

  @Test
  public void testNotEqualsDifferentWidget() {
    IState state = new TestState( "testWidgetID" );
    IState otherState = new TestState( "otherTestWidgetID" );

    assertFalse( state.equals( otherState ) );
    assertFalse( otherState.equals( state ) );
  }

  @Test
  public void testSetRefusesEqualWidgets() {
    IState state = new TestState( "testWidgetID" );
    IState otherState = new TestState( "testWidgetID" );
    Set<IState> set = new HashSet<IState>();

    set.add( state );

    assertFalse( set.add( otherState ) );
  }

  @Test
  public void testSetContainsOnlyOneOfEqualWidgets() {
    IState state = new TestState( "testWidgetID" );
    IState otherState = new TestState( "testWidgetID" );
    Set<IState> set = new HashSet<IState>();

    set.add( state );
    assertTrue( set.remove( otherState ) );
    set.add( otherState );

    assertEquals( 1, set.size() );
  }
}
