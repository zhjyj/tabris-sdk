/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.RecordingCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectionState;

public class RecordingCheckedChangedListener_Test {

  @Test
  public void testCheckedChangedTrue() {
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingCheckedChangedListener listener = new RecordingCheckedChangedListener( stateRecorder );
    SelectionState selectionState = new SelectionState( "w2", true );
    CompoundButton button = mock( CompoundButton.class );
    when( button.getTag() ).thenReturn( "w2" );

    listener.onCheckedChanged( button, true );

    verify( stateRecorder ).recordState( selectionState );
  }

  @Test
  public void testCheckedChangedFalse() {
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingCheckedChangedListener listener = new RecordingCheckedChangedListener( stateRecorder );
    SelectionState selectionState = new SelectionState( "w2", false );
    CompoundButton button = mock( CompoundButton.class );
    when( button.getTag() ).thenReturn( "w2" );

    listener.onCheckedChanged( button, false );

    verify( stateRecorder ).recordState( selectionState );
  }

}
