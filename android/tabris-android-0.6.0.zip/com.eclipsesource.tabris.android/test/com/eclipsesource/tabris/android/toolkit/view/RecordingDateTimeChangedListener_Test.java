/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.RecordingDateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.state.DateTimeState;

public class RecordingDateTimeChangedListener_Test {

  private static final String WIDGET_ID = "widgetId";

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testCreateNullProtocolProcessor() {
    new RecordingDateTimeChangedListener( null, mock( HashMap.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNullDateValues() {
    new RecordingDateTimeChangedListener( mock( StateRecorder.class ), null );
  }

  @Test
  public void testNotifiyStateRecorder() {
    HashMap<Integer, String> dateValues = new HashMap<Integer, String>();
    dateValues.put( Calendar.YEAR, IProtocolConstants.DATE_TIME_YEAR );
    dateValues.put( Calendar.MONTH, IProtocolConstants.DATE_TIME_MONTH );
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingDateTimeChangedListener listener = new RecordingDateTimeChangedListener( stateRecorder,
                                                                                      dateValues );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime();
    when( spinner.getDate() ).thenReturn( date );
    when( spinner.getTag() ).thenReturn( WIDGET_ID );

    listener.dateTimeChanged( spinner );

    Set<Entry<Integer, String>> entrySet = dateValues.entrySet();
    for( Entry<Integer, String> entry : entrySet ) {
      DateTimeState state = new DateTimeState( WIDGET_ID,
                                               entry.getValue(),
                                               calendar.get( entry.getKey() ) );
      verify( stateRecorder ).recordState( state );
    }
  }

}
