/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeStyleGcOperation;

public class StrokeStyleGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new StrokeStyleGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    List<Integer> colorList = Arrays.asList( 1, 2, 3 );

    op.execute( gc, Arrays.asList( op.getOperation(), colorList ) );

    int color = SetterManager.colorToupleToInt( colorList );
    verify( gc ).setStrokeColor( color );
  }
}
