/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.PaintColorGcOperation;

public class PaintColorGcOperation_Test {

  public class ClassUnderTest extends PaintColorGcOperation {

    public ClassUnderTest( String operation ) {
      super( operation );
    }

    @Override
    public void setColor( GraphicalContext gc, int color ) {
      // not implemented
    }

  };

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteInvalidColorFormat() {
    PaintColorGcOperation op = new ClassUnderTest( "operation" );
    GraphicalContext gc = mock( GraphicalContext.class );
    List<String> params = Arrays.asList( op.getOperation(), "String" );

    op.execute( gc, params );
  }

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testExecuteInvalidColorTypeFormat() {
    PaintColorGcOperation op = new ClassUnderTest( "operation" );
    GraphicalContext gc = mock( GraphicalContext.class );
    List<?> params = Arrays.asList( op.getOperation(), Arrays.asList( 1, 2, "3" ) );

    op.execute( gc, params );
  }

  @Test
  public void testExecute() {
    PaintColorGcOperation spyOp = spy( new ClassUnderTest( "operation" ) );
    GraphicalContext gc = mock( GraphicalContext.class );
    List<Integer> colorList = Arrays.asList( 1, 2, 3 );

    spyOp.execute( gc, Arrays.asList( spyOp.getOperation(), colorList ) );

    int color = SetterManager.colorToupleToInt( colorList );
    verify( spyOp ).setColor( gc, color );
  }
}
