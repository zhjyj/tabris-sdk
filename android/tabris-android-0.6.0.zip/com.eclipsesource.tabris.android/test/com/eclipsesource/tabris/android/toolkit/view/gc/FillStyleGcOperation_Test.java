/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Paint;
import android.graphics.Shader;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.LinearGradiant;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillStyleGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class FillStyleGcOperation_Test {

  @Test
  public void testExecuteForColor() {
    IGcOperation op = new FillStyleGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    List<Integer> colorList = Arrays.asList( 1, 2, 3 );

    op.execute( gc, Arrays.asList( op.getOperation(), colorList ) );

    int color = SetterManager.colorToupleToInt( colorList );
    verify( gc ).setFillColor( color );
  }

  @Test
  public void testExecuteForGradiant() {
    IGcOperation op = new FillStyleGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    Paint paint = mock( Paint.class );
    when( gc.getPaint() ).thenReturn( paint );
    when( gc.getLinearGradient() ).thenReturn( mock( LinearGradiant.class ) );

    op.execute( gc, Arrays.asList( op.getOperation(), "linearGradient" ) );

    verify( paint ).setShader( any( Shader.class ) );
  }
}
