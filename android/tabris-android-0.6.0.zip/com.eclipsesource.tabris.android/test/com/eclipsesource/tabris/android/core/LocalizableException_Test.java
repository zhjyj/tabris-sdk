/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import junit.framework.Assert;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.LocalizableException;

public class LocalizableException_Test {

  @Test
  public void testCreate() {
    LocalizableException exception = new LocalizableException( "foo" );

    Assert.assertEquals( "foo", exception.getKey() );
  }

}
