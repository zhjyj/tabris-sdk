/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.app.Activity;
import android.widget.EditText;

import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.TextSelectionChangeListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Text_Test extends Text {

  public Text_Test() {
    super( null );
  }

  private Activity activity;

  @Before
  public void setUp() {
    activity = new Activity();
  }

  @Test
  public void testCreateWithNull() {
    Text text = new Text( null );

    Assert.assertTrue( text instanceof EditText );
  }

  @Test
  public void testCreate() {
    Text text = new Text( activity );

    Assert.assertTrue( text instanceof EditText );
  }

  @Test
  public void testOnSelectionChanged() {
    Text text = new Text_Test();
    TextSelectionChangeListener listenerMock = Mockito.mock( TextSelectionChangeListener.class );
    text.setSelectionChangeListener( listenerMock );

    text.onSelectionChanged( 1, 10 );

    Mockito.verify( listenerMock ).afterSelectionChanged( 1, 9 );
  }

  @Test
  public void testOnSelectionChangedWithoutListener() {
    Text text = new Text_Test();

    text.onSelectionChanged( 1, 10 );
  }

}
