/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.SaveGcOperation;

public class SaveGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new SaveGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );

    op.execute( gc, Arrays.asList( op.getOperation() ) );

    verify( gc ).savePaint();
  }
}
