/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowImageView;

@RunWith(RobolectricTestRunner.class)
public class DialogHeader_Test {

  private static String TITLE_TEXT = "title";

  @Test
  public void testSetIcon() {
    DialogHeader header = new DialogHeader( UiTestUtil.createUiActivity() );
    Drawable icon = mock( Drawable.class );

    header.setIcon( icon );

    assertNotNull( header.getIcon() );
    assertTrue( header.getIcon() instanceof ImageView );
    ShadowImageView shadowImageView = Robolectric.shadowOf( header.getIcon() );
    assertEquals( icon, shadowImageView.getDrawable() );
    assertEquals( View.VISIBLE, header.getIcon().getVisibility() );
  }

  @Test
  public void testSetTitleText() {
    DialogHeader header = new DialogHeader( UiTestUtil.createUiActivity() );

    header.setTitleText( TITLE_TEXT );

    TextView titleTextView = ( TextView )header.getHeader().findViewById( R.id.alertTitle );
    assertNotNull( titleTextView );
    assertEquals( TITLE_TEXT, titleTextView.getText() );
  }

  @Test
  public void testGetTitleText() {
    DialogHeader header = new DialogHeader( UiTestUtil.createUiActivity() );
    header.setTitleText( TITLE_TEXT );

    String titleText = header.getTitleText().toString();

    assertEquals( TITLE_TEXT, titleText );
  }
}
