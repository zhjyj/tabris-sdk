/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Looper;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Geolocation;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator.NeedsPositionFlavor;
import com.xtremelabs.robolectric.RobolectricTestRunner;


@RunWith( RobolectricTestRunner.class )
public class Geolocation_Test {
  
  private Geolocation geolocation;
  private UiActivity activity;
  private ProtocolProcessor processor;
  private LocationManager locationManager;

  @Before
  public void setUp() {
    activity = mock( UiActivity.class );
    Geolocation original = new Geolocation( activity, "foo" );
    geolocation = spy( original );
    locationManager = mock( LocationManager.class );
    doReturn( locationManager ).when( geolocation ).getLocationManager();
    mockProcessor();
  }
  
  private void mockProcessor() {
    processor = mock( ProtocolProcessor.class );
    when( activity.getProcessor() ).thenReturn( processor );
  }

  @Test
  public void testSendsRequest() {
    geolocation.onLocationChanged( mock( Location.class ) );
    
    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    PostRequest request = captor.getValue();
    Map<String, String> params = request.getParams();
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_ACCURACY ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_ALTITUDE ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_ALTITUDE_ACCURACY ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_HEADING ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_LATITUDE ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_LONGITUDE ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_SPEED ) );
    assertTrue( params.containsKey( "foo." + Geolocation.PROP_TIMESTAMP ) );
  }
  
  @Test
  public void testResetsPositionFlavorOnOnce() {
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onLocationChanged( mock( Location.class ) );
    
    assertEquals( NeedsPositionFlavor.NEVER, geolocation.getFlavor() );
  }
  
  @Test
  public void testStopsUpdate() {
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onLocationChanged( mock( Location.class ) );
    
    verify( locationManager ).removeUpdates( geolocation );
  }
  
  @Test
  public void testDoesNotResetsPositionFlavorOnContinous() {
    geolocation.setNeedsPosition( NeedsPositionFlavor.CONTINUOUS );
    
    geolocation.onLocationChanged( mock( Location.class ) );
    
    assertEquals( NeedsPositionFlavor.CONTINUOUS, geolocation.getFlavor() );
  }
  
  @Test
  public void testFrequency() {
    when( locationManager.getBestProvider( any( Criteria.class ), 
                                           anyBoolean() ) ).thenReturn( "bar" );
    geolocation.setFrequency( 42 );
   
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).requestLocationUpdates( eq( "bar" ), 
                                                      eq( 42L ), 
                                                      eq( 0.0F ), 
                                                      any( LocationListener.class ), 
                                                      any( Looper.class ) );
  }
  
  @Test
  public void testNoHighAccuracy() {
    geolocation.setEnableHighAccuracy( false );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).getBestProvider( any( Criteria.class ), anyBoolean() );
  }
  
  @Test
  public void testHighAccuracy() {
    when( locationManager.getBestProvider( any( Criteria.class ), 
                                           anyBoolean() ) ).thenReturn( "bar" );
    geolocation.setEnableHighAccuracy( true );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).getBestProvider( any( Criteria.class ), anyBoolean() );
  }
  
  @Test
  public void testMaximumAgeValid() {
    when( locationManager.getBestProvider( any( Criteria.class ), 
                                           anyBoolean() ) ).thenReturn( "bar" );
    Location location = mock( Location.class );
    when( location.getTime() ).thenReturn( System.currentTimeMillis() - 5 );
    when( locationManager.getLastKnownLocation( anyString() ) ).thenReturn( location );
    geolocation.setMaximumAge( 10 );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( geolocation ).onLocationChanged( location );
  }
  
  @Test
  public void testMaximumAgeInalid() {
    when( locationManager.getBestProvider( any( Criteria.class ), 
                                           anyBoolean() ) ).thenReturn( "bar" );
    Location location = mock( Location.class );
    when( location.getTime() ).thenReturn( System.currentTimeMillis() - 15 );
    when( locationManager.getLastKnownLocation( anyString() ) ).thenReturn( location );
    geolocation.setMaximumAge( 10 );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).requestLocationUpdates( eq( "bar" ), 
                                                      eq( 10000L ), 
                                                      eq( 0.0F ), 
                                                      any( LocationListener.class ), 
                                                      any( Looper.class ) );
  }
  
  @Test
  public void testNoMaximumAge() {
    when( locationManager.getBestProvider( any( Criteria.class ), 
                                           anyBoolean() ) ).thenReturn( "bar" );
    Location location = mock( Location.class );
    when( location.getTime() ).thenReturn( System.currentTimeMillis() - 5 );
    when( locationManager.getLastKnownLocation( anyString() ) ).thenReturn( location );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).requestLocationUpdates( eq( "bar" ), 
                                                      eq( 10000L ), 
                                                      eq( 0.0F ), 
                                                      any( LocationListener.class ), 
                                                      any( Looper.class ) );
  }
  
  
  @Test
  public void testGpsProvider() {
    when( locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ).thenReturn( true );

    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).requestLocationUpdates( eq( LocationManager.GPS_PROVIDER ), 
                                                      eq( 10000L ), 
                                                      eq( 0.0F ), 
                                                      any( LocationListener.class ), 
                                                      any( Looper.class ) );
  }
  
  @Test
  public void testNetworkProvider() {
    when( locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ).thenReturn( false );
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( true );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    verify( locationManager ).requestLocationUpdates( eq( LocationManager.NETWORK_PROVIDER ), 
                                                      eq( 10000L ), 
                                                      eq( 0.0F ), 
                                                      any( LocationListener.class ), 
                                                      any( Looper.class ) );
  }
  
  @Test
  public void testNoProvider() {
    when( locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ).thenReturn( false );
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( false );
    
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    Map<String, String> params = captor.getValue().getParams();
    String code = params.get( "foo." + Geolocation.PROP_ERROR_CODE );
    assertNotNull( code );
    assertEquals( Geolocation.CODE_PERMISSION_DENIED, code );
    assertNotNull( params.get( "foo." + Geolocation.PROP_ERROR_MESSAGE ) );
  }
  
  @Test
  public void testOnProviderDisabledGps() {
    when( locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ).thenReturn( true );
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onProviderDisabled( LocationManager.GPS_PROVIDER );
    
    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    Map<String, String> params = captor.getValue().getParams();
    String code = params.get( "foo." + Geolocation.PROP_ERROR_CODE );
    assertNotNull( code );
    assertEquals( Geolocation.CODE_UNAVAILABLE, code );
    assertNotNull( params.get( "foo." + Geolocation.PROP_ERROR_MESSAGE ) );
  }
  
  @Test
  public void testOnProviderDisabledNetwork() {
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( true );
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onProviderDisabled( LocationManager.NETWORK_PROVIDER );
    
    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    Map<String, String> params = captor.getValue().getParams();
    String code = params.get( "foo." + Geolocation.PROP_ERROR_CODE );
    assertNotNull( code );
    assertEquals( Geolocation.CODE_UNAVAILABLE, code );
    assertNotNull( params.get( "foo." + Geolocation.PROP_ERROR_MESSAGE ) );
  }
  
  @Test
  public void testOnProviderEnabled() {
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( true );
    geolocation.setNeedsPosition( NeedsPositionFlavor.CONTINUOUS );
    
    geolocation.onProviderEnabled( LocationManager.NETWORK_PROVIDER );
    
    verify( locationManager, times( 2 ) ).requestLocationUpdates( eq( LocationManager.NETWORK_PROVIDER ), 
                                                                  eq( 10000L ), 
                                                                  eq( 0.0F ), 
                                                                  any( LocationListener.class ), 
                                                                  any( Looper.class ) );
  }
  
  @Test
  public void testOnStatusChangedOutOfService() {
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( true );
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onStatusChanged( LocationManager.NETWORK_PROVIDER, 
                                 LocationProvider.OUT_OF_SERVICE, 
                                 null );
    

    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    Map<String, String> params = captor.getValue().getParams();
    String code = params.get( "foo." + Geolocation.PROP_ERROR_CODE );
    assertNotNull( code );
    assertEquals( Geolocation.CODE_UNKNOWN, code );
    assertNotNull( params.get( "foo." + Geolocation.PROP_ERROR_MESSAGE ) );
  }
  
  @Test
  public void testOnStatusChangedtempUnavailable() {
    when( locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ).thenReturn( true );
    geolocation.setNeedsPosition( NeedsPositionFlavor.ONCE );
    
    geolocation.onStatusChanged( LocationManager.NETWORK_PROVIDER, 
                                 LocationProvider.TEMPORARILY_UNAVAILABLE, 
                                 null );
    
    
    ArgumentCaptor<PostRequest> captor = ArgumentCaptor.forClass( PostRequest.class );
    verify( processor ).processPostRequest( captor.capture() );
    Map<String, String> params = captor.getValue().getParams();
    String code = params.get( "foo." + Geolocation.PROP_ERROR_CODE );
    assertNotNull( code );
    assertEquals( Geolocation.CODE_UNKNOWN, code );
    assertNotNull( params.get( "foo." + Geolocation.PROP_ERROR_MESSAGE ) );
  }
  
  
  @Test
  public void testDestroy() {
    geolocation.destroy();
    
    verify( locationManager ).removeUpdates( geolocation );
  }

}
