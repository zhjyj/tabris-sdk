/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAlertDialog;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
public class Dialog_Test {

  private static final String TITLE_STR = "title";

  @Test
  public void testCreateDialog() {
    Activity activity = new Activity();

    Dialog dialog = new Dialog( activity );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    int themeId = shadowDialog.getThemeId();
    TypedValue outValue = new TypedValue();
    activity.getTheme().resolveAttribute( R.attr.alertDialogTheme, outValue, true );
    assertEquals( outValue.resourceId, themeId );
  }

  @Test
  public void testSetTitleStr() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    Activity activity = new Activity();
    Dialog dialog = new Dialog( activity );

    dialog.setTitle( TITLE_STR );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    View customTitleView = shadowDialog.getCustomTitleView();
    TextView titleView = ( TextView )customTitleView.findViewById( R.id.alertTitle );
    assertEquals( TITLE_STR, titleView.getText().toString() );
  }

  @Test
  public void testSetTitleRes() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    Activity activity = new Activity();
    Dialog dialog = new Dialog( activity );

    dialog.setTitle( R.string.app_name );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    View customTitleView = shadowDialog.getCustomTitleView();
    TextView titleView = ( TextView )customTitleView.findViewById( R.id.alertTitle );
    assertEquals( activity.getString( R.string.app_name ), titleView.getText().toString() );
  }

  @Test
  public void testSetIconDrawable() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    Activity activity = new Activity();
    Dialog dialog = new Dialog( activity );
    Drawable drawable = Mockito.mock( Drawable.class );

    dialog.setIcon( drawable );

    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    View customTitleView = shadowDialog.getCustomTitleView();
    ImageView image = ( ImageView )customTitleView.findViewById( R.id.icon );
    assertSame( drawable, image.getDrawable() );
  }

  @Test
  public void testSetIconRes() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAlertDialog.class );
    Activity activity = new Activity();
    Dialog dialog = new Dialog( activity );
    ShadowAlertDialog shadowDialog = Robolectric.shadowOf( dialog );
    View customTitleView = shadowDialog.getCustomTitleView();
    ImageView image = ( ImageView )customTitleView.findViewById( R.id.icon );

    assertNull( image.getDrawable() );
    dialog.setIcon( R.drawable.icon );

    assertNotNull( image.getDrawable() );
  }

  @Test
  public void testSetTextColorOnMessageText() throws Exception {
    Activity activity = new Activity();
    final TextView textView = mock( TextView.class );
    Dialog dialog = new Dialog( activity ) {

      @Override
      public View findViewById( int id ) {
        return textView;
      }
    };
    int attrResId = ThemeUtil.getAttrResId( activity, android.R.attr.textAppearance );

    dialog.onCreate( null );

    verify( textView ).setTextAppearance( any( Context.class ), eq( attrResId ) );
  }
}
