/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.TextView;

import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowTextView;
import com.xtremelabs.robolectric.shadows.ShadowView;

@RunWith(RobolectricTestRunner.class)
public class Group_Test {

  private static final String TITLE = "title";

  @Test
  public void testCreate() {
    Group group = new Group( UiTestUtil.createUiActivityWithoutOnCreate() );

    TextView titleView = ( TextView )group.getChildAt( 1 );
    assertNotNull( titleView );
    View separatorView = group.getChildAt( 0 );
    assertNotNull( separatorView );
  }

  @Test
  public void testSetText() throws Exception {
    Group group = new Group( UiTestUtil.createUiActivityWithoutOnCreate() );
    TextView titleView = ( TextView )group.getChildAt( 1 );

    group.setTitle( TITLE );

    assertEquals( TITLE, titleView.getText() );
  }

  @Test
  public void testSetTitleAndSeparatorColor() throws Exception {
    Group group = new Group( UiTestUtil.createUiActivityWithoutOnCreate() );
    TextView titleView = ( TextView )group.getChildAt( 1 );
    ShadowTextView shadowTitleView = Robolectric.shadowOf( titleView );
    View separatorView = group.getChildAt( 0 );
    ShadowView shadowSeparatorView = Robolectric.shadowOf( separatorView );

    group.setTitleAndSeparatorColor( 123 );

    assertEquals( new Integer( 123 ), shadowTitleView.getTextColorHexValue() );
    assertEquals( 123, shadowSeparatorView.getBackgroundColor() );
  }
}
