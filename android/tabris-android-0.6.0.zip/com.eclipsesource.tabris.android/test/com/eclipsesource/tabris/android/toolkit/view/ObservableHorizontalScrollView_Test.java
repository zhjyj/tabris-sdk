/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollXState;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollYState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ObservableHorizontalScrollView_Test extends ObservableHorizontalScrollView {

  public ObservableHorizontalScrollView_Test() {
    super( UiTestUtil.createUiActivity() );
  }

  @Test
  public void testDoSmoothScrollTo() {
    ObservableHorizontalScrollView scrollView = new ObservableHorizontalScrollView( UiTestUtil.createUiActivity() );

    scrollView.doSmoothScrollTo( 40, 30 );

    Assert.assertEquals( 40, scrollView.getScrollSupport().getScrollTargetX() );
    Assert.assertEquals( 30, scrollView.getScrollSupport().getScrollTargetY() );
  }

  @Test
  public void testRecordScrollState() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();
    IWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    when( toolkit.divideByDensityFactor( 500 ) ).thenReturn( 250 );
    when( toolkit.divideByDensityFactor( 100 ) ).thenReturn( 50 );
    when( toolkit.divideByDensityFactor( 800 ) ).thenReturn( 400 );
    when( toolkit.divideByDensityFactor( 50 ) ).thenReturn( 25 );
    activity.getProcessor().setWidgetToolkit( toolkit );

    StateRecorder recorder = activity.getProcessor().getStateRecorder();
    ObservableHorizontalScrollView scrollView = new ObservableHorizontalScrollView( activity );
    scrollView.setTag( "w4" );

    scrollView.onScrollChanged( 500, 100, 0, 0 );

    ScrollXState stateX = new ScrollXState( "w4" );
    stateX.setScrollX( 250 );
    ScrollYState stateY = new ScrollYState( "w4" );
    stateY.setScrollY( 50 );
    assertTrue( recorder.contains( stateX ) );
    assertTrue( recorder.contains( stateY ) );

    scrollView.onScrollChanged( 800, 50, 500, 100 );

    stateX.setScrollX( 400 );
    stateY.setScrollY( 25 );
    assertTrue( recorder.contains( stateX ) );
    assertTrue( recorder.contains( stateY ) );
  }

  @Test
  public void testScrollTargetInit() {
    ObservableHorizontalScrollView scrollView = new ObservableHorizontalScrollView( UiTestUtil.createUiActivity() );

    assertEquals( 0, scrollView.getScrollSupport().getScrollTargetX() );
    assertEquals( 0, scrollView.getScrollSupport().getScrollTargetY() );
  }

  @Test
  public void testScrollTargetXUpdate() {
    ObservableHorizontalScrollView_Test scrollView = new ObservableHorizontalScrollView_Test();
    IWidgetToolkit toolkit = getToolkit();
    scrollView.setTag( "w4" );
    int newX = 10;

    scrollView.onScrollChanged( newX, 0, 0, 0 );

    assertEquals( toolkit.divideByDensityFactor( newX ), scrollView.getScrollSupport()
      .getScrollTargetX() );
    assertEquals( 0, scrollView.getScrollSupport().getScrollTargetY() );
  }

  @Test
  public void testScrollTargetYUpdate() {
    ObservableHorizontalScrollView_Test scrollView = new ObservableHorizontalScrollView_Test();
    IWidgetToolkit toolkit = getToolkit();
    scrollView.setTag( "w4" );

    scrollView.onScrollChanged( 0, 10, 0, 0 );

    assertEquals( 0, scrollView.getScrollSupport().getScrollTargetX() );
    assertEquals( toolkit.divideByDensityFactor( 10 ), scrollView.getScrollSupport()
      .getScrollTargetY() );
  }

  @Test
  public void testScrollTargetXYUpdate() {
    ObservableHorizontalScrollView_Test scrollView = new ObservableHorizontalScrollView_Test();
    IWidgetToolkit toolkit = getToolkit();
    scrollView.setTag( "w4" );

    scrollView.onScrollChanged( 10, 10, 11, 11 );

    assertEquals( toolkit.divideByDensityFactor( 10 ), scrollView.getScrollSupport()
      .getScrollTargetX() );
    assertEquals( toolkit.divideByDensityFactor( 10 ), scrollView.getScrollSupport()
      .getScrollTargetY() );
  }

  private IWidgetToolkit getToolkit() {
    return ( ( UiActivity )getContext() ).getProcessor().getWidgetToolkit();
  }

}
