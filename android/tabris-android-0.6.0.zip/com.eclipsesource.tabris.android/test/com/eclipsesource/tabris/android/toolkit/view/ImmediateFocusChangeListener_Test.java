/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateFocusChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateFocusChangeListener_Test {

  private static final String SHELL_ID = "w2";
  private static final String WIDGET1_ID = "w3";
  private static final String WIDGET2_ID = "w4";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new ImmediateFocusChangeListener( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOnClickNullArg() throws Exception {
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( new UiActivity() );
    listener.onFocusChange( null, false );
  }

  @Test
  public void testOnFocusChangeTrue() throws Exception {
    UiActivity activity = new UiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, WIDGET1_ID );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET1_ID );

    listener.onFocusChange( view, true );

    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testOnFocusLostInWidgetHierarchy() throws Exception {
    UiActivity activity = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    Shell shell = new Shell( activity, animSupportMock );
    shell.setTag( SHELL_ID );
    Composite comp = new Composite( activity );
    comp.setTag( WIDGET1_ID );
    shell.addView( comp );
    View view = new View( activity );
    view.setTag( WIDGET2_ID );
    comp.addView( view );
    activity.setContentView( shell );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, SHELL_ID );

    listener.onFocusChange( view, false );

    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testOnFocusLostOnShell() throws Exception {
    UiActivity activity = new UiActivity();
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    Shell shell = new Shell( activity, animSupportMock );
    shell.setTag( SHELL_ID );
    Composite comp = new Composite( activity );
    comp.setTag( WIDGET1_ID );
    shell.addView( comp );
    activity.setContentView( shell );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, SHELL_ID );

    listener.onFocusChange( shell, false );

    verify( processor ).processPostRequest( request );
  }

}
