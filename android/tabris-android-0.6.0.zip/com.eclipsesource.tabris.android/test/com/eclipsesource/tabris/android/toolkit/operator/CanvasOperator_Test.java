/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CanvasOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CanvasOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String CANVAS_ID = "w3";

  private UiActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = UiTestUtil.createUiActivityWithMockedFields();
    toolkit = activity.getProcessor().getWidgetToolkit();
    parentLayout = new FrameLayout( activity );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new CanvasOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCanvasNoProps() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCanvasNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateCanvasNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( CANVAS_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( CANVAS_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    View view = parentLayout.findViewWithTag( CANVAS_ID );
    verify( toolkit ).registerObjectById( eq( CANVAS_ID ), eq( view ) );
    assertTrue( view instanceof Canvas );
    assertEquals( CANVAS_ID, view.getTag() );
  }

  @Test
  public void testDestroy() throws Exception {
    AbstractWidgetOperator operator = new CanvasOperator( activity );
    Canvas canvas = new Canvas( activity );
    canvas.setTag( CANVAS_ID );
    canvas.initCanvas( 100, 100 );
    parentLayout.addView( canvas );

    Bitmap bitmap = canvas.getBitmap();
    assertNotNull( bitmap );

    canvas.setTag( CANVAS_ID );
    when( toolkit.findObjectById( CANVAS_ID, Canvas.class ) ).thenReturn( canvas );
    when( toolkit.findObjectById( CANVAS_ID, View.class ) ).thenReturn( canvas );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( CANVAS_ID );

    operator.destroy( destroyOperation );

    assertTrue( bitmap.isRecycled() );
    assertNull( canvas.getBitmap() );
  }

  @Test
  public void testGetType() throws Exception {
    CanvasOperator op = new CanvasOperator( new UiActivity() );
    assertEquals( CanvasOperator.TYPE, op.getType() );
  }

}
