/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.AbstractTouchListener.*;
import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.MotionEvent;
import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class MouseEventTouchListener_Test {

  private static final String WIDGET_ID = "w1";

  private UiActivity activity;
  private ProtocolProcessor processor;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = new UiActivity();
    toolkit = mock( AndroidWidgetToolkit.class );
    processor = mock( ProtocolProcessor.class );
    when( processor.getSessionTime() ).thenReturn( 3000l );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );
  }

  @Test
  public void testTransmittingUpDown() {
    MouseEventTouchListener listener = new MouseEventTouchListener( activity, false );

    assertFalse( listener.isTransmittingUpDown() );

    listener.setTransmittingUpDown( true );

    assertTrue( listener.isTransmittingUpDown() );
  }

  @Test
  public void testOnTouchDown() {
    MouseEventTouchListener listener = new MouseEventTouchListener( activity, true );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, MotionEvent.ACTION_DOWN, 10f, 30f, 0 );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    when( toolkit.divideByDensityFactor( 10 ) ).thenReturn( 5 );
    when( toolkit.divideByDensityFactor( 30 ) ).thenReturn( 15 );

    boolean wasConsumed = listener.onTouch( view, motionEvent );

    assertFalse( wasConsumed );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_MOUSE_DOWN, WIDGET_ID );
    request.addParam( IProtocolConstants.EVENT_MOUSE_DOWN + EVENT_MOUSE_BUTTON, MOUSE_BUTTON_1 );
    request.addParam( IProtocolConstants.EVENT_MOUSE_DOWN + EVENT_MOUSE_COORD_X, "5" );
    request.addParam( IProtocolConstants.EVENT_MOUSE_DOWN + EVENT_MOUSE_COORD_Y, "15" );
    request.addParam( IProtocolConstants.W1_CURSOR_LOCATION_X, "5" );
    request.addParam( IProtocolConstants.W1_CURSOR_LOCATION_Y, "15" );
    request.addParam( IProtocolConstants.EVENT_MOUSE_DOWN + EVENT_MOUSE_TIME,
                      String.valueOf( processor.getSessionTime() ) );
    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testOnTouchUp() {
    MouseEventTouchListener listener = new MouseEventTouchListener( activity, true );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, MotionEvent.ACTION_UP, 10f, 30f, 0 );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    when( toolkit.divideByDensityFactor( 10 ) ).thenReturn( 5 );
    when( toolkit.divideByDensityFactor( 30 ) ).thenReturn( 15 );

    boolean wasConsumed = listener.onTouch( view, motionEvent );

    assertFalse( wasConsumed );
    PostRequest request = new PostRequest();
    request.addParam( EVENT_MOUSE_UP, WIDGET_ID );
    request.addParam( EVENT_MOUSE_UP + EVENT_MOUSE_BUTTON, MOUSE_BUTTON_1 );
    request.addParam( EVENT_MOUSE_UP + EVENT_MOUSE_COORD_X, "5" );
    request.addParam( EVENT_MOUSE_UP + EVENT_MOUSE_COORD_Y, "15" );
    request.addParam( IProtocolConstants.W1_CURSOR_LOCATION_X, "5" );
    request.addParam( IProtocolConstants.W1_CURSOR_LOCATION_Y, "15" );
    request.addParam( EVENT_MOUSE_UP + EVENT_MOUSE_TIME,
                      String.valueOf( processor.getSessionTime() ) );
    verify( processor ).processPostRequest( request );
  }

}
