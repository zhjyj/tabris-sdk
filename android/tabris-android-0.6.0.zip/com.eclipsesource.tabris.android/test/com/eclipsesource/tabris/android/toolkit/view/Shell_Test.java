/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Shell_Test {

  public static class TestShell extends Shell {

    public TestShell( UiActivity context ) {
      super( context, Mockito.mock( ShellAnimationSupport.class ) );
    }

    ShellAnimationSupport getAnimationSupport() {
      return animSupport;
    }

    DialogHeader getTitle() {
      return dialogHeader;
    }
  }

  @Test
  public void testSetMode() throws Exception {
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    Shell shell = new Shell( new UiActivity(), animSupportMock );

    shell.setMode( "foo" );

    assertEquals( "foo", shell.getMode() );
  }

  @Test
  public void testAnimatedIfMaximized() throws Exception {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );
    shell.setMode( Shell.MAXIMIZED );

    shell.playShowAnimation( activityMock );

    verify( shell.getAnimationSupport() ).playShellAnimations( any( Shell.class ),
                                                               anyInt(),
                                                               anyInt(),
                                                               eq( activityMock ) );
  }

  @Test
  public void testNotAnimatedIfNotMaximized() throws Exception {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );

    shell.playShowAnimation( activityMock );

    verifyNoMoreInteractions( shell.getAnimationSupport() );
  }

  @Test
  public void testSetTitle() throws Exception {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );
    DialogHeader title = mock( DialogHeader.class );
    View header = new View( activityMock );
    Mockito.when( title.getHeader() ).thenReturn( header );
    assertNull( shell.getTitle() );

    shell.setHeader( title );

    assertSame( title, shell.getTitle() );
    assertNotSame( -1, shell.indexOfChild( shell.getTitle().getHeader() ) );
  }

  @Test
  public void testSetText() throws Exception {
    DialogHeader title = mock( DialogHeader.class );
    TestShell shell = createShellWithTitle( title );
    String titleText = "titleText";

    shell.setText( titleText );

    verify( title ).setTitleText( eq( titleText ) );
  }

  @Test
  public void testSetTextNoTitle() throws Exception {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );
    String titleText = "titleText";

    shell.setText( titleText );

    assertNull( shell.getTitle() );
  }

  private TestShell createShellWithTitle( DialogHeader title ) {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );
    View header = new View( activityMock );
    Mockito.when( title.getHeader() ).thenReturn( header );
    shell.setHeader( title );
    return shell;
  }

  @Test
  public void testSetIcon() throws Exception {
    DialogHeader title = mock( DialogHeader.class );
    TestShell shell = createShellWithTitle( title );
    Drawable icon = mock( Drawable.class );

    shell.setIcon( icon );

    verify( title ).setIcon( eq( icon ) );
  }

  @Test
  public void testSetIconNoTitle() throws Exception {
    UiActivity activityMock = mock( UiActivity.class );
    TestShell shell = new TestShell( activityMock );
    Drawable icon = mock( Drawable.class );

    shell.setIcon( icon );

    assertNull( shell.getTitle() );
  }

  @Test
  public void testGetHeader() throws Exception {
    UiActivity activity = new UiActivity();
    Shell shell = new Shell( activity, mock( ShellAnimationSupport.class ) );
    DialogHeader dialogHeader = new DialogHeader( activity );
    shell.setHeader( dialogHeader );

    DialogHeader header = shell.getHeader();

    assertEquals( dialogHeader, header );
  }
}
