/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.widget.ListView;

import com.eclipsesource.tabris.android.toolkit.view.List;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class List_Test {

  @Test
  public void testCreateWithNull() {
    List list = new List( null );

    Assert.assertTrue( list instanceof ListView );
  }

  @Test
  public void testCreate() {
    List list = new List( new Activity() );

    Assert.assertTrue( list instanceof ListView );
  }
}
