/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.content.Intent;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class UiActivity_Test {

  @Test()
  public void testActivityCreateEmptyIntent() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    activity.setIntent( intent );

    activity.onCreate( null );

    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testActivityCreateNoEndpoint() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();

    activity.onCreate( null );

    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testActivityCreateEndpointWithoutHost() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.END_POINT, "http://" );
    activity.setIntent( intent );

    activity.onCreate( null );

    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testActivityCreateAutoStartFalse() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.AUTO_START_SESSION, false );
    intent.putExtra( UiActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );

    activity.onCreate( null );

    Display display = ( Display )activity.findViewById( R.id.root_layout );
    assertFalse( display.isSessionRunning() );
  }

  @Test
  public void testActivityCreateAutoStartTrue() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.AUTO_START_SESSION, true );
    intent.putExtra( UiActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    activity.onCreate( null );
    activity.getProcessor().setWidgetToolkit( mock( IWidgetToolkit.class ) );
    Display displayLayout = ( Display )activity.findViewById( R.id.root_layout );
    displayLayout.onSizeChanged( 800, 480, 0, 0 );

    Display display = ( Display )activity.findViewById( R.id.root_layout );
    assertTrue( display.isSessionRunning() );
  }

  @Test
  public void testActivityCreateAutoStartDefault() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    activity.onCreate( null );
    activity.getProcessor().setWidgetToolkit( mock( IWidgetToolkit.class ) );
    Display displayLayout = ( Display )activity.findViewById( R.id.root_layout );
    displayLayout.onSizeChanged( 800, 480, 0, 0 );

    Display display = ( Display )activity.findViewById( R.id.root_layout );
    assertTrue( display.isSessionRunning() );
  }

  @Test
  public void testApplyThemeWithThemeZero() throws Exception {
    TabrisShadowActivity shadowActivity = createActivityWithThemeKey( 0 );

    assertEquals( shadowActivity.getThemeResourceId(), 0 );
  }

  @Test
  public void testApplyThemeWithThemeOne() throws Exception {
    TabrisShadowActivity shadowActivity = createActivityWithThemeKey( 1 );

    assertEquals( shadowActivity.getThemeResourceId(), R.style.Theme_Holo_Light_RAP );
  }

  @Test
  public void testApplyThemeWithThemeTwo() throws Exception {
    TabrisShadowActivity shadowActivity = createActivityWithThemeKey( 2 );

    assertEquals( shadowActivity.getThemeResourceId(), R.style.Theme_Holo_RAP );
  }

  private TabrisShadowActivity createActivityWithThemeKey( int themeKey ) {
    Robolectric.bindShadowClass( TabrisShadowActivity.class );
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.THEME, themeKey );
    intent.putExtra( UiActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    activity.onCreate( null );

    TabrisShadowActivity shadowActivity = ( TabrisShadowActivity )Robolectric.shadowOf( activity );
    return shadowActivity;
  }

  @Test
  public void testActivityCreateMalformedEndpoint() {
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.END_POINT, "malformed" );
    activity.setIntent( intent );

    activity.onCreate( null );

    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testActivityCreate() throws MalformedURLException {
    UiActivity activity = UiTestUtil.createUiActivity();

    ITransport transport = activity.getProcessor().getTransport();
    assertEquals( transport.getEndPoint(), new URL( "http://localhost" ) );
  }

  @Test
  public void testActivityHasFrameLayout() {
    UiActivity activity = UiTestUtil.createUiActivity();
    View layout = activity.findViewById( R.id.root_layout );
    assertTrue( layout instanceof FrameLayout );
  }

  @Test
  public void testActivityInitializesProcessor() {
    UiActivity activity = UiTestUtil.createUiActivity();

    ProtocolProcessor processor = activity.getProcessor();
    assertNotNull( processor.getWidgetToolkit() );
    assertNotNull( processor.getParser() );
    assertNotNull( processor.getTransport() );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testDestroy() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );
    activity.setProcessor( processor );

    activity.onDestroy();

    verify( processor ).shutdown();
  }

  @Test
  public void testOnKeyDownWithMiscKey() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowActivity.class );
    UiActivity activity = UiTestUtil.createUiActivity();
    Display display = ( Display )activity.findViewById( R.id.root_layout );

    assertEquals( 0, display.getChildCount() );

    boolean result = activity.onKeyDown( KeyEvent.KEYCODE_T, mock( KeyEvent.class ) );

    assertFalse( result );
    assertFalse( activity.isFinishing() );
    TabrisShadowActivity shadowActivity = ( TabrisShadowActivity )Robolectric.shadowOf( activity );
    assertEquals( shadowActivity.getLastKeyDownKeyCode(), KeyEvent.KEYCODE_T );
  }

  @Test
  public void testOnKeyDownWithBackKeyAndNoChildren() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();

    boolean result = activity.onKeyDown( KeyEvent.KEYCODE_BACK, mock( KeyEvent.class ) );

    assertTrue( result );
    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testOnKeyDownWithBackKeyAndOneChild() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();
    Display display = ( Display )activity.findViewById( R.id.root_layout );
    Shell shell = new Shell( activity, Mockito.mock( ShellAnimationSupport.class ) );
    shell.setTag( "w3" );
    display.addView( shell );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.SHELL_CLOSE, "w3" );

    boolean result = activity.onKeyDown( KeyEvent.KEYCODE_BACK, mock( KeyEvent.class ) );

    assertTrue( result );
    assertTrue( activity.isFinishing() );
  }

  @Test
  public void testOnKeyDownWithBackKeyAndMoreThanOneChild() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();
    Display display = ( Display )activity.findViewById( R.id.root_layout );
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    display.addView( new Shell( activity, animSupportMock ) );
    Shell shell = new Shell( activity, animSupportMock );
    shell.setTag( "w3" );
    display.addView( shell );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.SHELL_CLOSE, "w3" );

    boolean result = activity.onKeyDown( KeyEvent.KEYCODE_BACK, mock( KeyEvent.class ) );

    assertTrue( result );
    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testCreateUserAgent() throws Exception {
    UiActivity activity = new UiActivity();

    String userAgent = activity.createUserAgent();

    assertTrue( userAgent.contains( "com.eclipsesource.rap.mobile.client.android/" ) );
    assertTrue( userAgent.contains( "RAPmobile/" ) );
  }

  @Test
  public void testCloseActivityWithResult() throws Exception {
    UiActivity activitySpy = spy( new UiActivity() );
    String message = "abc";
    Throwable t = new Throwable( message );

    activitySpy.closeActivity( t );

    verify( activitySpy ).finish();
    Intent intent = new Intent();
    intent.putExtra( UiActivity.RESULT_MESSAGE, message );
    verify( activitySpy ).setResult( UiActivity.RESULT_CODE_ERROR, intent );
  }
}
