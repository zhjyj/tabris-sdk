/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.eclipsesource.tabris.android.core.InitialRequestHandler;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.transport.ITransport;

public class InitialRequestHandler_Test {

  private InitialRequestHandler handler;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    processor = mock( ProtocolProcessor.class );
    handler = new InitialRequestHandler( processor );
  }

  @Test(expected = IllegalStateException.class)
  public void testNoOperationsFound() {
    handler.operationsFound( new ArrayList<Operation>() );
  }

  @Test
  public void testNoProbeFound() {
    ArrayList<Operation> ops = new ArrayList<Operation>();
    ops.add( prepareInitOperation( true ) );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );

    handler.operationsFound( ops );

    verify( processor ).sendInitialPostRequest( null );
  }

  private CallOperation prepareInitOperation( boolean containsURL ) {
    CallOperation initOp = mock( CallOperation.class );
    when( initOp.getMethod() ).thenReturn( "init" );
    CallProperties props = mock( CallProperties.class );
    if( containsURL ) {
      when( props.containsKey( "url" ) ).thenReturn( true );
      when( props.get( eq( "url" ) ) ).thenReturn( "foo" );
    }
    when( initOp.getProperties() ).thenReturn( props );
    return initOp;
  }

  @Test(expected = IllegalStateException.class)
  public void testNoURLFound() {
    ArrayList<Operation> ops = new ArrayList<Operation>();
    ops.add( prepareInitOperation( false ) );

    handler.operationsFound( ops );
  }

  @Test
  public void testOperationsFoundOK() {
    ArrayList<Operation> ops = new ArrayList<Operation>();
    ops.add( prepareInitOperation( true ) );
    CallOperation probeOp = mock( CallOperation.class );
    when( probeOp.getMethod() ).thenReturn( "probe" );
    ops.add( probeOp );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );

    handler.operationsFound( ops );

    verify( processor ).sendInitialPostRequest( any( CallOperation.class ) );
  }
}
