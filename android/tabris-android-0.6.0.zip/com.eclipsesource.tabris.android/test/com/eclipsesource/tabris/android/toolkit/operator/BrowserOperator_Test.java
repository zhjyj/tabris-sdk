/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.BrowserOperator;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.BrowserWebViewClient;
import com.eclipsesource.tabris.android.toolkit.view.IBrowserProgressListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowWebView;

@RunWith(RobolectricTestRunner.class)
public class BrowserOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String VIEW_ID = "w3";

  private UiActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = new UiActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new BrowserOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateBrowserNoProps() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateBrowserNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateBrowserNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private Browser getCreatedValidatedView() {
    View view = parentLayout.findViewWithTag( VIEW_ID );
    assertTrue( view instanceof Browser );
    assertEquals( VIEW_ID, view.getTag() );
    return ( Browser )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    AbstractWidgetOperator operator = new BrowserOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Browser view = getCreatedValidatedView();
    verify( toolkit ).registerObjectById( VIEW_ID, view );
    assertTrue( view instanceof Browser );
    FrameLayout parent = ( FrameLayout )view.getParent();
    assertEquals( PARENT_ID, parent.getTag() );
  }

  @Test
  public void testGetType() throws Exception {
    BrowserOperator op = new BrowserOperator( new UiActivity() );
    assertEquals( BrowserOperator.TYPE, op.getType() );
  }

  @Test
  public void testAttachProgressListener() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    BrowserWebViewClient client = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( client );
    ListenOperation op = new ListenOperation();
    op.setTarget( VIEW_ID );
    ListenProperties props = new ListenProperties();
    props.setProgress( true );
    op.setProperties( props );

    operator.listen( op );

    verify( client ).setProgressListener( any( IBrowserProgressListener.class ) );
  }

  private Browser createAddedBrowserWidget() {
    Browser browser = new Browser( activity );
    browser.init();
    browser.setTag( VIEW_ID );
    when( toolkit.findObjectById( VIEW_ID, Browser.class ) ).thenReturn( browser );
    return browser;
  }

  @Test
  public void testRemoveProgressListener() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    BrowserWebViewClient client = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( client );
    ListenOperation op = new ListenOperation();
    op.setTarget( VIEW_ID );
    ListenProperties props = new ListenProperties();
    props.setProgress( false );
    op.setProperties( props );

    operator.listen( op );

    verify( client ).setProgressListener( null );
  }

  @Test
  public void testCallEvaluate() throws Exception {
    BrowserOperator operator = new BrowserOperator( activity );
    Browser browser = createAddedBrowserWidget();
    CallOperation op = new CallOperation();
    op.setMethod( "evaluate" );
    op.setTarget( VIEW_ID );
    CallProperties props = new CallProperties();
    props.put( "script", "someScript" );
    op.setProperties( props );

    operator.call( op );

    ShadowWebView shadowBrowser = Robolectric.shadowOf( browser );
    assertTrue( shadowBrowser.getLastLoadedUrl().contains( "someScript" ) );
  }
}
