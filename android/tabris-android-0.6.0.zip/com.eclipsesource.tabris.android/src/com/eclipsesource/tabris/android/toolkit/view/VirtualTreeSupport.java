/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class VirtualTreeSupport implements OnScrollListener {

  private final UiActivity activity;
  private int curTopItem;
  private int lastRequestIndex;

  public VirtualTreeSupport( UiActivity activity ) {
    if( activity == null ) {
      throw new IllegalArgumentException( "The activity can not be null" );
    }
    this.activity = activity;
    reset();
  }

  public void onScrollStateChanged( AbsListView view, int scrollState ) {
    // nothing to do here
  }

  public void onScroll( AbsListView view,
                        int firstVisibleItem,
                        int visibleItemCount,
                        int totalItemCount )
  {
    if( !itemAlreadyConsidered( curTopItem, firstVisibleItem )
        || firstVisibleItem + visibleItemCount > lastRequestIndex )
    {
      curTopItem = firstVisibleItem;
      ViewParent parent = view.getParent();
      if( parent instanceof TreeView ) {
        TreeView treeView = ( TreeView )parent;
        TreeItemView parentTreeItem = treeView.getParentTreeItem();
        int itemCount = parentTreeItem.getItemCount();
        if( itemCount == 0 ) {
          reset();
          return;
        }
        int posInParentChain = getPosInParentChain( treeView, parentTreeItem );
        int requestIndex = firstVisibleItem + visibleItemCount + posInParentChain;
        if( !allTreeItemsLoaded( treeView, itemCount )
            && !loadedToHeadPosition( visibleItemCount, totalItemCount, posInParentChain )
            && !itemAlreadyLoaded( treeView, requestIndex + visibleItemCount )
            && sufficientGapToLastRequest( lastRequestIndex, visibleItemCount, requestIndex ) )
        {
          lastRequestIndex = requestIndex;
          sendTopItemRequest( treeView, lastRequestIndex );
        }
      }
    }
  }

  private boolean loadedToHeadPosition( int visibleItemCount,
                                        int totalItemCount,
                                        int posInParentChain )
  {
    return lastRequestIndex + visibleItemCount > totalItemCount + posInParentChain;
  }

  private static boolean itemAlreadyLoaded( TreeView treeView, int index ) {
    return index < treeView.getCurrentTreeItems().size();
  }

  static int getPosInParentChain( TreeView treeView, TreeItemView treeItem ) {
    if( treeItem == treeView.getRootTreeItem() ) {
      return 0;
    }
    return calculatePositionInParent( treeView, treeItem );
  }

  private static int calculatePositionInParent( TreeView treeView, TreeItemView treeItem ) {
    TreeItemView parent = treeItem.getTreeItemParent();
    if( parent == null ) {
      throw new IllegalArgumentException( "Tree item is not attached to tree view " + treeView );
    }
    int itemPos = parent.getChildren().indexOf( treeItem );
    if( parent == treeView.getRootTreeItem() ) {
      return itemPos;
    } else {
      return getPosInParentChain( treeView, parent ) + itemPos + 1;
    }
  }

  private static boolean sufficientGapToLastRequest( int lastRequestIndex,
                                                     int visibleItemCount,
                                                     int requestIndex )
  {
    return requestIndex > lastRequestIndex + visibleItemCount / 2;
  }

  private static boolean allTreeItemsLoaded( TreeView treeView, int itemCount ) {
    return treeView.getCurrentTreeItems().size() > itemCount;
  }

  private static boolean itemAlreadyConsidered( int curTopItem, int firstVisibleItem ) {
    return curTopItem == firstVisibleItem;
  }

  private void sendTopItemRequest( TreeView treeView, int topItemIndex ) {
    PostRequest request = createRequest( treeView, topItemIndex );
    activity.getProcessor().processPostRequest( request );
  }

  private static PostRequest createRequest( TreeView treeView, int topItemIndex ) {
    PostRequest request = new PostRequest();
    request.addParam( treeView.getTag() + IProtocolConstants.SCROLL_TOP_ITEM_INDEX,
                      String.valueOf( topItemIndex ) );
    return request;
  }

  public void reset() {
    curTopItem = -1;
    lastRequestIndex = 0;
  }

  public PostRequest createTopItemRequest( TreeView treeView, TreeItemView currentItem ) {
    return createRequest( treeView, getPosInParentChain( treeView, currentItem ) );
  }

}
