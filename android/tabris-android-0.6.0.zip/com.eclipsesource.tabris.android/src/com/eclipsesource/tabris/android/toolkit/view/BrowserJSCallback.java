/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.util.StringUtil;

public class BrowserJSCallback {

  public static final String CALLBACK_NAME = "androidCallback";

  private final UiActivity activity;
  private final String widgetId;

  public BrowserJSCallback( UiActivity activity, String widgetId ) {
    this.activity = activity;
    this.widgetId = widgetId;
  }

  public void setResult( String result ) {
    PostRequest request = new PostRequest();
    request.addParam( widgetId + IProtocolConstants.EXECUTE_RESULT_POSTFIX, StringUtil.TRUE );
    request.addParam( widgetId + IProtocolConstants.EVALUATE_RESULT_POSTFIX,
                      StringUtil.SQUARE_BRACKET_OPEN + result + StringUtil.SQUARE_BRACKET_CLOSE );
    activity.getProcessor().processPostRequest( request );
  }
}