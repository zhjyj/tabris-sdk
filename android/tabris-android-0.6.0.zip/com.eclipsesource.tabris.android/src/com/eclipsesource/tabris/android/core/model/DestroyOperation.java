/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class DestroyOperation extends Operation {

  public static final String ACTION = "destroy";

}
