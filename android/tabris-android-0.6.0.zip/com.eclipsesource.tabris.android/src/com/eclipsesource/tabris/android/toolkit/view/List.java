/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.widget.ListView;

public class List extends ListView {

  public List( Context context ) {
    super( context );
  }

}
