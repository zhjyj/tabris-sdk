/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class KeyboardClosingFocusListener implements OnFocusChangeListener {

  private Activity activity;
  private EditText editText;

  public KeyboardClosingFocusListener( Activity activity, EditText editText ) {
    this.activity = activity;
    this.editText = editText;
  }

  public void onFocusChange( View v, boolean hasFocus ) {
    if( hasFocus == false ) {
      InputMethodManager imm = ( InputMethodManager )activity.getSystemService( Context.INPUT_METHOD_SERVICE );
      imm.hideSoftInputFromWindow( editText.getWindowToken(), 0 );
    }
  }

}
