/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;

public class ToolItemSetter<T extends ToolItem> extends TextViewSetter<T> {

  static final int ICON_PADDING = 5;

  @Override
  protected void setBounds( View view, SetProperties properties ) {
    // the toolitem bounds are controlled by the parent toolbar
  }

  @Override
  protected int getDefaultVerticalAlignment() {
    return Gravity.CENTER_VERTICAL;
  }

  @Override
  protected void setCustomVariant( T view, SetProperties properties ) {
    String prevCustomVariant = ( String )view.getTag( R.id.custom_variant );
    super.setCustomVariant( view, properties );
    String newCustomVariant = ( String )view.getTag( R.id.custom_variant );
    if( ICustomVariants.TITLE.equals( prevCustomVariant )
        && !ICustomVariants.TITLE.equals( newCustomVariant )
        || ICustomVariants.TITLE.equals( newCustomVariant )
        && !ICustomVariants.TITLE.equals( prevCustomVariant ) )
    {
      repositionViewOnParent( view );
    }
  }

  private void repositionViewOnParent( T view ) {
    ViewGroup parent = ( ViewGroup )view.getParent();
    if( parent != null ) {
      // using index based deletion to facilitate robolectric
      parent.removeViewAt( parent.indexOfChild( view ) );
      view.getParentToolBar().addView( view );
    }
  }

  @Override
  protected void setText( TextView textView, SetProperties properties ) {
    super.setText( textView, properties );
    updateCompoundDrawablePadding( textView );
  }

  @Override
  public BitmapDrawable getBitmapDrawable( TextView textView ) {
    return ( BitmapDrawable )textView.getCompoundDrawables()[ 0 ];
  }

  @Override
  protected void setBitmapDrawable( TextView textView, BitmapDrawable drawable ) {
    textView.setCompoundDrawablesWithIntrinsicBounds( drawable, null, null, null );
    updateCompoundDrawablePadding( textView );
  }

  private void updateCompoundDrawablePadding( TextView textView ) {
    CharSequence text = textView.getText();
    if( text != null && text.length() > 0 && textView.getCompoundDrawables()[ 0 ] != null ) {
      IWidgetToolkit widgetToolkit = getActivity().getProcessor().getWidgetToolkit();
      textView.setCompoundDrawablePadding( widgetToolkit.multiplyByDensityFactor( ICON_PADDING ) );
    } else {
      textView.setCompoundDrawablePadding( 0 );
    }
  }
}
