/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class DialogHeader {

  private final TextView titleView;
  private final View header;
  private final ImageView iconView;

  public DialogHeader( Context context ) {
    LayoutInflater inflater = ( LayoutInflater )context.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
    header = inflater.inflate( R.layout.dialog_header_holo, null );
    titleView = ( TextView )header.findViewById( R.id.alertTitle );
    iconView = ( ImageView )header.findViewById( R.id.icon );
    iconView.setImageResource( ThemeUtil.getAttrResId( context, R.attr.alertDialogIcon ) );
  }

  public View getHeader() {
    return header;
  }

  public CharSequence getTitleText() {
    return titleView.getText();
  }

  public void setTitleText( String text ) {
    titleView.setText( text );
  }

  public ImageView getIcon() {
    return iconView;
  }

  public void setIcon( Drawable icon ) {
    iconView.setImageDrawable( icon );
    iconView.setVisibility( View.VISIBLE );
  }
}
