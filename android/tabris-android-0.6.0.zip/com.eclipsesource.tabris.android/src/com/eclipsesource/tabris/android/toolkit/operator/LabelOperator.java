/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.setter.TextViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class LabelOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Label";
  private final TextViewSetter<TextView> textViewSetter;

  public LabelOperator( UiActivity activity ) {
    super( activity );
    textViewSetter = new TextViewSetter<TextView>();
  }

  public void create( CreateOperation operation ) {
    TextView textView = new TextView( getActivity() );
    textView.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.LABEL_TEXT_SIZE );
    textView.setIncludeFontPadding( false );
    initiateNewView( operation, textView );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null || !( view instanceof TextView ) ) {
      throw new IllegalArgumentException( "Could not find TextView "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    BitmapDrawableCache cache = getProcessor().getWidgetToolkit().getBitmapCache();
    cache.decreaseReferenceCount( textViewSetter.getBitmapDrawable( ( TextView )view ) );
    super.destroy( operation );
  }
}
