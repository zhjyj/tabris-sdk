/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.util;

public class StringUtil {

  public static final String UTF_8 = "UTF-8";
  public static final String EMPTY_STRING = "";
  public static final String DOT_DOT_DOT = "...";
  public static final String SLASH_DOT_DOT_SLASH = "/../";
  public static final String SLASH = "/";
  public static final String SQUARE_BRACKET_CLOSE = "]";
  public static final String SQUARE_BRACKET_OPEN = "[";
  public static final String SEMICOLON = ";";
  public static final String COMMA = ",";
  public static final String TRUE = "true";

}
