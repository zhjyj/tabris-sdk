/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ExpansionTreeItemClickListener implements OnItemClickListener {

  private final UiActivity activity;

  public ExpansionTreeItemClickListener( UiActivity activity ) {
    this.activity = activity;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = new PostRequest();
    if( parent.getParent() instanceof TreeView ) {
      TreeView treeView = ( TreeView )parent.getParent();
      ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
      if( currentTreeItems.size() > position ) {
        TreeItemView selectedItem = currentTreeItems.get( position );
        if( selectedItem.hasChildren() ) {
          request.addParam( IProtocolConstants.EVENT_TREE_EXPANDED, ( String )selectedItem.getTag() );
          addVirtualTreeParameter( request, treeView, selectedItem );
          processor.processPostRequest( request );
        }
      }
    }
  }

  private void addVirtualTreeParameter( PostRequest request,
                                        TreeView treeView,
                                        TreeItemView selectedItem )
  {
    if( treeView.hasVirtualTreeSupport() ) {
      VirtualTreeSupport virtualTreeSupport = treeView.getVirtualTreeSupport();
      virtualTreeSupport.reset();
      PostRequest topItemRequest = virtualTreeSupport.createTopItemRequest( treeView, selectedItem );
      request.mergeInto( topItemRequest );
    }
  }

}