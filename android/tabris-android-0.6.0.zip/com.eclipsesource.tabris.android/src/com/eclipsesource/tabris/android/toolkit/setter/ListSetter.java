/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.List;

public class ListSetter<T extends List> extends ViewSetter<List> {

  @Override
  public void execute( UiActivity activity, List list, SetProperties properties ) {
    super.execute( activity, list, properties );
  }

}
