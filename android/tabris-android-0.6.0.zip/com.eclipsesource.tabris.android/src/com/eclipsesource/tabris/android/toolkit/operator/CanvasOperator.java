/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;

public class CanvasOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Canvas";

  public CanvasOperator( UiActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Canvas canvas = new Canvas( getActivity() );
    initiateNewView( operation, canvas );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    Canvas canvas = findObjectById( operation.getTarget(), Canvas.class );
    canvas.destroyBitmap();
    super.destroy( operation );
  }

}
