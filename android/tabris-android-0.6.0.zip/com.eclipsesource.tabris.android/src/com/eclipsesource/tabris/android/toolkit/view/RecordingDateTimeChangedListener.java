/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.DateTimeState;

public class RecordingDateTimeChangedListener implements IDateTimeChangedListener {

  private final StateRecorder stateRecorder;
  private final HashMap<Integer, String> dateValues;

  public RecordingDateTimeChangedListener( StateRecorder stateRecorder,
                                           HashMap<Integer, String> dateValues )
  {
    if( stateRecorder == null ) {
      throw new IllegalArgumentException( "The stateRecorder can not be null" );
    }
    if( dateValues == null ) {
      throw new IllegalArgumentException( "The dateValues can not be null" );
    }
    this.stateRecorder = stateRecorder;
    this.dateValues = dateValues;
  }

  public void dateTimeChanged( DateTimeSpinner spinner ) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime( spinner.getDate() );
    createStates( ( String )spinner.getTag(), calendar );
  }

  private void createStates( String tag, Calendar calendar ) {
    Set<Entry<Integer, String>> entrySet = dateValues.entrySet();
    for( Entry<Integer, String> entry : entrySet ) {
      int calendarField = entry.getKey();
      String protocolField = dateValues.get( calendarField );
      IState state = new DateTimeState( tag, protocolField, calendar.get( calendarField ) );
      stateRecorder.recordState( state );
    }
  }

  /** To be used for testing only. */
  public HashMap<Integer, String> getDateValues() {
    return dateValues;
  }
}
