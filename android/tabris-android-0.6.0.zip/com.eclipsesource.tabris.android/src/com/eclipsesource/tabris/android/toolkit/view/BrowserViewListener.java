/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;
import android.view.View;

public final class BrowserViewListener implements View.OnTouchListener {

  public boolean onTouch( View v, MotionEvent event ) {
    switch( event.getAction() ) {
      case MotionEvent.ACTION_DOWN:
      case MotionEvent.ACTION_UP:
        if( !v.hasFocus() ) {
          v.requestFocus();
        }
      break;
    }
    return false;
  }
}
