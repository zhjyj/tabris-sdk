/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.view.View;
import android.widget.EditText;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;

public class EditTextSetter<T extends EditText> extends TextViewSetter<EditText> {

  public void execute( UiActivity activity, EditText editText, SetProperties properties ) {
    super.execute( activity, editText, properties );
    setEditable( editText, properties );
  }

  @Override
  protected void setEnabled( View view, SetProperties properties ) {
    Boolean enabled = properties.getEnabled();
    if( enabled != null ) {
      view.setEnabled( enabled );
      setEditable( view, enabled );
    }
  }

  protected void setEditable( EditText editText, SetProperties properties ) {
    Boolean editable = properties.getEditable();
    if( editable != null ) {
      setEditable( editText, editable );
    }
  }

  private void setEditable( View view, boolean editable ) {
    EditText editText = ( ( EditText )view );
    editText.setFocusable( editable );
    editText.setFocusableInTouchMode( editable );
  }

  @Override
  @SuppressWarnings("unchecked")
  protected void setSelection( View view, SetProperties properties ) {
    GenericObject selectionProperty = properties.getSelection();
    if( selectionProperty != null ) {
      List<Number> selection = selectionProperty.getObjectAs( List.class );
      ( ( EditText )view ).setSelection( selection.get( 0 ).intValue(), selection.get( 1 )
        .intValue() );
    }
  }
}
