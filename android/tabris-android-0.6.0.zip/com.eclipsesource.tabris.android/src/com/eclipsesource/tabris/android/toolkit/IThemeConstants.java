/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

public interface IThemeConstants {

  public static final float LABEL_TEXT_SIZE = 16;
  public static final float BUTTON_RADIO_TEXT_SIZE = LABEL_TEXT_SIZE;
  public static final float BUTTON_CHECK_TEXT_SIZE = LABEL_TEXT_SIZE;
  public static final float BUTTON_TEXT_SIZE = 16;
  public static final float TEXT_TEXT_SIZE = LABEL_TEXT_SIZE;
  public static final int DIALOG_SHADOW_SIZE = 8;
  public static final float GROUP_TITLE_TEXT_SIZE = 16;

}
