/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static android.view.ViewGroup.LayoutParams.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.app.Service;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.util.SetAlphaBeforeStartAnimListener;

public class TreeView extends LinearLayout {

  private final UiActivity activity;
  private TextView treeHeaderLabel;
  private ListView listView;
  private TreeItemView rootTreeItem;
  private TreeItemView parentTreeItem;
  private VirtualTreeSupport virtualTreeSupport;
  private ImageView navigateUpImage;
  private Animation fadeOut;
  private Animation fadeIn;

  public TreeView( UiActivity activity ) {
    super( activity );
    this.activity = activity;
    setOrientation( LinearLayout.VERTICAL );
    createHeaderBar();
    createListView();
    createRootTreeItem();
    loadAnimations();
  }

  private void loadAnimations() {
    fadeOut = AnimationUtils.loadAnimation( activity, android.R.anim.fade_out );
    fadeOut.setFillAfter( true );
    fadeIn = AnimationUtils.loadAnimation( activity, android.R.anim.fade_in );
    fadeIn.setFillAfter( true );
    // we need to set the alpha because the alpha is initially 0 and
    // the animation does not physically alter the alpha on which the
    // animation is based
    fadeIn.setAnimationListener( new SetAlphaBeforeStartAnimListener( navigateUpImage, 255, true ) );
  }

  private void createListView() {
    listView = new ListView( activity );
    addView( listView, MATCH_PARENT, MATCH_PARENT );
  }

  private void createHeaderBar() {
    LayoutInflater inflater = ( LayoutInflater )activity.getSystemService( Service.LAYOUT_INFLATER_SERVICE );
    View treeHeader = inflater.inflate( R.layout.tree_header, null );
    treeHeaderLabel = ( TextView )treeHeader.findViewById( R.id.tree_header_label );
    setupUpButton( treeHeader );
    addView( treeHeader, MATCH_PARENT, WRAP_CONTENT );
  }

  private void createRootTreeItem() {
    rootTreeItem = new TreeItemView( activity );
    rootTreeItem.setTexts( Arrays.asList( StringUtil.EMPTY_STRING ) );
    rootTreeItem.setTreeView( this );
    parentTreeItem = rootTreeItem;
  }

  private void setupUpButton( View treeHeader ) {
    navigateUpImage = ( ImageView )treeHeader.findViewById( R.id.tree_header_up_image );
    navigateUpImage.setOnClickListener( new ContractionTreeClickListener( activity, this ) );
    navigateUpImage.setAlpha( 0 );
  }

  @Override
  public void addView( View view ) {
    rootTreeItem.addView( view );
  }

  public void refreshTree() {
    final TreeViewAdapter treeAdapter = ( TreeViewAdapter )listView.getAdapter();
    if( treeAdapter != null ) {
      treeAdapter.notifyDataSetChanged();
    }
  }

  /**
   * Gets the currently shown tree items.
   * 
   * @return the {@link TreeItemView}s currently shown
   * @see #getParentTreeItem()
   */
  public ArrayList<TreeItemView> getCurrentTreeItems() {
    return parentTreeItem.getChildren();
  }

  @Override
  public void removeViewAt( int index ) {
    parentTreeItem.removeViewAt( index );
  }

  @Override
  public int indexOfChild( View child ) {
    return parentTreeItem.indexOfChild( child );
  }

  /**
   * Technically this method overrides the findViewWithTagTraversal(Object tag)
   * in View.class. The parent class "[at]hides" the protected method though. If
   * the underlying implementation changes this might break.
   * 
   * @param tag the tag to search for
   * @return the found view or <code>null</code> if no view could be found
   */
  // @Override
  protected View findViewWithTagTraversal( Object tag ) {
    if( tag == null ) {
      throw new IllegalArgumentException( "Can not searh for null tag in "
                                          + TreeView.class.getSimpleName() );
    } else if( getTag().equals( tag ) ) {
      return this;
    }
    return rootTreeItem.findViewWithTagTraversal( tag );
  }

  public void setParentTreeItem( TreeItemView curItem ) {
    this.parentTreeItem = curItem;
    List<String> texts = curItem.getTexts();
    if( texts != null && texts.size() > 0 ) {
      treeHeaderLabel.setText( texts.get( 0 ) );
    }
    updateUpButton();
  }

  private void updateUpButton() {
    if( parentTreeItem == rootTreeItem ) {
      navigateUpImage.startAnimation( fadeOut );
    } else if( navigateUpImage.getAnimation() != fadeIn ) {
      navigateUpImage.startAnimation( fadeIn );
    }
  }

  public TreeItemView getRootTreeItem() {
    return rootTreeItem;
  }

  public void setToolTip( String toolTip ) {
    rootTreeItem.setTexts( Arrays.asList( toolTip ) );
    if( rootTreeItem == parentTreeItem ) {
      treeHeaderLabel.setText( toolTip );
    }
  }

  public void setAdapter( TreeViewAdapter adapter ) {
    listView.setAdapter( adapter );
  }

  public TreeViewAdapter getAdapter() {
    return ( TreeViewAdapter )listView.getAdapter();
  }

  public void setOnItemClickListener( OnItemClickListener listener ) {
    listView.setOnItemClickListener( listener );

  }

  public OnItemClickListener getOnItemClickListener() {
    return listView.getOnItemClickListener();
  }

  /**
   * Gets the {@link TreeItemView} that contains the currently shown items as
   * children.
   * 
   * @return the parent of the currently show items
   */
  public TreeItemView getParentTreeItem() {
    return parentTreeItem;
  }

  /** To be used for testing only. */
  ListView getListView() {
    return listView;
  }

  /** To be used for testing only. */
  void setListView( ListView listView ) {
    this.listView = listView;
  }

  public void setVirtualTreeSupport( VirtualTreeSupport virtualTreeSupport ) {
    this.virtualTreeSupport = virtualTreeSupport;
    listView.setOnScrollListener( virtualTreeSupport );
  }

  public VirtualTreeSupport getVirtualTreeSupport() {
    return virtualTreeSupport;
  }

  public boolean hasVirtualTreeSupport() {
    return virtualTreeSupport != null;
  }

  public void scrollTo( TreeItemView item ) {
    int itemIndex = parentTreeItem.getChildren().indexOf( item );
    if( itemIndex == -1 ) {
      throw new IllegalArgumentException( "Could not find the item to scroll to. Got: " + item );
    }
    listView.setSelection( itemIndex );
  }

}
