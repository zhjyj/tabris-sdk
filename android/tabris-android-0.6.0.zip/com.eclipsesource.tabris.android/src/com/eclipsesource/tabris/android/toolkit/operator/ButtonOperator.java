/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.ToggleButton;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.PropertiesOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.CompoundButtonClickListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingCheckedChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;

public class ButtonOperator extends LabelOperator {

  public static final String TYPE = "rwt.widgets.Button";

  public static final String STYLE_PUSH = "PUSH";
  public static final String STYLE_TOGGLE = "TOGGLE";
  public static final String STYLE_RADIO = "RADIO";
  public static final String STYLE_CHECK = "CHECK";

  public ButtonOperator( UiActivity activity ) {
    super( activity );
  }

  @Override
  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List<String> styles = operation.getProperties().getStyle();
    if( styles == null || styles.isEmpty() || styles.contains( STYLE_PUSH ) ) {
      createButton( operation );
    } else if( styles.contains( STYLE_TOGGLE ) ) {
      createToggleButton( operation );
    } else if( styles.contains( STYLE_CHECK ) ) {
      createCheckBox( operation );
    } else if( styles.contains( STYLE_RADIO ) ) {
      createRadioButton( operation );
    }
    adjustOpacity();
  }

  private void adjustOpacity() {

  }

  private void createToggleButton( CreateOperation operation ) {
    ToggleButton button = new ToggleButton( getActivity() );
    setButtonProperties( button );
    setCheckedChangedListener( button, operation.getTarget() );
    initiateNewView( operation, button );
    setTextOnToggleButton( operation );
  }

  private void createButton( CreateOperation operation ) {
    Button button = new Button( getActivity() );
    setButtonProperties( button );
    initiateNewView( operation, button );
  }

  private void createRadioButton( CreateOperation operation ) {
    RadioButton button = new RadioButton( getActivity() );
    button.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.BUTTON_RADIO_TEXT_SIZE );
    setCheckedChangedListener( button, operation.getTarget() );
    initiateNewView( operation, button );
  }

  private void createCheckBox( CreateOperation operation ) {
    CheckBox button = new CheckBox( getActivity() );
    button.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.BUTTON_CHECK_TEXT_SIZE );
    setCheckedChangedListener( button, operation.getTarget() );
    initiateNewView( operation, button );
  }

  private void setCheckedChangedListener( CompoundButton button, String widgetId ) {
    ListenerRegistry listenerRegistry = getProcessor().getWidgetToolkit().getListenerRegistry();
    CompositeCheckedChangedListener listener = new CompositeCheckedChangedListener();
    listener.addListener( new RecordingCheckedChangedListener( getProcessor().getStateRecorder() ) );
    button.setOnCheckedChangeListener( listener );
    listenerRegistry.registerListener( widgetId, listener );
  }

  private void setButtonProperties( Button button ) {
    button.setTextSize( IThemeConstants.BUTTON_TEXT_SIZE );
  }

  @Override
  public String getType() {
    return TYPE;
  }

  @Override
  public void set( SetOperation operation ) {
    super.set( operation );
    setTextOnToggleButton( operation );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    if( view instanceof CompoundButton ) {
      view.setOnClickListener( new CompoundButtonClickListener( getActivity() ) );
    } else {
      view.setOnClickListener( new ViewClickListener( getActivity() ) );
    }
  }

  private void setTextOnToggleButton( PropertiesOperation<? extends SetProperties> operation ) {
    SetProperties properties = operation.getProperties();
    if( properties != null ) {
      String text = properties.getText();
      final View view = findViewByTarget( operation );
      if( text != null && view instanceof ToggleButton ) {
        ToggleButton toggleButton = ( ToggleButton )view;
        toggleButton.setTextOn( text );
        toggleButton.setTextOff( text );
      }
    }
  }

}
