/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class TextSelectionLengthState extends AbstractState {

  private final int selectionLength;

  public TextSelectionLengthState( String widgetID, int selectionLength ) {
    super( widgetID );
    this.selectionLength = selectionLength;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTION_LENGTH_POSTFIX;
  }

  @Override
  public String generateValue() {
    return Integer.toString( selectionLength );
  }

}
