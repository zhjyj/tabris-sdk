/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.transport.ITransportRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

final class PostRequestRunnable implements Runnable {

  private final PostRequest request;
  private final ProtocolProcessor processor;

  public PostRequestRunnable( PostRequest request, ProtocolProcessor processor ) {
    this.request = request;
    this.processor = processor;
  }

  public void run() {
    if( processor.getCurMeta() != null ) {
      appendMetadata( request );
    }
    ITransportResult transportResult = processor.getTransport().post( request );
    if( !transportResult.hasParsableContent() ) {
      processor.getWidgetToolkit().showError( transportResult.getException() );
    } else {
      try {
        processor.getParser().parse( transportResult.getResult() );
      } catch( Exception e ) {
        processor.getWidgetToolkit().showError( e );
      }
    }
  }

  private void appendMetadata( PostRequest request ) {
    request.addParam( Meta.REQUEST_COUNTER,
                      String.valueOf( processor.getCurMeta().getRequestCounter() ) );
    request.addParam( ITransportRequest.PARAM_UI_ROOT, ITransportRequest.PARAM_UI_ROOT_VALUE );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( processor == null )
                                                     ? 0
                                                     : processor.hashCode() );
    result = prime * result + ( ( request == null )
                                                   ? 0
                                                   : request.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    PostRequestRunnable other = ( PostRequestRunnable )obj;
    if( processor == null ) {
      if( other.processor != null ) {
        return false;
      }
    } else if( !processor.equals( other.processor ) ) {
      return false;
    }
    if( request == null ) {
      if( other.request != null ) {
        return false;
      }
    } else if( !request.equals( other.request ) ) {
      return false;
    }
    return true;
  }

}