/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;

public class ValidationUtil {

  public static void validateOperation( Operation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "The Operation can not be null" );
    }
    if( operation.getTarget() == null || operation.getTarget().trim().length() == 0 ) {
      throw new IllegalArgumentException( operation.getClass().getSimpleName()
                                          + " has to have a target widget" );
    }
  }

  public static void validateCreateOperation( UiActivity activity, CreateOperation op ) {
    validateOperation( op );
    CreateProperties properties = op.getProperties();
    if( properties == null ) {
      throw new IllegalArgumentException( "The following CreateOperation does not have CreateProperties: "
                                          + op );
    }
    String parent = properties.getParent();
    if( parent == null || parent.length() == 0 ) {
      throw new IllegalArgumentException( "A CreateOperation needs to have its parent property set: "
                                          + op );
    }
    validateCreateProperties( op, activity );
  }

  private static void validateCreateProperties( CreateOperation op, UiActivity activity ) {
    CreateProperties props = op.getProperties();
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    View view = widgetToolkit.findObjectById( props.getParent(), View.class );
    if( view == null ) {
      throw new IllegalStateException( "The parent view \""
                                       + props.getParent()
                                       + "\" could not be found for "
                                       + op );
    }
    if( !( view instanceof ViewGroup ) ) {
      throw new IllegalStateException( "Parent \""
                                       + props.getParent()
                                       + "\" of a "
                                       + op
                                       + " is not of type "
                                       + ViewGroup.class.getName()
                                       + ". Instead it is of type: "
                                       + view.getClass().getName() );
    }
  }

  public static void validateSetOperation( SetOperation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "Can not execute a null SetOperation" );
    }
    if( operation.getTarget() == null || operation.getTarget().trim().length() == 0 ) {
      throw new IllegalArgumentException( "Can not execute SetOperation "
                                          + operation
                                          + "without a target" );
    }
    if( operation.getProperties() == null ) {
      throw new IllegalArgumentException( "There are no SetProperties set on " + operation );
    }
  }

  public static void validateListenOperation( ListenOperation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "Can not execute a null ListenOperation" );
    }
    if( operation.getTarget() == null || operation.getTarget().trim().length() == 0 ) {
      throw new IllegalArgumentException( "Can not execute ListenOperation "
                                          + operation
                                          + "without a target" );
    }
    if( operation.getProperties() == null ) {
      throw new IllegalArgumentException( "No ListenerProperties found on " + operation );
    }
  }

  public static void validateCallOperation( CallOperation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "Can not execute a null CallOperation" );
    }
    if( operation.getTarget() == null || operation.getTarget().trim().length() == 0 ) {
      throw new IllegalArgumentException( "Can not execute CallOperation "
                                          + operation
                                          + " without a target" );
    }
    if( operation.getProperties() == null ) {
      throw new IllegalArgumentException( "No properties found on CallOperation " + operation );
    }
  }

  public static void validateDestroyOperation( DestroyOperation operation ) {
    if( operation == null ) {
      throw new IllegalArgumentException( "Can not execute null DestroyOperation" );
    }
    if( operation.getTarget() == null || operation.getTarget().trim().length() == 0 ) {
      throw new IllegalArgumentException( "Can not execute DestroyOperation "
                                          + operation
                                          + "without a target" );
    }
  }

  public static void checkNullArg( Object target, Object arg, Class<?> argClass ) {
    if( arg == null ) {
      throw new IllegalArgumentException( "The "
                                          + argClass.getSimpleName()
                                          + " passed to the "
                                          + target.getClass().getSimpleName()
                                          + " can not be null" );
    }

  }
}
