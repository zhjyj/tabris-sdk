/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

class ContractionTreeClickListener implements OnClickListener {

  private final UiActivity activity;
  private final TreeView treeView;

  public ContractionTreeClickListener( UiActivity activity, TreeView treeView ) {
    this.activity = activity;
    this.treeView = treeView;
  }

  public void onClick( View v ) {
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_TREE_COLLAPSED,
                      ( String )treeView.getParentTreeItem().getTag() );
    addVirtualTreeParameter( request, treeView, treeView.getParentTreeItem() );
    ProtocolProcessor processor = activity.getProcessor();
    processor.processPostRequest( request );
  }

  private void addVirtualTreeParameter( PostRequest request,
                                        TreeView treeView,
                                        TreeItemView selectedItem )
  {
    if( treeView.hasVirtualTreeSupport() ) {
      VirtualTreeSupport virtualTreeSupport = treeView.getVirtualTreeSupport();
      virtualTreeSupport.reset();
      PostRequest topItemRequest = virtualTreeSupport.createTopItemRequest( treeView, selectedItem );
      request.mergeInto( topItemRequest );
    }
  }
};