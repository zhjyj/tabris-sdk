/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class ScrollYState extends AbstractState {

  private int scrollY;

  public ScrollYState( String widgetID ) {
    super( widgetID );
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SCROLL_Y_POSTFIX;
  }

  @Override
  public String generateValue() {
    return String.valueOf( scrollY );
  }

  public void setScrollY( int scrollY ) {
    this.scrollY = scrollY;
  }

  public void setWidgetId( String widgetId ) {
    if( widgetId == null ) {
      throw new IllegalArgumentException( "The widgetId can not be set to null" );
    }
    super.widgetId = widgetId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + scrollY;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    ScrollYState other = ( ScrollYState )obj;
    if( scrollY != other.scrollY ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "ScrollYState [scrollY=" + scrollY + ", " + ( widgetId != null
                                                                         ? "widgetId=" + widgetId
                                                                         : "" ) + "]";
  }

}
