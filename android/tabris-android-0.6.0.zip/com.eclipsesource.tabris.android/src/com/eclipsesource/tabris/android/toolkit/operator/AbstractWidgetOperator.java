/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateFocusChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.LongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;

public abstract class AbstractWidgetOperator implements IOperator {

  private final UiActivity activity;
  protected SetterManager setterManager;

  public AbstractWidgetOperator( UiActivity activity ) {
    this.activity = activity;
    setterManager = new SetterManager();
  }

  public UiActivity getActivity() {
    return activity;
  }

  protected ProtocolProcessor getProcessor() {
    return activity.getProcessor();
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    View view = findViewByTarget( operation );
    setterManager.execute( activity, view, operation.getProperties() );
  }

  protected void initiateNewView( CreateOperation operation, View view ) {
    setInitialLayoutParams( view );
    view.setTag( operation.getTarget() );
    getParentView( operation ).addView( view );
    getProcessor().getWidgetToolkit().registerObjectById( operation.getTarget(), view );
    applyProperties( operation, view );
  }

  protected void applyProperties( CreateOperation operation, View view ) {
    if( operation.getProperties() != null ) {
      setterManager.execute( activity, view, operation.getProperties() );
    }
  }

  private ViewGroup getParentView( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( activity, operation );
    CreateProperties props = operation.getProperties();
    return findObjectById( props.getParent(), ViewGroup.class );
  }

  protected <T> T findObjectById( String id, Class<? extends T> clazz ) {
    return getProcessor().getWidgetToolkit().findObjectById( id, clazz );
  }

  protected void setInitialLayoutParams( View view ) {
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams( 0, 0 );
    layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
    view.setLayoutParams( layoutParams );
  }

  public void listen( ListenOperation operation ) {
    ValidationUtil.validateListenOperation( operation );
    ListenProperties properties = operation.getProperties();
    if( properties.getSelection() != null ) {
      if( properties.getSelection() ) {
        attachSelectionListener( operation );
      } else {
        removeSelectionListener( operation );
      }
    }
    if( properties.getMouse() != null ) {
      if( properties.getMouse() ) {
        attachMouseListener( operation );
      } else {
        removeMouseListener( operation );
      }
    }
    if( properties.getFocus() != null ) {
      if( properties.getFocus() ) {
        attachFocusListener( operation );
      } else {
        removeFocusListener( operation );
      }
    }
    if( properties.getModify() != null ) {
      if( properties.getModify() ) {
        attachModifyListener( operation );
      } else {
        removeModifyListener( operation );
      }
    }
    if( properties.getProgress() != null ) {
      if( properties.getProgress() ) {
        attachProgressListener( operation );
      } else {
        removeProgressListener( operation );
      }
    }
    if( properties.isMenuDetect() != null ) {
      if( properties.isMenuDetect() ) {
        attachMenuDetectListener( operation );
      } else {
        removeMenuDetectListener( operation );
      }
    }
  }

  protected View findViewByTarget( Operation operation ) {
    return findObjectById( operation.getTarget(), View.class );
  }

  protected void attachFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( new ImmediateFocusChangeListener( activity ) );
  }

  protected void removeFocusListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnFocusChangeListener( null );
  }

  protected void attachMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, true, false );
    } else {
      if( !previousTouchListener.isTransmittingUpDown() ) {
        previousTouchListener.setTransmittingUpDown( true );
      }
    }
  }

  public void attachInitialTouchListener( final View view,
                                          boolean transmitUpDownEvents,
                                          boolean transmitMenuDetectEvents )
  {
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener mouseEventTouchListener;
    LongClickListener longClickListener;
    mouseEventTouchListener = new MouseEventTouchListener( activity, transmitUpDownEvents );
    longClickListener = new LongClickListener( activity,
                                               mouseEventTouchListener,
                                               mouseEventTouchListener,
                                               transmitMenuDetectEvents );
    view.setOnTouchListener( mouseEventTouchListener );
    view.setOnLongClickListener( longClickListener );
    getListenerRegistry().registerListener( widgetId, mouseEventTouchListener );
    getListenerRegistry().registerListener( widgetId, longClickListener );
  }

  protected ListenerRegistry getListenerRegistry() {
    return activity.getProcessor().getWidgetToolkit().getListenerRegistry();
  }

  protected void attachMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      attachInitialTouchListener( view, false, true );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( true );
    }
  }

  private MouseEventTouchListener getPreviousTouchListener( String widgetId ) {
    return getListenerRegistry().getListener( widgetId, MouseEventTouchListener.class );
  }

  private LongClickListener getPreviousLongClickListener( String widgetId ) {
    return getListenerRegistry().getListener( widgetId, LongClickListener.class );
  }

  protected void removeMouseListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    LongClickListener previousLongClickListener = getPreviousLongClickListener( widgetId );
    if( previousLongClickListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousLongClickListener.isTransmittingMenuDetect() ) {
      removeTouchListenersFinally( view );
      restoreConsumingTouchListener( view );
    } else {
      getPreviousTouchListener( widgetId ).setTransmittingUpDown( false );
    }
  }

  private void restoreConsumingTouchListener( View view ) {
    if( view instanceof Composite ) {
      view.setOnTouchListener( new ConsumingTouchListener() );
    }
  }

  private void throwNoTouchListenerException( final String widgetId ) {
    throw new NullPointerException( "Widget with ID="
                                    + widgetId
                                    + " does not have a touch listener attached." );
  }

  public void removeTouchListenersFinally( final View view ) {
    final String widgetId = ( String )view.getTag();
    view.setOnTouchListener( null );
    view.setOnLongClickListener( null );
    getListenerRegistry().unregisterListener( widgetId, MouseEventTouchListener.class );
    getListenerRegistry().unregisterListener( widgetId, LongClickListener.class );
  }

  protected void attachSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( new ViewClickListener( activity ) );
  }

  protected void removeSelectionListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    view.setOnClickListener( null );
  }

  protected void removeMenuDetectListener( ListenOperation operation ) {
    final View view = findViewByTarget( operation );
    final String widgetId = ( String )view.getTag();
    MouseEventTouchListener previousTouchListener = getPreviousTouchListener( widgetId );
    if( previousTouchListener == null ) {
      throwNoTouchListenerException( widgetId );
    }
    if( !previousTouchListener.isTransmittingUpDown() ) {
      removeTouchListenersFinally( view );
      restoreConsumingTouchListener( view );
    } else {
      getPreviousLongClickListener( widgetId ).setTransmittingMenuDetect( false );
    }
  }

  protected void attachModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeModifyListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void removeProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  protected void attachProgressListener( ListenOperation operation ) {
    // to be implemented by subclasses
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( view == null ) {
      throw new IllegalArgumentException( "Could not find widget "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    ViewSetter.dereferenceBackground( getProcessor(), view );
    // It would be possible to directly call viewGroup.removeView(view) but to
    // support robolectric we use the index based approach. Could be minimized
    // with custom shadow object.
    ViewGroup viewGroup = ( ViewGroup )view.getParent();
    viewGroup.removeViewAt( viewGroup.indexOfChild( view ) );
    getProcessor().getWidgetToolkit().unregisterObjectById( operation.getTarget() );
  }

  public void call( CallOperation operation ) {
    // to be implemented by subclasses
  }

  /** To be used for testing only. */
  void setSetterManager( SetterManager setterUtil ) {
    this.setterManager = setterUtil;
  }

}
