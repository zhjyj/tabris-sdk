/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public interface ICustomVariants {

  static final String PREFIX = "variant_";

  public static final String ANIMATED = PREFIX + "ANIMATED";
  public static final String TITLE = PREFIX + "TITLE";
  public static final String CLIENT_CANVAS = PREFIX + "CLIENT_CANVAS";

}
