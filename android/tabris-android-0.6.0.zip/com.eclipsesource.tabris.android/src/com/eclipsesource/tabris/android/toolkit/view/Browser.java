/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.webkit.WebSettings;
import android.webkit.WebView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.util.StringUtil;

public class Browser extends WebView {

  private static final String JAVASCRIPT = "javascript:";
  private static final String METHOD = ".setResult(";
  private static final String CLOSING_BRACKET = ");";

  private final UiActivity activity;
  private BrowserWebViewClient webViewClient;

  public Browser( UiActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  public void init() {
    String widgetId = ( String )getTag();
    webViewClient = new BrowserWebViewClient( widgetId );
    setWebViewClient( webViewClient );
    setWebChromeClient( new BrowserWebChromeClient( activity ) );
    setOnTouchListener( new BrowserViewListener() );
    setScrollBarStyle( WebView.SCROLLBARS_OUTSIDE_OVERLAY );
    setScrollbarFadingEnabled( true );
    addJavascriptInterface( new BrowserJSCallback( activity, widgetId ),
                            BrowserJSCallback.CALLBACK_NAME );
    WebSettings settings = getSettings();
    settings.setJavaScriptEnabled( true );
  }

  public void setProgressListener( IBrowserProgressListener listener ) {
    webViewClient.setProgressListener( listener );
  }

  /** To be used for testing only. */
  public void setBrowserWebViewClient( BrowserWebViewClient client ) {
    super.setWebViewClient( client );
    webViewClient = client;
  }

  public void executeScript( String script ) {
    String sanatizedScript = sanatizeScript( script );
    loadUrl( JAVASCRIPT
             + BrowserJSCallback.CALLBACK_NAME
             + METHOD
             + sanatizedScript
             + CLOSING_BRACKET );
  }

  private String sanatizeScript( String script ) {
    String sanatizedScript = script.trim();
    if( sanatizedScript.endsWith( StringUtil.SEMICOLON ) ) {
      sanatizedScript = sanatizedScript.substring( 0, sanatizedScript.length() - 1 );
    }
    return sanatizedScript;
  }

}
