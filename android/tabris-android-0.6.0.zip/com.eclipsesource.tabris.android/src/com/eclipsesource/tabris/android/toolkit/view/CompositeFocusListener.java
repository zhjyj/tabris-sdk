/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.view.View.OnFocusChangeListener;

public class CompositeFocusListener implements OnFocusChangeListener {

  private ArrayList<OnFocusChangeListener> listeners;

  public CompositeFocusListener() {
    listeners = new ArrayList<OnFocusChangeListener>();
  }

  public void onFocusChange( View view, boolean hasFocus ) {
    fireOnFocusChange( view, hasFocus );
  }

  private void fireOnFocusChange( View view, boolean hasFocus ) {
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onFocusChange( view, hasFocus );
    }
  }

  public void addListener( OnFocusChangeListener listener ) {
    listeners.add( listener );
  }

  public void removeListener( OnFocusChangeListener listener ) {
    listeners.remove( listener );
  }

  public void removeListeners( Class<? extends OnFocusChangeListener> listenerClass ) {
    for( int i = listeners.size() - 1; i >= 0; i-- ) {
      OnFocusChangeListener listener = listeners.get( i );
      if( listener.getClass().equals( listenerClass ) ) {
        listeners.remove( listener );
      }
    }
  }

  public int getSize() {
    return listeners.size();
  }
}
