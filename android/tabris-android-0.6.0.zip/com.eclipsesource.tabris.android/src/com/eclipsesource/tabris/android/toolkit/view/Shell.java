/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.graphics.drawable.Drawable;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;

public class Shell extends Composite {

  protected ShellAnimationSupport animSupport;
  protected DialogHeader dialogHeader;

  public static final String MAXIMIZED = "maximized";
  private String mode;

  public Shell( UiActivity context, ShellAnimationSupport animSupport ) {
    super( context );
    this.animSupport = animSupport;
  }

  public void setHeader( DialogHeader dialogHeader ) {
    this.dialogHeader = dialogHeader;
    addView( dialogHeader.getHeader() );
  }

  public String getMode() {
    return mode;
  }

  public void setMode( String mode ) {
    this.mode = mode;
  }

  public boolean isMaximized() {
    return MAXIMIZED.equals( getMode() );
  }

  public void playShowAnimation( UiActivity activity ) {
    if( mode != null && mode.equals( Shell.MAXIMIZED ) ) {
      animSupport.playShellAnimations( this,
                                       android.R.attr.activityOpenEnterAnimation,
                                       android.R.attr.activityOpenExitAnimation,
                                       activity );
    }
  }

  public void playHideAnimation( UiActivity activity ) {
    if( mode != null && mode.equals( Shell.MAXIMIZED ) ) {
      animSupport.playShellAnimations( this,
                                       android.R.attr.activityCloseExitAnimation,
                                       android.R.attr.activityCloseEnterAnimation,
                                       activity );
    }
  }

  public void setText( String text ) {
    if( dialogHeader != null ) {
      dialogHeader.setTitleText( text );
    }
  }

  public void setIcon( Drawable icon ) {
    if( dialogHeader != null && icon != null ) {
      dialogHeader.setIcon( icon );
    }
  }

  public DialogHeader getHeader() {
    return dialogHeader;
  }
}
