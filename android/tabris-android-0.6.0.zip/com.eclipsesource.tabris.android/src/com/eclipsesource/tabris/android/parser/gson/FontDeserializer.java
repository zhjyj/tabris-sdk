/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser.gson;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.parser.ParseException;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;

public class FontDeserializer implements JsonDeserializer<Font> {

  public Font deserialize( JsonElement json, Type typeOfT, JsonDeserializationContext context )
    throws JsonParseException
  {
    Font font = null;
    if( json instanceof JsonArray ) {
      JsonArray array = ( JsonArray )json;
      if( array.size() != 4 ) {
        throw new ParseException( "The font description is not a 4 element touple" );
      }
      font = createFont( array );
    }
    return font;
  }

  private Font createFont( JsonArray array ) {
    Font font = new Font();
    populateFontWithFamily( array, font );
    populateFontWithSize( array, font );
    populateFontWithBold( array, font );
    populateFontWithItalic( array, font );
    return font;
  }

  private void populateFontWithFamily( JsonArray array, Font font ) {
    JsonElement familyListCandidate = array.get( 0 );
    if( isFontFamilyList( familyListCandidate ) ) {
      font.setFamily( toList( ( JsonArray )familyListCandidate ) );
    }
  }

  private void populateFontWithItalic( JsonArray array, Font font ) {
    JsonElement italicCandidate = array.get( 3 );
    if( italicCandidate.isJsonPrimitive() ) {
      font.setItalic( italicCandidate.getAsBoolean() );
    } else {
      throw new ParseException( "The italic property of the font is not a json primitive." );
    }
  }

  private void populateFontWithBold( JsonArray array, Font font ) {
    JsonElement booleanCandidate = array.get( 2 );
    if( booleanCandidate.isJsonPrimitive() ) {
      font.setBold( booleanCandidate.getAsBoolean() );
    } else {
      throw new ParseException( "The bold propertey of the font is not a json primitive." );
    }
  }

  private void populateFontWithSize( JsonArray array, Font font ) {
    JsonElement sizeCandidate = array.get( 1 );
    if( sizeCandidate.isJsonPrimitive() ) {
      font.setSize( sizeCandidate.getAsInt() );
    } else {
      throw new ParseException( "The size property of the font is not a json primitive." );
    }
  }

  private List<String> toList( JsonArray array ) {
    ArrayList<String> result = new ArrayList<String>();
    Iterator<JsonElement> iter = array.iterator();

    while( iter.hasNext() ) {
      JsonElement element = iter.next();
      if( element instanceof JsonPrimitive ) {
        JsonPrimitive primitve = ( JsonPrimitive )element;
        result.add( primitve.getAsString() );
      } else {
        throw new ParseException( "Given JsonElement is not a json primitive in a font family list. Got: "
                                  + element );
      }
    }
    return result;
  }

  private boolean isFontFamilyList( JsonElement fontFamilyListCandidate ) {
    if( fontFamilyListCandidate instanceof JsonArray ) {
      JsonArray familyList = ( JsonArray )fontFamilyListCandidate;
      if( familyList.size() > 0 ) {
        JsonElement family = familyList.get( 0 );
        if( family.isJsonPrimitive() ) {
          return true;
        }
      }
    }
    return false;
  }
}
