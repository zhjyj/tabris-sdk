/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class SelectionState extends AbstractState {

  private final boolean selection;

  public SelectionState( String widgetID, boolean selection ) {
    super( widgetID );
    this.selection = selection;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTION_POSTFIX;
  }

  @Override
  public String generateValue() {
    return Boolean.toString( selection );
  }

}
