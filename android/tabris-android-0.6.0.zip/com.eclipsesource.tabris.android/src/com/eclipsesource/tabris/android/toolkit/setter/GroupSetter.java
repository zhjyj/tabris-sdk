/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Group;

public class GroupSetter<T extends Group> extends CompositeSetter<T> {

  @Override
  public void execute( UiActivity activity, T group, SetProperties properties ) {
    super.execute( activity, group, properties );
    setText( activity, group, properties );
    setForeground( activity, group, properties );
  }

  private void setText( UiActivity activity, T group, SetProperties properties ) {
    String text = properties.getText();
    if( text != null ) {
      group.setTitle( text );
    }
  }

  private void setForeground( UiActivity activity, T group, SetProperties properties ) {
    List<Integer> foreground = properties.getForeground();
    if( foreground != null ) {
      group.setTitleAndSeparatorColor( SetterManager.colorToupleToInt( foreground ) );
    }
  }

}
