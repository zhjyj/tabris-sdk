/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

public class ListenerHolder<T> {

  private final ArrayList<T> listeners;

  public ListenerHolder() {
    listeners = new ArrayList<T>();
  }

  public void addListener( T listener ) {
    listeners.add( listener );
  }

  public void removeListener( T listener ) {
    listeners.remove( listener );
  }

  public void removeListeners( Class<? extends T> listenerClass ) {
    for( int i = listeners.size() - 1; i >= 0; i-- ) {
      T listener = listeners.get( i );
      if( listener.getClass().equals( listenerClass ) ) {
        listeners.remove( listener );
      }
    }
  }

  public boolean contains( Class<? extends T> listenerClass ) {
    return findListener( listenerClass ) != null;
  }

  public T findListener( Class<? extends T> listenerClass ) {
    for( int i = listeners.size() - 1; i >= 0; i-- ) {
      T listener = listeners.get( i );
      if( listener.getClass().equals( listenerClass ) ) {
        return listener;
      }
    }
    return null;
  }

  public int getSize() {
    return listeners.size();
  }

  public ArrayList<T> getListeners() {
    return listeners;
  }

}
