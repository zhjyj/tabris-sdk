/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Paint.Style;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class StrokeGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "stroke";

  public StrokeGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    gc.setStyle( Style.STROKE );
    gc.drawCurrentPath();
  }

}
