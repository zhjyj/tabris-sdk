/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

public interface ITransportRequest {

  public static final String PARAM_W4T_HEIGHT = "w4t_height";
  public static final String PARAM_W4T_WIDTH = "w4t_width";
  public static final String PARAM_W1_DPI_Y = "w1.dpi.y";
  public static final String PARAM_W1_DPI_X = "w1.dpi.x";
  public static final String PARAM_W1_CURSOR_LOCATION_Y = "w1.cursorLocation.y";
  public static final String PARAM_W1_CURSOR_LOCATION_X = "w1.cursorLocation.x";
  public static final String PARAM_W1_COLOR_DEPTH = "w1.colorDepth";
  public static final String PARAM_W1_BOUNDS_HEIGHT = "w1.bounds.height";
  public static final String PARAM_W1_BOUNDS_WIDTH = "w1.bounds.width";
  public static final String PARAM_RWT_INITIALIZE = "rwt_initialize";
  public static final String PARAM_UI_ROOT = "uiRoot";
  public static final String PARAM_UI_ROOT_VALUE = "w1";

  String getPath();

  String getQuery();

  void setQuery( String query );

  /**
   * Sets the timeout of the particular request.
   * <ul>
   * <li>Set -1 (default) to ignore the individual value and use the application
   * default instead</li>
   * <li>Set 0 to set an infinite timeout</li>
   * <li>Set a value > 0 to set the specific timeout</li>
   * </ul>
   * 
   * @param timeouty the timeout to set
   */
  void setTimeout( int timeout );

  /**
   * @see #setTimeout(int)
   * @return the currently configured timeout
   */
  int getTimeout();

  /**
   * Silent requests do not show up in the ui in case of failure.
   * 
   * @return <code>true</code> if the request is silent or <code>false</code>
   *         otherwise
   */
  boolean isSilentRequest();

  void setSilentRequest( boolean backgroundRequest );

}
