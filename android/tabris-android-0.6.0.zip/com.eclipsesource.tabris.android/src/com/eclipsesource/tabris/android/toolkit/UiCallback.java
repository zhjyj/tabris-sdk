/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.eclipsesource.tabris.android.UiActivity;

public class UiCallback extends BroadcastReceiver {

  private final UiActivity activity;
  private Thread thread;

  public UiCallback( UiActivity activity ) {
    this.activity = activity;
  }

  public void setActive( boolean active ) {
    if( active ) {
      updateThread( active );
      activity.registerReceiver( this, new IntentFilter( ConnectivityManager.CONNECTIVITY_ACTION ) );
    } else {
      if( callbackIsActive() ) {
        activity.unregisterReceiver( this );
      }
      updateThread( active );
    }
  }

  private void updateThread( boolean active ) {
    interruptThread();
    if( active ) {
      thread = createNewThread();
      thread.start();
    }
  }

  protected Thread createNewThread() {
    return new Thread( new UiCallbackRunnable( activity ) );
  }

  private void interruptThread() {
    if( callbackIsActive() ) {
      thread.interrupt();
    }
  }

  public boolean callbackIsActive() {
    return thread != null && thread.isAlive() && !thread.isInterrupted();
  }

  /** To be used for testing only. */
  public Thread getThread() {
    return thread;
  }

  @Override
  public void onReceive( Context context, Intent intent ) {
    String action = intent.getAction();
    if( ConnectivityManager.CONNECTIVITY_ACTION.equals( action ) ) {
      boolean isConnected = !intent.getBooleanExtra( ConnectivityManager.EXTRA_NO_CONNECTIVITY,
                                                     false );
      if( callbackIsActive() && !isConnected ) {
        updateThread( false );
      } else if( !callbackIsActive() && isConnected ) {
        updateThread( true );
      }
    }
  }

}