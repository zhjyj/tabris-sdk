/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class ConsumingTouchListener implements OnTouchListener {

  public boolean onTouch( View v, MotionEvent event ) {
    // intercept all touch events
    return true;
  }
}