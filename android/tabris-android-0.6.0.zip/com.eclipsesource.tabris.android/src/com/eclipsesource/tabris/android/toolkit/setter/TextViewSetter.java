/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;
import android.widget.TextView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;

public class TextViewSetter<T extends TextView> extends ViewSetter<T> {

  private static final String ALIGNMENT_LEFT = "left";
  private static final String ALIGNMENT_RIGHT = "right";
  private static final String ALIGNMENT_CENTER = "center";

  @Override
  public void execute( UiActivity activity, T textView, SetProperties properties ) {
    super.execute( activity, textView, properties );
    setText( textView, properties );
    setForeground( textView, properties );
    setImage( activity, textView, properties );
    setFont( textView, properties );
    setTooltip( textView, properties );
    setMessage( textView, properties );
    setAlignment( textView, properties );
  }

  private void setAlignment( T textView, SetProperties properties ) {
    String alignment = properties.getAlignment();
    if( alignment != null ) {
      if( alignment.equals( ALIGNMENT_LEFT ) ) {
        textView.setGravity( Gravity.LEFT | getDefaultVerticalAlignment() );
      } else if( alignment.equals( ALIGNMENT_RIGHT ) ) {
        textView.setGravity( Gravity.RIGHT | getDefaultVerticalAlignment() );
      } else if( alignment.equals( ALIGNMENT_CENTER ) ) {
        textView.setGravity( Gravity.CENTER_HORIZONTAL | getDefaultVerticalAlignment() );
      }
    }
  }

  protected int getDefaultVerticalAlignment() {
    return Gravity.TOP;
  }

  private void setMessage( TextView textView, SetProperties properties ) {
    String message = properties.getMessage();
    if( message != null ) {
      textView.setHint( message );
    }
  }

  private void setTooltip( TextView textView, SetProperties properties ) {
    String toolTip = properties.getToolTip();
    if( toolTip != null ) {
      textView.setHint( toolTip );
    }
  }

  private void setFont( TextView textView, SetProperties properties ) {
    Font font = properties.getFont();
    if( font != null ) {
      int style = 0;
      if( font.getBold() ) {
        style |= Typeface.BOLD;
      }
      if( font.getItalic() ) {
        style |= Typeface.ITALIC;
      }
      Typeface typeFace = null;
      if( font.getFamily() != null && font.getFamily().size() > 0 ) {
        typeFace = Typeface.create( font.getFamily().get( 0 ), style );
      }
      textView.setTypeface( typeFace, style );
      if( font.getSize() != null ) {
        textView.setTextSize( font.getSize() );
      }
    }
  }

  @SuppressWarnings("unchecked")
  private void setImage( UiActivity activity, final TextView textView, SetProperties properties ) {
    List<String> image = properties.getImage();
    if( image != null ) {
      new LoadImageTask( activity ) {

        @Override
        protected void onPostExecute( BitmapDrawable drawable ) {
          BitmapDrawableCache cache = getProcessor().getWidgetToolkit().getBitmapCache();
          cache.decreaseReferenceCount( getBitmapDrawable( textView ) );
          setBitmapDrawable( textView, drawable );
        }

      }.loadBitmap( image );
    }
  }

  public BitmapDrawable getBitmapDrawable( TextView textView ) {
    return ( BitmapDrawable )textView.getCompoundDrawables()[ 1 ];
  }

  protected void setBitmapDrawable( final TextView textView, BitmapDrawable drawable ) {
    textView.setCompoundDrawablesWithIntrinsicBounds( null, drawable, null, null );
  }

  protected void setForeground( TextView textView, SetProperties properties ) {
    List<Integer> foreground = properties.getForeground();
    if( foreground != null ) {
      textView.setTextColor( SetterManager.colorToupleToInt( foreground ) );
    }
  }

  protected void setText( TextView textView, SetProperties properties ) {
    String text = properties.getText();
    if( text != null ) {
      textView.setText( text );
    }
  };

}
