/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class Meta {

  public static final String REQUEST_COUNTER = "requestCounter";
  public static final String SESSION_TIMEOUT_ERROR = "session timeout";

  private int requestCounter;
  private String error;
  private String message;

  public int getRequestCounter() {
    return requestCounter;
  }

  public String getError() {
    return error;
  }

  public void setError( String error ) {
    this.error = error;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage( String message ) {
    this.message = message;
  }

  public void setRequestCounter( int requestCounter ) {
    this.requestCounter = requestCounter;
  }

  @Override
  public String toString() {
    return "MetaMsg [requestCounter=" + requestCounter + "]";
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( error == null )
                                                 ? 0
                                                 : error.hashCode() );
    result = prime * result + ( ( message == null )
                                                   ? 0
                                                   : message.hashCode() );
    result = prime * result + requestCounter;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    Meta other = ( Meta )obj;
    if( error == null ) {
      if( other.error != null ) {
        return false;
      }
    } else if( !error.equals( other.error ) ) {
      return false;
    }
    if( message == null ) {
      if( other.message != null ) {
        return false;
      }
    } else if( !message.equals( other.message ) ) {
      return false;
    }
    if( requestCounter != other.requestCounter ) {
      return false;
    }
    return true;
  }

}
