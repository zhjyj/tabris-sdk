/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class QuadraticCurveToGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "quadraticCurveTo";

  public QuadraticCurveToGcOperation( UiActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 5 );
    float x1 = getScaledFloat( properties, 1 );
    float y1 = getScaledFloat( properties, 2 );
    float x2 = getScaledFloat( properties, 3 );
    float y2 = getScaledFloat( properties, 4 );
    gc.getPath().quadTo( x1, y1, x2, y2 );
  }

}
