/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;

public class ScrolledCompositeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.ScrolledComposite";

  private static final String STYLE_H_SCROLL = "H_SCROLL";
  private static final String STYLE_V_SCROLL = "V_SCROLL";

  public ScrolledCompositeOperator( UiActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List<String> styles = operation.getProperties().getStyle();
    if( styles == null || styles.isEmpty() ) {
      throw new IllegalArgumentException( "The style of the ScrollComposite has to be either V_SCROLL or H_SCROLL." );
    }
    createScrollView( operation, styles );
  }

  private void createScrollView( CreateOperation operation, List<String> styles ) {
    if( styles.contains( STYLE_V_SCROLL ) && styles.contains( STYLE_H_SCROLL ) ) {
      ObservableScrollView scrollView = new ObservableScrollView( getActivity() );
      initiateNewView( operation, scrollView );
      scrollView.createNestedScrollViews();
    } else if( styles.contains( STYLE_V_SCROLL ) ) {
      ObservableVerticalScrollView scrollView = new ObservableVerticalScrollView( getActivity() );
      initiateNewView( operation, scrollView );
    } else if( styles.contains( STYLE_H_SCROLL ) ) {
      ObservableHorizontalScrollView scrollView = new ObservableHorizontalScrollView( getActivity() );
      initiateNewView( operation, scrollView );
    }
  }

  public String getType() {
    return TYPE;
  }

}
