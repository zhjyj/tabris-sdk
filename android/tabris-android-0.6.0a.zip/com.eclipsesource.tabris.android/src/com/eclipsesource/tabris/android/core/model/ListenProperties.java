/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class ListenProperties implements IProperties {

  private Boolean mouse;
  private Boolean focus;
  private Boolean selection;
  private Boolean modify;
  private Boolean menuDetect;
  private Boolean progress;

  public Boolean getMouse() {
    return mouse;
  }

  public void setMouse( Boolean mouse ) {
    this.mouse = mouse;
  }

  public Boolean getFocus() {
    return focus;
  }

  public void setFocus( Boolean focus ) {
    this.focus = focus;
  }

  public Boolean getSelection() {
    return selection;
  }

  public void setSelection( Boolean selection ) {
    this.selection = selection;
  }

  public Boolean getModify() {
    return modify;
  }

  public void setModify( Boolean modify ) {
    this.modify = modify;
  }

  public Boolean isMenuDetect() {
    return menuDetect;
  }

  public void setMenuDetect( Boolean menuDetect ) {
    this.menuDetect = menuDetect;
  }

  public Boolean getProgress() {
    return progress;
  }

  public void setProgress( Boolean progress ) {
    this.progress = progress;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( focus == null )
                                                 ? 0
                                                 : focus.hashCode() );
    result = prime * result + ( ( menuDetect == null )
                                                      ? 0
                                                      : menuDetect.hashCode() );
    result = prime * result + ( ( modify == null )
                                                  ? 0
                                                  : modify.hashCode() );
    result = prime * result + ( ( mouse == null )
                                                 ? 0
                                                 : mouse.hashCode() );
    result = prime * result + ( ( progress == null )
                                                    ? 0
                                                    : progress.hashCode() );
    result = prime * result + ( ( selection == null )
                                                     ? 0
                                                     : selection.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    ListenProperties other = ( ListenProperties )obj;
    if( focus == null ) {
      if( other.focus != null ) {
        return false;
      }
    } else if( !focus.equals( other.focus ) ) {
      return false;
    }
    if( menuDetect == null ) {
      if( other.menuDetect != null ) {
        return false;
      }
    } else if( !menuDetect.equals( other.menuDetect ) ) {
      return false;
    }
    if( modify == null ) {
      if( other.modify != null ) {
        return false;
      }
    } else if( !modify.equals( other.modify ) ) {
      return false;
    }
    if( mouse == null ) {
      if( other.mouse != null ) {
        return false;
      }
    } else if( !mouse.equals( other.mouse ) ) {
      return false;
    }
    if( progress == null ) {
      if( other.progress != null ) {
        return false;
      }
    } else if( !progress.equals( other.progress ) ) {
      return false;
    }
    if( selection == null ) {
      if( other.selection != null ) {
        return false;
      }
    } else if( !selection.equals( other.selection ) ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "ListenProperties ["
           + ( mouse != null
                            ? "mouse=" + mouse + ", "
                            : "" )
           + ( focus != null
                            ? "focus=" + focus + ", "
                            : "" )
           + ( selection != null
                                ? "selection=" + selection + ", "
                                : "" )
           + ( modify != null
                             ? "modify=" + modify + ", "
                             : "" )
           + ( progress != null
                               ? "progress=" + progress
                               : "" )
           + "]";
  }

}
