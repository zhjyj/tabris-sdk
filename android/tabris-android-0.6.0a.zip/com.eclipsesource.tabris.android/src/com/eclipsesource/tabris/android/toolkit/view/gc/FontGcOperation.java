/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Typeface;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.method.MeasureStringsMethod;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class FontGcOperation extends AbstractGcOperation {

  public static final String OPERATION = "font";

  public FontGcOperation( UiActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    List<?> fontDef = ( List<?> )properties.get( 1 );
    List<?> fontNames = ( List<?> )fontDef.get( 0 );
    int textSize = getScaledInt( fontDef, 1 );
    Boolean bold = ( Boolean )fontDef.get( 2 );
    Boolean italic = ( Boolean )fontDef.get( 3 );
    Typeface typeface = getTypeface( fontNames, bold, italic );
    gc.getPaint().setTypeface( typeface );
    gc.getPaint().setTextSize( textSize );
  }

  protected Typeface getTypeface( List<?> fontNames, Boolean bold, Boolean italic ) {
    return MeasureStringsMethod.getTypeface( fontNames, bold, italic );
  }

  protected int getScaledInt( List<?> properties, int i ) {
    IWidgetToolkit toolkit = getActivity().getProcessor().getWidgetToolkit();
    int value = ( ( Number )properties.get( i ) ).intValue();
    return toolkit.multiplyByDensityFactor( value );
  }
}
