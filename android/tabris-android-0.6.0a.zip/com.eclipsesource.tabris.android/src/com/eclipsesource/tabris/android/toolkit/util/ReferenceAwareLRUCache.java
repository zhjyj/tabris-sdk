/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ReferenceAwareLRUCache<K, V> {

  private final Map<K, CacheEntry<V>> map;
  private int size;
  private final int maxSize;

  public static class CacheEntry<T> {

    private final T entry;
    private int referenceCount;

    public CacheEntry( T entry ) {
      this.entry = entry;
    }

    public T getValue() {
      return entry;
    }

    public int getReferenceCount() {
      return referenceCount;
    }

    public void increaseReferenceCount() {
      referenceCount++;
    }

    public void decreaseReferenceCount() {
      referenceCount--;
    }

    @Override
    public String toString() {
      return "CacheEntry [referenceCount=" + referenceCount + "]";
    }

  }

  public ReferenceAwareLRUCache( final int maxSize ) {
    this.maxSize = maxSize;
    map = new LinkedHashMap<K, CacheEntry<V>>( 0, 0.75f, true );
  }

  public void putAndReference( K key, V value ) {
    put( key, value, true );
  }

  public void put( K key, V value ) {
    put( key, value, false );
  }

  private void put( K key, V value, boolean countReference ) {
    synchronized( map ) {
      if( map.containsKey( key ) ) {
        throw new IllegalArgumentException( "The cache already contains an entry for: " + key );
      }
      CacheEntry<V> cacheEntry = new CacheEntry<V>( value );
      if( countReference ) {
        cacheEntry.increaseReferenceCount();
      }
      map.put( key, cacheEntry );
      size += sizeOf( key, value );
      if( size > maxSize ) {
        trimToSize( maxSize );
      }
    }
  }

  @SuppressWarnings("unchecked")
  private void trimToSize( int targetSize ) {
    synchronized( map ) {
      Set<Entry<K, CacheEntry<V>>> entrySet = map.entrySet();
      Entry<K, CacheEntry<V>>[] entryArray = entrySet.toArray( new Entry[ entrySet.size() ] );
      for( int i = 0; i < entryArray.length; i++ ) {
        if( size <= targetSize ) {
          break;
        }
        Entry<K, CacheEntry<V>> entry = entryArray[ i ];
        CacheEntry<V> value = entry.getValue();
        K key = entry.getKey();
        if( value.getReferenceCount() == 0 ) {
          map.remove( key );
          size -= sizeOf( key, value.getValue() );
          entryRemoved( key, value.getValue() );
        }
      }
    }
  }

  protected void entryRemoved( K key, V value ) {
  }

  public V get( K key ) {
    CacheEntry<V> cacheEntry = map.get( key );
    if( cacheEntry != null ) {
      return cacheEntry.getValue();
    }
    return null;
  }

  public int sizeOf( K key, V value ) {
    return 1;
  }

  public void clear() {
    trimToSize( 0 );
  }

  public void increaseReferenceCount( String key ) {
    map.get( key ).increaseReferenceCount();
  }

  public void decreaseReferenceCount( String key ) {
    map.get( key ).decreaseReferenceCount();
  }

  public Map<K, CacheEntry<V>> getMap() {
    return map;
  }
}