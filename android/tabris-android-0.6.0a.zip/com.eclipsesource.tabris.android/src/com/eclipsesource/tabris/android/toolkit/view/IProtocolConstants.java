/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

public interface IProtocolConstants {

  public static final String EVENT_WIDGET_SELECTED = "org.eclipse.swt.events.widgetSelected";
  public static final String EVENT_WIDGET_SELECTED_ITEM = "org.eclipse.swt.events.widgetSelected.item";
  public static final String EVENT_TREE_EXPANDED = "org.eclipse.swt.events.treeExpanded";
  public static final String EVENT_TREE_COLLAPSED = "org.eclipse.swt.events.treeCollapsed";

  public static final String W1_CURSOR_LOCATION_Y = "w1.cursorLocation.y";
  public static final String W1_CURSOR_LOCATION_X = "w1.cursorLocation.x";

  public static final String W1_FOCUS_CONTROL = "w1.focusControl";

  public static final String PROGRESS_COMPLETED_POSTFIX = ".org.eclipse.swt.events.progressCompleted";
  public static final String SELECTION_POSTFIX = ".selection";
  public static final String SELECTION_START_POSTFIX = ".selectionStart";
  public static final String SELECTION_LENGTH_POSTFIX = ".selectionLength";
  public static final String TEXT_POSTFIX = ".text";

  public static final String W1_BOUNDS_HEIGHT = "w1.bounds.height";
  public static final String W1_BOUNDS_WIDTH = "w1.bounds.width";

  public static final String SHELL_CLOSE = "org.eclipse.swt.widgets.Shell_close";

  public static final String SCROLL_X_POSTFIX = ".horizontalBar.selection";
  public static final String SCROLL_Y_POSTFIX = ".verticalBar.selection";
  public static final String SCROLL_TOP_ITEM_INDEX = ".topItemIndex";

  public static final String SELECTED_ITEM_POSTFIX = ".selectedItem";
  public static final String LIST_VISIBLE_POSTFIX = ".listVisible";

  public static final String DATE_TIME_DAY = ".day";
  public static final String DATE_TIME_MONTH = ".month";
  public static final String DATE_TIME_YEAR = ".year";
  public static final String DATE_TIME_HOURS = ".hours";
  public static final String DATE_TIME_MINUTES = ".minutes";
  public static final String DATE_TIME_SECONDS = ".seconds";

  public static final String EXECUTE_RESULT_POSTFIX = ".executeResult";
  public static final String EVALUATE_RESULT_POSTFIX = ".evaluateResult";

  public static final String DRAWINGS = ".drawings";

  public static final String EVENT_MOUSE_DOWN = "org.eclipse.swt.events.mouseDown";
  public static final String EVENT_MOUSE_UP = "org.eclipse.swt.events.mouseUp";
  public static final String EVENT_MOUSE_TIME = ".time";
  public static final String EVENT_MOUSE_BUTTON = ".button";
  public static final String EVENT_MOUSE_COORD_X = ".x";
  public static final String EVENT_MOUSE_COORD_Y = ".y";

  public static final String EVENT_MENU_DETECT = "org.eclipse.swt.events.menuDetect";
}
