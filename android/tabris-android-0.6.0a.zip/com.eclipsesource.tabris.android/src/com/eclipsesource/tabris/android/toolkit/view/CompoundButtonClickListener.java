/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class CompoundButtonClickListener extends ViewClickListener {

  public CompoundButtonClickListener( UiActivity activity ) {
    super( activity );
  }

  @Override
  protected PostRequest createRequestParam( View view ) {
    PostRequest request = super.createRequestParam( view );
    if( view instanceof CompoundButton ) {
      CompoundButton button = ( CompoundButton )view;
      request.addParam( view.getTag() + IProtocolConstants.SELECTION_POSTFIX,
                        Boolean.toString( button.isChecked() ) );
    }
    return request;
  }

}