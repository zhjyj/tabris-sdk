/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ListenerRegistry {

  private Map<String, Set<Object>> registry;

  public ListenerRegistry() {
    registry = new HashMap<String, Set<Object>>();
  }

  public void registerListener( String widgetId, Object listener ) {
    Set<Object> listeners = registry.get( widgetId );
    if( listeners == null ) {
      listeners = new HashSet<Object>();
      listeners.add( listener );
    } else {
      listeners.add( listener );
    }
    registry.put( widgetId, listeners );
  }

  public <T> T unregisterListener( String widgetId, Class<T> listenerClass ) {
    Set<Object> listeners = registry.get( widgetId );
    T result = null;
    if( listeners != null ) {
      result = removeListener( listeners, listenerClass );
      if( listeners.isEmpty() ) {
        registry.remove( widgetId );
      }
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  private <T> T removeListener( Set<Object> listeners, Class<T> listenerClass ) {
    T result = null;
    Iterator<Object> iter = listeners.iterator();
    while( iter.hasNext() ) {
      Object listener = iter.next();
      if( listener.getClass() != listenerClass ) {
        result = ( T )listener;
        iter.remove();
        break;
      }
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  public <T> T getListener( String widgetId, Class<T> clazz ) {
    Set<Object> listeners = registry.get( widgetId );
    T result = null;
    if( listeners != null ) {
      Iterator<Object> iter = listeners.iterator();
      while( iter.hasNext() ) {
        Object listener = iter.next();
        if( listener.getClass().equals( clazz ) ) {
          result = ( T )listener;
          break;
        }
      }
    }
    return result;
  }

  /**
   * Only for testing purposes.
   * 
   * @return the internal store of this registry
   */
  Map<String, Set<Object>> getBackingStore() {
    return registry;
  }

  /**
   * Only for testing purposes.
   * 
   * @return the number of registered listeners for the specified widgetId
   */
  public int getNumberOfListenersForWidget( String widgetId ) {
    Set<Object> listeners = registry.get( widgetId );
    if( listeners == null ) {
      return 0;
    }
    return listeners.size();
  }

}
