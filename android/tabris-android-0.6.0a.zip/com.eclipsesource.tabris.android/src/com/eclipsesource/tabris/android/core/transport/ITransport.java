/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import java.net.URL;

public interface ITransport {

  ITransportResult get( GetRequest request );

  ITransportResult post( PostRequest request );

  URL getEndPoint();

  void dispose();

  void setSessionId( String sessionId );

}
