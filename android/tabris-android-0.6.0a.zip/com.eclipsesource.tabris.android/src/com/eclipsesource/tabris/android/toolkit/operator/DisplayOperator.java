/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.HashMap;
import java.util.Map;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.IMethod;
import com.eclipsesource.tabris.android.toolkit.method.MeasureStringsMethod;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class DisplayOperator extends AbstractWidgetOperator {

  public static final String TYPE = "w1";

  private static final String FUNC_PROBE = "probe";
  private static final String FUNC_MEASURE_STRINGS = "measureStrings";

  private Map<String, IMethod> methods;

  public DisplayOperator( UiActivity activity, MeasureStringsMethod measureStringsMethod ) {
    super( activity );
    methods = new HashMap<String, IMethod>();
    methods.put( FUNC_MEASURE_STRINGS, measureStringsMethod );
    methods.put( FUNC_PROBE, measureStringsMethod );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    throw new IllegalStateException( "A display can not be created manually. It is created during initialiazation of the system." );
  }

  @Override
  public void set( SetOperation operation ) {
    // we currently don't support any properties that are set on the display
  }

  @Override
  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    IMethod method = methods.get( operation.getMethod() );
    if( method == null ) {
      throw new IllegalAccessError( "The method \""
                                    + operation.getMethod()
                                    + "\" is unknown and can not be invoked." );
    }
    method.call( operation.getProperties() );
  }

  public CallProperties callIndirectly( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    IMethod method = methods.get( operation.getMethod() );
    if( method == null ) {
      throw new IllegalAccessError( "The method \""
                                    + operation.getMethod()
                                    + "\" is unknown and can not be invoked." );
    }
    return operation.getProperties();
  }

  void setMethods( Map<String, IMethod> methods ) {
    this.methods = methods;
  }
}
