/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateFocusChangeListener implements OnFocusChangeListener {

  private final UiActivity activity;

  public ImmediateFocusChangeListener( UiActivity activity ) {
    if( activity == null ) {
      throw new IllegalArgumentException( "The given activity can not be null" );
    }
    this.activity = activity;
  }

  public void onFocusChange( View view, boolean hasFocus ) {
    if( view == null ) {
      throw new IllegalArgumentException( "The view parameter that has been focused can not be null" );
    }
    activity.getProcessor().processPostRequest( createRequest( view, hasFocus ) );
  }

  protected PostRequest createRequest( View view, boolean hasFocus ) {
    String focusedWidget;
    if( hasFocus ) {
      focusedWidget = ( String )view.getTag();
    } else {
      focusedWidget = ( String )findShell( view ).getTag();
    }
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, focusedWidget );
    return request;
  }

  private Shell findShell( View view ) {
    Shell result = null;
    if( view instanceof Shell ) {
      result = ( Shell )view;
    } else {
      result = findShell( ( ViewGroup )view.getParent() );
    }
    return result;
  }
}
