/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.eclipsesource.org.apache.http.ParseException;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.TransportException;

public class InitialGetRequestRunnable implements Runnable {

  private static final String START_TOKEN = "org.eclipse.rwt.protocol.Processor.processMessage( ";
  private static final String END_TOKEN = ");/*EOM*/";

  private final GetRequest request;
  private final ProtocolProcessor processor;
  private final IProtocolParser snippetParser;

  public InitialGetRequestRunnable( GetRequest request,
                                    ProtocolProcessor processor,
                                    IProtocolParser snippetParser )
  {
    this.request = request;
    this.processor = processor;
    this.snippetParser = snippetParser;
  }

  public void run() {
    ITransportResult transportResult = processor.getTransport().get( request );
    InputStream responseStream = transportResult.getResult();
    if( transportResult.hasException() ) {
      processor.getWidgetToolkit().showError( transportResult.getException() );
      return;
    }
    handleResponse( responseStream );
  }

  public void handleResponse( InputStream responseStream ) {
    try {
      String initialResponse = readInputStreamAsString( responseStream );
      ByteArrayInputStream buffer = bufferSnippet( sanitizeContent( initialResponse ) );
      snippetParser.parse( buffer );
    } catch( ParseException pe ) {
      IllegalStateException se = new IllegalStateException( "Could not start session: "
                                                            + pe.getMessage(), pe );
      processor.getWidgetToolkit().showError( se );
    } catch( Exception e ) {
      e = new TransportException( "Could not connect to "
                                  + processor.getTransport().getEndPoint()
                                  + request.getPath(), e );
      processor.getWidgetToolkit().showError( e );
    } finally {
      if( responseStream != null ) {
        try {
          responseStream.close();
        } catch( IOException e ) {
          processor.getWidgetToolkit()
            .showError( new TransportException( "Could not close input stream from initial http response",
                                                e ) );
        }
      }
    }
  }

  private ByteArrayInputStream bufferSnippet( List<String> jsonSnippetFromStartupPage ) {
    StringBuilder snippet = new StringBuilder();
    for( int i = 0; i < jsonSnippetFromStartupPage.size(); i++ ) {
      snippet.append( jsonSnippetFromStartupPage.get( i ) );
    }
    return new ByteArrayInputStream( snippet.toString().getBytes(), 0, 4096 );
  }

  private String readInputStreamAsString( final InputStream in ) throws IOException {
    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    BufferedInputStream bis = new BufferedInputStream( in );
    int result;
    result = bis.read();
    while( result != -1 ) {
      byte b = ( byte )result;
      buf.write( b );
      result = bis.read();
    }
    return buf.toString();
  }

  private ArrayList<String> sanitizeContent( String content ) {
    ArrayList<String> result = new ArrayList<String>();
    int startTokenIndex = content.indexOf( START_TOKEN );
    int stop = 0;

    while( startTokenIndex > -1 ) {
      int start = startTokenIndex + START_TOKEN.length();
      stop = content.indexOf( END_TOKEN, stop + END_TOKEN.length() );
      if( stop < start ) {
        stop = content.length();
      }
      result.add( content.substring( start, stop ) );
      startTokenIndex = content.indexOf( START_TOKEN, start );
    }
    if( result.isEmpty() ) {
      result.add( content );
    }
    return result;
  }

}
