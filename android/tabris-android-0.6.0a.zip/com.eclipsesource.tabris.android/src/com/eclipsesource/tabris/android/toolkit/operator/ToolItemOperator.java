/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;

public class ToolItemOperator extends LabelOperator {

  private static final String STYLE_SEPARATOR = "SEPARATOR";
  private static final String STYLE_PUSH = "PUSH";

  public ToolItemOperator( UiActivity activity ) {
    super( activity );
  }

  public static final String TYPE = "rwt.widgets.ToolItem";

  @Override
  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List<String> style = operation.getProperties().getStyle();
    ToolItem toolItem = null;
    if( style != null ) {
      if( style.contains( STYLE_PUSH ) ) {
        toolItem = new PushToolItem( getActivity() );
      } else if( style.contains( STYLE_SEPARATOR ) ) {
        toolItem = new SeparatorToolItem( getActivity() );
      }
    }
    if( toolItem != null ) {
      initiateNewView( operation, toolItem );
    }
  }

  @Override
  public String getType() {
    return TYPE;
  }

}
