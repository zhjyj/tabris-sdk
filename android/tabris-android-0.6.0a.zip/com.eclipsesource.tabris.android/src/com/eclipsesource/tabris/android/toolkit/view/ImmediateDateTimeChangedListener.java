/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateDateTimeChangedListener implements IDateTimeChangedListener {

  private final ProtocolProcessor processor;
  private final HashMap<Integer, String> dateValues;

  public ImmediateDateTimeChangedListener( ProtocolProcessor processor,
                                           HashMap<Integer, String> dateValues )
  {
    if( processor == null ) {
      throw new IllegalArgumentException( "The protocol processor can not be null" );
    }
    if( dateValues == null ) {
      throw new IllegalArgumentException( "The dateValues can not be null" );
    }
    this.dateValues = dateValues;
    this.processor = processor;
  }

  public void dateTimeChanged( DateTimeSpinner spinner ) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime( spinner.getDate() );
    PostRequest request = createRequestParam( ( String )spinner.getTag(), calendar );
    processor.processPostRequest( request );
  }

  protected PostRequest createRequestParam( String widgetId, Calendar calendar ) {
    PostRequest request = new PostRequest();
    Set<Entry<Integer, String>> entrySet = dateValues.entrySet();
    for( Entry<Integer, String> entry : entrySet ) {
      int calendarField = entry.getKey();
      String protocolField = dateValues.get( calendarField );
      request.addParam( widgetId + protocolField, String.valueOf( calendar.get( calendarField ) ) );
    }
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, widgetId );
    return request;
  }

  /** To be used for testing only. */
  public HashMap<Integer, String> getDateValues() {
    return dateValues;
  }
}
