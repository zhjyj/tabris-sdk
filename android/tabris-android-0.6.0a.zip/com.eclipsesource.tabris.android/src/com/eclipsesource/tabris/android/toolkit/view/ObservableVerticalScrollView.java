/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.ScrollView;

import com.eclipsesource.tabris.android.UiActivity;

public class ObservableVerticalScrollView extends ScrollView {

  private final ScrollSupport scrollSupport;

  public ObservableVerticalScrollView( UiActivity activity ) {
    super( activity );
    scrollSupport = new ScrollSupport( activity, this );
  }

  @Override
  protected void onScrollChanged( int x, int y, int oldx, int oldy ) {
    super.onScrollChanged( x, y, oldx, oldy );
    scrollSupport.onScrollChanged( x, y, oldx, oldy );
  }

  public void doSmoothScrollTo( int x, int y ) {
    scrollSupport.setScrollTargetX( x );
    scrollSupport.setScrollTargetY( y );
    smoothScrollTo( x, y );
  }

  public ScrollSupport getScrollSupport() {
    return scrollSupport;
  }

}