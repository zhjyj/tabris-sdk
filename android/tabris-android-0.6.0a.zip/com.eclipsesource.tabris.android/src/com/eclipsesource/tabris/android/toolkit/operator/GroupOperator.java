/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Group;

public class GroupOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Group";

  public GroupOperator( UiActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Group group = new Group( getActivity() );
    group.setOnTouchListener( new ConsumingTouchListener() );
    initiateNewView( operation, group );
  }

  public String getType() {
    return TYPE;
  }

}
