/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

public class DateTimeState extends AbstractState {

  private final String key;
  private final int value;

  public DateTimeState( String tag, String key, int value ) {
    super( tag );
    this.key = key;
    this.value = value;
  }

  public String generateKey() {
    return widgetId + key;
  }

  public String generateValue() {
    return String.valueOf( value );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( key == null )
                                               ? 0
                                               : key.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( !super.equals( obj ) )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    DateTimeState other = ( DateTimeState )obj;
    if( key == null ) {
      if( other.key != null )
        return false;
    } else if( !key.equals( other.key ) )
      return false;
    return true;
  }

}
