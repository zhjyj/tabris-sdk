/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class SelectedItemState implements IState {

  private final String tag;
  private final int position;

  public SelectedItemState( String tag, int position ) {
    this.tag = tag;
    this.position = position;
  }

  public String generateKey() {
    return tag + IProtocolConstants.SELECTED_ITEM_POSTFIX;
  }

  public String generateValue() {
    return String.valueOf( position );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + position;
    result = prime * result + ( ( tag == null )
                                               ? 0
                                               : tag.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( obj == null )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    SelectedItemState other = ( SelectedItemState )obj;
    if( position != other.position )
      return false;
    if( tag == null ) {
      if( other.tag != null )
        return false;
    } else if( !tag.equals( other.tag ) )
      return false;
    return true;
  }

}
