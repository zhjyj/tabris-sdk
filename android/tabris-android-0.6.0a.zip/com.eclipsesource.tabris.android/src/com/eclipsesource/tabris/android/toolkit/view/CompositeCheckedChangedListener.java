/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class CompositeCheckedChangedListener extends ListenerHolder<OnCheckedChangeListener>
  implements OnCheckedChangeListener
{

  public void onClick( View v ) {
  }

  public void onCheckedChanged( CompoundButton buttonView, boolean isChecked ) {
    ArrayList<OnCheckedChangeListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onCheckedChanged( buttonView, isChecked );
    }

  }
}
