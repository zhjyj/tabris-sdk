/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;

public class CompositeOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Composite";

  public CompositeOperator( UiActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Composite comp = new Composite( getActivity() );
    comp.setOnTouchListener( new ConsumingTouchListener() );
    initiateNewView( operation, comp );
  }

  public String getType() {
    return TYPE;
  }

}
