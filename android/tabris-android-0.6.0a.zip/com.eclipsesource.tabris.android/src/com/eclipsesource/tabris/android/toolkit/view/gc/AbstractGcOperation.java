/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public abstract class AbstractGcOperation implements IGcOperation {

  private final String operation;
  private final UiActivity activity;

  public AbstractGcOperation( String operation ) {
    this( operation, null );
  }

  public AbstractGcOperation( String operation, UiActivity activity ) {
    ValidationUtil.checkNullArg( this, operation, String.class );
    this.operation = operation;
    this.activity = activity;
  }

  public String getOperation() {
    return operation;
  }

  public UiActivity getActivity() {
    return activity;
  }

  protected void assertPropertiesSize( List<?> properties, int count ) {
    ValidationUtil.checkNullArg( this, properties, List.class );
    if( properties.size() != count ) {
      throw new IllegalArgumentException( "The gc operation '"
                                          + operation
                                          + "' has to be a "
                                          + count
                                          + " element touple. Got a "
                                          + properties.size()
                                          + " element touple." );
    }
  }

  protected float getScaledFloat( List<?> properties, int i ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    float value = ( ( Number )properties.get( i ) ).floatValue();
    return toolkit.multiplyByDensityFactor( value );
  }
}
