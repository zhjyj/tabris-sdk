/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class LineWidthGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "lineWidth";

  public LineWidthGcOperation( UiActivity activity ) {
    super( OPERATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    float lineWidth = getScaledFloat( properties, 1 );
    gc.getPaint().setStrokeWidth( lineWidth );
  }
}
