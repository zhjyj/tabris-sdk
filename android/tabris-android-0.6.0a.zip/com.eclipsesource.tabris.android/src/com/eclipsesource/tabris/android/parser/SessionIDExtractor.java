/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.parser;

public class SessionIDExtractor {

  private static final String SESSION_ID_FLAG = "jsessionid=";

  public String extract( String snippet ) {
    if( snippet == null ) {
      throw new IllegalArgumentException( "Entry point snippet must not be null." );
    }
    int sessionIDStartIndex = snippet.indexOf( SESSION_ID_FLAG );
    int sessionIDFlagLength = SESSION_ID_FLAG.length();
    if( sessionIDStartIndex > -1 ) {
      return snippet.substring( sessionIDStartIndex + sessionIDFlagLength );
    }
    return null;
  }
}
