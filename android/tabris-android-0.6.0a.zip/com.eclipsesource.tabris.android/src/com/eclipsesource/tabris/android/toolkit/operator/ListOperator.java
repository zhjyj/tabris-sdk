/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.ArrayList;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.List;

public class ListOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.List";

  public ListOperator( UiActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List list = new List( getActivity() );
    initiateNewView( operation, list );
    setItems( operation, list );
  }

  private void setItems( CreateOperation operation, List list ) {
    java.util.List<String> itemsProp = operation.getProperties().getItems();
    String[] items;
    if( itemsProp == null ) {
      items = new String[ 0 ];
      itemsProp = new ArrayList<String>();
    } else {
      items = new String[ itemsProp.size() ];
    }
    new ArrayList<String>( itemsProp ).toArray( items );
    list.setAdapter( new ArrayAdapter<String>( getActivity(),
                                               android.R.layout.simple_list_item_1,
                                               android.R.id.text1,
                                               items ) );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final List view = ( List )findViewByTarget( operation );
    view.setOnItemClickListener( new OnItemClickListener() {

      public void onItemClick( AdapterView<?> arg0, View arg1, int arg2, long arg3 ) {
        System.out.println( arg2 + " " + arg3 );
        getActivity().getProcessor()
          .processPostRequest( createRequestParam( view, Integer.toString( arg2 ) ) );
      }

      private PostRequest createRequestParam( List view, String selectedIndex ) {
        PostRequest request = new PostRequest();
        String widgetId = ( String )view.getTag();
        request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, widgetId );
        request.addParam( widgetId + IProtocolConstants.SELECTION_POSTFIX, selectedIndex );
        return request;
      }
    } );
  }
}
