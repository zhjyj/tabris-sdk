/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.os.Build;
import android.widget.LinearLayout.LayoutParams;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;

public class SeparatorToolItem extends ToolItem {

  private static final int VERTICAL_PADDING = 1;

  private final int verticalPadding;

  public SeparatorToolItem( UiActivity activity ) {
    super( activity );
    if( Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB ) {
      setBackgroundResource( ThemeUtil.getAttrResId( activity, R.attr.toolbarSeparatorColor ) );
    } else {
      setBackgroundResource( ThemeUtil.getAttrResId( activity, R.attr.toolbarSeparatorGradiant ) );
    }
    verticalPadding = activity.getProcessor()
      .getWidgetToolkit()
      .multiplyByDensityFactor( VERTICAL_PADDING );
  }

  @Override
  public LayoutParams createLayoutParams() {
    LayoutParams layoutParams = new LayoutParams( verticalPadding, LayoutParams.FILL_PARENT );
    layoutParams.topMargin = verticalPadding;
    layoutParams.bottomMargin = verticalPadding;
    return layoutParams;
  }

  @Override
  public void setHorizontalSpacing( int itemSpacing ) {
    LayoutParams params = ( LayoutParams )getLayoutParams();
    int extendedSpacing = itemSpacing * 2;
    params.leftMargin = extendedSpacing;
    params.rightMargin = extendedSpacing;
  }
}
