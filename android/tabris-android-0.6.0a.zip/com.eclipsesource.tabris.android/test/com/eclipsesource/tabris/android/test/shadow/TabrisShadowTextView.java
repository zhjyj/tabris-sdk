/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.graphics.drawable.Drawable;
import android.widget.TextView;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowTextView;

@Implements(TextView.class)
public class TabrisShadowTextView extends ShadowTextView {

  private Drawable leftDrawable;
  private Drawable topDrawable;
  private Drawable rightDrawable;
  private Drawable bottomDrawable;
  private boolean includepad = true;

  @Override
  @Implementation
  public void setCompoundDrawablesWithIntrinsicBounds( Drawable left,
                                                       Drawable top,
                                                       Drawable right,
                                                       Drawable bottom )
  {
    this.leftDrawable = left;
    this.topDrawable = top;
    this.rightDrawable = right;
    this.bottomDrawable = bottom;

  }

  @Override
  @Implementation
  public Drawable[] getCompoundDrawables() {
    return new Drawable[]{
      leftDrawable, topDrawable, rightDrawable, bottomDrawable
    };

  }

  public boolean getIncludeFontPadding() {
    return includepad;
  }

  @Implementation
  public void setIncludeFontPadding( boolean includepad ) {
    this.includepad = includepad;
  }

}
