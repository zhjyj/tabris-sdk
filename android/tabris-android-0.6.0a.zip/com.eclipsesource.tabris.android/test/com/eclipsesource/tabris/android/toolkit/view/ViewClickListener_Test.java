/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ViewClickListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ViewClickListener_Test {

  private static final String WIDGET_ID = "w2";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new ViewClickListener( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOnClickNullArg() throws Exception {
    ViewClickListener listener = new ViewClickListener( new UiActivity() );
    listener.onClick( null );
  }

  @Test
  public void testOnClick() throws Exception {
    UiActivity activity = new UiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ViewClickListener listener = new ViewClickListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, WIDGET_ID );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );

    listener.onClick( view );

    verify( processor ).processPostRequest( request );
  }

}
