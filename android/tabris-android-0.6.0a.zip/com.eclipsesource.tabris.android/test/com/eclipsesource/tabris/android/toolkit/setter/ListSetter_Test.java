/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.setter.ListSetter;
import com.eclipsesource.tabris.android.toolkit.view.List;

public class ListSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ListSetter<List> setter = new ListSetter<List>();
    setter.execute( mock( UiActivity.class ), null, mock( SetProperties.class ) );
  }
}
