/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateFocusChangeListener;

import android.view.View;
import android.view.View.OnFocusChangeListener;

public class CompositeFocusListener_Test {

  class OneOnFocusChangeListener implements OnFocusChangeListener {

    public void onFocusChange( View v, boolean hasFocus ) {

    }
  }
  class AnotherOnFocusChangeListener implements OnFocusChangeListener {

    public void onFocusChange( View v, boolean hasFocus ) {

    }
  }

  @Test
  public void testAddListener() {
    CompositeFocusListener listener = new CompositeFocusListener();
    ImmediateFocusChangeListener newListener = mock( ImmediateFocusChangeListener.class );

    listener.addListener( newListener );

    assertEquals( 1, listener.getSize() );
  }

  @Test
  public void testAddNullListener() {
    CompositeFocusListener listener = new CompositeFocusListener();

    listener.addListener( null );

    assertEquals( 1, listener.getSize() );
  }

  @Test
  public void testRemoveListener() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    ImmediateFocusChangeListener newListener = mock( ImmediateFocusChangeListener.class );
    listener.addListener( newListener );

    listener.removeListener( newListener );

    assertEquals( 0, listener.getSize() );
  }

  @Test
  public void testRemoveNonAddedListener() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    ImmediateFocusChangeListener newListener = mock( ImmediateFocusChangeListener.class );
    ImmediateFocusChangeListener nonAddedListener = mock( ImmediateFocusChangeListener.class );
    listener.addListener( newListener );

    listener.removeListener( nonAddedListener );

    assertEquals( 1, listener.getSize() );
  }

  @Test
  public void testRemoveListenerFromEmptyCompositeListener() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    ImmediateFocusChangeListener newListener = mock( ImmediateFocusChangeListener.class );

    listener.removeListener( newListener );

    assertEquals( 0, listener.getSize() );
  }

  @Test
  public void testRemoveListeners() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    listener.addListener( new OneOnFocusChangeListener() );
    listener.addListener( new OneOnFocusChangeListener() );
    listener.addListener( new AnotherOnFocusChangeListener() );

    listener.removeListeners( OneOnFocusChangeListener.class );

    assertEquals( 1, listener.getSize() );
  }

  @Test
  public void testOnFocusChangeWithoutAnyListeners() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    View mockView = mock( View.class );

    listener.onFocusChange( mockView, true );
  }

  @Test
  public void testOnFocusChangePropagatesToMultipleListeners() throws Exception {
    CompositeFocusListener listener = new CompositeFocusListener();
    View mockView = mock( View.class );
    ImmediateFocusChangeListener first = mock( ImmediateFocusChangeListener.class );
    ImmediateFocusChangeListener second = mock( ImmediateFocusChangeListener.class );
    listener.addListener( first );
    listener.addListener( second );

    listener.onFocusChange( mockView, true );

    verify( first ).onFocusChange( eq( mockView ), eq( true ) );
    verify( second ).onFocusChange( eq( mockView ), eq( true ) );
  }

}
