/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Path;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.MoveToGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class MoveToGcOperation_Test {

  @Test
  @SuppressWarnings("unchecked")
  public void testExecute() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 10f ) ).thenReturn( 20f );
    when( toolkit.multiplyByDensityFactor( 30f ) ).thenReturn( 60f );
    GraphicalContext gc = mock( GraphicalContext.class );
    Path path = mock( Path.class );
    when( gc.getPath() ).thenReturn( path );
    IGcOperation op = new MoveToGcOperation( activity );

    op.execute( gc, Arrays.asList( op.getOperation(), 10f, 30f ) );

    verify( path ).moveTo( 20f, 60f );
  }
}
