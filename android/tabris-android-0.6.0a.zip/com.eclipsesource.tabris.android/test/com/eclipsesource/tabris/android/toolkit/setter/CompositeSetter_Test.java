/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.setter.CompositeSetter;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CompositeSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() {
    CompositeSetter<Composite> compositeSetter = new CompositeSetter<Composite>();
    compositeSetter.execute( mock( UiActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test
  public void testSetterFound() {
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = new SetterManager().getViewSetter();

    Assert.assertTrue( "CompositeSetter not found in SetterUtil's list of setters.",
                       viewSetter.containsKey( Composite.class ) );
  }

  @Test
  public void testSetZorderOnChildren() {
    CompositeSetter<Composite> compositeSetter = new CompositeSetter<Composite>();
    Composite composite = mock( Composite.class );
    View child1 = mock( View.class );
    View child2 = mock( View.class );
    when( composite.findViewWithTag( "w1" ) ).thenReturn( child1 );
    when( composite.findViewWithTag( "w2" ) ).thenReturn( child2 );
    SetProperties properties = new SetProperties();
    properties.setChildren( new ArrayList<String>( Arrays.asList( "w2", "w1" ) ) );

    compositeSetter.execute( mock( UiActivity.class ), composite, properties );

    InOrder inOrder = inOrder( composite );
    inOrder.verify( composite ).bringChildToFront( child1 );
    inOrder.verify( composite ).bringChildToFront( child2 );
    verify( composite ).invalidate();
  }
}
