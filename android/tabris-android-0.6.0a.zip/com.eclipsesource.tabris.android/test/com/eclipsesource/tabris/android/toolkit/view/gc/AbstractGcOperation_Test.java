/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.AbstractGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class AbstractGcOperation_Test {

  class OpUnderTest extends AbstractGcOperation {

    public OpUnderTest( String operation, UiActivity activity ) {
      super( operation, activity );
    }

    public OpUnderTest( String op ) {
      super( op );
    }

    public void execute( GraphicalContext gc, List<?> properties ) {
      // nothing to do here
    }

  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullOp() {
    new OpUnderTest( null, new UiActivity() );
  }

  @Test
  public void testConstructorAndGetter() throws Exception {
    String operation = "operation";
    UiActivity activity = new UiActivity();

    OpUnderTest op = new OpUnderTest( operation, activity );

    assertEquals( operation, op.getOperation() );
    assertEquals( activity, op.getActivity() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAssertPropertiesSizeNullList() throws Exception {
    OpUnderTest op = new OpUnderTest( "op" );

    op.assertPropertiesSize( null, 0 );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAssertPropertiesSizeIllegal() throws Exception {
    OpUnderTest op = new OpUnderTest( "op" );

    op.assertPropertiesSize( Arrays.asList( "a" ), 2 );
  }

  @Test
  public void testAssertPropertiesSizeOk() throws Exception {
    OpUnderTest op = new OpUnderTest( "op" );

    op.assertPropertiesSize( Arrays.asList( "a", "b" ), 2 );
  }

  public void testGetScaledFloat() throws Exception {
    UiActivity uiActivity = UiTestUtil.createUiActivity();
    IWidgetToolkit toolkit = uiActivity.getProcessor().getWidgetToolkit();
    Mockito.when( toolkit.multiplyByDensityFactor( 2.6f ) ).thenReturn( 5.2f );
    OpUnderTest op = new OpUnderTest( "op", uiActivity );

    float scaledFloat = op.getScaledFloat( Arrays.asList( 3.5, 2.6 ), 1 );

    assertEquals( 5.2f, scaledFloat, 0 );
  }
}