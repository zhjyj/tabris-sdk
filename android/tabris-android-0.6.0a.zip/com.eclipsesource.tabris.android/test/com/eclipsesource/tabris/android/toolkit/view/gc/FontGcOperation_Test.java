/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Paint;
import android.graphics.Typeface;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.FontGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class FontGcOperation_Test {

  class OpUnderTest extends FontGcOperation {

    private final List<String> fonts;

    public OpUnderTest( UiActivity activity, List<String> fonts ) {
      super( activity );
      this.fonts = fonts;
    }

    @Override
    protected Typeface getTypeface( List<?> fontNames, Boolean bold, Boolean italic ) {
      assertTrue( bold );
      assertTrue( italic );
      assertEquals( fonts, fontNames );
      return mock( Typeface.class );
    }
  }

  @Test
  public void test() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 12 ) ).thenReturn( 24 );
    List<String> fonts = Arrays.asList( "Arial", "Veradana" );
    FontGcOperation op = new OpUnderTest( activity, fonts );
    GraphicalContext gc = mock( GraphicalContext.class );
    Paint paint = mock( Paint.class );
    when( gc.getPaint() ).thenReturn( paint );

    op.execute( gc, Arrays.asList( op.getOperation(), Arrays.asList( fonts, 12, true, true ) ) );

    verify( paint ).setTextSize( eq( 24f ) );
    verify( paint ).setTypeface( any( Typeface.class ) );
  }
}
