/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.ListView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.SelectionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SelectionTreeItemClickListener_Test {

  private static final String TREE_ID = "w9";
  private static final String TREE_ITEM_ID = "w12";
  private TreeItemView treeItemView;
  private TreeView treeView;
  private UiActivity activity;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    activity = new UiActivity();
    processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    treeView = mock( TreeView.class );
    ListView listView = mock( ListView.class );
    when( listView.getParent() ).thenReturn( treeView );
    when( treeView.getTag() ).thenReturn( TREE_ID );
    when( treeView.getListView() ).thenReturn( listView );
    treeItemView = new TreeItemView( activity );
    treeItemView.setTreeView( treeView );
    treeItemView.setTag( TREE_ITEM_ID );
  }

  @Test
  public void testTreeClickTriggersSelectionOk() {
    SelectionTreeItemClickListener listener = new SelectionTreeItemClickListener( activity );
    ArrayList<TreeItemView> children = new ArrayList<TreeItemView>();
    children.add( treeItemView );
    when( treeView.getCurrentTreeItems() ).thenReturn( children );
    PostRequest request = new PostRequest();
    request.addParam( TREE_ID + IProtocolConstants.SELECTION_POSTFIX, TREE_ITEM_ID );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, TREE_ID );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED_ITEM, TREE_ITEM_ID );

    listener.onItemClick( treeView.getListView(), treeItemView, 0, 123 );

    verify( processor ).processPostRequest( request );
  }
}
