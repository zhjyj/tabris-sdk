/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.TreeViewAdapter;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeView_Test {

  private static final String TREE_VIEW_ID = "w1";
  private static final String TREE_ITEM_VIEW_ID = "w2";

  private UiActivity activity;

  @Before
  public void setUp() {
    activity = new UiActivity();
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testAddUnsupportedChildView() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.addView( mock( View.class ) );
  }

  @Test
  public void testAddTreeItem() throws Exception {
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = mock( TreeViewAdapter.class );
    treeView.setAdapter( adapter );

    assertTrue( treeView.getCurrentTreeItems().isEmpty() );

    treeView.addView( mock( TreeItemView.class ) );

    assertEquals( 1, treeView.getCurrentTreeItems().size() );
  }

  @Test
  public void testGetIndexOf() throws Exception {
    TreeView treeView = new TreeView( activity );
    TreeItemView item1 = mock( TreeItemView.class );
    TreeItemView item2 = mock( TreeItemView.class );
    treeView.addView( item1 );
    treeView.addView( item2 );

    assertEquals( 2, treeView.getCurrentTreeItems().size() );

    assertEquals( 0, treeView.indexOfChild( item1 ) );
    assertEquals( 1, treeView.indexOfChild( item2 ) );
  }

  @Test
  public void testRemoveViewAt() throws Exception {
    TreeView treeView = new TreeView( activity );
    TreeItemView item1 = mock( TreeItemView.class );
    TreeItemView item2 = mock( TreeItemView.class );
    treeView.addView( item1 );
    treeView.addView( item2 );

    assertEquals( 2, treeView.getCurrentTreeItems().size() );

    treeView.removeViewAt( 0 );

    assertEquals( 1, treeView.getCurrentTreeItems().size() );
    assertEquals( 0, treeView.indexOfChild( item2 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFindViewTagTraversalWithNullParam() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.findViewWithTagTraversal( null );
  }

  @Test
  public void testFindViewTagTraversalSelf() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.setTag( TREE_VIEW_ID );
    assertSame( treeView, treeView.findViewWithTagTraversal( TREE_VIEW_ID ) );
  }

  @Test
  public void testFindViewTagTraversalCurTreeItem() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.setTag( TREE_VIEW_ID );
    TreeItemView item1 = new TreeItemView( activity );
    item1.setTexts( Arrays.asList( "text" ) );
    item1.setTag( TREE_ITEM_VIEW_ID );
    treeView.addView( item1 );
    treeView.setParentTreeItem( item1 );
    assertSame( item1, treeView.findViewWithTagTraversal( TREE_ITEM_VIEW_ID ) );
  }

  @Test
  public void testFindViewTagTraversalChildTreeItem() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.setTag( TREE_VIEW_ID );
    TreeItemView item1 = new TreeItemView( activity );
    item1.setTexts( Arrays.asList( "text" ) );
    item1.setTag( TREE_ITEM_VIEW_ID );
    treeView.addView( item1 );
    assertSame( item1, treeView.findViewWithTagTraversal( TREE_ITEM_VIEW_ID ) );
  }

  @Test
  public void testSetCurrentItem() throws Exception {
    TreeView treeView = new TreeView( activity );
    treeView.setTag( TREE_VIEW_ID );
    TreeItemView item1 = new TreeItemView( activity );
    item1.setTexts( Arrays.asList( "text" ) );
    item1.setTag( TREE_ITEM_VIEW_ID );
    treeView.addView( item1 );

    treeView.setParentTreeItem( item1 );

    assertSame( item1, treeView.getParentTreeItem() );
    TextView headerText = ( TextView )treeView.findViewById( R.id.tree_header_label );
    assertEquals( "text", headerText.getText() );
  }

  @Test
  public void testSetGetHasVirtualTreeSupport() throws Exception {
    TreeView treeView = new TreeView( activity );
    ListView listView = mock( ListView.class );
    treeView.setListView( listView );
    VirtualTreeSupport support = mock( VirtualTreeSupport.class );

    assertFalse( treeView.hasVirtualTreeSupport() );
    assertNull( treeView.getVirtualTreeSupport() );

    treeView.setVirtualTreeSupport( support );

    assertTrue( treeView.hasVirtualTreeSupport() );
    assertSame( support, treeView.getVirtualTreeSupport() );
    verify( listView ).setOnScrollListener( support );
  }

  @Test
  public void testRefreshTree() throws Exception {
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = mock( TreeViewAdapter.class );
    treeView.getListView().setAdapter( adapter );

    treeView.refreshTree();

    verify( adapter ).notifyDataSetChanged();
  }
}
