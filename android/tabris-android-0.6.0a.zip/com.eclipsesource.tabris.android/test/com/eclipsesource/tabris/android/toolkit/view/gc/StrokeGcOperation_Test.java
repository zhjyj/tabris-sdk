/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.util.Arrays;

import org.junit.Test;

import android.graphics.Paint.Style;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;

public class StrokeGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new FillGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );

    op.execute( gc, Arrays.asList( op.getOperation() ) );

    verify( gc ).setStyle( Style.FILL );
    verify( gc ).drawCurrentPath();
  }

}
