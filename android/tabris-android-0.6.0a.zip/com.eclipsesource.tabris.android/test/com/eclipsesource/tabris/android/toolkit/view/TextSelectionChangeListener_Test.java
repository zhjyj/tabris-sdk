/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import junit.framework.Assert;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.TextSelectionChangeListener;

public class TextSelectionChangeListener_Test {

  @Test
  public void testCreate() {
    Assert.assertNotNull( new TextSelectionChangeListener( null, null ) );
  }

}
