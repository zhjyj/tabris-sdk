/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.state.ListVisibleState;

public class ListVisibleState_Test {

  private static final String WIDGET_ID = "w23";

  @Test
  public void testGenerateKey() {
    ListVisibleState state = new ListVisibleState( WIDGET_ID, true );

    assertEquals( WIDGET_ID + IProtocolConstants.LIST_VISIBLE_POSTFIX, state.generateKey() );
  }

  @Test
  public void testGenerateValue() {
    ListVisibleState state = new ListVisibleState( WIDGET_ID, true );

    assertEquals( Boolean.TRUE.toString(), state.generateValue() );
  }

}
