/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollXState;

public class ScrollXState_Test {

  @Test
  public void testGenerateKey() {
    ScrollXState state = new ScrollXState( "w4" );

    assertEquals( "w4" + IProtocolConstants.SCROLL_X_POSTFIX, state.generateKey() );
  }

  @Test
  public void testGenerateValue() {
    ScrollXState state = new ScrollXState( "w4" );
    state.setScrollX( 400 );

    assertEquals( "400", state.generateValue() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetWidgetIdNull() {
    ScrollXState state = new ScrollXState( "" );
    state.setWidgetId( null );
  }
}
