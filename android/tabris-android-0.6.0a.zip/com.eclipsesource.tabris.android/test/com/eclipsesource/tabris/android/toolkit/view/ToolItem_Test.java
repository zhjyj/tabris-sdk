/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.widget.LinearLayout.LayoutParams;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolItem_Test {

  @Test
  public void testCreateLayoutParams() {
    ToolItem toolItem = new ToolItem( new Activity() );

    LayoutParams params = toolItem.createLayoutParams();

    assertEquals( LayoutParams.WRAP_CONTENT, params.width );
    assertEquals( LayoutParams.FILL_PARENT, params.height );
  }

  @Test
  public void testSetHorizontalSpacing() {
    ToolItem toolItem = new ToolItem( new Activity() );
    ToolItem spyToolItem = spy( toolItem );

    spyToolItem.setHorizontalSpacing( 10 );

    verify( spyToolItem ).setPadding( 10, 0, 10, 0 );
  }

  @Test
  public void testSetGetParentToolBar() throws Exception {
    ToolItem toolItem = new ToolItem( new UiActivity() );
    ToolBar toolBar = mock( ToolBar.class );

    assertNull( toolItem.getParentToolBar() );

    toolItem.setParentToolBar( toolBar );

    assertSame( toolBar, toolItem.getParentToolBar() );
  }
}
