/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectedItemState;

public class SelectedItemState_Test {

  private static final String WIDGET_ID = "w23";

  @Test
  public void testGenerateKey() {
    SelectedItemState state = new SelectedItemState( WIDGET_ID, 5 );

    assertEquals( WIDGET_ID + IProtocolConstants.SELECTED_ITEM_POSTFIX, state.generateKey() );
  }

  @Test
  public void testGenerateValue() {
    SelectedItemState state = new SelectedItemState( WIDGET_ID, 6 );

    assertEquals( "6", state.generateValue() );
  }

}
