/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.IDateTimeSpinnerDialog;
import com.eclipsesource.tabris.android.toolkit.view.RecordingDateTimeChangedListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
@SuppressWarnings("unchecked")
public class DateTimeSpinner_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeSpinnerNullContext() {
    new DateTimeSpinner( null, mock( ArrayAdapter.class ), mock( IDateTimeSpinnerDialog.class ), "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeSpinnerNullAdapter() {
    new DateTimeSpinner( mock( Context.class ), null, mock( IDateTimeSpinnerDialog.class ), "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeSpinnerNullDialog() {
    new DateTimeSpinner( mock( Context.class ), mock( ArrayAdapter.class ), null, "" );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDateTimeSpinnerNullDateFormat() {
    new DateTimeSpinner( mock( Context.class ),
                         mock( ArrayAdapter.class ),
                         mock( IDateTimeSpinnerDialog.class ),
                         null );
  }

  @Test
  public void testPerformClick() throws Exception {
    IDateTimeSpinnerDialog dialog = mock( IDateTimeSpinnerDialog.class );
    DateTimeSpinner spinner = new DateTimeSpinner( mock( Context.class ),
                                                   mock( ArrayAdapter.class ),
                                                   dialog,
                                                   "" );

    spinner.performClick();

    verify( dialog ).reset();
    verify( dialog ).show();
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testSetDate() throws Exception {
    IDateTimeSpinnerDialog dialog = mock( IDateTimeSpinnerDialog.class );
    ArrayAdapter adapter = mock( ArrayAdapter.class );
    DateTimeSpinner spinner = new DateTimeSpinner( mock( Context.class ), adapter, dialog, "yyyy" );
    IDateTimeChangedListener listener = mock( IDateTimeChangedListener.class );
    spinner.addListener( listener );
    Calendar calendar = Calendar.getInstance();

    spinner.setDate( calendar.getTime() );

    verify( adapter ).clear();
    verify( adapter ).add( String.valueOf( calendar.get( Calendar.YEAR ) ) );
    verify( listener ).dateTimeChanged( spinner );
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testAddRemoveListeners() throws Exception {
    IDateTimeSpinnerDialog dialog = mock( IDateTimeSpinnerDialog.class );
    ArrayAdapter adapter = mock( ArrayAdapter.class );
    DateTimeSpinner spinner = new DateTimeSpinner( mock( Context.class ), adapter, dialog, "yyyy" );
    IDateTimeChangedListener listener = new RecordingDateTimeChangedListener( mock( StateRecorder.class ),
                                                                              mock( HashMap.class ) );
    spinner.addListener( listener );

    assertEquals( 1, spinner.getListeners().size() );

    spinner.removeListeners( RecordingDateTimeChangedListener.class );

    assertEquals( 0, spinner.getListeners().size() );
  }
}
