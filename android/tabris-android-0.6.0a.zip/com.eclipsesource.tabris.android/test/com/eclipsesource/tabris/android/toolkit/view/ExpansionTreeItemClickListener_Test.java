/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.ListView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.ExpansionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ExpansionTreeItemClickListener_Test {

  private static final String TREE_ID = "w9";
  private static final String TREE_ITEM_ID = "w12";
  private TreeItemView treeItemView;
  private TreeView treeView;
  private UiActivity activity;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    activity = new UiActivity();
    processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    treeView = mock( TreeView.class );
    ListView listView = mock( ListView.class );
    when( listView.getParent() ).thenReturn( treeView );
    when( treeView.getListView() ).thenReturn( listView );
    treeItemView = new TreeItemView( activity );
    treeItemView.setTreeView( treeView );
    treeItemView.setTag( TREE_ITEM_ID );
  }

  @Test
  public void testTreeClickTriggersExpandOk() {
    ExpansionTreeItemClickListener listener = new ExpansionTreeItemClickListener( activity );
    treeItemView.addView( new TreeItemView( activity ) );
    ArrayList<TreeItemView> children = new ArrayList<TreeItemView>();
    children.add( treeItemView );
    when( treeView.getCurrentTreeItems() ).thenReturn( children );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_TREE_EXPANDED, TREE_ITEM_ID );

    listener.onItemClick( treeView.getListView(), mock( View.class ), 0, 123 );

    verify( processor ).processPostRequest( request );
    verify( treeView, never() ).getVirtualTreeSupport();
    verify( treeView ).hasVirtualTreeSupport();
  }

  @Test
  public void testVirtualTreeSupport() throws Exception {
    ExpansionTreeItemClickListener listener = new ExpansionTreeItemClickListener( activity );
    treeItemView.addView( new TreeItemView( activity ) );
    ArrayList<TreeItemView> children = new ArrayList<TreeItemView>();
    children.add( treeItemView );
    when( treeView.getCurrentTreeItems() ).thenReturn( children );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_TREE_EXPANDED, TREE_ITEM_ID );
    request.addParam( TREE_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, "32" );
    when( treeView.hasVirtualTreeSupport() ).thenReturn( true );
    VirtualTreeSupport support = mock( VirtualTreeSupport.class );
    PostRequest virtualTreeRequest = new PostRequest();
    virtualTreeRequest.addParam( TREE_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, "32" );
    when( support.createTopItemRequest( treeView, treeItemView ) ).thenReturn( virtualTreeRequest );
    when( treeView.getVirtualTreeSupport() ).thenReturn( support );

    listener.onItemClick( treeView.getListView(), mock( View.class ), 0, 123 );

    verify( support ).reset();
    verify( processor ).processPostRequest( request );
  }
}
