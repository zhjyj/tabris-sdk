/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAsyncTask;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapDrawable;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowBitmapFactory;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.DrawImageGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DrawImageGcOperation_Test {

  @Test
  @SuppressWarnings("unchecked")
  public void testExecuteDrawImageDirect() {
    UiActivity activity = createUiActivity();
    GraphicalContext gc = mock( GraphicalContext.class );
    when( gc.getPaint() ).thenReturn( mock( Paint.class ) );
    Canvas canvas = mock( Canvas.class );
    when( gc.getCanvas() ).thenReturn( canvas );
    IGcOperation op = new DrawImageGcOperation( activity );
    String operation = op.getOperation();
    List<?> properties = Arrays.asList( operation, "/image/path", 100, 50 );

    op.execute( gc, properties );

    verify( canvas ).drawBitmap( any( Bitmap.class ), eq( 200f ), eq( 100f ), any( Paint.class ) );
    verify( gc ).invalidate();
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    verify( cache ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testExecuteDrawImageScaled() {
    UiActivity activity = createUiActivity();
    IGcOperation op = new DrawImageGcOperation( activity );
    GraphicalContext gc = mock( GraphicalContext.class );
    when( gc.getPaint() ).thenReturn( mock( Paint.class ) );
    Canvas canvas = mock( Canvas.class );
    when( gc.getCanvas() ).thenReturn( canvas );

    op.execute( gc,
                Arrays.asList( op.getOperation(), "/image/path", 100, 50, 100, 50, 100, 50, 100, 50 ) );

    // we can not easily assert the concrete parameters because Rect and RectF
    // do not implement equals/hashcode. Could use custom mockito Matcher
    // instead
    verify( canvas ).drawBitmap( any( Bitmap.class ),
                                 any( Rect.class ),
                                 any( RectF.class ),
                                 any( Paint.class ) );
    verify( gc ).invalidate();
  }

  private UiActivity createUiActivity() {
    Robolectric.bindShadowClass( TabrisShadowBitmapFactory.class );
    Robolectric.bindShadowClass( TabrisShadowBitmapDrawable.class );
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    UiActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    ProtocolProcessor processor = activity.getProcessor();
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 100f ) ).thenReturn( 200f );
    when( toolkit.multiplyByDensityFactor( 50f ) ).thenReturn( 100f );
    ITransportResult transportResult = mock( ITransportResult.class );
    InputStream is = new ByteArrayInputStream( new byte[]{
      'a', 'b', 'c'
    } );
    when( transportResult.getResult() ).thenReturn( is );
    when( processor.processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    return activity;
  }
}
