/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Bitmap;
import android.graphics.Paint;
import android.view.MotionEvent;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.ClientGraphicalContext;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Canvas_Test {

  private Canvas canvas;

  @Test
  public void testConstructorOk() throws Exception {
    Canvas canvas = new Canvas( new UiActivity() );

    assertFalse( canvas.willNotDraw() );
  }

  @Before
  public void setUp() {
    canvas = new Canvas( new UiActivity() );
  }

  @Test
  public void testInitCanvasNew() {
    assertNull( canvas.getCanvas() );

    canvas.initCanvas( 100, 50 );

    android.graphics.Canvas androidCanvas1 = canvas.getCanvas();
    assertNotNull( androidCanvas1 );
    assertEquals( 100, canvas.getBitmap().getWidth() );
    assertEquals( 50, canvas.getBitmap().getHeight() );
  }

  @Test
  public void testInitCanvas() {
    assertNull( canvas.getCanvas() );

    canvas.initCanvas( 100, 50 );

    android.graphics.Canvas androidCanvas1 = canvas.getCanvas();
    assertNotNull( androidCanvas1 );
    assertEquals( 100, canvas.getBitmap().getWidth() );
    assertEquals( 50, canvas.getBitmap().getHeight() );

    canvas.initCanvas( 100, 100 );

    android.graphics.Canvas androidCanvas2 = canvas.getCanvas();
    assertNotSame( androidCanvas1, androidCanvas2 );
  }

  @Test
  public void testInitCanvasNewWithZeroDims() {
    assertNull( canvas.getCanvas() );

    canvas.initCanvas( 0, 0 );

    android.graphics.Canvas androidCanvas1 = canvas.getCanvas();
    assertNotNull( androidCanvas1 );
    assertNull( canvas.getBitmap() );
  }

  @Test
  public void testInitCanvasToZeroDims() {
    assertNull( canvas.getCanvas() );

    canvas.initCanvas( 100, 50 );

    android.graphics.Canvas androidCanvas1 = canvas.getCanvas();
    assertNotNull( androidCanvas1 );
    assertEquals( 100, canvas.getBitmap().getWidth() );
    assertEquals( 50, canvas.getBitmap().getHeight() );

    canvas.initCanvas( 0, 0 );

    android.graphics.Canvas androidCanvas2 = canvas.getCanvas();
    assertNotSame( androidCanvas1, androidCanvas2 );
    assertNull( canvas.getBitmap() );
  }

  @Test
  public void testInitCanvasWithSameDims() {
    canvas.initCanvas( 100, 50 );

    android.graphics.Canvas androidCanvas = mock( android.graphics.Canvas.class );
    when( androidCanvas.getWidth() ).thenReturn( 100 );
    when( androidCanvas.getHeight() ).thenReturn( 50 );
    canvas.setCanvas( androidCanvas );

    canvas.initCanvas( 100, 50 );

    verify( androidCanvas ).drawPaint( any( Paint.class ) );
  }

  @Test
  public void testOnDrawCanvasZeroSize() {
    android.graphics.Canvas androidCanvas = mock( android.graphics.Canvas.class );
    canvas.initCanvas( 0, 0 );
    Bitmap bitmap = canvas.getBitmap();

    canvas.onDraw( androidCanvas );

    verify( androidCanvas, never() ).drawBitmap( bitmap, 0, 0, Canvas.BITMAP_PAINT );
  }

  @Test
  public void testOnDrawCanvas() {
    android.graphics.Canvas androidCanvas = mock( android.graphics.Canvas.class );
    canvas.initCanvas( 100, 50 );
    Bitmap bitmap = canvas.getBitmap();

    canvas.onDraw( androidCanvas );

    verify( androidCanvas ).drawBitmap( bitmap, 0, 0, Canvas.BITMAP_PAINT );
  }

  @Test
  public void testDestroyNull() {
    assertNull( canvas.getBitmap() );

    canvas.destroyBitmap();

    assertNull( canvas.getBitmap() );
  }

  @Test
  public void testDestroy() {
    canvas.initCanvas( 100, 50 );
    Bitmap bitmap = canvas.getBitmap();

    canvas.destroyBitmap();

    assertTrue( bitmap.isRecycled() );
  }

  @Test
  public void testOnTouchEventForward() throws Exception {
    canvas.setClientDrawingEnabled( true );
    ClientGraphicalContext gc = mock( ClientGraphicalContext.class );
    MotionEvent event = mock( MotionEvent.class );
    when( gc.onTouchEvent( event ) ).thenReturn( true );
    canvas.setGc( gc );

    boolean result = canvas.onTouchEvent( event );

    assertTrue( result );
    verify( gc ).onTouchEvent( event );
  }

  @Test
  public void testOnTouchEventConsum() throws Exception {
    canvas.setClientDrawingEnabled( false );
    ClientGraphicalContext gc = mock( ClientGraphicalContext.class );
    canvas.setGc( gc );
    MotionEvent event = mock( MotionEvent.class );

    boolean result = canvas.onTouchEvent( event );

    assertFalse( result );
    verify( gc, never() ).onTouchEvent( event );
  }
}
