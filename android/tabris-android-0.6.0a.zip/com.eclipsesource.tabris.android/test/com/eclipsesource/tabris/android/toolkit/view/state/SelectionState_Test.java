/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectionState;

public class SelectionState_Test {

  private static final String WIDGET_ID = "w23";

  @Test
  public void testGenerateKey() {
    SelectionState state = new SelectionState( WIDGET_ID, true );

    assertEquals( WIDGET_ID + IProtocolConstants.SELECTION_POSTFIX, state.generateKey() );
  }

  @Test
  public void testGenerateValue() {
    SelectionState state = new SelectionState( WIDGET_ID, true );

    assertEquals( "true", state.generateValue() );
  }

}
