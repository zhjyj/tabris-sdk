/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class VirtualTreeSupport_Test {

  private static final String WIDGET_ID = "w2";

  class VirtualTreeSupportUnderTest extends VirtualTreeSupport {

    private boolean resetCalled;

    public VirtualTreeSupportUnderTest( UiActivity activity ) {
      super( activity );
    }

    @Override
    public void reset() {
      super.reset();
      resetCalled = true;
    }

    public boolean isResetCalled() {
      return resetCalled;
    }

  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullActivity() throws Exception {
    new VirtualTreeSupport( null );
  }

  @Test
  public void testConstructorOk() throws Exception {
    VirtualTreeSupportUnderTest support = new VirtualTreeSupportUnderTest( new UiActivity() );
    assertTrue( support.isResetCalled() );
  }

  @Test
  public void testScrollOnTreeWithZeroElementsItem() throws Exception {
    UiActivity activity = new UiActivity();
    VirtualTreeSupportUnderTest support = new VirtualTreeSupportUnderTest( activity );
    TreeView treeView = new TreeView( activity );

    support.onScroll( treeView.getListView(), 23, 5, 100 );

    assertTrue( support.isResetCalled() );
  }

  @Test
  public void testSendsRequestWhenScrollingOnTopLevel() {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    treeView.setTag( WIDGET_ID );
    treeView.getParentTreeItem().setItemCount( 10 );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, String.valueOf( 28 ) );
    VirtualTreeSupport support = new VirtualTreeSupport( activity );

    support.onScroll( treeView.getListView(), 23, 5, 100 );

    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testSendsRequestWhenScrollingOnChildLevel() {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    treeView.setTag( WIDGET_ID );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    TreeItemView treeItem0 = new TreeItemView( activity );
    rootTreeItem.addView( treeItem0 );
    TreeItemView treeItem1 = new TreeItemView( activity );
    treeItem1.setTreeView( treeView );
    treeItem1.setItemCount( 10 );
    treeItem0.addView( treeItem1 );
    treeView.setParentTreeItem( treeItem1 );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, String.valueOf( 29 ) );
    VirtualTreeSupport support = new VirtualTreeSupport( activity );

    support.onScroll( treeView.getListView(), 23, 5, 100 );

    verify( processor ).processPostRequest( request );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetPosInParentNotOnTree() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );

    VirtualTreeSupport.getPosInParentChain( treeView, new TreeItemView( activity ) );
  }

  @Test
  public void testGetPosInParentNested() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeItemView rootItem = treeView.getRootTreeItem();
    TreeItemView item0 = new TreeItemView( activity );
    TreeItemView item1 = new TreeItemView( activity );
    TreeItemView item2 = new TreeItemView( activity );
    TreeItemView item3 = new TreeItemView( activity );
    rootItem.addView( item0 );
    rootItem.addView( item1 );
    item1.addView( item2 );
    item1.addView( item3 );

    assertEquals( 0, VirtualTreeSupport.getPosInParentChain( treeView, item0 ) );
    assertEquals( 1, VirtualTreeSupport.getPosInParentChain( treeView, item1 ) );
    assertEquals( 2, VirtualTreeSupport.getPosInParentChain( treeView, item2 ) );
    assertEquals( 3, VirtualTreeSupport.getPosInParentChain( treeView, item3 ) );
  }

  @Test
  public void testGetPosInParentChained() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeItemView rootItem = treeView.getRootTreeItem();
    TreeItemView item0 = new TreeItemView( activity );
    TreeItemView item1 = new TreeItemView( activity );
    TreeItemView item2 = new TreeItemView( activity );
    TreeItemView item3 = new TreeItemView( activity );
    rootItem.addView( item0 );
    item0.addView( item1 );
    item1.addView( item2 );
    item2.addView( item3 );

    assertEquals( 0, VirtualTreeSupport.getPosInParentChain( treeView, item0 ) );
    assertEquals( 1, VirtualTreeSupport.getPosInParentChain( treeView, item1 ) );
    assertEquals( 2, VirtualTreeSupport.getPosInParentChain( treeView, item2 ) );
    assertEquals( 3, VirtualTreeSupport.getPosInParentChain( treeView, item3 ) );
  }

}
