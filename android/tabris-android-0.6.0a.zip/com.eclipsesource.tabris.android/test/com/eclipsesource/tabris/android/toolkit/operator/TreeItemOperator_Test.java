/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeItemOperator_Test {

  private static final String WIDGET_ID = "w3";

  private static final String PARENT_ID = "w1";

  private UiActivity activity;

  @Before
  public void setup() {
    activity = UiTestUtil.createUiActivityWithoutOnCreate();
    activity.setContentView( R.layout.protocol );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    FrameLayout parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    rootLayout.addView( parentLayout );
  }

  @Test(expected = NullPointerException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeItemNoProps() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeItemNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeItemParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( buttonId );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateTreeItemOk() throws Exception {
    UiActivity activity = UiTestUtil.createUiActivity();
    AbstractWidgetOperator operator = new TreeItemOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof TreeItemView );
    assertEquals( WIDGET_ID, view.getTag() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;

  }

  @Test
  public void testGetType() throws Exception {
    TreeItemOperator op = new TreeItemOperator( new UiActivity() );
    assertEquals( TreeItemOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNullOperation() throws Exception {
    TreeItemOperator operator = new TreeItemOperator( activity );
    operator.destroy( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyNoTarget() throws Exception {
    TreeItemOperator operator = new TreeItemOperator( activity );
    DestroyOperation destroyOperation = new DestroyOperation();
    operator.destroy( destroyOperation );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDestroyTargetDoesNotExist() throws Exception {
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    TreeItemOperator operator = new TreeItemOperator( activity );

    assertNull( rootLayout.findViewWithTag( WIDGET_ID ) );

    operator.destroy( destroyOperation );
  }

  @Test
  public void testDestroyOk() throws Exception {
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( WIDGET_ID );
    TreeView treeView = new TreeView( activity );
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.setTag( WIDGET_ID );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    rootTreeItem.addView( treeItem );
    treeItem.setTag( WIDGET_ID );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.findObjectById( WIDGET_ID, TreeItemView.class ) ).thenReturn( treeItem );
    when( toolkit.findObjectById( WIDGET_ID, View.class ) ).thenReturn( treeItem );
    TreeItemOperator operator = new TreeItemOperator( activity );

    assertTrue( treeView.getRootTreeItem().getChildren().contains( treeItem ) );

    operator.destroy( destroyOperation );

    assertNull( treeView.findViewWithTag( WIDGET_ID ) );
    verify( toolkit.getBitmapCache() ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }
}
