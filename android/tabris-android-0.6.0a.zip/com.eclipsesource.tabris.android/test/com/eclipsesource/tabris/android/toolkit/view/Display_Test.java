/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.view.ViewGroup.LayoutParams;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.ShellAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Display_Test {

  @Test
  public void testOnSizeChangedResizesMaximizedSubShells() {
    UiActivity activity = UiTestUtil.createUiActivity();
    Display disp = new Display( activity );
    disp.onSizeChanged( 0, 0, 0, 0 ); // initializes session
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    Shell shell = new Shell( activity, animSupportMock );
    shell.setMode( Shell.MAXIMIZED );
    shell.setLayoutParams( new LayoutParams( 0, 0 ) );
    disp.addView( shell );
    LayoutParams dispLayout = disp.getLayoutParams();
    LayoutParams expectedLayout = new LayoutParams( shell.getLayoutParams() );
    expectedLayout.width += 10;
    expectedLayout.height += 10;

    disp.onSizeChanged( dispLayout.width + 10,
                        dispLayout.height + 10,
                        dispLayout.width,
                        dispLayout.height );

    LayoutParams currentLayout = shell.getLayoutParams();
    assertEquals( expectedLayout.width, currentLayout.width );
    assertEquals( expectedLayout.height, currentLayout.height );
  }

  @Test
  public void testOnSizeChangedDoesNotResizesNonMaximizedSubShells() {
    UiActivity activity = UiTestUtil.createUiActivity();
    Display disp = new Display( activity );
    disp.onSizeChanged( 0, 0, 0, 0 ); // initializes session
    ShellAnimationSupport animSupportMock = Mockito.mock( ShellAnimationSupport.class );
    Shell shell = new Shell( activity, animSupportMock );
    shell.setLayoutParams( new LayoutParams( 0, 0 ) );
    disp.addView( shell );
    LayoutParams layout = disp.getLayoutParams();
    LayoutParams expectedLayout = new LayoutParams( shell.getLayoutParams() );

    disp.onSizeChanged( layout.width + 10, layout.height + 10, layout.width, layout.height );

    LayoutParams currentLayout = shell.getLayoutParams();
    assertEquals( expectedLayout.width, currentLayout.width );
    assertEquals( expectedLayout.height, currentLayout.height );
  }
}
