/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Path;
import android.graphics.RectF;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.EllipseGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class EllipseGcOperation_Test {

  @Test
  @SuppressWarnings("unchecked")
  public void testExecute() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IGcOperation op = new EllipseGcOperation( activity );
    GraphicalContext gc = mock( GraphicalContext.class );
    Path path = mock( Path.class );
    when( gc.getPath() ).thenReturn( path );

    op.execute( gc, Arrays.asList( op.getOperation(), 1f, 2f, 3f, 4f, 5f, 6f, 7f, 8f ) );

    float start = ( float )( 6f * 180f / Math.PI );
    float angle = ( float )( 7f * 180f / Math.PI );
    verify( path ).addArc( any( RectF.class ), eq( start ), eq( angle - start ) );
  }
}
