/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.StaticLayout;
import android.text.TextPaint;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeTextGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class StrokeTextGcOperation_Test {

  class OpUnderTest extends StrokeTextGcOperation {

    private final StaticLayout staticLayout;

    public OpUnderTest( UiActivity activity ) {
      super( activity );
      staticLayout = mock( StaticLayout.class );
    }

    @Override
    protected StaticLayout createTextLayout( String text, TextPaint textPaint ) {
      Assert.assertEquals( "text", text );
      return staticLayout;
    }

    public StaticLayout getStaticLayout() {
      return staticLayout;
    }
  };

  @Test
  @SuppressWarnings("unchecked")
  public void testExecute() {
    UiActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 12f ) ).thenReturn( 12f );
    when( toolkit.multiplyByDensityFactor( 34f ) ).thenReturn( 34f );
    GraphicalContext gc = mock( GraphicalContext.class );
    Canvas canvas = mock( Canvas.class );
    Paint paint = mock( Paint.class );
    when( gc.getPaint() ).thenReturn( paint );
    when( gc.getCanvas() ).thenReturn( canvas );
    OpUnderTest op = new OpUnderTest( activity );

    op.execute( gc, Arrays.asList( op.getOperation(), "text", true, true, true, 12, 34 ) );

    verify( canvas ).save();
    verify( canvas ).translate( 12, 34 );
    verify( op.getStaticLayout() ).draw( canvas );
    verify( canvas ).restore();
  }
}
