/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.view.View;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowView;

@Implements(View.class)
public class TabrisShadowView extends ShadowView {

  private View.OnFocusChangeListener onFocusChangeListener;
  private boolean isFocused;
  private View.OnLongClickListener onLongClickListener;

  @Implementation
  public View.OnFocusChangeListener getOnFocusChangeListener() {
    return onFocusChangeListener;
  }

  @Override
  @Implementation
  public void setOnFocusChangeListener( View.OnFocusChangeListener listener ) {
    onFocusChangeListener = listener;

  }

  @Override
  public void setViewFocus( boolean hasFocus ) {
    this.isFocused = hasFocus;
    if( onFocusChangeListener != null ) {
      onFocusChangeListener.onFocusChange( realView, hasFocus );
    }
  }

  @Override
  @Implementation
  public boolean isFocused() {
    return isFocused;
  }

  @Override
  @Implementation
  public boolean hasFocus() {
    return isFocused;
  }

  @Override
  @Implementation
  public void setOnLongClickListener( View.OnLongClickListener onLongClickListener ) {
    super.setOnLongClickListener( onLongClickListener );
    this.onLongClickListener = onLongClickListener;
  }

  public View.OnLongClickListener getOnLongClickListener() {
    return this.onLongClickListener;
  }
}
