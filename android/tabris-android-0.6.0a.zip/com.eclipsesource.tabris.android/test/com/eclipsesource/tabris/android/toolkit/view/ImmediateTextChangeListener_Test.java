/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.text.Editable;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateTextChangeListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateTextChangeListener_Test {

  private static final String EDIT_TEXT_ID = "w3";

  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    UiActivity activity = new UiActivity();
    processor = mock( ProtocolProcessor.class );
    StateRecorder stateRecorder = mock( StateRecorder.class );
    when( processor.getStateRecorder() ).thenReturn( stateRecorder );
    activity.setProcessor( processor );
  }

  @Test
  public void testAfterTextChanged() {
    String editTextTag = EDIT_TEXT_ID;
    ImmediateTextChangeListener textChangeListener = new ImmediateTextChangeListener( editTextTag,
                                                                                      processor );
    Editable s = mock( Editable.class );
    PostRequest request = new PostRequest();
    request.addParam( EDIT_TEXT_ID + IProtocolConstants.TEXT_POSTFIX, s.toString() );

    textChangeListener.afterTextChanged( s );

    verify( processor ).processPostRequest( request );
  }
}
