/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.ContractionTreeClickListener;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ContractionTreeClickListener_Test {

  private static final String TREE_ID = "w12";

  @Test
  public void test() {
    UiActivity activity = new UiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    TreeView treeView = mock( TreeView.class );
    TreeItemView treeItem = mock( TreeItemView.class );
    when( treeItem.getTag() ).thenReturn( "w2" );
    when( treeView.getParentTreeItem() ).thenReturn( treeItem );
    ContractionTreeClickListener listener = new ContractionTreeClickListener( activity, treeView );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_TREE_COLLAPSED,
                      ( String )treeView.getParentTreeItem().getTag() );

    listener.onClick( mock( View.class ) );

    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testVirtualTreeSupport() throws Exception {
    UiActivity activity = new UiActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    TreeView treeView = mock( TreeView.class );
    TreeItemView treeItem = mock( TreeItemView.class );
    when( treeItem.getTag() ).thenReturn( "w2" );
    when( treeView.getParentTreeItem() ).thenReturn( treeItem );
    ContractionTreeClickListener listener = new ContractionTreeClickListener( activity, treeView );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_TREE_COLLAPSED,
                      ( String )treeView.getParentTreeItem().getTag() );
    request.addParam( TREE_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, "32" );
    when( treeView.hasVirtualTreeSupport() ).thenReturn( true );
    VirtualTreeSupport support = mock( VirtualTreeSupport.class );
    PostRequest virtualTreeRequest = new PostRequest();
    virtualTreeRequest.addParam( TREE_ID + IProtocolConstants.SCROLL_TOP_ITEM_INDEX, "32" );
    when( support.createTopItemRequest( treeView, treeItem ) ).thenReturn( virtualTreeRequest );
    when( treeView.getVirtualTreeSupport() ).thenReturn( support );

    listener.onClick( mock( View.class ) );

    verify( support ).reset();
    verify( processor ).processPostRequest( request );
  }
}
