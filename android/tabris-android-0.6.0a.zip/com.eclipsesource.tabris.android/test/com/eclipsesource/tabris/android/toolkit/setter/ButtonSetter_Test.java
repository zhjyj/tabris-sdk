/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.setter.ButtonSetter;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ButtonSetter_Test {

  class SetterUnderTest extends ButtonSetter<Button> {

    public Drawable bgDrawable;
    public float r;
    public float g;
    public float b;
    private final int buttonStyle;

    public SetterUnderTest( int buttonStyle ) {
      this.buttonStyle = buttonStyle;
    }

    @Override
    protected void applyColorFilter( Drawable bgDrawable, float r, float g, float b ) {
      super.applyColorFilter( bgDrawable, r, g, b );
      this.bgDrawable = bgDrawable;
      this.r = r;
      this.g = g;
      this.b = b;
    }

    @Override
    protected int getCurrentButtonStyle() {
      return buttonStyle;
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    setter.execute( mock( UiActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    setter.execute( mock( UiActivity.class ), mock( CompoundButton.class ), null );
  }

  @Test
  public void testSetBackgroundNull() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    UiActivity activity = new UiActivity();
    SetProperties props = new SetProperties();
    CompoundButton button = mock( CompoundButton.class );

    setter.execute( activity, button, props );

    verifyNoMoreInteractions( button );
  }

  @Test
  public void testSetBackgroundOnButtonWithouthBgDrawable() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    UiActivity activity = new UiActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( 255, 255, 0 ) );
    CompoundButton button = mock( CompoundButton.class );
    when( button.getBackground() ).thenReturn( null );

    setter.execute( activity, button, props );

    verify( button ).setBackgroundColor( 0xFFFFFF00 );
  }

  @Test
  public void testSetBackgroundOnDrawableWithLightTheme() throws Exception {
    int r = 128;
    int g = 24;
    int b = 156;
    SetterUnderTest setter = new SetterUnderTest( R.style.Widget_Holo_Light_Button );
    UiActivity activity = new UiActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( r, g, b ) );
    CompoundButton button = mock( CompoundButton.class );
    Drawable bgDrawable = mock( Drawable.class );
    when( button.getBackground() ).thenReturn( bgDrawable );

    setter.execute( activity, button, props );

    assertEquals( bgDrawable, setter.bgDrawable );
    assertEquals( r / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME, setter.r, 0 );
    assertEquals( g / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME, setter.g, 0 );
    assertEquals( b / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME, setter.b, 0 );
    verify( bgDrawable ).setColorFilter( any( ColorMatrixColorFilter.class ) );
  }

  @Test
  public void testSetBackgroundOnDrawableWithDarkTheme() throws Exception {
    int r = 128;
    int g = 24;
    int b = 156;
    SetterUnderTest setter = new SetterUnderTest( R.style.Widget_Holo_Button );
    UiActivity activity = new UiActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( r, g, b ) );
    CompoundButton button = mock( CompoundButton.class );
    Drawable bgDrawable = mock( Drawable.class );
    when( button.getBackground() ).thenReturn( bgDrawable );

    setter.execute( activity, button, props );

    assertEquals( bgDrawable, setter.bgDrawable );
    assertEquals( r / 255f + ButtonSetter.LUMINOCITY_DARK_THEME, setter.r, 0 );
    assertEquals( g / 255f + ButtonSetter.LUMINOCITY_DARK_THEME, setter.g, 0 );
    assertEquals( b / 255f + ButtonSetter.LUMINOCITY_DARK_THEME, setter.b, 0 );
    verify( bgDrawable ).setColorFilter( any( ColorMatrixColorFilter.class ) );
  }

  @Test
  public void testGetDefaultVerticalAlignment() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();

    int defaultVerticalAlignment = setter.getDefaultVerticalAlignment();

    assertEquals( Gravity.CENTER_VERTICAL, defaultVerticalAlignment );
  }

  @Test
  public void testSetBitmapDrawable() throws Exception {
    ButtonSetter<Button> buttonSetter = new ButtonSetter<Button>();
    Button button = mock( Button.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );

    buttonSetter.setBitmapDrawable( button, bitmapDrawable );

    verify( button ).setCompoundDrawablesWithIntrinsicBounds( eq( bitmapDrawable ),
                                                              isNull( BitmapDrawable.class ),
                                                              isNull( BitmapDrawable.class ),
                                                              isNull( BitmapDrawable.class ) );
  }

  @Test
  public void testGetBitmapDrawable() throws Exception {
    ButtonSetter<Button> buttonSetter = new ButtonSetter<Button>();
    Button button = mock( Button.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( button.getCompoundDrawables() ).thenReturn( new Drawable[]{
      bitmapDrawable, null, null, null
    } );

    BitmapDrawable result = buttonSetter.getBitmapDrawable( button );

    assertEquals( result, bitmapDrawable );
  }
}
