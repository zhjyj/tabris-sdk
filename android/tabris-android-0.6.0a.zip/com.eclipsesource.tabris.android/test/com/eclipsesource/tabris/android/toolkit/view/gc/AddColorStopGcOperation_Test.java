/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.LinearGradiant;
import com.eclipsesource.tabris.android.toolkit.view.gc.AddColorStopGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.IGcOperation;

public class AddColorStopGcOperation_Test {

  @Test
  public void testExecute() {
    IGcOperation op = new AddColorStopGcOperation();
    GraphicalContext gc = mock( GraphicalContext.class );
    LinearGradiant linearGradiant = mock( LinearGradiant.class );
    when( gc.getLinearGradient() ).thenReturn( linearGradiant );

    List<Integer> colorList = Arrays.asList( 2, 3, 4 );
    op.execute( gc, Arrays.asList( op.getOperation(), 1, colorList ) );

    verify( linearGradiant ).addColor( 1, SetterManager.colorToupleToInt( colorList ) );
  }

}
