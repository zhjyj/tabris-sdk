/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.view.View;

import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeItemView_Test {

  private static final String WIDGET_W1 = "w1";
  private static final String WIDGET_W2 = "w2";

  private Activity activity;

  @Before
  public void setUp() {
    activity = new Activity();
  }

  @Test(expected = UnsupportedOperationException.class)
  public void testAddUnsupportedChildView() throws Exception {
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.addView( mock( View.class ) );
  }

  @Test
  public void testAddTreeItem() throws Exception {
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.setTreeView( mock( TreeView.class ) );

    assertTrue( treeItem.getChildren().isEmpty() );

    treeItem.addView( mock( TreeItemView.class ) );

    assertEquals( 1, treeItem.getChildren().size() );
  }

  @Test
  public void testGetIndexOf() throws Exception {
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.setTreeView( mock( TreeView.class ) );
    TreeItemView item1 = mock( TreeItemView.class );
    TreeItemView item2 = mock( TreeItemView.class );
    treeItem.addView( item1 );
    treeItem.addView( item2 );

    assertEquals( 2, treeItem.getChildren().size() );

    assertEquals( 0, treeItem.indexOfChild( item1 ) );
    assertEquals( 1, treeItem.indexOfChild( item2 ) );
  }

  @Test
  public void testRemoveViewAt() throws Exception {
    TreeItemView treeItem = new TreeItemView( activity );
    treeItem.setTreeView( mock( TreeView.class ) );
    TreeItemView item1 = mock( TreeItemView.class );
    TreeItemView item2 = mock( TreeItemView.class );
    treeItem.addView( item1 );
    treeItem.addView( item2 );

    assertEquals( 2, treeItem.getChildren().size() );

    treeItem.removeViewAt( 0 );

    assertEquals( 1, treeItem.getChildren().size() );
    assertEquals( 0, treeItem.indexOfChild( item2 ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFindViewTagTraversalWithNullParam() throws Exception {
    TreeItemView treeItemViewRoot = new TreeItemView( activity );
    treeItemViewRoot.findViewWithTagTraversal( null );
  }

  @Test
  public void testFindViewTagTraversal() throws Exception {
    TreeItemView treeItemViewRoot = new TreeItemView( activity );
    treeItemViewRoot.setTreeView( mock( TreeView.class ) );
    TreeItemView item1 = new TreeItemView( activity );
    item1.setTag( WIDGET_W1 );
    TreeItemView item2 = new TreeItemView( activity );
    item2.setTag( WIDGET_W2 );
    treeItemViewRoot.addView( item1 );
    item1.addView( item2 );

    assertSame( item1, treeItemViewRoot.findViewWithTagTraversal( WIDGET_W1 ) );
    assertSame( item2, treeItemViewRoot.findViewWithTagTraversal( WIDGET_W2 ) );
  }

}
