/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.TreeViewAdapter;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeViewAdapter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullUiActivity() {
    new TreeViewAdapter( null, mock( TreeView.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullTreeView() {
    new TreeViewAdapter( mock( UiActivity.class ), null );
  }

  @Test
  public void testGetCountOnNormalTreeView() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    rootTreeItem.getChildren().add( new TreeItemView( activity ) );
    rootTreeItem.setItemCount( 2 );

    int count = adapter.getCount();

    assertEquals( 1, count );
  }

  @Test
  public void testGetCountOnNormalVirtualTreeView() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    treeView.setVirtualTreeSupport( mock( VirtualTreeSupport.class ) );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    rootTreeItem.getChildren().add( new TreeItemView( activity ) );
    rootTreeItem.setItemCount( 2 );

    int count = adapter.getCount();

    assertEquals( 2, count );
  }

  @Test
  public void testGetItemOnNormalTreeView() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    TreeItemView expected = new TreeItemView( activity );
    rootTreeItem.getChildren().add( expected );

    TreeItemView item = ( TreeItemView )adapter.getItem( 0 );

    assertSame( expected, item );
  }

  @Test
  public void testGetItemId() throws Exception {
    TreeViewAdapter adapter = new TreeViewAdapter( new UiActivity(),
                                                   new TreeView( new UiActivity() ) );

    assertEquals( 0, adapter.getItemId( 0 ) );
    assertEquals( 1, adapter.getItemId( 1 ) );
    assertEquals( 2, adapter.getItemId( 2 ) );
  }

  @Test
  public void testGetViewOnEmptyTree() throws Exception {
    TreeViewAdapter adapter = new TreeViewAdapter( new UiActivity(),
                                                   new TreeView( new UiActivity() ) );

    View view = adapter.getView( 0, null, null );

    TextView textView = ( TextView )view.findViewById( R.id.tree_item_title_text );
    assertEquals( StringUtil.EMPTY_STRING, textView.getText() );
    textView = ( TextView )view.findViewById( R.id.tree_item_desc_text );
    assertEquals( StringUtil.EMPTY_STRING, textView.getText() );
    ImageView image = ( ImageView )view.findViewById( R.id.tree_item_image_item );
    assertNull( image.getDrawable() );
  }

  @Test
  public void testGetViewOnItemWithTitle() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    TreeItemView expected = new TreeItemView( activity );
    expected.setTexts( Arrays.asList( "Hallo" ) );
    rootTreeItem.getChildren().add( expected );

    View view = adapter.getView( 0, null, null );

    TextView textView = ( TextView )view.findViewById( R.id.tree_item_title_text );
    assertEquals( "Hallo", textView.getText() );
    textView = ( TextView )view.findViewById( R.id.tree_item_desc_text );
    assertEquals( View.GONE, textView.getVisibility() );
    ImageView image = ( ImageView )view.findViewById( R.id.tree_item_image_item );
    assertEquals( View.GONE, image.getVisibility() );
  }

  @Test
  public void testGetViewOnItemWithTitleAndDescription() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    TreeItemView expected = new TreeItemView( activity );
    expected.setTexts( Arrays.asList( "Hallo", "World" ) );
    rootTreeItem.getChildren().add( expected );

    View view = adapter.getView( 0, null, null );

    TextView textView = ( TextView )view.findViewById( R.id.tree_item_title_text );
    assertEquals( "Hallo", textView.getText() );
    textView = ( TextView )view.findViewById( R.id.tree_item_desc_text );
    assertEquals( "World", textView.getText() );
    ImageView image = ( ImageView )view.findViewById( R.id.tree_item_image_item );
    assertEquals( View.GONE, image.getVisibility() );
  }

  @Test
  public void testGetViewOnItemWithTitleAndDescriptionAndIcon() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );
    TreeItemView rootTreeItem = treeView.getRootTreeItem();
    TreeItemView expected = new TreeItemView( activity );
    expected.setTexts( Arrays.asList( "Hallo", "World" ) );
    BitmapDrawable drawable = mock( BitmapDrawable.class );
    expected.setImage( drawable );
    rootTreeItem.getChildren().add( expected );

    View view = adapter.getView( 0, null, null );

    TextView textView = ( TextView )view.findViewById( R.id.tree_item_title_text );
    assertEquals( "Hallo", textView.getText() );
    textView = ( TextView )view.findViewById( R.id.tree_item_desc_text );
    assertEquals( "World", textView.getText() );
    ImageView image = ( ImageView )view.findViewById( R.id.tree_item_image_item );
    assertSame( drawable, image.getDrawable() );
  }

  @Test
  public void testGetViewOnNotYetLoadedItemOnVirtualTree() throws Exception {
    UiActivity activity = new UiActivity();
    TreeView treeView = new TreeView( activity );
    treeView.setVirtualTreeSupport( mock( VirtualTreeSupport.class ) );
    TreeViewAdapter adapter = new TreeViewAdapter( activity, treeView );

    View view = adapter.getView( 2, null, null );

    TextView textView = ( TextView )view.findViewById( R.id.tree_item_title_text );
    assertEquals( StringUtil.DOT_DOT_DOT, textView.getText() );
    textView = ( TextView )view.findViewById( R.id.tree_item_desc_text );
    assertEquals( View.GONE, textView.getVisibility() );
    ImageView image = ( ImageView )view.findViewById( R.id.tree_item_image_item );
    assertEquals( View.GONE, image.getVisibility() );
  }
}
