/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;
import android.content.Context;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.eclipsesource.tabris.android.toolkit.view.KeyboardClosingFocusListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowInputMethodManager;

@RunWith(RobolectricTestRunner.class)
public class KeyboardClosingFocusListener_Test {

  @Test
  public void testKeyboardClosedAfterFocusChangedToFalse() {
    Activity activity = new Activity();
    EditText editText = new EditText( activity );
    KeyboardClosingFocusListener listener = new KeyboardClosingFocusListener( activity, editText );
    InputMethodManager inputManager = ( InputMethodManager )activity.getSystemService( Context.INPUT_METHOD_SERVICE );
    inputManager.showSoftInput( editText, 0 );

    listener.onFocusChange( editText, false );

    ShadowInputMethodManager shadowInputMethodManager = Robolectric.shadowOf( inputManager );
    assertFalse( shadowInputMethodManager.isSoftInputVisible() );
  }

  @Test
  public void testKeyboardShowingAfterFocusChangedToTrue() {
    Activity activity = new Activity();
    EditText editText = new EditText( activity );
    KeyboardClosingFocusListener listener = new KeyboardClosingFocusListener( activity, editText );
    InputMethodManager inputManager = ( InputMethodManager )activity.getSystemService( Context.INPUT_METHOD_SERVICE );
    ShadowInputMethodManager shadowInputMethodManager = Robolectric.shadowOf( inputManager );
    boolean keyboardIsVisible = shadowInputMethodManager.isSoftInputVisible();

    listener.onFocusChange( editText, true );

    assertEquals( keyboardIsVisible, shadowInputMethodManager.isSoftInputVisible() );
  }
}
