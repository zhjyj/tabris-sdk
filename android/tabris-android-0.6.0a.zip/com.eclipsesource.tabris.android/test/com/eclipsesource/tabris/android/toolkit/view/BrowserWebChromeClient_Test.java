/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.webkit.JsResult;
import android.webkit.WebView;

import com.eclipsesource.tabris.android.UiActivity;
import com.eclipsesource.tabris.android.toolkit.view.BrowserWebChromeClient;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BrowserWebChromeClient_Test {

  private static final String URL = "http://someurl.com";
  private static final String MESSAGE = "hello world";

  class ClientUnderTest extends BrowserWebChromeClient {

    private final Context context;
    private Dialog spyDialog;

    public ClientUnderTest( Context context ) {
      super( context );
      this.context = context;
    }

    @Override
    Dialog createNewDialog() {
      spyDialog = spy( new Dialog( context ) );
      return spyDialog;
    }

    public Dialog getSpyDialog() {
      return spyDialog;
    }
  }

  @Test
  public void testOnJsConfirm() {
    ClientUnderTest clientUnderTest = new ClientUnderTest( new UiActivity() );

    clientUnderTest.onJsConfirm( mock( WebView.class ), URL, MESSAGE, mock( JsResult.class ) );

    Dialog spyDialog = clientUnderTest.spyDialog;
    verify( spyDialog ).setTitle( "someurl.com" );
    verify( spyDialog ).setMessage( MESSAGE );
    verify( spyDialog ).setButton( eq( DialogInterface.BUTTON_NEGATIVE ),
                                   any( CharSequence.class ),
                                   any( OnClickListener.class ) );
    verify( spyDialog ).setButton( eq( DialogInterface.BUTTON_NEUTRAL ),
                                   any( CharSequence.class ),
                                   any( OnClickListener.class ) );
    verify( spyDialog ).show();
  }

  @Test
  public void testOnJsAlert() {
    ClientUnderTest clientUnderTest = new ClientUnderTest( new UiActivity() );

    clientUnderTest.onJsAlert( mock( WebView.class ), URL, MESSAGE, mock( JsResult.class ) );

    Dialog spyDialog = clientUnderTest.spyDialog;
    verify( spyDialog ).setTitle( "someurl.com" );
    verify( spyDialog ).setMessage( MESSAGE );
    verify( spyDialog ).setButton( eq( DialogInterface.BUTTON_NEUTRAL ),
                                   any( CharSequence.class ),
                                   any( OnClickListener.class ) );
    verify( spyDialog ).show();
  }
}
