/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class TextSelectionStartState extends AbstractState {

  private final int selectionStart;

  public TextSelectionStartState( String widgetID, int selectionStart ) {
    super( widgetID );
    this.selectionStart = selectionStart;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.SELECTION_START_POSTFIX;
  }

  @Override
  public String generateValue() {
    return Integer.toString( selectionStart );
  }

}
