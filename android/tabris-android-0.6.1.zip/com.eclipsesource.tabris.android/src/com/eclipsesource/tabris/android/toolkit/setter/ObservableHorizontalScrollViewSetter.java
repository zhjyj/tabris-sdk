/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.app.Activity;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;

public class ObservableHorizontalScrollViewSetter<T extends ObservableHorizontalScrollView>
  extends ViewSetter<T>
{

  @Override
  public void execute( TabrisActivity activity, T view, SetProperties properties ) {
    super.execute( activity, view, properties );
    setOrigin( activity, view, properties );
  }

  private void setOrigin( Activity activity,
                          ObservableHorizontalScrollView view,
                          SetProperties properties )
  {
    List<Integer> origin = properties.getOrigin();
    if( origin != null ) {
      if( origin.size() < 2 ) {
        throw new IllegalArgumentException( "The origin property for scrolling has to have two params (x and y coords)" );
      }
      IWidgetToolkit toolkit = getActivity().getProcessor().getWidgetToolkit();
      int x = toolkit.multiplyByDensityFactor( origin.get( 0 ) );
      int y = toolkit.multiplyByDensityFactor( origin.get( 1 ) );
      view.doSmoothScrollTo( x, y );
    }
  }

}