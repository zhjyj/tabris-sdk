/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.BoundsAnimationSupport;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupport;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;

public class ViewSetter<T extends View> implements IViewSetter<T> {

  private TabrisActivity activity;
  private BoundsAnimationSupport boundsAnimSupport;

  public ViewSetter() {
    boundsAnimSupport = new BoundsAnimationSupport();
  }

  void setActivity( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void execute( TabrisActivity activity, T view, SetProperties properties ) {
    setActivity( activity );
    ValidationUtil.checkNullArg( this, view, View.class );
    ValidationUtil.checkNullArg( this, properties, SetProperties.class );
    setBounds( view, properties );
    setBackground( view, properties );
    setBackgroundImage( view, properties );
    setSelection( view, properties );
    setEnabled( view, properties );
    setVisibility( view, properties );
    setCustomVariant( view, properties );
  }

  protected void setCustomVariant( T view, SetProperties properties ) {
    String customVariant = properties.getCustomVariant();
    if( customVariant == null ) {
      view.setTag( R.id.custom_variant, null );
    } else if( customVariant != SetProperties.NOT_MODIFIFED ) {
      view.setTag( R.id.custom_variant, customVariant );
    }
  }

  private void setVisibility( View view, SetProperties properties ) {
    Boolean visibility = properties.getVisibility();
    if( visibility != null ) {
      if( visibility ) {
        view.setVisibility( View.VISIBLE );
      } else {
        view.setVisibility( View.INVISIBLE );
      }
    }
  }

  protected void setEnabled( View view, SetProperties properties ) {
    Boolean enabled = properties.getEnabled();
    if( enabled != null ) {
      view.setEnabled( enabled );
    }
  }

  protected void setSelection( View view, SetProperties properties ) {
    GenericObject selectionProperty = properties.getSelection();
    if( selectionProperty != null ) {
      Boolean selection = selectionProperty.getObjectAs( Boolean.class );
      view.setSelected( selection );
    }
  }

  @SuppressWarnings("unchecked")
  private void setBackgroundImage( final View view, SetProperties properties ) {
    List<String> backgroundImage = properties.getBackgroundImage();
    if( backgroundImage != null ) {
      new LoadImageTask( activity ) {

        @Override
        protected void onPostExecute( BitmapDrawable drawable ) {
          dereferenceBackground( getProcessor(), view );
          view.setBackgroundDrawable( drawable );
        }
      }.loadBitmap( backgroundImage );
    }
  }

  protected void setBackground( View view, SetProperties properties ) {
    List<Integer> background = properties.getBackground();
    if( background != null ) {
      view.setBackgroundColor( SetterManager.colorToupleToInt( background ) );
    }
  }

  protected void setBounds( View view, SetProperties properties ) {
    List<Integer> bounds = properties.getBounds();
    if( bounds != null ) {
      if( bounds.size() != 4 ) {
        throw new IllegalArgumentException( "The bounds properties have to be a 4 element touple" );
      }
      bounds = adjustBoundsForScrollableParent( view, bounds );
      bounds = adjustBoundsForTabFolderParent( view, bounds );
      String customVariant = ( String )view.getTag( R.id.custom_variant );
      if( customVariant != null && customVariant.equals( ICustomVariants.ANIMATED ) ) {
        boundsAnimSupport.applyBoundsAnimations( this, view, bounds );
      } else {
        applyBoundsToView( view, bounds );
        view.requestLayout();
      }
    }
  }

  private List<Integer> adjustBoundsForTabFolderParent( View view, List<Integer> bounds ) {
    List<Integer> newBounds = bounds;
    Class<?>[] parents = {
      LinearLayout.class, FrameLayout.class, LinearLayout.class, TabFolder.class
    };
    if( hasParentChain( view, parents ) ) {
      newBounds.set( 0, 0 );
      newBounds.set( 1, 0 );
    }
    return newBounds;
  }

  private boolean hasParentChain( View view, Class<?>[] classes ) {
    ViewParent curParent = view.getParent();
    for( int i = 0; i < classes.length; i++ ) {
      if( !classes[ i ].isInstance( curParent ) ) {
        return false;
      }
      curParent = curParent.getParent();
    }
    return true;
  }

  public void applyBoundsToView( View view, List<Integer> bounds ) {
    IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
    MarginLayoutParams params = ( MarginLayoutParams )view.getLayoutParams();
    params.leftMargin = scaleBoundValue( toolkit, bounds.get( 0 ) );
    params.topMargin = scaleBoundValue( toolkit, bounds.get( 1 ) );
    params.width = scaleBoundValue( toolkit, bounds.get( 2 ) );
    params.height = scaleBoundValue( toolkit, bounds.get( 3 ) );
    view.setMinimumWidth( params.width );
    view.setMinimumHeight( params.height );
  }

  private List<Integer> adjustBoundsForScrollableParent( View view, List<Integer> bounds ) {
    ViewParent parent = view.getParent();
    if( parent instanceof ObservableVerticalScrollView ) {
      return adjustBoundsForVerticalScrollParent( bounds, parent );
    } else if( parent instanceof ObservableHorizontalScrollView ) {
      return adjustBoundsForHorizontalScrollParent( bounds, parent );
    } else if( parent instanceof ObservableScrollView ) {
      return adjustBoundsForScrollParent( bounds, parent );
    }
    return bounds;
  }

  private List<Integer> adjustBoundsForScrollParent( List<Integer> bounds, ViewParent parent ) {
    ObservableScrollView scrollView = ( ObservableScrollView )parent;
    ObservableVerticalScrollView verticalScroll = scrollView.getVerticalScroll();
    ObservableHorizontalScrollView horizontalScroll = scrollView.getHorizontalScroll();
    int scrollTargetX = horizontalScroll.getScrollSupport().getScrollTargetX();
    int scrollTargetY = verticalScroll.getScrollSupport().getScrollTargetY();
    return adjustBoundsForScrollableParent( bounds, scrollTargetX, scrollTargetY );
  }

  private List<Integer> adjustBoundsForHorizontalScrollParent( List<Integer> bounds,
                                                               ViewParent parent )
  {
    ScrollSupport scrollSupport = ( ( ObservableHorizontalScrollView )parent ).getScrollSupport();
    return adjustBoundsForScrollableParent( bounds,
                                            scrollSupport.getScrollTargetX(),
                                            scrollSupport.getScrollTargetY() );
  }

  private List<Integer> adjustBoundsForVerticalScrollParent( List<Integer> bounds, ViewParent parent )
  {
    ScrollSupport scrollSupport = ( ( ObservableVerticalScrollView )parent ).getScrollSupport();
    return adjustBoundsForScrollableParent( bounds,
                                            scrollSupport.getScrollTargetX(),
                                            scrollSupport.getScrollTargetY() );
  }

  private List<Integer> adjustBoundsForScrollableParent( List<Integer> bounds, int x, int y ) {
    IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
    ArrayList<Integer> newBounds = new ArrayList<Integer>( bounds );
    int scaledX = toolkit.divideByDensityFactor( x );
    int scaledY = toolkit.divideByDensityFactor( y );
    newBounds.set( 0, bounds.get( 0 ) + scaledX );
    newBounds.set( 1, bounds.get( 1 ) + scaledY );
    return newBounds;
  }

  protected int scaleBoundValue( IWidgetToolkit toolkit, Integer value ) {
    return toolkit.multiplyByDensityFactor( value );
  }

  public TabrisActivity getActivity() {
    return activity;
  }

  public ProtocolProcessor getProcessor() {
    return activity.getProcessor();
  }

  /** Should only be used for testing. */
  public void setBoundsAnimationSupport( BoundsAnimationSupport boundsAnimSupport ) {
    this.boundsAnimSupport = boundsAnimSupport;
  }

  public static void dereferenceBackground( ProtocolProcessor processor, final View view ) {
    BitmapDrawableCache bitmapCache = processor.getWidgetToolkit().getBitmapCache();
    Drawable background = view.getBackground();
    if( background instanceof BitmapDrawable ) {
      bitmapCache.decreaseReferenceCount( ( BitmapDrawable )background );
    }
  }
}
