/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.app.Activity;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.setter.TreeItemViewSetter;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;

public class TreeItemOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.TreeItem";

  private final Activity activity;

  public TreeItemOperator( TabrisActivity activity ) {
    super( activity );
    this.activity = activity;
  }

  public void create( CreateOperation operation ) {
    TreeItemView treeItemView = new TreeItemView( activity );
    initiateNewView( operation, treeItemView );
  }

  public String getType() {
    return TYPE;
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    View view = findViewByTarget( operation );
    if( !( view instanceof TreeItemView ) ) {
      throw new IllegalArgumentException( "Could not find TreeItemView "
                                          + operation.getTarget()
                                          + " to perform DestroyOperation on." );
    }
    TreeItemView treeItemView = ( TreeItemView )view;
    treeItemView.getTreeItemParent().removeView( view );
    TreeItemViewSetter.decreaseReferenceCount( getProcessor(), treeItemView );
  }
}
