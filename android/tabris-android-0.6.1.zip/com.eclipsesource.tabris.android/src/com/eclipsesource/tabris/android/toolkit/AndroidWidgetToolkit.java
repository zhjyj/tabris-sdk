/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.eclipsesource.tabris.android.BuildConfig;
import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.LocalizableException;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.toolkit.method.MeasureStringsMethod;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Geolocation;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator;
import com.eclipsesource.tabris.android.toolkit.operator.BrowserOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ButtonOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CanvasOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ComboOperator;
import com.eclipsesource.tabris.android.toolkit.operator.CompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.DateTimeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.DisplayOperator;
import com.eclipsesource.tabris.android.toolkit.operator.GraphicalContextOperator;
import com.eclipsesource.tabris.android.toolkit.operator.GroupOperator;
import com.eclipsesource.tabris.android.toolkit.operator.LabelOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ListOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ProgressBarOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ScrolledCompositeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ShellOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TabFolderOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TabItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TableColumnOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TextOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ToolBarOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ToolItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TreeItemOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TreeOperator;
import com.eclipsesource.tabris.android.toolkit.operator.UiCallbackOperator;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.ClientGraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.DateTimeSpinner;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.eclipsesource.tabris.android.toolkit.view.RecordingFocusTrackingListener;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.SeparatorToolItem;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.eclipsesource.tabris.android.toolkit.view.TabItemView;
import com.eclipsesource.tabris.android.toolkit.view.TableColumn;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class AndroidWidgetToolkit implements IWidgetToolkit {

  public static final String DISPLAY_ID = "w1";

  private final TabrisActivity activity;
  Map<Class<? extends Object>, IOperator> operatorsMap;
  private DisplayMetrics displayMetrics;
  private final ListenerRegistry listenerRegistry;
  private ErrorDialog errorDialog;
  private final MeasureStringsMethod measureStringsMethod;
  private HashMap<String, Object> objectRegistry;
  private final MessageFactory messageFactory;
  private Handler handler;
  private BitmapDrawableCache bitmapCache;
  private final RecordingFocusTrackingListener recordingFocusChangedListener;

  public AndroidWidgetToolkit( TabrisActivity activity ) {
    this.activity = activity;
    handler = new Handler();
    errorDialog = new ErrorDialog( activity, this );
    measureStringsMethod = new MeasureStringsMethod( activity.getProcessor() );
    messageFactory = new MessageFactory( activity );
    initializeObjectRegistry( activity );
    initializeBitmapCache();
    initializeOperators();
    populateDisplayMetrics();
    listenerRegistry = new ListenerRegistry();
    recordingFocusChangedListener = new RecordingFocusTrackingListener( activity );
  }

  private void initializeObjectRegistry( TabrisActivity activity ) {
    objectRegistry = new HashMap<String, Object>();
    View displayView = activity.findViewById( R.id.root_layout );
    registerObjectById( DISPLAY_ID, displayView );
  }

  private void initializeBitmapCache() {
    final int memClass = ( ( ActivityManager )activity.getSystemService( Context.ACTIVITY_SERVICE ) ).getMemoryClass();
    final int cacheSize = 1024 * 1024 * memClass / 8;
    bitmapCache = new BitmapDrawableCache( cacheSize );
  }

  private void initializeOperators() {
    ButtonOperator buttonOperator = new ButtonOperator( activity );
    ToolItemOperator toolItemOperator = new ToolItemOperator( activity );
    ScrolledCompositeOperator scrolledCompositeOperator = new ScrolledCompositeOperator( activity );
    operatorsMap = new HashMap<Class<? extends Object>, IOperator>();
    operatorsMap.put( Display.class, new DisplayOperator( activity, measureStringsMethod ) );
    operatorsMap.put( Shell.class, new ShellOperator( activity ) );
    operatorsMap.put( ModalShell.class, new ShellOperator( activity ) );
    operatorsMap.put( Composite.class, new CompositeOperator( activity ) );
    operatorsMap.put( Group.class, new GroupOperator( activity ) );
    operatorsMap.put( ObservableScrollView.class, scrolledCompositeOperator );
    operatorsMap.put( ObservableVerticalScrollView.class, scrolledCompositeOperator );
    operatorsMap.put( ObservableHorizontalScrollView.class, scrolledCompositeOperator );
    operatorsMap.put( Button.class, buttonOperator );
    operatorsMap.put( CheckBox.class, buttonOperator );
    operatorsMap.put( RadioButton.class, buttonOperator );
    operatorsMap.put( ToggleButton.class, buttonOperator );
    operatorsMap.put( TextView.class, new LabelOperator( activity ) );
    operatorsMap.put( TabFolder.class, new TabFolderOperator( activity ) );
    operatorsMap.put( TabItemView.class, new TabItemOperator( activity ) );
    operatorsMap.put( TreeView.class, new TreeOperator( activity ) );
    operatorsMap.put( TreeItemView.class, new TreeItemOperator( activity ) );
    operatorsMap.put( Text.class, new TextOperator( activity ) );
    operatorsMap.put( TableColumn.class, new TableColumnOperator( activity ) );
    operatorsMap.put( Spinner.class, new ComboOperator( activity ) );
    operatorsMap.put( DateTimeSpinner.class, new DateTimeOperator( activity ) );
    operatorsMap.put( ToolBar.class, new ToolBarOperator( activity ) );
    operatorsMap.put( PushToolItem.class, toolItemOperator );
    operatorsMap.put( SeparatorToolItem.class, toolItemOperator );
    operatorsMap.put( UiCallback.class, new UiCallbackOperator( activity ) );
    operatorsMap.put( Canvas.class, new CanvasOperator( activity ) );
    operatorsMap.put( ClientGraphicalContext.class, new GraphicalContextOperator( activity ) );
    operatorsMap.put( Geolocation.class, new GeolocationOperator( activity ) );
    operatorsMap.put( Browser.class, new BrowserOperator( activity ) );
    operatorsMap.put( List.class, new ListOperator( activity ) );
    operatorsMap.put( ProgressBar.class, new ProgressBarOperator( activity ) );
    operatorsMap.put( Separator.class, new SeparatorOperator( activity ) );
  }

  /** To be used for testing only. */
  Map<Class<? extends Object>, IOperator> getOperatorsMap() {
    return operatorsMap;
  }

  /** To be used for testing only. */
  public HashMap<String, Object> getObjectRegistry() {
    return objectRegistry;
  }

  private void populateDisplayMetrics() {
    displayMetrics = new DisplayMetrics();
    activity.getWindowManager().getDefaultDisplay().getMetrics( displayMetrics );
  }

  public void process( final ArrayList<Operation> operations ) {
    executeInUiThread( new ExecuteOperationsRunnable( this, operations ) );
  }

  IOperator getOperator( Operation operation ) {
    ValidationUtil.validateOperation( operation );
    IOperator result = null;
    if( operation instanceof CreateOperation ) {
      result = findCreateOperator( operation );
    } else {
      result = findOperatorFromObjectRegistry( operation );
    }
    return result;
  }

  private IOperator findOperatorFromObjectRegistry( Operation operation ) {
    Object obj = findObjectById( operation.getTarget(), Object.class );
    IOperator result = null;
    if( obj != null ) {
      result = operatorsMap.get( obj.getClass() );
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  public <T> T findObjectById( String id, Class<? extends T> clazz ) {
    if( id == null ) {
      throw new IllegalArgumentException( "Can not find object with null id." );
    }
    Object object = objectRegistry.get( id );
    if( object != null && !clazz.isAssignableFrom( object.getClass() ) ) {
      throw new IllegalStateException( "Found object of type "
                                       + object.getClass().getName()
                                       + " but was looking for "
                                       + clazz.getName() );
    }
    return ( T )object;
  }

  public void registerObjectById( String id, Object object ) {
    if( id == null ) {
      throw new IllegalArgumentException( "Can not register object with null id." );
    }
    if( object == null ) {
      throw new IllegalArgumentException( "Can register null object." );
    }
    objectRegistry.put( id, object );
  }

  public Object unregisterObjectById( String id ) {
    if( id == null ) {
      throw new IllegalArgumentException( "Can not deregister object with null id." );
    }
    return objectRegistry.remove( id );
  }

  private IOperator findCreateOperator( Operation operation ) {
    IOperator result = null;
    CreateOperation createOp = ( CreateOperation )operation;
    Collection<IOperator> operators = operatorsMap.values();

    for( IOperator operator : operators ) {
      String type = operator.getType();
      if( type != null && type.equals( createOp.getType() ) ) {
        result = operator;
        break;
      }
    }
    return result;
  }

  public void showError( final Throwable t ) {
    Throwable error;
    if( t instanceof LocalizableException ) {
      LocalizableException exception = ( LocalizableException )t;
      error = new RuntimeException( messageFactory.createMessage( exception.getKey() ), t );
    } else {
      error = t;
    }
    if( BuildConfig.DEBUG ) {
      Log.e( TabrisActivity.LOG_TAG, error.getMessage(), t );
    }
    errorDialog.show( error );
  }

  void executeInUiThread( Runnable runnable ) {
    if( !activity.isFinishing() ) {
      handler.post( runnable );
    }
  }

  Activity getActivity() {
    return activity;
  }

  public int getSurfaceWidth() {
    View rootLayout = activity.findViewById( R.id.root_layout );
    return rootLayout.getWidth();
  }

  public int getSurfaceHeight() {
    View rootLayout = activity.findViewById( R.id.root_layout );
    return rootLayout.getHeight();
  }

  public int getSurfaceDpiX() {
    return Math.round( displayMetrics.xdpi );
  }

  public int getSurfaceDpiY() {
    return Math.round( displayMetrics.ydpi );
  }

  public int getSurfaceColorDepth() {
    // TODO mpost find a proper way to determine the color depth of the
    // surface
    return 24;
  }

  public float divideByDensityFactor( float value ) {
    return value / displayMetrics.density;
  }

  public int divideByDensityFactor( int value ) {
    return Math.round( value / displayMetrics.density );
  }

  public int multiplyByDensityFactor( int value ) {
    return Math.round( value * displayMetrics.density );
  }

  public float multiplyByDensityFactor( float value ) {
    return value * displayMetrics.density;
  }

  public void dispose() {
    UiCallback uicb = findObjectById( UiCallbackOperator.UI_CALLBACK_ID, UiCallback.class );
    if( uicb != null ) {
      uicb.setActive( false );
    }
    handler.removeCallbacksAndMessages( 0 );
    bitmapCache.clear();
  }

  public ListenerRegistry getListenerRegistry() {
    return listenerRegistry;
  }

  /** Used for testing only. */
  void setHandler( Handler handler ) {
    this.handler = handler;
  }

  /** Used for testing only. */
  void setBitmapCache( BitmapDrawableCache bitmapCache ) {
    this.bitmapCache = bitmapCache;
  }

  /** Used for testing only. */
  public void setErrorDialog( ErrorDialog errorDialog ) {
    this.errorDialog = errorDialog;
  }

  public float getDensityFactor() {
    return displayMetrics.density;
  }

  public int getDensityDpi() {
    return displayMetrics.densityDpi;
  }

  public HashMap<String, String> measureStrings( CallOperation probeOperation ) {
    if( probeOperation == null ) {
      return new HashMap<String, String>();
    }
    DisplayOperator displayOperator = ( DisplayOperator )operatorsMap.get( Display.class );
    CallProperties callProperties = displayOperator.callIndirectly( probeOperation );
    return measureStringsMethod.callIndirectly( callProperties );
  }

  public BitmapDrawableCache getBitmapCache() {
    return bitmapCache;
  }

  public int getApiLevel() {
    return Build.VERSION.SDK_INT;
  }

  public RecordingFocusTrackingListener getFocusTrackingListener() {
    return recordingFocusChangedListener;
  }

}
