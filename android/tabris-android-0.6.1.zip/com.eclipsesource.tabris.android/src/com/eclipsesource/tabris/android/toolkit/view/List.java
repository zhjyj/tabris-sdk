/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.content.Context;
import android.widget.ListView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;

public class List extends ListView {

  public List( Context context ) {
    super( context, null );
    setVerticalFadingEdgeEnabled( false );
    ListSelectionAdapter<String> adapter = new ListSelectionAdapter<String>( context,
                                                                             R.layout.simple_list_item_1,
                                                                             android.R.id.text1,
                                                                             new ArrayList<String>() );
    setAdapter( adapter );
  }

  @SuppressWarnings("unchecked")
  public void setItems( java.util.List<String> itemsToSet, TabrisActivity activity ) {
    if( itemsToSet == null ) {
      return;
    }
    ListSelectionAdapter<String> adapter = ( ListSelectionAdapter<String> )getAdapter();
    adapter.clear();
    for( String item : itemsToSet ) {
      adapter.add( item );
    }
  }
}