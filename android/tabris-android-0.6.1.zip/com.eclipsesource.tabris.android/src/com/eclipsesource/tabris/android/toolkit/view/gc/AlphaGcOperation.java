/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class AlphaGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "globalAlpha";

  public AlphaGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 2 );
    float alpha = ( ( Number )properties.get( 1 ) ).floatValue();
    gc.getPaint().setAlpha( Math.round( alpha * 255 ) );
  }

}
