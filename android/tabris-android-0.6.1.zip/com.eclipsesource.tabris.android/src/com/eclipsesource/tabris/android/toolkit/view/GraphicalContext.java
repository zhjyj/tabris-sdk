/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillStyleGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.FontGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeStyleGcOperation;

public class GraphicalContext {

  private static final String KEY_WIDTH = "width";
  private static final String KEY_HEIGHT = "height";

  private final TabrisActivity activity;
  private final Canvas canvasView;
  private LinearGradiant linearGradient;
  private Paint paint;
  private int strokeColor;
  private int fillColor;
  private Path path;
  private LinkedList<Paint> paintStash;

  public GraphicalContext( TabrisActivity activity, Canvas canvas ) {
    this.activity = activity;
    this.canvasView = canvas;
  }

  public void init( CallProperties properties ) {
    initInternal();

    List<?> strokeStyle = ( List<?> )properties.get( StrokeStyleGcOperation.OPERATION );
    if( strokeStyle != null ) {
      List<?> param = Arrays.asList( StrokeStyleGcOperation.OPERATION, strokeStyle );
      new StrokeStyleGcOperation().execute( this, param );
    }

    List<?> fillStyle = ( List<?> )properties.get( FillStyleGcOperation.OPERATION );
    if( fillStyle != null ) {
      List<Object> param = Arrays.asList( FillStyleGcOperation.OPERATION, fillStyle );
      new FillStyleGcOperation().execute( this, param );
    }

    List<?> fontDef = ( List<?> )properties.get( FontGcOperation.OPERATION );
    if( fontDef != null ) {
      List<Object> param = Arrays.asList( FontGcOperation.OPERATION, fontDef );
      new FontGcOperation( activity ).execute( this, param );
    }
    int width = getScaledInt( properties, KEY_WIDTH );
    int height = getScaledInt( properties, KEY_HEIGHT );
    canvasView.initCanvas( width, height );
  }

  public void init() {
    initInternal();
    canvasView.initCanvas( canvasView.getWidth(), canvasView.getHeight() );
  }

  private void initInternal() {
    paint = new Paint();
    paint.setAntiAlias( true );
    paintStash = new LinkedList<Paint>();
    linearGradient = new LinearGradiant();
  }

  public Canvas getCanvasView() {
    return canvasView;
  }

  private int getScaledInt( CallProperties properties, String key ) {
    Object number = properties.get( key );
    if( number instanceof Number ) {
      Number intNumber = ( Number )number;
      IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
      return widgetToolkit.multiplyByDensityFactor( intNumber.intValue() );
    }
    return 0;
  }

  public void setStyle( Style style ) {
    paint.setStyle( style );
    int alpha = paint.getAlpha();
    if( Style.FILL.equals( style ) ) {
      path.close();
      paint.setColor( fillColor );
    } else if( Style.STROKE.equals( style ) ) {
      paint.setColor( strokeColor );
    }
    paint.setAlpha( alpha );
  }

  public void drawCurrentPath() {
    canvasView.getCanvas().drawPath( path, paint );
    if( paint.getShader() != null ) {
      paint.setShader( null );
      linearGradient = new LinearGradiant();
    }
  }

  public void invalidate() {
    canvasView.invalidate();
  }

  protected void invalidate( int l, int t, int r, int b ) {
    canvasView.invalidate( l, t, r, b );
  }

  public void createNewPath() {
    path = new Path();
  }

  public Path getPath() {
    return path;
  }

  /** To be used for testing only. */
  void setPath( Path path ) {
    this.path = path;
  }

  public Paint getPaint() {
    return paint;
  }

  /** To be used for testing only. */
  void setPaint( Paint paint ) {
    this.paint = paint;
  }

  public android.graphics.Canvas getCanvas() {
    return canvasView.getCanvas();
  }

  public void setStrokeColor( int strokeColor ) {
    this.strokeColor = strokeColor;
  }

  public int getStrokeColor() {
    return strokeColor;
  }

  public void setFillColor( int fillColor ) {
    this.fillColor = fillColor;
  }

  public int getFillColor() {
    return fillColor;
  }

  public LinearGradiant getLinearGradient() {
    return linearGradient;
  }

  public void savePaint() {
    paintStash.addLast( paint );
    paint = new Paint( paint );
  }

  public void restorePaint() {
    try {
      paint = paintStash.removeLast();
    } catch( NoSuchElementException e ) {
      throw new IllegalStateException( "Can not restore the paint state because there are no stored states in the GraphicalContext",
                                       e );
    }
  }

}
