/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.method;

import java.util.HashMap;
import java.util.List;

import android.graphics.Typeface;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.FloatMath;

import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.IMethod;

public class MeasureStringsMethod implements IMethod {

  public static final String PARAM_STRINGS = "strings";
  public static final Object PARAM_FONTS = "fonts";

  private static final float MEASURE_FACTOR = 20f;
  private static final float TOLERANCE_FACTOR = 1.02f;

  private final ProtocolProcessor processor;

  public MeasureStringsMethod( ProtocolProcessor processor ) {
    if( processor == null ) {
      throw new IllegalArgumentException( "The ProtocolProcessor passed to the MeasureStringMethod can not be null" );
    }
    this.processor = processor;
  }

  @SuppressWarnings("rawtypes")
  public void call( CallProperties params ) {
    List stringConfigs = extractStringConfigs( params );
    HashMap<String, String> measurements = measureStrings( stringConfigs );
    sendResult( measurements );
  }

  @SuppressWarnings("rawtypes")
  private List extractStringConfigs( CallProperties params ) {
    validateParams( params );
    List stringConfigs = ( List )params.get( PARAM_STRINGS );
    if( stringConfigs == null ) {
      stringConfigs = ( List )params.get( PARAM_FONTS );
    }
    return stringConfigs;
  }

  @SuppressWarnings("rawtypes")
  public HashMap<String, String> callIndirectly( CallProperties params ) {
    List stringConfigs = extractStringConfigs( params );
    return measureStrings( stringConfigs );
  }

  @SuppressWarnings("rawtypes")
  private HashMap<String, String> measureStrings( List stringConfigs ) {
    HashMap<String, String> result = new HashMap<String, String>();
    if( stringConfigs == null ) {
      throw new IllegalArgumentException( "String configs can not be null" );
    }
    IWidgetToolkit toolkit = processor.getWidgetToolkit();

    for( Object elem : stringConfigs ) {
      if( !( elem instanceof List ) ) {
        throw new IllegalArgumentException( "Parameter to measure strings is not a List of Lists" );
      }
      List list = ( List )elem;

      try {
        int id = getNumberAsInt( list.get( 0 ) );
        String text = ( String )list.get( 1 );
        List fonts = ( List )list.get( 2 );
        float fontSize = toolkit.multiplyByDensityFactor( getNumberAsInt( list.get( 3 ) ) );
        boolean bold = ( Boolean )list.get( 4 );
        boolean italic = ( Boolean )list.get( 5 );
        int wrapWidth = 0;
        if( list.size() >= 7 ) {
          wrapWidth = toolkit.multiplyByDensityFactor( getNumberAsInt( list.get( 6 ) ) );
        }

        Typeface typeface = getTypeface( fonts, bold, italic );
        if( typeface == null ) {
          throw new IllegalStateException( "Could not obtain any font for measuring the text size" );
        }
        TextPaint textPaint = getTextPaint( typeface, fontSize );
        StaticLayout layout = measure( textPaint, text, wrapWidth );
        appendToResult( result, id, layout );
      } catch( ClassCastException e ) {
        throw new IllegalArgumentException( "A string config was not in the right format", e );
      }
    }

    return result;
  }

  private int getNumberAsInt( Object obj ) {
    return ( ( Number )obj ).intValue();
  }

  private void appendToResult( HashMap<String, String> result, int id, StaticLayout layout ) {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    float measuredWidth = getMaxLineWidth( layout ) / MEASURE_FACTOR * TOLERANCE_FACTOR;
    float measuredHeight = layout.getHeight() / MEASURE_FACTOR;
    int width = ( int )FloatMath.ceil( toolkit.divideByDensityFactor( measuredWidth ) );
    int height = ( int )FloatMath.ceil( toolkit.divideByDensityFactor( measuredHeight ) );
    result.put( String.valueOf( id ), width + StringUtil.COMMA + height );
  }

  private float getMaxLineWidth( StaticLayout layout ) {
    float maxLine = 0.0f;
    int lineCount = layout.getLineCount();
    for( int i = 0; i < lineCount; i++ ) {
      float lineLength = layout.getLineRight( i );
      if( lineLength > maxLine ) {
        maxLine = lineLength;
      }
    }
    return maxLine;
  }

  private TextPaint getTextPaint( Typeface typeface, float fontSize ) {
    TextPaint textPaint = new TextPaint();
    textPaint.setTypeface( typeface );
    textPaint.setTextSize( fontSize * MEASURE_FACTOR );
    return textPaint;
  }

  private void sendResult( HashMap<String, String> result ) {
    processor.processPostRequest( new PostRequest( result ) );
  }

  private StaticLayout measure( TextPaint textPaint, String text, int wrapWidth ) {
    int boundedWidth = Integer.MAX_VALUE;
    if( wrapWidth > 0 ) {
      boundedWidth = ( int )( wrapWidth * MEASURE_FACTOR );
    }
    return new StaticLayout( text,
                             textPaint,
                             boundedWidth,
                             Alignment.ALIGN_NORMAL,
                             1.0f,
                             0.0f,
                             false );
  }

  @SuppressWarnings("rawtypes")
  public static Typeface getTypeface( List fonts, boolean bold, boolean italic ) {
    int style = createStyle( bold, italic );
    Typeface defaultTypeface = Typeface.defaultFromStyle( style );

    for( Object font : fonts ) {
      if( font instanceof String ) {
        String fontName = ( String )font;
        Typeface typeface = Typeface.create( fontName, style );
        if( !defaultTypeface.equals( typeface ) ) {
          return typeface;
        }
      } else {
        throw new IllegalArgumentException( "The given font name is not a string" );
      }
    }
    return defaultTypeface;
  }

  private static int createStyle( boolean bold, boolean italic ) {
    int style = Typeface.NORMAL;
    if( bold ) {
      style |= Typeface.BOLD;
    }
    if( italic ) {
      style |= Typeface.ITALIC;
    }
    return style;
  }

  @SuppressWarnings("rawtypes")
  private void validateParams( CallProperties params ) {
    Object object = params.get( PARAM_STRINGS );
    if( object == null ) {
      object = params.get( PARAM_FONTS );
    }
    if( object == null ) {
      throw new IllegalArgumentException( "Calling the "
                                          + getClass().getSimpleName()
                                          + " method requires a parameter '"
                                          + PARAM_STRINGS
                                          + "'. The parameter has not been found." );
    }
    if( object instanceof List ) {
      List list = ( List )object;
      if( list.isEmpty() ) {
        throw new IllegalArgumentException( "The list given does not contain sublists with string configurations to measure" );
      }
    } else {
      throw new IllegalArgumentException( "Parameter to measure strings is not a List of string configurations to measure" );
    }
  }
}
