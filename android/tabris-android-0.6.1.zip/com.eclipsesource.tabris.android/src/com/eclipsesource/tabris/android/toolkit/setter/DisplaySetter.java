/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Display;

public class DisplaySetter<T extends Display> implements IViewSetter<T> {

  public void execute( TabrisActivity activity, T view, SetProperties properties ) {
    setFocusControl( activity, properties );
  }

  protected void setFocusControl( TabrisActivity activity, SetProperties properties ) {
    String focusControl = properties.getFocusControl();
    if( focusControl != null ) {
      IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
      View view = toolkit.findObjectById( properties.getFocusControl(), View.class );
      view.requestFocus();
    }
  }

}
