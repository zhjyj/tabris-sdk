/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;

public class ProgressBar extends android.widget.ProgressBar {

  private int min;

  public ProgressBar( Context context ) {
    super( context, null, android.R.attr.progressBarStyleHorizontal );
    min = 0;
    setMax( 100 );
  }

  @Override
  public void setProgress( int progress ) {
    super.setProgress( progress - min );
  }

  @Override
  public synchronized void setMax( int max ) {
    super.setMax( max - min );
  }

  public void setMin( int min ) {
    this.min = min;
    setProgress( getProgress() );
    setMax( getMax() );
  }

  /** To be used for testing only. */
  public int getMin() {
    return min;
  }

}
