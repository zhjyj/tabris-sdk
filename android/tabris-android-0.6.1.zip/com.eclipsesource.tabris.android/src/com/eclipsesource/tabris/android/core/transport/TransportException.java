/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

public class TransportException extends RuntimeException {

  /**
   * Default serial UID.
   */
  private static final long serialVersionUID = 3888958238525664945L;

  private int httpStatusCode;

  public TransportException( String message, Throwable e ) {
    super( message, e );
  }

  public TransportException( String message, int httpStatusCode ) {
    super( message );
    this.httpStatusCode = httpStatusCode;
  }

  public int getStatusCode() {
    return httpStatusCode;
  }
}
