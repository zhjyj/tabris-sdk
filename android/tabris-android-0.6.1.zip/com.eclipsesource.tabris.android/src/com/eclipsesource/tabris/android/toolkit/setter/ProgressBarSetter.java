/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.Drawable;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;

public class ProgressBarSetter<T extends ProgressBar> extends ViewSetter<T> {

  private static final int HEIGHT_NORMAL = 12;
  private static final int HEIGHT_INDETERMINATE = 9;
  private static final String STATE_NORMAL = "normal";
  private static final String STATE_PAUSED = "paused";
  private static final String STATE_ERROR = "error";

  private ColorUtil colorUtil;

  public ProgressBarSetter() {
    colorUtil = new ColorUtil();
  }

  @Override
  public void execute( TabrisActivity activity, T progressBar, SetProperties properties ) {
    super.execute( activity, progressBar, properties );
    setMinimum( progressBar, properties );
    setMaximum( progressBar, properties );
    setState( progressBar, properties );
  }

  private void setState( T progressBar, SetProperties properties ) {
    String state = properties.getState();
    if( state != null ) {
      Drawable drawable;
      if( progressBar.isIndeterminate() ) {
        drawable = progressBar.getIndeterminateDrawable();
      } else {
        drawable = progressBar.getProgressDrawable();
      }
      if( state.equals( STATE_ERROR ) ) {
        colorUtil.applyColorFilter( drawable, 1f, 0f, 0f );
      } else if( state.equals( STATE_PAUSED ) ) {
        colorUtil.applyColorFilter( drawable, 0.7f, 0.7f, 0.7f );
      } else if( state.equals( STATE_NORMAL ) ) {
        drawable.setColorFilter( null );
      }
    }
  }

  private void setMinimum( T progressBar, SetProperties properties ) {
    Integer minimum = properties.getMinimum();
    if( minimum != null ) {
      progressBar.setMin( minimum );
    }
  }

  private void setMaximum( T progressBar, SetProperties properties ) {
    Integer maximum = properties.getMaximum();
    if( maximum != null ) {
      progressBar.setMax( maximum );
    }
  }

  @Override
  protected void setSelection( View view, SetProperties properties ) {
    GenericObject selection = properties.getSelection();
    if( selection != null ) {
      ( ( ProgressBar )view ).setProgress( selection.getObjectAs( Number.class ).intValue() );
    }
  }

  @Override
  public void applyBoundsToView( View view, List<Integer> bounds ) {
    int top = bounds.get( 1 );
    int height = bounds.get( 3 );
    int newHeight = HEIGHT_NORMAL;
    if( ( ( ProgressBar )view ).isIndeterminate() ) {
      newHeight = HEIGHT_INDETERMINATE;
    }
    ArrayList<Integer> newBounds = new ArrayList<Integer>();
    newBounds.add( bounds.get( 0 ) );
    newBounds.add( top + height / 2 - newHeight / 2 );
    newBounds.add( bounds.get( 2 ) );
    newBounds.add( newHeight );
    super.applyBoundsToView( view, newBounds );
  }

  /** To be used for testing only. */
  public void setColorUtil( ColorUtil colorUtil ) {
    this.colorUtil = colorUtil;
  }
}
