/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateFocusChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateTextChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.TextChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.TextSelectionChangeListener;

public class TextOperator extends LabelOperator {

  private static final String STYLE_SINGLE = "SINGLE";
  private static final String STYLE_PASSWORD = "PASSWORD";
  private static final String STYLE_MULTI = "MULTI";

  public static final String TYPE = "rwt.widgets.Text";

  public TextOperator( TabrisActivity activity ) {
    super( activity );
    if( activity == null ) {
      throw new IllegalArgumentException( "No activity provided." );
    }
  }

  @Override
  public void create( CreateOperation operation ) {
    EditText editText = new Text( getActivity() );
    editText.setGravity( Gravity.TOP );
    setTextProperties( editText, operation.getProperties() );
    initiateNewView( operation, editText );
    initiateTextChangeListener( editText );
    initiateSelectionListener( editText );
    initiateCompositeFocusListener( editText );
  }

  private void initiateCompositeFocusListener( EditText editText ) {
    CompositeFocusListener compositeListener = new CompositeFocusListener();
    getListenerRegistry().registerListener( ( String )editText.getTag(), compositeListener );
    editText.setOnFocusChangeListener( compositeListener );
  }

  private void setTextProperties( EditText text, CreateProperties props ) {
    text.setTextSize( TypedValue.COMPLEX_UNIT_DIP, IThemeConstants.TEXT_TEXT_SIZE );

    List<String> styles = props.getStyle();

    if( styles != null ) {
      if( styles.contains( STYLE_SINGLE ) ) {
        // has to precede any PASSWORD style that may follow!
        text.setSingleLine( true );
      }
      if( styles.contains( STYLE_MULTI ) ) {
        text.setInputType( InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_CLASS_TEXT );
      }
      if( styles.contains( STYLE_PASSWORD ) ) {
        text.setTransformationMethod( new PasswordTransformationMethod() );
        text.setInputType( InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS );
      }
    }
  }

  private void initiateTextChangeListener( EditText view ) {
    String tag = ( String )view.getTag();
    StateRecorder recorder = getProcessor().getStateRecorder();
    TextChangeListener listener = new TextChangeListener( tag, recorder );
    view.addTextChangedListener( listener );
  }

  private void initiateSelectionListener( EditText view ) {
    StateRecorder recorder = getProcessor().getStateRecorder();
    TextSelectionChangeListener listener = new TextSelectionChangeListener( view, recorder );
    ( ( Text )view ).setSelectionChangeListener( listener );
  }

  @Override
  public String getType() {
    return TYPE;
  }

  @Override
  protected void attachModifyListener( ListenOperation operation ) {
    final EditText view = ( EditText )findViewByTarget( operation );
    String editTextTag = ( String )view.getTag();
    ImmediateTextChangeListener listener = new ImmediateTextChangeListener( editTextTag,
                                                                            getProcessor() );
    view.addTextChangedListener( listener );
    getListenerRegistry().registerListener( editTextTag, listener );
  }

  @Override
  protected void removeModifyListener( ListenOperation operation ) {
    String tag = operation.getTarget();
    final EditText view = ( EditText )findViewByTarget( operation );
    TextWatcher listenerToRemove = getListenerRegistry().unregisterListener( tag, TextWatcher.class );
    if( listenerToRemove != null ) {
      view.removeTextChangedListener( listenerToRemove );
    }
  }

  @Override
  protected void attachFocusListener( ListenOperation operation ) {
    CompositeFocusListener compositeListener = getCompositeListener( operation );
    compositeListener.addListener( new ImmediateFocusChangeListener( getActivity() ) );
  }

  private CompositeFocusListener getCompositeListener( ListenOperation operation ) {
    String widgetId = ( String )findViewByTarget( operation ).getTag();
    return getListenerRegistry().findListener( widgetId, CompositeFocusListener.class );
  }

  @Override
  protected void removeFocusListener( ListenOperation operation ) {
    CompositeFocusListener compositeListener = getCompositeListener( operation );
    compositeListener.removeListeners( ImmediateFocusChangeListener.class );
  }

}
