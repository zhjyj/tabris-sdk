/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class TreeViewAdapter extends BaseAdapter {

  private final TreeView treeView;
  private final LayoutInflater inflater;

  static class ViewHolder {

    public ImageView iconImage;
    public TextView titleText;
    public TextView descText;
  }

  public TreeViewAdapter( Activity activity, TreeView treeView ) {
    ValidationUtil.checkNullArg( this, activity, Activity.class );
    ValidationUtil.checkNullArg( this, treeView, TreeView.class );
    this.treeView = treeView;
    inflater = activity.getLayoutInflater();
  }

  public int getCount() {
    if( treeView.hasVirtualTreeSupport() ) {
      return treeView.getParentTreeItem().getItemCount();
    }
    return treeView.getCurrentTreeItems().size();
  }

  public Object getItem( int position ) {
    return treeView.getCurrentTreeItems().get( position );
  }

  public long getItemId( int position ) {
    return position;
  }

  public View getView( int position, View convertView, ViewGroup parent ) {
    ViewHolder viewHolder;
    View rowView = convertView;
    if( rowView == null ) {
      rowView = inflater.inflate( R.layout.tree_item_two_line, null, true );
      viewHolder = createHolder( rowView );
    } else {
      viewHolder = ( ViewHolder )rowView.getTag();
    }
    setupView( position, viewHolder );
    return rowView;
  }

  private void setupView( int position, ViewHolder viewHolder ) {
    ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
    if( currentTreeItems.size() > position ) {
      TreeItemView treeItemView = currentTreeItems.get( position );
      populateView( viewHolder, treeItemView );
    } else if( treeView.hasVirtualTreeSupport() ) {
      viewHolder.titleText.setText( StringUtil.DOT_DOT_DOT );
      viewHolder.descText.setVisibility( View.GONE );
      viewHolder.iconImage.setVisibility( View.GONE );
    }
  }

  private void populateView( ViewHolder viewHolder, TreeItemView treeItemView ) {
    populateTitle( viewHolder, treeItemView );
    populateDesc( viewHolder, treeItemView );
    populateIcon( viewHolder, treeItemView );
  }

  private void populateIcon( ViewHolder viewHolder, TreeItemView treeItemView ) {
    BitmapDrawable image = treeItemView.getImage();
    if( image != null ) {
      viewHolder.iconImage.setVisibility( View.VISIBLE );
      viewHolder.iconImage.setImageDrawable( image );
    } else {
      viewHolder.iconImage.setVisibility( View.GONE );
    }
  }

  private void populateDesc( ViewHolder viewHolder, TreeItemView treeItemView ) {
    List<String> texts = treeItemView.getTexts();
    if( texts != null && texts.size() > 1 ) {
      viewHolder.descText.setText( texts.get( 1 ) );
      viewHolder.descText.setVisibility( View.VISIBLE );
      if( texts.get( 1 ).length() == 0 ) {
        viewHolder.descText.setVisibility( View.GONE );
      }
    } else {
      viewHolder.descText.setVisibility( View.GONE );
    }
  }

  private void populateTitle( ViewHolder viewHolder, TreeItemView treeItemView ) {
    List<String> texts = treeItemView.getTexts();
    if( texts != null ) {
      viewHolder.titleText.setText( texts.get( 0 ) );
    }
  }

  private ViewHolder createHolder( View rowView ) {
    ViewHolder holder;
    holder = new ViewHolder();
    holder.titleText = ( TextView )rowView.findViewById( R.id.tree_item_title_text );
    holder.descText = ( TextView )rowView.findViewById( R.id.tree_item_desc_text );
    holder.iconImage = ( ImageView )rowView.findViewById( R.id.tree_item_image_item );
    rowView.setTag( holder );
    return holder;
  }

}
