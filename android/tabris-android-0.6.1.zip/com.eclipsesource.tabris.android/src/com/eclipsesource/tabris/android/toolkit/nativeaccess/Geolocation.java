/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import java.sql.Date;
import java.text.SimpleDateFormat;

import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Looper;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.GeolocationOperator.NeedsPositionFlavor;

public class Geolocation implements LocationListener {
  
  private static final String TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
  private static final int DEFAULT_MAXIMUM_AGE = -1;
  static final String CODE_PERMISSION_DENIED = "PERMISSION_DENIED";
  static final String CODE_UNKNOWN = "UNKNOWN";
  static final String CODE_UNAVAILABLE = "POSITION_UNAVAILABLE";
  static final String PROP_TIMESTAMP = "timestamp";
  static final String PROP_SPEED = "speed";
  static final String PROP_HEADING = "heading";
  static final String PROP_ALTITUDE_ACCURACY = "altitudeAccuracy";
  static final String PROP_ACCURACY = "accuracy";
  static final String PROP_ALTITUDE = "altitude";
  static final String PROP_LONGITUDE = "longitude";
  static final String PROP_LATITUDE = "latitude";
  static final String PROP_ERROR_MESSAGE = "errorMessage";
  static final String PROP_ERROR_CODE = "errorCode";
  
  private final Object lock = new Object();
  private final TabrisActivity activity;
  private final String id;
  private NeedsPositionFlavor flavor;
  private boolean enableHighAccuracy;
  private int frequency;
  private int maximumAge;
  private String provider;

  public Geolocation( TabrisActivity activity, String id ) {
    this.activity = activity;
    this.id = id;
    initializeDefaultValues();
  }

  private void initializeDefaultValues() {
    setNeedsPosition( NeedsPositionFlavor.NEVER );
    setEnableHighAccuracy( false );
    setMaximumAge( DEFAULT_MAXIMUM_AGE );
    setFrequency( 10000 );
  }
  
  public void setNeedsPosition( NeedsPositionFlavor newFlavor ) {
    synchronized( lock ) {
      flavor = newFlavor;
      if( flavor != NeedsPositionFlavor.NEVER ) {
        start();
      } else {
        stop();
      }
    }
  }

  public void setEnableHighAccuracy( boolean enableHighAccuracy ) {
    synchronized( lock ) {
      this.enableHighAccuracy = enableHighAccuracy;
    }
  }

  public void setFrequency( int intValue ) {
    synchronized( lock ) {
      this.frequency = intValue;
    }
  }

  public void setMaximumAge( int maximumAge ) {
    synchronized( lock ) {
      this.maximumAge = maximumAge;
    }
  }

  private void start() {
    synchronized( lock ) {
      Criteria criteria = createCriteria();
      createBestProvider( criteria ); 
      triggerUpdate();
    }
  }

  private Criteria createCriteria() {
    int accuracy = Criteria.ACCURACY_MEDIUM;
    if( enableHighAccuracy ) {
      accuracy = Criteria.ACCURACY_FINE;
    }
    Criteria criteria = new Criteria();
    criteria.setAccuracy( accuracy );
    criteria.setAltitudeRequired( true );
    criteria.setBearingRequired( true );
    return criteria;
  }

  private void createBestProvider( Criteria criteria ) {
    provider = getLocationManager().getBestProvider( criteria, true );
    if( provider == null ) {
      chooseProvider();
    }
  }

  private void chooseProvider() {
    if( getLocationManager().isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
      provider = LocationManager.GPS_PROVIDER;
    } else if( getLocationManager().isProviderEnabled( LocationManager.NETWORK_PROVIDER ) ) {
      provider = LocationManager.NETWORK_PROVIDER;
    } else {
      sendError( CODE_PERMISSION_DENIED, "No Provider enabled" );
    }
  }

  private void triggerUpdate() {
    if( maximumAge != DEFAULT_MAXIMUM_AGE ) {
      Location location = getLocationManager().getLastKnownLocation( provider );
      if( ( location.getTime() + maximumAge ) > System.currentTimeMillis() ) {
        onLocationChanged( location );
      } else {
        startUpdating();
      }
    } else {
      startUpdating();
    }
  }

  private void startUpdating() {
    getLocationManager().requestLocationUpdates( provider, frequency, 0, this, Looper.myLooper() );
  }

  public void destroy() {
    stop();
  }

  private void stop() {
    if( getLocationManager() != null ) {
      getLocationManager().removeUpdates( this );
    }
  }

  public void onLocationChanged( Location newLocation ) {
    PostRequest postRequest = new PostRequest();
    postRequest.addParam( id + "." + PROP_LATITUDE, String.valueOf( newLocation.getLatitude() ) );
    postRequest.addParam( id + "." + PROP_LONGITUDE, String.valueOf( newLocation.getLongitude() ) );
    postRequest.addParam( id + "." + PROP_ALTITUDE, String.valueOf( newLocation.getAltitude() ) );
    postRequest.addParam( id + "." + PROP_SPEED, String.valueOf( newLocation.getSpeed() ) );
    postRequest.addParam( id + "." + PROP_ACCURACY, String.valueOf( newLocation.getAccuracy() ) );
    // TODO: think about altitudeAccuracy
    postRequest.addParam( id + "." + PROP_ALTITUDE_ACCURACY, 
                          String.valueOf( newLocation.getAccuracy() ) );
    postRequest.addParam( id + "." + PROP_HEADING, String.valueOf( newLocation.getBearing() ) );
    SimpleDateFormat formater = new SimpleDateFormat( TIMESTAMP_FORMAT );
    String timestamp = formater.format( new Date( newLocation.getTime() ) );
    postRequest.addParam( id + "." + PROP_TIMESTAMP, String.valueOf( timestamp ) );
    activity.getProcessor().processPostRequest( postRequest );
    resetFlavor();
  }

  private void resetFlavor() {
    synchronized( lock ) {
      if( flavor == NeedsPositionFlavor.ONCE ) {
        stop();
        flavor = NeedsPositionFlavor.NEVER;
      }
    }
  }

  public void onProviderDisabled( String provider ) {
    if( provider.equals( this.provider ) ) {
      sendError( CODE_UNAVAILABLE, "Provider disabled" );
      getLocationManager().removeUpdates( this );
    }
  }

  public void onProviderEnabled( String provider ) {
    if( provider.equals( this.provider ) && flavor != NeedsPositionFlavor.NEVER ) {
      start();
    }
  }

  public void onStatusChanged( String provider, int status, Bundle extras ) {
    if(    status == LocationProvider.OUT_OF_SERVICE 
        || status == LocationProvider.TEMPORARILY_UNAVAILABLE ) 
    {
      String message = ( status == LocationProvider.OUT_OF_SERVICE ) 
                       ? "Out of Service" 
                       : "Temporarily Unavailable";
      sendError( CODE_UNKNOWN, message );
    }
  }

  private void sendError( String code, String message ) {
    PostRequest postRequest = new PostRequest();
    postRequest.addParam( id + "." + PROP_ERROR_CODE, code );
    postRequest.addParam( id + "." + PROP_ERROR_MESSAGE, message );
    activity.getProcessor().processPostRequest( postRequest );
  }

  // For testing purpose
  LocationManager getLocationManager() {
    return ( LocationManager )activity.getSystemService( Context.LOCATION_SERVICE );
  }
  
  NeedsPositionFlavor getFlavor() {
    return flavor;
  }

}
