/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DelegatingItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.ListItemLongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingOnScrollListener;
import com.eclipsesource.tabris.android.toolkit.view.TouchPositionBuffer;

public class ListOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.List";

  public ListOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    List list = new List( getActivity() );
    initiateNewView( operation, list );
    registerDefaultListeners( list );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    super.destroy( operation );
    String target = operation.getTarget();
    ListenerRegistry registry = getListenerRegistry();
    List list = findObjectById( target, List.class );
    list.setOnScrollListener( null );
    registry.unregisterListener( target, RecordingOnScrollListener.class );
    registry.unregisterListener( target, TouchPositionBuffer.class );
  }

  private void registerDefaultListeners( final List list ) {
    String widgetId = ( String )list.getTag();
    IWidgetToolkit toolkit = getActivity().getProcessor().getWidgetToolkit();
    registerTouchPositionBuffer( widgetId, toolkit );
    final OnItemClickListener compositeListItemClickListener = registerRecordingListItemClickListener( list );
    list.setOnItemSelectedListener( new DelegatingItemSelectedListener( compositeListItemClickListener ) );
    registerScrollListener( list );
  }

  private OnItemClickListener registerRecordingListItemClickListener( final List list ) {
    CompositeItemClickListener compositeListener = new CompositeItemClickListener();
    list.setOnItemClickListener( compositeListener );
    final RecordingListItemClickListener recordingListItemClickListener;
    recordingListItemClickListener = new RecordingListItemClickListener( getStateRecorder() );
    compositeListener.addListener( recordingListItemClickListener );
    return compositeListener;
  }

  private void registerTouchPositionBuffer( String widgetId, IWidgetToolkit toolkit ) {
    TouchPositionBuffer touchPositionBuffer = new TouchPositionBuffer( toolkit );
    getListenerRegistry().registerListener( widgetId, touchPositionBuffer );
    getCompositeTouchListener( widgetId ).addListener( touchPositionBuffer );
  }

  private StateRecorder getStateRecorder() {
    return getActivity().getProcessor().getStateRecorder();
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    CompositeItemClickListener compositeItemClickListener = ( CompositeItemClickListener )list.getOnItemClickListener();
    ImmediateListItemClickListener listItemClickListener = new ImmediateListItemClickListener( getActivity().getProcessor() );
    compositeItemClickListener.addListener( listItemClickListener );
  }

  private CompositeTouchListener getCompositeTouchListener( String widgetId ) {
    return getListenerRegistry().findListener( widgetId, CompositeTouchListener.class );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    CompositeItemClickListener compositeListener = ( CompositeItemClickListener )list.getOnItemClickListener();
    compositeListener.removeListeners( ImmediateListItemClickListener.class );
  }

  @Override
  protected void attachMenuDetectListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    list.setOnItemLongClickListener( new ListItemLongClickListener( getActivity().getProcessor() ) );
  }

  @Override
  protected void removeMenuDetectListener( ListenOperation operation ) {
    final List list = ( List )findViewByTarget( operation );
    list.setOnItemLongClickListener( null );
    list.setLongClickable( false );
  }

  private void registerScrollListener( final List list ) {
    RecordingOnScrollListener scrollListener = new RecordingOnScrollListener( getProcessor().getStateRecorder() );
    list.setOnScrollListener( scrollListener );
  }

}
