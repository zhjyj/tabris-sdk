/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import com.eclipsesource.tabris.android.TabrisActivity;

public class MouseEventTouchListener extends AbstractTouchListener
  implements OnTouchListener, IMotionBuffer
{

  private MotionEvent motionBuffer;
  private boolean isTransmittingUpDown;
  private boolean longPressDetected;

  public MouseEventTouchListener( TabrisActivity activity, boolean isTransmittingUpDown ) {
    super( activity );
    this.isTransmittingUpDown = isTransmittingUpDown;
  }

  public boolean onTouch( View view, MotionEvent event ) {
    String protocolEvent = calculateProtocolEvent( event );
    if( isTransmittingUpDown && protocolEvent != null ) {
      String button;
      if( longPressDetected ) {
        button = MOUSE_BUTTON_3;
      } else {
        button = MOUSE_BUTTON_1;
      }
      longPressDetected = false;
      sendMouseEventRequest( event, protocolEvent, button, ( String )view.getTag() );
    }
    if( EVENT_MOUSE_DOWN.equals( protocolEvent ) ) {
      updateMotionBuffer( event );
    } else if( EVENT_MOUSE_UP.equals( protocolEvent ) ) {
      // do nothing
    } else {
      updateMotionBuffer( event );
    }
    return false;
  }

  private void updateMotionBuffer( MotionEvent event ) {
    motionBuffer = event;
  }

  public boolean isTransmittingUpDown() {
    return isTransmittingUpDown;
  }

  public void setTransmittingUpDown( boolean isTransmittingUpDown ) {
    this.isTransmittingUpDown = isTransmittingUpDown;
  }

  public void longPressDetected() {
    longPressDetected = true;
  }

  public MotionEvent getLastMotion() {
    return motionBuffer;
  }

  public void clear() {
    motionBuffer = null;
  }

  private String calculateProtocolEvent( MotionEvent event ) {
    String protocolEvent = null;
    if( event.getAction() == MotionEvent.ACTION_DOWN ) {
      protocolEvent = EVENT_MOUSE_DOWN;
    } else if( event.getAction() == MotionEvent.ACTION_UP ) {
      protocolEvent = EVENT_MOUSE_UP;
    }
    return protocolEvent;
  }

}