/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.parser.SessionIDExtractor;

public class InitialRequestHandler implements IProtocolParserCallback {

  private static final String PROBE_METHOD = "probe";
  private static final String INIT_METHOD = "init";
  private static final String URL_PROPERTY_KEY = "url";

  private final ProtocolProcessor processor;
  private final SessionIDExtractor sessionIDExtractor;

  public InitialRequestHandler( ProtocolProcessor processor ) {
    this.processor = processor;
    this.sessionIDExtractor = new SessionIDExtractor();
  }

  public void operationsFound( ArrayList<Operation> ops ) {
    handleInitOperation( ops );
    handleProbeOperation( ops );
  }

  private void handleProbeOperation( ArrayList<Operation> ops ) {
    CallOperation probeOperation = getCallOperationByMethod( ops, PROBE_METHOD );
    processor.sendInitialPostRequest( probeOperation );
  }

  private void handleInitOperation( ArrayList<Operation> ops ) {
    CallOperation initOperation = getCallOperationByMethod( ops, INIT_METHOD );
    if( initOperation == null ) {
      throw new IllegalStateException( "CallOperation with method \""
                                       + INIT_METHOD
                                       + "\" not found in initial json snippet" );
    }
    String snippet = extractSessionIDSnippet( initOperation.getProperties() );
    processor.getTransport().setSessionId( sessionIDExtractor.extract( snippet ) );
  }

  private CallOperation getCallOperationByMethod( ArrayList<Operation> ops, String method ) {
    for( Operation operation : ops ) {
      if( operation instanceof CallOperation ) {
        CallOperation callOp = ( CallOperation )operation;
        if( method.equals( callOp.getMethod() ) ) {
          return callOp;
        }
      }
    }
    return null;
  }

  private String extractSessionIDSnippet( CallProperties props ) {
    String urlKey = URL_PROPERTY_KEY;
    if( props.containsKey( urlKey ) ) {
      return ( String )props.get( urlKey );
    }
    throw new IllegalStateException( "URL not found in initial json snippet" );
  }

  public void metaFound( Meta meta ) {
    // not required
  }

}
