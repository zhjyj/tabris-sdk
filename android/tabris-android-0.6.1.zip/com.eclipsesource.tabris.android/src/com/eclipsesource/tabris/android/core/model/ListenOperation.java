/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class ListenOperation extends PropertiesOperation<ListenProperties> {

  public static final String ACTION = "listen";

  @Override
  public String toString() {
    return "ListenOperation [getTarget()="
           + getTarget()
           + ", getProperties()="
           + getProperties()
           + "]";
  }

}
