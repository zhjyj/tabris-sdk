/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class FocusState extends AbstractState {

  String w1FocusControl = IProtocolConstants.W1_FOCUS_CONTROL;

  public FocusState( String widgetID ) {
    super( widgetID );
  }

  @Override
  public String generateKey() {
    return w1FocusControl;
  }

  @Override
  public String generateValue() {
    return widgetId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( w1FocusControl == null )
                                                          ? 0
                                                          : w1FocusControl.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    FocusState other = ( FocusState )obj;
    if( w1FocusControl == null ) {
      if( other.w1FocusControl != null ) {
        return false;
      }
    } else if( !w1FocusControl.equals( other.w1FocusControl ) ) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "FocusState [w1FocusControl=" + w1FocusControl + "]";
  }

}
