/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DefaultFonts {

  /*
   * [ 6145,
   * "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy"
   * , [ "" ], 24, true, false ], [ -785380997,
   * "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy"
   * , [ "Verdana", "Lucida Sans", "Arial", "Helvetica", "sans-serif" ], 14,
   * false, false ], [ 196059807,
   * "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy"
   * , [ "Helvetica", "Arial", "Verdana", "Lucida Sans", "sans-serif" ], 16,
   * false, false ], [ 9217,
   * "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy"
   * , [ "" ], 36, true, false ], [ -785377413,
   * "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy"
   * , [ "Verdana", "Lucida Sans", "Arial", "Helvetica", "sans-serif" ], 16,
   * false, false ]
   */
  @SuppressWarnings("rawtypes")
  public static List getFonts() {
    List<List> result = new ArrayList<List>();
    String probeString = "!#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxy";
    List<String> fonts = Arrays.asList( "" );

    result.add( Arrays.asList( 6145, probeString, fonts, 24, true, false ) );
    result.add( Arrays.asList( 9217, probeString, fonts, 36, true, false ) );
    fonts = Arrays.asList( "Verdana", "Lucida Sans", "Arial", "Helvetica", "sans-serif" );
    result.add( Arrays.asList( -785380997, probeString, fonts, 14, false, false ) );
    result.add( Arrays.asList( -785377413, probeString, fonts, 16, false, false ) );
    fonts = Arrays.asList( "Helvetica", "Arial", "Verdana", "Lucida Sans", "sans-serif" );
    result.add( Arrays.asList( 196059807, probeString, fonts, 16, false, false ) );

    return result;
  }
}
