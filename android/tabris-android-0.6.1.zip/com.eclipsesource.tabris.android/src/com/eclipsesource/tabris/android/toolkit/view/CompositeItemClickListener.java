/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

public class CompositeItemClickListener extends ListenerHolder<OnItemClickListener>
  implements OnItemClickListener
{

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    ArrayList<OnItemClickListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onItemClick( parent, view, position, id );
    }
  }

}
