/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;

public class EditTextSetter<T extends EditText> extends TextViewSetter<EditText> {

  @Override
  public void execute( TabrisActivity activity, EditText editText, SetProperties properties ) {
    super.execute( activity, editText, properties );
    setEditable( editText, properties );
    setTextLimit( editText, properties );
  }

  private void setTextLimit( EditText editText, SetProperties properties ) {
    Integer textLimit = properties.getTextLimit();
    if( textLimit != null ) {
      InputFilter[] filterArray = new InputFilter[ 1 ];
      filterArray[ 0 ] = new InputFilter.LengthFilter( textLimit );
      editText.setFilters( filterArray );
    }
  }

  @Override
  protected void setEnabled( View view, SetProperties properties ) {
    Boolean enabled = properties.getEnabled();
    if( enabled != null ) {
      view.setEnabled( enabled );
      setEditable( view, enabled );
    }
  }

  protected void setEditable( EditText editText, SetProperties properties ) {
    Boolean editable = properties.getEditable();
    if( editable != null ) {
      setEditable( editText, editable );
    }
  }

  private void setEditable( View view, boolean editable ) {
    EditText editText = ( ( EditText )view );
    editText.setFocusable( editable );
    editText.setFocusableInTouchMode( editable );
  }

  @Override
  @SuppressWarnings("unchecked")
  protected void setSelection( View view, SetProperties properties ) {
    GenericObject selectionProperty = properties.getSelection();
    if( selectionProperty != null ) {
      List<Number> selection = selectionProperty.getObjectAs( List.class );
      ( ( EditText )view ).setSelection( selection.get( 0 ).intValue(), selection.get( 1 )
        .intValue() );
    }
  }
}
