/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class LongClickListener extends AbstractTouchListener implements OnLongClickListener {

  private final IMotionBuffer motionBuffer;
  private final MouseEventTouchListener mouseEventTouchListener;
  private boolean isTransmittingMenuDetect;

  public LongClickListener( TabrisActivity activity,
                            IMotionBuffer motionBuffer,
                            MouseEventTouchListener mouseEventTouchListener,
                            boolean isTransmittingMenuDetect )
  {
    super( activity );
    this.motionBuffer = motionBuffer;
    this.mouseEventTouchListener = mouseEventTouchListener;
    this.isTransmittingMenuDetect = isTransmittingMenuDetect;
  }

  public boolean isTransmittingMenuDetect() {
    return isTransmittingMenuDetect;
  }

  public void setTransmittingMenuDetect( boolean isTransmittingMenuDetect ) {
    this.isTransmittingMenuDetect = isTransmittingMenuDetect;
  }

  public boolean onLongClick( View view ) {
    String widgetId = ( String )view.getTag();
    if( mouseEventTouchListener.isTransmittingUpDown() ) {
      String protocolEvent = EVENT_MOUSE_DOWN;
      sendMouseEventRequest( motionBuffer.getLastMotion(), protocolEvent, MOUSE_BUTTON_3, widgetId );
      mouseEventTouchListener.longPressDetected();
    }
    if( isTransmittingMenuDetect ) {
      sendMenuDetectRequest( motionBuffer.getLastMotion(), widgetId );
    }
    motionBuffer.clear();
    return true;
  }

  private void sendMenuDetectRequest( MotionEvent event, String widgetId ) {
    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = createMenuDetectRequest( event, widgetId, processor );
    processor.processPostRequest( request );
  }

  private PostRequest createMenuDetectRequest( MotionEvent event,
                                               String widgetId,
                                               ProtocolProcessor processor )
  {
    IWidgetToolkit toolkit = processor.getWidgetToolkit();
    String coordX = String.valueOf( toolkit.divideByDensityFactor( Math.round( event.getRawX() ) ) );
    String coordY = String.valueOf( toolkit.divideByDensityFactor( Math.round( event.getRawY() ) ) );
    PostRequest request = new PostRequest();
    request.addParam( EVENT_MENU_DETECT, widgetId );
    request.addParam( EVENT_MENU_DETECT + EVENT_MOUSE_COORD_X, coordX );
    request.addParam( EVENT_MENU_DETECT + EVENT_MOUSE_COORD_Y, coordY );
    request.addParam( W1_CURSOR_LOCATION_X, coordX );
    request.addParam( W1_CURSOR_LOCATION_Y, coordY );
    return request;
  }

}
