/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.util.TypedValue;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.view.Dialog;

public class ErrorDialog implements Runnable {

  protected final AndroidWidgetToolkit awt;
  protected Dialog dialog;

  public ErrorDialog( final Activity activity, AndroidWidgetToolkit awt ) {
    this.awt = awt;
    createDialog( activity );
  }

  private void createDialog( final Activity activity ) {
    String appName = activity.getString( R.string.app_name );
    dialog = new Dialog( activity );
    dialog.setTitle( appName );
    dialog.setIcon( getIcon( activity ) );
    createButtons( activity );
  }

  protected void createButtons( final Activity activity ) {
    dialog.setButton( DialogInterface.BUTTON_NEGATIVE,
                      activity.getString( R.string.dialog_error_button_close ),
                      new OnClickListener() {

                        public void onClick( DialogInterface dialog, int which ) {
                          activity.finish();
                        }
                      } );
    dialog.setButton( DialogInterface.BUTTON_POSITIVE,
                      activity.getString( R.string.dialog_restart_button_restart ),
                      new OnClickListener() {

                        public void onClick( DialogInterface dialog, int which ) {
                          activity.finish();
                          activity.startActivity( activity.getIntent() );
                        }
                      } );
    dialog.setButton( DialogInterface.BUTTON_NEUTRAL,
                      activity.getString( R.string.dialog_error_button_ignore ),
                      new OnClickListener() {

                        public void onClick( DialogInterface dialog, int which ) {
                          dialog.cancel();
                        }
                      } );
  }

  private static int getIcon( Context context ) {
    TypedValue outValue = new TypedValue();
    context.getTheme().resolveAttribute( R.attr.alertDialogIcon, outValue, true );
    return outValue.resourceId;
  }

  public void show( Throwable t ) {
    if( !dialog.isShowing() ) {
      dialog.setMessage( getMessage( t ) );
      awt.executeInUiThread( this );
    }
  }

  private String getMessage( Throwable t ) {
    String message = t.getMessage();
    if( message == null ) {
      message = dialog.getContext().getString( R.string.dialog_unexpected_error_occured )
                + t.getClass().getSimpleName();
    }
    return message;

  }

  public void run() {
    dialog.show();
  }

  /** To be used for testing only. */
  Dialog getDialog() {
    return dialog;
  }

}