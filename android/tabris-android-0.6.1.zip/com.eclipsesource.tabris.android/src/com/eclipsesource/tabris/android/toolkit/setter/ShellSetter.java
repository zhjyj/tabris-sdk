/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.graphics.drawable.BitmapDrawable;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.util.LoadImageTask;
import com.eclipsesource.tabris.android.toolkit.view.DialogHeader;
import com.eclipsesource.tabris.android.toolkit.view.Shell;

public class ShellSetter<T extends Shell> extends CompositeSetter<T> {

  @Override
  public void execute( TabrisActivity activity, T shell, SetProperties setProperties ) {
    super.execute( activity, shell, setProperties );
    setMode( shell, setProperties );
    setVisibility( activity, shell, setProperties );
    setText( shell, setProperties );
    setIcon( shell, setProperties );
  }

  private void setText( T shell, SetProperties setProperties ) {
    String text = setProperties.getText();
    if( text != null ) {
      shell.setText( text );
    }
  }

  private void setIcon( T shell, SetProperties setProperties ) {
    if( hasImage( setProperties ) ) {
      List<String> image = setProperties.getImage();
      asynchSetIconOnTitle( shell, image );
    }
  }

  @SuppressWarnings("unchecked")
  private void asynchSetIconOnTitle( final T shell, List<String> image ) {
    new LoadImageTask( getActivity() ) {

      @Override
      protected void onPostExecute( BitmapDrawable drawable ) {
        dereferenceIcon( getProcessor(), shell );
        shell.setIcon( drawable );
      }

    }.loadBitmap( image );
  }

  private boolean hasImage( SetProperties properties ) {
    if( properties == null ) {
      return false;
    }
    List<String> image = properties.getImage();
    return image != null && !image.isEmpty();
  }

  private void setVisibility( TabrisActivity activity, Shell shell, SetProperties setProperties ) {
    Boolean visibility = setProperties.getVisibility();
    if( visibility != null ) {
      if( visibility == true ) {
        shell.playShowAnimation( getActivity() );
      } else if( visibility == false ) {
        shell.playHideAnimation( getActivity() );
      }
    }
  }

  private void setMode( Shell shell, SetProperties setProperties ) {
    String mode = setProperties.getMode();
    if( mode == null ) {
      shell.setMode( null );
    } else if( mode != SetProperties.NOT_MODIFIFED ) {
      shell.setMode( mode );
    }
  }

  public static void dereferenceIcon( ProtocolProcessor processor, final Shell shell ) {
    BitmapDrawableCache bitmapCache = processor.getWidgetToolkit().getBitmapCache();
    DialogHeader header = shell.getHeader();
    if( header != null ) {
      BitmapDrawable bitmapDrawable = ( BitmapDrawable )header.getIcon().getDrawable();
      bitmapCache.decreaseReferenceCount( bitmapDrawable );
    }
  }

}
