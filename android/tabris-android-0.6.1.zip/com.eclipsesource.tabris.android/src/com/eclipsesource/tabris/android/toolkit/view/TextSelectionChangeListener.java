/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.EditText;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.TextSelectionLengthState;
import com.eclipsesource.tabris.android.toolkit.view.state.TextSelectionStartState;

public class TextSelectionChangeListener {

  private EditText view;
  private StateRecorder stateRecorder;

  public TextSelectionChangeListener( EditText view, StateRecorder stateRecorder ) {
    this.view = view;
    this.stateRecorder = stateRecorder;
  }

  public void afterSelectionChanged( int selectionStart, int selectionLength ) {
    String tag = ( String )view.getTag();
    stateRecorder.recordState( new TextSelectionStartState( tag, selectionStart ) );
    stateRecorder.recordState( new TextSelectionLengthState( tag, selectionLength ) );
  }
}
