/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Looper;
import android.util.DisplayMetrics;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;

public class LoadImageTask extends AsyncTask<List<String>, Integer, BitmapDrawable> {

  private static final Executor threadPool = Executors.newFixedThreadPool( 5 );

  private final TabrisActivity activity;

  public LoadImageTask( TabrisActivity activity ) {
    this.activity = activity;
  }

  @Override
  protected BitmapDrawable doInBackground( List<String>... params ) {
    String pathToImage = getValidatedPath( params );
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    BitmapDrawable drawable = cache.getOrWait( pathToImage );
    if( drawable == null ) {
      Bitmap loadedBitmap = loadBitmapFromPath( activity, pathToImage );
      if( loadedBitmap == null ) {
        cache.unlockWriteLock( pathToImage );
      } else {
        drawable = createBitmapDrawable( loadedBitmap );
        cache.putAndNotify( pathToImage, drawable );
      }
    } else {
      cache.increaseReferenceCount( pathToImage );
    }
    return drawable;
  }

  private BitmapDrawable createBitmapDrawable( Bitmap loadedBitmap ) {
    BitmapDrawable drawable = new BitmapDrawable( activity.getResources(), loadedBitmap );
    drawable.setTileModeXY( TileMode.REPEAT, TileMode.REPEAT );
    return drawable;
  }

  public void loadBitmap( List<String>... params ) {
    String path = getValidatedPath( params );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    ReferenceAwareLRUCache<String, BitmapDrawable> cache = toolkit.getBitmapCache();
    BitmapDrawable bitmapDrawable = cache.get( path );
    if( bitmapDrawable != null && Looper.myLooper() == Looper.getMainLooper() ) {
      cache.increaseReferenceCount( path );
      onPostExecute( bitmapDrawable );
    } else {
      if( toolkit.getApiLevel() < Build.VERSION_CODES.HONEYCOMB ) {
        execute( params );
      } else {
        executeOnExecutor( threadPool, params );
      }
    }
  }

  private String getValidatedPath( List<String>... params ) {
    if( params.length == 0 ) {
      throw new IllegalArgumentException( "The image list given to LoadBitmapTask can not be empty." );
    }
    if( params[ 0 ] == null ) {
      throw new IllegalArgumentException( "The image param given to LoadBitmapTask can not be null." );
    }
    List<String> image = params[ 0 ];
    if( image.size() != 3 ) {
      throw new IllegalArgumentException( "The image parameter has to be a 3-element touple. Got "
                                          + image.size()
                                          + " elements." );
    }
    String pathToImage = image.get( 0 ).trim();
    if( pathToImage.length() == 0 ) {
      throw new IllegalArgumentException( "The backgroundImage url path is empty" );
    }
    return pathToImage;
  }

  private static Bitmap loadBitmapFromPath( TabrisActivity activity,
                                            String pathToImage )
  {
    ITransportResult transportResult = activity.getProcessor()
      .processGetRequest( new GetRequest( StringUtil.SLASH_DOT_DOT_SLASH + pathToImage ) );
    if( transportResult.hasException() ) {
      return null;
    }
    return loadBitmap( activity, transportResult );
  }

  private static Bitmap loadBitmap( TabrisActivity activity,
                                    final ITransportResult transportResult )
  {
    byte[] bytes = toByteArray( transportResult.getResult() );
    Bitmap bitmap = null;
    try {
      BitmapFactory.Options options = new BitmapFactory.Options();
      options.inDensity = DisplayMetrics.DENSITY_DEFAULT;
      options.inTargetDensity = activity.getProcessor().getWidgetToolkit().getDensityDpi();
      bitmap = BitmapFactory.decodeStream( new ByteArrayInputStream( bytes ), null, options );
    } catch( Throwable t ) {
      if( t instanceof OutOfMemoryError ) {
        t = new RuntimeException( "The device memory limit has been reached while trying to decode an image." );
      }
      activity.getProcessor().getWidgetToolkit().showError( t );
    }
    return bitmap;
  }

  private static byte[] toByteArray( final InputStream is ) {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    try {
      int nRead;
      byte[] data = new byte[ 16384 ];

      while( ( nRead = is.read( data, 0, data.length ) ) != -1 ) {
        buffer.write( data, 0, nRead );
      }

      buffer.flush();
    } catch( IOException e ) {
      throw new RuntimeException( "Could not read image from stream", e );
    }
    return buffer.toByteArray();
  }

}