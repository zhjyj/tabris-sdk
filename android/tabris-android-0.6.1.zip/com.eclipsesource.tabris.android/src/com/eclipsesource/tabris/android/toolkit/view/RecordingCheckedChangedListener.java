/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectionState;

public class RecordingCheckedChangedListener implements OnCheckedChangeListener {

  private final StateRecorder stateRecorder;

  public RecordingCheckedChangedListener( StateRecorder stateRecorder ) {
    this.stateRecorder = stateRecorder;
    if( stateRecorder == null ) {
      throw new IllegalArgumentException( "The state recorder can not be null" );
    }
  }

  public void onCheckedChanged( CompoundButton buttonView, boolean isChecked ) {
    SelectionState state = new SelectionState( ( String )buttonView.getTag(), isChecked );
    stateRecorder.recordState( state );
  }
}