/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

public interface IBrowserProgressListener {

  void pageFinishedLoading( String widgetId );

}
