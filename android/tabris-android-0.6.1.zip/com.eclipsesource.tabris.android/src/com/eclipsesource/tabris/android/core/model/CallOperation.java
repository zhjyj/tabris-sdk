/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

public class CallOperation extends PropertiesOperation<CallProperties> {

  public static final String ACTION = "call";

  private String method;

  public String getMethod() {
    return method;
  }

  public void setMethod( String method ) {
    this.method = method;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( method == null )
                                                  ? 0
                                                  : method.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( !super.equals( obj ) )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    CallOperation other = ( CallOperation )obj;
    if( method == null ) {
      if( other.method != null )
        return false;
    } else if( !method.equals( other.method ) )
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "CallOperation [method="
           + method
           + ", getTarget()="
           + getTarget()
           + ", getProperties()="
           + getProperties()
           + "]";
  }

}
