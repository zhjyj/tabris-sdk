/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Calendar;

import android.util.SparseArray;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.state.DateTimeState;

public class RecordingDateTimeChangedListener implements IDateTimeChangedListener {

  private final StateRecorder stateRecorder;
  private final SparseArray<String> dateValues;

  public RecordingDateTimeChangedListener( StateRecorder stateRecorder,
                                           SparseArray<String> dateValues )
  {
    ValidationUtil.checkNullArg( this, stateRecorder, StateRecorder.class );
    ValidationUtil.checkNullArg( this, dateValues, SparseArray.class );
    this.stateRecorder = stateRecorder;
    this.dateValues = dateValues;
  }

  public void dateTimeChanged( DateTimeSpinner spinner ) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime( spinner.getDate() );
    recordStates( ( String )spinner.getTag(), calendar );
  }

  private void recordStates( String tag, Calendar calendar ) {
    for( int i = 0; i < dateValues.size(); i++ ) {
      IState state = new DateTimeState( tag,
                                        dateValues.valueAt( i ),
                                        calendar.get( dateValues.keyAt( i ) ) );
      stateRecorder.recordState( state );
    }
  }

  /** To be used for testing only. */
  public SparseArray<String> getDateValues() {
    return dateValues;
  }
}
