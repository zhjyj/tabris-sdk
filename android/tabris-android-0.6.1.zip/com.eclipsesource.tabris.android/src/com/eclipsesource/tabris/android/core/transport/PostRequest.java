/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.transport;

import java.util.HashMap;
import java.util.Map;

public class PostRequest extends TransportRequest {

  private final HashMap<String, String> params;

  public PostRequest( String path ) {
    super( path );
    params = new HashMap<String, String>();
  }

  public PostRequest() {
    this( "" );
  }

  public PostRequest( HashMap<String, String> params ) {
    this();
    addParams( params );
  }

  public void addParam( String key, String value ) {
    if( key == null ) {
      throw new IllegalArgumentException( "Can not add parameter with null key to a PostRequest" );
    }
    params.put( key, value );
  }

  public Map<String, String> getParams() {
    return params;
  }

  public void addParams( HashMap<String, String> newParams ) {
    if( newParams == null ) {
      throw new IllegalArgumentException( "Can not add null parameter map to a PostRequest" );
    }
    params.putAll( newParams );
  }

  public void mergeInto( PostRequest request ) {
    params.putAll( request.getParams() );
  }

  @Override
  public String toString() {
    return "PostRequest [params=" + params + ", getPath()=" + getPath() + "]";
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( params == null )
                                                  ? 0
                                                  : params.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    PostRequest other = ( PostRequest )obj;
    if( params == null ) {
      if( other.params != null ) {
        return false;
      }
    } else if( !params.equals( other.params ) ) {
      return false;
    }
    return true;
  }

}
