/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;

public class SpinnerSetter<T extends Spinner> extends ViewSetter<T> {

  @Override
  public void execute( TabrisActivity activity, T spinner, SetProperties properties ) {
    super.execute( activity, spinner, properties );
    setItems( spinner, properties );
    setSelectionIndex( spinner, properties );
  }

  @SuppressWarnings("unchecked")
  private void setItems( Spinner spinner, SetProperties properties ) {
    List<String> items = properties.getItems();
    if( items != null ) {
      ArrayAdapter<String> adapter = ( ArrayAdapter<String> )spinner.getAdapter();
      clearAdapter( adapter );
      for( int i = 0; i < items.size(); i++ ) {
        adapter.add( items.get( i ) );
      }
    }
  }

  private void clearAdapter( ArrayAdapter<String> adapter ) {
    int count = adapter.getCount();
    for( int i = 0; i < count; i++ ) {
      adapter.remove( adapter.getItem( 0 ) );
    }
  }

  private void setSelectionIndex( Spinner spinner, SetProperties properties ) {
    Integer selectionIndex = properties.getSelectionIndex();
    if( selectionIndex != null ) {
      if( selectionIndex < 0 ) {
        spinner.setSelection( 0 );
      } else {
        spinner.setSelection( selectionIndex );
      }
    }

  }
}
