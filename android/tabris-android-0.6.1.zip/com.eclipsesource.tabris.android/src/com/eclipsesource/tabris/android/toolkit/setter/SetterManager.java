/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.HashMap;
import java.util.List;

import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.Browser;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.Composite;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Shell;
import com.eclipsesource.tabris.android.toolkit.view.TabFolder;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;
import com.eclipsesource.tabris.android.toolkit.view.TreeItemView;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class SetterManager {

  static final int COLOR_COMP_A = 24;
  static final int COLOR_COMP_R = 16;
  static final int COLOR_COMP_G = 8;
  static final int COLOR_COMP_B = 0;

  private final HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter;

  public SetterManager() {
    viewSetter = new HashMap<Class<? extends View>, IViewSetter<? extends View>>();
    viewSetter.put( Display.class, new DisplaySetter<Display>() );
    viewSetter.put( View.class, new ViewSetter<View>() );
    viewSetter.put( TextView.class, new TextViewSetter<TextView>() );
    viewSetter.put( EditText.class, new EditTextSetter<EditText>() );
    viewSetter.put( Button.class, new ButtonSetter<Button>() );
    viewSetter.put( CompoundButton.class, new CompoundButtonSetter<CompoundButton>() );
    viewSetter.put( TreeItemView.class, new TreeItemViewSetter<TreeItemView>() );
    viewSetter.put( TreeView.class, new TreeViewSetter<TreeView>() );
    viewSetter.put( TabFolder.class, new TabHostSetter<TabFolder>() );
    viewSetter.put( ObservableVerticalScrollView.class,
                    new ObservableVerticalScrollViewSetter<ObservableVerticalScrollView>() );
    viewSetter.put( ObservableHorizontalScrollView.class,
                    new ObservableHorizontalScrollViewSetter<ObservableHorizontalScrollView>() );
    viewSetter.put( Spinner.class, new SpinnerSetter<Spinner>() );
    viewSetter.put( Composite.class, new CompositeSetter<Composite>() );
    viewSetter.put( Shell.class, new ShellSetter<Shell>() );
    viewSetter.put( ModalShell.class, new ModalShellSetter<ModalShell>() );
    viewSetter.put( ToolItem.class, new ToolItemSetter<ToolItem>() );
    viewSetter.put( Browser.class, new BrowserSetter<Browser>() );
    viewSetter.put( Canvas.class, new CanvasSetter<Canvas>() );
    viewSetter.put( Group.class, new GroupSetter<Group>() );
    viewSetter.put( com.eclipsesource.tabris.android.toolkit.view.List.class,
                    new ListSetter<com.eclipsesource.tabris.android.toolkit.view.List>() );
    viewSetter.put( ProgressBar.class, new ProgressBarSetter<ProgressBar>() );
    viewSetter.put( Separator.class, new SeparatorSetter<Separator>() );
  }

  @SuppressWarnings("unchecked")
  public void execute( TabrisActivity activity, View view, SetProperties properties ) {
    if( view == null ) {
      throw new IllegalArgumentException( "The view to set properties on can not be null" );
    }
    if( properties == null ) {
      throw new IllegalArgumentException( "The properties to set properties on a view can not be null" );
    }
    IViewSetter<View> setter = ( IViewSetter<View> )findSetter( view.getClass() );
    if( setter == null ) {
      throw new IllegalStateException( "Could not find a Setter class for a " + view.getClass() );
    }
    setter.execute( activity, view, properties );
  }

  private IViewSetter<?> findSetter( Class<?> clazz ) {
    IViewSetter<?> setter = viewSetter.get( clazz );
    if( setter == null ) {
      Class<?> superclass = clazz.getSuperclass();
      if( superclass != null ) {
        setter = findSetter( superclass );
      }
    }
    return setter;
  }

  public static int colorToupleToInt( List<Integer> touple ) {
    if( touple == null ) {
      throw new IllegalArgumentException( "The given color touple can not be null" );
    }
    if( touple.size() < 3 ) {
      throw new IllegalArgumentException( "The given color touple can not be smaller than 3. Given Touple is "
                                          + touple.size() );
    }
    if( touple.size() > 4 ) {
      throw new IllegalArgumentException( "The given color touple can not be larger than 4. Given Touple is "
                                          + touple.size() );
    }

    int r = createHex( touple.get( 0 ), COLOR_COMP_R );
    int g = createHex( touple.get( 1 ), COLOR_COMP_G );
    int b = createHex( touple.get( 2 ), COLOR_COMP_B );
    int a;
    if( touple.size() == 4 ) {
      a = createHex( touple.get( 3 ), COLOR_COMP_A );
    } else {
      a = 0xFF000000;
    }
    return a | r | g | b;
  }

  private static int createHex( int value, int component ) {
    if( value < 0 || value > 255 ) {
      throw new IllegalArgumentException( "Can not create color because color value is not in the range of [0-255]" );
    }
    return ( value & 0xff ) << component;
  }

  /** Should only be used for testing. */
  public HashMap<Class<? extends View>, IViewSetter<? extends View>> getViewSetter() {
    return viewSetter;
  }
}
