/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.view.View.OnClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class ViewClickListener implements OnClickListener {

  private final TabrisActivity activity;

  public ViewClickListener( TabrisActivity activity ) {
    ValidationUtil.checkNullArg( this, activity, TabrisActivity.class );
    this.activity = activity;
  }

  public void onClick( View view ) {
    if( view == null ) {
      throw new IllegalArgumentException( "The view parameter that has been clicked on can not be null" );
    }
    activity.getProcessor().processPostRequest( createRequestParam( view ) );
  }

  protected PostRequest createRequestParam( View view ) {
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, ( String )view.getTag() );
    return request;
  }
}