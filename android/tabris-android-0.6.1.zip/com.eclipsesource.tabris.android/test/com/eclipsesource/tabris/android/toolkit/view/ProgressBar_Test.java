/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.app.Activity;

import com.eclipsesource.tabris.android.test.shadow.TabrisProgressBar;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ProgressBar_Test {

  @Test
  public void testCreate() {
    ProgressBar progressBar = new ProgressBar( new Activity() );

    assertEquals( 100, progressBar.getMax() );
    assertEquals( 0, progressBar.getMin() );
  }

  @Test
  public void testSetProgress() throws Exception {
    ProgressBar progressBar = new ProgressBar( new Activity() );
    progressBar.setMin( 30 );

    progressBar.setProgress( 50 );

    assertEquals( 20, progressBar.getProgress() );
  }

  @Test
  public void testSetMin() throws Exception {
    Robolectric.bindShadowClass( TabrisProgressBar.class );
    ProgressBar progressBar = new ProgressBar( new Activity() );
    progressBar.setMax( 100 );
    progressBar.setProgress( 40 );

    progressBar.setMin( 30 );

    assertEquals( 10, progressBar.getProgress() );
    assertEquals( 70, progressBar.getMax() );
  }

  @Test
  public void testSetMax() throws Exception {
    Robolectric.bindShadowClass( TabrisProgressBar.class );
    ProgressBar progressBar = new ProgressBar( new Activity() );
    progressBar.setMax( 100 );

    assertEquals( 100, progressBar.getMax() );

    progressBar.setMin( 30 );

    progressBar.setMax( 200 );

    assertEquals( 170, progressBar.getMax() );
  }

}
