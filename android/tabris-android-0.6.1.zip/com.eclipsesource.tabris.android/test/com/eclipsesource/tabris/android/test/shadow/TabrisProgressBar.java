/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import com.eclipsesource.tabris.android.toolkit.view.ProgressBar;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowProgressBar;

@Implements(ProgressBar.class)
public class TabrisProgressBar extends ShadowProgressBar {

  private int max;
  private boolean indeterminate;

  @Override
  @Implementation
  public void setMax( int max ) {
    this.max = max;
  }

  @Override
  @Implementation
  public int getMax() {
    return max;
  }

  @Implementation
  public synchronized void setIndeterminate( boolean indeterminate ) {
    this.indeterminate = indeterminate;
  }

  @Implementation
  public synchronized boolean isIndeterminate() {
    return indeterminate;
  }
}
