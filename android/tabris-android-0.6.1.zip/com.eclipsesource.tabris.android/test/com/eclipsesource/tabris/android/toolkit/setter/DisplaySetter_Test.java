/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Display;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class DisplaySetter_Test {

  private static final String WIDGET_ID = "w23";

  @Test
  public void testSetFocusControl() {
    DisplaySetter<Display> setter = new DisplaySetter<Display>();
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    Display display = mock( Display.class );
    View view = mock( View.class );
    when( activity.getProcessor().getWidgetToolkit().findObjectById( WIDGET_ID, View.class ) ).thenReturn( view );
    SetProperties props = new SetProperties();
    props.setFocusControl( WIDGET_ID );

    setter.execute( activity, display, props );

    verify( view ).requestFocus();
  }
}
