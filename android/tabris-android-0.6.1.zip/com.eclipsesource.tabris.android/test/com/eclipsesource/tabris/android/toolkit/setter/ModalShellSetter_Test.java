/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.setter.IViewSetter;
import com.eclipsesource.tabris.android.toolkit.setter.ModalShellSetter;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.ModalShell;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ModalShellSetter_Test {

  private TabrisActivity activityMock;
  private ModalShell shellMock;

  @Before
  public void setUp() {
    activityMock = mock( TabrisActivity.class );
    shellMock = mock( ModalShell.class );
  }

  @Test
  public void testSetterFound() {
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = new SetterManager().getViewSetter();

    Assert.assertTrue( "ModalShellSetter not found in SetterUtil's list of setters.",
                       viewSetter.containsKey( ModalShell.class ) );
  }

  @Test
  public void testSetTranslatedBounds() {
    ModalShellSetter<ModalShell> setter = new ModalShellSetter<ModalShell>();
    SetProperties props = new SetProperties();
    props.setBounds( Arrays.asList( 10, 20, 30, 40 ) );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( activityMock.getProcessor() ).thenReturn( processor );
    when( shellMock.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( toolkit.multiplyByDensityFactor( 10 - IThemeConstants.DIALOG_SHADOW_SIZE ) ).thenReturn( 15 );
    when( toolkit.multiplyByDensityFactor( 20 - IThemeConstants.DIALOG_SHADOW_SIZE ) ).thenReturn( 25 );
    when( toolkit.multiplyByDensityFactor( 30 ) ).thenReturn( 35 );
    when( toolkit.multiplyByDensityFactor( 40 ) ).thenReturn( 45 );

    setter.execute( activityMock, shellMock, props );

    MarginLayoutParams layoutParams = ( MarginLayoutParams )shellMock.getLayoutParams();
    assertEquals( 15, layoutParams.leftMargin );
    assertEquals( 25, layoutParams.topMargin );
    assertEquals( 35, layoutParams.width );
    assertEquals( 45, layoutParams.height );
  }
}
