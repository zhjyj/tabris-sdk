/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.util.TypedValue;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.toolkit.IThemeConstants;
import com.eclipsesource.tabris.android.toolkit.view.PushToolItem;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class PushToolItem_Test {

  private TabrisActivity activity;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    when( processor.getWidgetToolkit() ).thenReturn( mock( IWidgetToolkit.class ) );
    activity.setProcessor( processor );
  }

  @Test
  public void testUpdateAppearance() {
    PushToolItem toolItem = new PushToolItem( activity );
    PushToolItem toolItemSpy = spy( toolItem );

    toolItemSpy.updateAppearance();

    verify( toolItemSpy ).setTextSize( eq( TypedValue.COMPLEX_UNIT_DIP ),
                                       eq( IThemeConstants.BUTTON_TEXT_SIZE ) );
  }

  @Test
  public void testUpdateAppearanceWithCustomVariantTitle() {
    PushToolItem toolItem = new PushToolItem( activity );
    toolItem.setTag( R.id.custom_variant, ICustomVariants.TITLE );
    PushToolItem toolItemSpy = spy( toolItem );

    toolItemSpy.updateAppearance();

    verify( toolItemSpy ).setTextAppearance( eq( activity ), anyInt() );
  }

}
