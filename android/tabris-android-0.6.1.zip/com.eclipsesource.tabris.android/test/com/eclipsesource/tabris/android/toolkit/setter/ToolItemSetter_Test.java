/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.ICustomVariants;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowTextView;
import com.eclipsesource.tabris.android.toolkit.setter.ToolItemSetter;
import com.eclipsesource.tabris.android.toolkit.view.ToolBar;
import com.eclipsesource.tabris.android.toolkit.view.ToolItem;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ToolItemSetter_Test {

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );
  }

  @Test
  public void testSetTextNull() {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    TextView textView = mock( TextView.class );

    setter.setText( textView, mock( SetProperties.class ) );

    verify( textView ).setCompoundDrawablePadding( 0 );
  }

  @Test
  public void testSetTextEmptyString() {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    TextView textView = mock( TextView.class );

    setter.setText( textView, mock( SetProperties.class ) );

    verify( textView ).setCompoundDrawablePadding( 0 );
  }

  @Test
  public void testSetLoadedBitmapDrawable() {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    TextView textView = mock( TextView.class );

    setter.setBitmapDrawable( textView, mock( BitmapDrawable.class ) );

    verify( textView ).setCompoundDrawablePadding( 0 );
  }

  @Test
  public void testSetImageWithExistingText() {
    Robolectric.bindShadowClass( TabrisShadowTextView.class );
    when( toolkit.multiplyByDensityFactor( ToolItemSetter.ICON_PADDING ) ).thenReturn( 1000 );
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    toolItem.setText( "Hallo" );
    TextView spyTextView = spy( toolItem );

    setter.execute( activity, toolItem, new SetProperties() );
    setter.setBitmapDrawable( spyTextView, mock( BitmapDrawable.class ) );

    verify( spyTextView ).setCompoundDrawablePadding( 1000 );
  }

  @Test
  public void testSetTextWithExistingImage() {
    Robolectric.bindShadowClass( TabrisShadowTextView.class );
    when( toolkit.multiplyByDensityFactor( ToolItemSetter.ICON_PADDING ) ).thenReturn( 1000 );
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    toolItem.setCompoundDrawablesWithIntrinsicBounds( mock( BitmapDrawable.class ),
                                                      null,
                                                      null,
                                                      null );
    ToolItem spyTextView = spy( toolItem );
    SetProperties properties = new SetProperties();
    properties.setText( "Hallo" );
    setter.execute( activity, toolItem, properties );
    setter.setText( spyTextView, properties );

    verify( spyTextView ).setCompoundDrawablePadding( 1000 );
  }

  @Test
  public void testSetCustomVariantFromNotTitleToTitle() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    ToolBar toolBar = new ToolBar( activity );
    toolBar.addView( toolItem );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( ICustomVariants.TITLE );

    ViewGroup firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 0, firstChild.getChildCount() );
    ViewGroup secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 1, secondChild.getChildCount() );

    setter.execute( activity, toolItem, properties );

    firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 1, firstChild.getChildCount() );
    secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 0, secondChild.getChildCount() );
  }

  @Test
  public void testSetCustomVariantFromTitleToNotTitle() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    toolItem.setTag( R.id.custom_variant, ICustomVariants.TITLE );
    ToolBar toolBar = new ToolBar( activity );
    toolBar.addView( toolItem );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( null );

    ViewGroup firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 1, firstChild.getChildCount() );
    ViewGroup secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 0, secondChild.getChildCount() );

    setter.execute( activity, toolItem, properties );

    firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 0, firstChild.getChildCount() );
    secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 1, secondChild.getChildCount() );
  }

  @Test
  public void testSetCustomVariantFromTitleToTitle() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    toolItem.setTag( R.id.custom_variant, ICustomVariants.TITLE );
    ToolBar toolBar = new ToolBar( activity );
    toolBar.addView( toolItem );
    SetProperties properties = new SetProperties();
    properties.setCustomVariant( ICustomVariants.TITLE );

    ViewGroup firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 1, firstChild.getChildCount() );
    ViewGroup secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 0, secondChild.getChildCount() );

    setter.execute( activity, toolItem, properties );

    firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 1, firstChild.getChildCount() );
    secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 0, secondChild.getChildCount() );
  }

  @Test
  public void testSetCustomVariantFromNotTitleToNotTitle() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = new ToolItem( activity );
    ToolBar toolBar = new ToolBar( activity );
    toolBar.addView( toolItem );
    SetProperties properties = new SetProperties();

    ViewGroup firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 0, firstChild.getChildCount() );
    ViewGroup secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 1, secondChild.getChildCount() );

    setter.execute( activity, toolItem, properties );

    firstChild = ( ViewGroup )toolBar.getChildAt( 0 );
    assertEquals( 0, firstChild.getChildCount() );
    secondChild = ( ViewGroup )toolBar.getChildAt( 1 );
    assertEquals( 1, secondChild.getChildCount() );
  }

  @Test
  public void testGetDefaultVerticalAlignment() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();

    int defaultVerticalAlignment = setter.getDefaultVerticalAlignment();

    assertEquals( Gravity.CENTER_VERTICAL, defaultVerticalAlignment );
  }

  @Test
  public void testSetBitmapDrawable() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = mock( ToolItem.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );

    setter.setBitmapDrawable( toolItem, bitmapDrawable );

    verify( toolItem ).setCompoundDrawablesWithIntrinsicBounds( eq( bitmapDrawable ),
                                                                isNull( BitmapDrawable.class ),
                                                                isNull( BitmapDrawable.class ),
                                                                isNull( BitmapDrawable.class ) );
  }

  @Test
  public void testGetBitmapDrawable() throws Exception {
    ToolItemSetter<ToolItem> setter = new ToolItemSetter<ToolItem>();
    ToolItem toolItem = mock( ToolItem.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( toolItem.getCompoundDrawables() ).thenReturn( new Drawable[]{
      bitmapDrawable, null, null, null
    } );

    BitmapDrawable result = setter.getBitmapDrawable( toolItem );

    assertEquals( result, bitmapDrawable );
  }
}
