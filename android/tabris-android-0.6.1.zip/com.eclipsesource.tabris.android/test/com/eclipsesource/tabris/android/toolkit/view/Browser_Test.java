/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.webkit.WebSettings;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowWebView;

@RunWith(RobolectricTestRunner.class)
public class Browser_Test {

  @Test
  public void testInit() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    ListenerRegistry listenerRegistry = activity.getProcessor()
      .getWidgetToolkit()
      .getListenerRegistry();
    CompositeTouchListener registeredListener = new CompositeTouchListener();
    when( listenerRegistry.findListener( "w3", CompositeTouchListener.class ) ).thenReturn( registeredListener );
    Browser browser = new Browser( activity );
    browser.setTag( "w3" );

    browser.init();

    WebSettings settings = browser.getSettings();
    assertTrue( settings.getJavaScriptEnabled() );
    ShadowWebView shadowBrowser = Robolectric.shadowOf( browser );
    Object jsInterface = shadowBrowser.getJavascriptInterface( "androidCallback" );
    assertTrue( jsInterface instanceof BrowserJSCallback );
    assertTrue( shadowBrowser.getWebViewClient() instanceof BrowserWebViewClient );
    assertTrue( shadowBrowser.getWebChromeClient() instanceof BrowserWebChromeClient );
    assertNotNull( registeredListener.findListener( BrowserViewListener.class ) );
  }

  @Test
  public void testSetProgressListener() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    BrowserWebViewClient webViewClient = mock( BrowserWebViewClient.class );
    browser.setBrowserWebViewClient( webViewClient );
    IBrowserProgressListener listener = mock( IBrowserProgressListener.class );

    browser.setProgressListener( listener );

    verify( webViewClient ).setProgressListener( listener );
  }

  @Test
  public void testExecuteScript() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    Browser spyBrowser = spy( browser );

    spyBrowser.executeScript( "javascriptCode" );

    verify( spyBrowser ).loadUrl( "javascript:androidCallback.setResult(javascriptCode);" );
  }

  @Test
  public void testExecuteScriptSantized() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    Browser browser = new Browser( activity );
    Browser spyBrowser = spy( browser );

    spyBrowser.executeScript( "javascriptCode;" );

    verify( spyBrowser ).loadUrl( "javascript:androidCallback.setResult(javascriptCode);" );
  }
}
