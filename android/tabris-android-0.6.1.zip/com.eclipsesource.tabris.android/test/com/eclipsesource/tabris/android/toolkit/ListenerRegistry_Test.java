/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;

import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import android.text.TextWatcher;

import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListenerRegistry_Test {

  private static final String WIDGET_ID = "w3";
  private static final String OTHER_WIDGET_ID = "w2";

  @Test
  public void testCreation() {
    ListenerRegistry reg = new ListenerRegistry();

    assertNotNull( reg );
  }

  @Test
  public void testUnregisterFromEmpty() {
    ListenerRegistry reg = new ListenerRegistry();

    Object removedListener = reg.unregisterListener( WIDGET_ID, TextWatcher.class );

    assertNull( removedListener );
  }

  @Test
  public void testRegisterAtEmpty() {
    ListenerRegistry reg = new ListenerRegistry();
    String listener = new String( "123" );

    reg.registerListener( WIDGET_ID, listener );
    Object removedListener = reg.unregisterListener( WIDGET_ID, String.class );
    Object removedListener2 = reg.unregisterListener( WIDGET_ID, String.class );

    assertNotNull( removedListener );
    assertEquals( listener, removedListener );
    assertNull( removedListener2 );
  }

  @Test
  public void testRegisterMultipleListeners() {
    ListenerRegistry reg = new ListenerRegistry();
    TextWatcher listener1 = Mockito.mock( TextWatcher.class );
    TextWatcher listener2 = Mockito.mock( TextWatcher.class );

    reg.registerListener( WIDGET_ID, listener1 );
    reg.registerListener( WIDGET_ID, listener2 );

    assertEquals( 1, reg.getBackingStore().size() );
  }

  @Test
  public void testRemoveListenerFromMultipleListeners() {
    ListenerRegistry reg = new ListenerRegistry();
    Integer listener1 = new Integer( 123 );
    String listener2 = new String();

    reg.registerListener( WIDGET_ID, listener1 );
    reg.registerListener( WIDGET_ID, listener2 );

    reg.unregisterListener( WIDGET_ID, String.class );

    Map<String, Set<Object>> backingStore = reg.getBackingStore();
    assertEquals( 1, backingStore.size() );
    assertTrue( backingStore.get( WIDGET_ID ).contains( listener1 ) );
    assertEquals( 1, backingStore.get( WIDGET_ID ).size() );
  }

  @Test
  public void testUnregisterOtherWidgetAtEmpty() {
    ListenerRegistry reg = new ListenerRegistry();
    TextWatcher listener = Mockito.mock( TextWatcher.class );

    reg.registerListener( WIDGET_ID, listener );
    Object removedListener = reg.unregisterListener( OTHER_WIDGET_ID, TextWatcher.class );

    assertNull( removedListener );
  }

  @Test
  public void testIsTotalyEmptyAfterLastListenerWasUnregistered() {
    ListenerRegistry reg = new ListenerRegistry();
    String listener = new String( "213" );
    reg.registerListener( WIDGET_ID, listener );
    assertEquals( 1, reg.getBackingStore().size() );
    assertTrue( reg.getBackingStore().containsKey( WIDGET_ID ) );

    Object removedListener = reg.unregisterListener( WIDGET_ID, String.class );

    assertNotNull( removedListener );
    assertFalse( reg.getBackingStore().containsKey( WIDGET_ID ) );
  }

  @Test
  public void testGetListenerNullArg() throws Exception {
    ListenerRegistry reg = new ListenerRegistry();

    assertNull( reg.findListener( null, null ) );
  }

  @Test
  public void testGetListenerNotExistent() throws Exception {
    ListenerRegistry reg = new ListenerRegistry();
    Object listener = new Object();

    assertNull( reg.findListener( WIDGET_ID, listener.getClass() ) );
  }

  @Test
  public void testGetListenerOk() throws Exception {
    ListenerRegistry reg = new ListenerRegistry();
    Object listener = new Object();
    reg.registerListener( WIDGET_ID, listener );

    assertSame( listener, reg.findListener( WIDGET_ID, listener.getClass() ) );
    assertSame( listener, reg.findListener( WIDGET_ID, listener.getClass() ) );
  }
}
