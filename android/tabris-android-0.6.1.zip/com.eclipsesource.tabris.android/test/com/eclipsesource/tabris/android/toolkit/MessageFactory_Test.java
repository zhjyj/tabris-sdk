/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.LocalizableException;
import com.eclipsesource.tabris.android.toolkit.MessageFactory;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class MessageFactory_Test {

  @Test
  public void testInstantiateHasMap() {
    TabrisActivity activity = new TabrisActivity();

    MessageFactory factory = new MessageFactory( activity );

    assertNull( factory.createMessage( "foo" ) );
  }

  @Test
  public void testContainsSessionTimeout() {
    TabrisActivity activity = UiTestUtil.createUiActivity();

    MessageFactory factory = new MessageFactory( activity );

    assertNotNull( factory.createMessage( LocalizableException.SESSION_TIMEOUT ) );
  }

}
