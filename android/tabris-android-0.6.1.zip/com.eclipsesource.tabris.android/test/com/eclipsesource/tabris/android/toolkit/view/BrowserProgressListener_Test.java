/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.BrowserProgressListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BrowserProgressListener_Test {

  private static final String WIDGET_ID = "w54";

  @Test
  public void testSendsPageFinishedLoadingRequest() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    BrowserProgressListener listener = new BrowserProgressListener( activity );

    listener.pageFinishedLoading( WIDGET_ID );

    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + ".org.eclipse.swt.events.progressCompleted", StringUtil.TRUE );
    Mockito.verify( processor ).processPostRequest( request );
  }
}
