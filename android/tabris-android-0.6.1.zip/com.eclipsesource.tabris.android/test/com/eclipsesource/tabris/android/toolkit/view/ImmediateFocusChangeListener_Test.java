/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateFocusChangeListener_Test {

  private static final String WIDGET1_ID = "w3";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new ImmediateFocusChangeListener( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOnClickNullArg() throws Exception {
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( new TabrisActivity() );
    listener.onFocusChange( null, false );
  }

  @Test
  public void testOnFocusTrue() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( activity );
    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, WIDGET1_ID );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET1_ID );

    listener.onFocusChange( view, true );

    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testOnFocusLost() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateFocusChangeListener listener = new ImmediateFocusChangeListener( activity );

    listener.onFocusChange( new View( activity ), false );

    PostRequest request = new PostRequest();
    request.addParam( IProtocolConstants.W1_FOCUS_CONTROL, AndroidWidgetToolkit.DISPLAY_ID );
    verify( processor ).processPostRequest( request );
  }

}
