/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.LinearLayout.LayoutParams;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SeparatorToolItem_Test {

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    toolkit = mock( IWidgetToolkit.class );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.multiplyByDensityFactor( 1 ) ).thenReturn( 2 );
    activity = new TabrisActivity();
    activity.setProcessor( processor );
  }

  @Test
  public void testCreateParams() {
    SeparatorToolItem toolItem = new SeparatorToolItem( activity );

    LayoutParams params = toolItem.createLayoutParams();

    assertEquals( 2, params.topMargin );
    assertEquals( 2, params.bottomMargin );
  }

  @Test
  public void testSetHorizontalSpacing() throws Exception {
    SeparatorToolItem toolItem = new SeparatorToolItem( activity );

    toolItem.setLayoutParams( toolItem.createLayoutParams() );
    toolItem.setHorizontalSpacing( 10 );

    LayoutParams params = ( LayoutParams )toolItem.getLayoutParams();
    assertEquals( 20, params.leftMargin );
    assertEquals( 20, params.rightMargin );
  }

}
