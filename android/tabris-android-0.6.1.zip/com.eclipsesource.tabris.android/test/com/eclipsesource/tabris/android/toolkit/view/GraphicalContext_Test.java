/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Shader;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;
import com.eclipsesource.tabris.android.toolkit.view.LinearGradiant;
import com.eclipsesource.tabris.android.toolkit.view.gc.FillStyleGcOperation;
import com.eclipsesource.tabris.android.toolkit.view.gc.StrokeStyleGcOperation;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class GraphicalContext_Test {

  private Canvas canvasView;
  private GraphicalContext gc;
  private android.graphics.Canvas canvas;
  private CallProperties callProps;

  @Before
  public void setUp() {
    canvasView = mock( Canvas.class );
    canvas = mock( android.graphics.Canvas.class );
    when( canvasView.getCanvas() ).thenReturn( canvas );
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( 14 ) ).thenReturn( 10 );
    when( toolkit.multiplyByDensityFactor( 100 ) ).thenReturn( 100 );
    when( toolkit.multiplyByDensityFactor( 50 ) ).thenReturn( 50 );
    gc = new GraphicalContext( activity, canvasView );
    callProps = new CallProperties();
    callProps.put( StrokeStyleGcOperation.OPERATION, Arrays.asList( 12, 34, 56 ) );
    callProps.put( FillStyleGcOperation.OPERATION, Arrays.asList( 98, 76, 54 ) );
    callProps.put( "width", 100 );
    callProps.put( "height", 50 );
    gc.init( callProps );
  }

  @Test
  public void testDrawCurrentPath() {
    gc.createNewPath();

    gc.drawCurrentPath();

    verify( canvas ).drawPath( gc.getPath(), gc.getPaint() );
  }

  @Test
  public void testDrawCurrentPathWithShader() {
    gc.createNewPath();
    gc.getPaint().setShader( mock( Shader.class ) );
    LinearGradiant linearGradient = gc.getLinearGradient();

    gc.drawCurrentPath();

    verify( canvas ).drawPath( gc.getPath(), gc.getPaint() );
    assertNotSame( linearGradient, gc.getLinearGradient() );
    assertNull( gc.getPaint().getShader() );
  }

  @Test
  public void createNewAndGetPath() throws Exception {
    assertNull( gc.getPath() );

    gc.createNewPath();

    Path path = gc.getPath();
    assertNotNull( path );

    gc.createNewPath();
    assertNotSame( path, gc.getPath() );
  }

  @Test
  public void testInvalidate() throws Exception {
    gc.invalidate();

    verify( canvasView ).invalidate();
  }

  @Test
  public void testGetCanvas() throws Exception {
    assertEquals( canvas, gc.getCanvas() );
  }

  @Test
  public void testSetGetStrokeColor() throws Exception {
    gc.setStrokeColor( 1234 );
    assertEquals( 1234, gc.getStrokeColor() );
  }

  @Test
  public void testSetGetFillColor() throws Exception {
    gc.setFillColor( 4321 );
    assertEquals( 4321, gc.getFillColor() );
  }

  @Test(expected = IllegalStateException.class)
  public void testRestoreEmptyPaint() throws Exception {
    gc.restorePaint();
  }

  @Test
  public void testSaveAndRestorePaint() throws Exception {
    Paint curPaint = gc.getPaint();

    gc.savePaint();

    assertNotSame( curPaint, gc.getPaint() );

    gc.restorePaint();

    assertSame( curPaint, gc.getPaint() );
  }

  @Test
  public void testSetStyleFill() throws Exception {
    gc.setFillColor( 1234 );
    Paint paint = mock( Paint.class );
    when( paint.getAlpha() ).thenReturn( 128 );
    gc.setPaint( paint );
    Path path = mock( Path.class );
    gc.setPath( path );

    gc.setStyle( Style.FILL );

    verify( paint ).setStyle( Style.FILL );
    verify( path ).close();
    verify( paint ).setColor( 1234 );
    verify( paint ).setAlpha( 128 );
  }

  @Test
  public void testSetStyleStroke() throws Exception {
    gc.setStrokeColor( 4321 );
    Paint paint = mock( Paint.class );
    when( paint.getAlpha() ).thenReturn( 128 );
    gc.setPaint( paint );

    gc.setStyle( Style.STROKE );

    verify( paint ).setStyle( Style.STROKE );
    verify( paint ).setColor( 4321 );
    verify( paint ).setAlpha( 128 );
  }

  @Test
  public void testInitWithProperties() throws Exception {
    assertTrue( gc.getFillColor() != 0 );
    assertTrue( gc.getStrokeColor() != 0 );

    Paint curPaint = gc.getPaint();
    assertNotNull( curPaint );
    LinearGradiant curLg = gc.getLinearGradient();
    assertNotNull( curLg );

    gc.init( callProps );

    assertNotSame( curPaint, gc.getPaint() );
    assertNotSame( curLg, gc.getLinearGradient() );
    verify( canvasView, times( 2 ) ).initCanvas( 100, 50 );
  }

  @Test
  public void testInit() throws Exception {
    Canvas canvasView = mock( Canvas.class );
    when( canvasView.getWidth() ).thenReturn( 2000 );
    when( canvasView.getHeight() ).thenReturn( 3000 );
    android.graphics.Canvas canvas = mock( android.graphics.Canvas.class );
    when( canvasView.getCanvas() ).thenReturn( canvas );
    GraphicalContext gc = new GraphicalContext( UiTestUtil.createUiActivity(), canvasView );

    Paint curPaint = gc.getPaint();
    LinearGradiant curLg = gc.getLinearGradient();

    gc.init();

    assertNotSame( curPaint, gc.getPaint() );
    assertNotSame( curLg, gc.getLinearGradient() );
    verify( canvasView ).initCanvas( 2000, 3000 );
  }

  @Test
  public void testInvalidateRegion() throws Exception {
    gc.invalidate( 1, 2, 3, 4 );

    verify( canvasView ).invalidate( 1, 2, 3, 4 );
  }
}
