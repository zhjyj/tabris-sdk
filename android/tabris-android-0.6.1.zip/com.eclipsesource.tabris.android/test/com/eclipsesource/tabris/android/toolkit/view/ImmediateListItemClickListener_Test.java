/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateListItemClickListener_Test {

  private static final String WIDGET1_ID = "w1";
  private static final String SELECTED_INDEX = "23";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new ImmediateListItemClickListener( null );
  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testOnListItemClicked() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    ProtocolProcessor processor = activity.getProcessor();
    ImmediateListItemClickListener listener = new ImmediateListItemClickListener( processor );
    List list = mock( List.class );
    when( list.getTag() ).thenReturn( WIDGET1_ID );
    TouchPositionBuffer touchPositionBuffer = mock( TouchPositionBuffer.class );
    when( touchPositionBuffer.getX() ).thenReturn( 100f );
    when( touchPositionBuffer.getY() ).thenReturn( 120f );
    when( processor.getWidgetToolkit()
      .getListenerRegistry()
      .findListener( eq( WIDGET1_ID ), eq( TouchPositionBuffer.class ) ) ).thenReturn( touchPositionBuffer );
    ListSelectionAdapter adapter = mock( ListSelectionAdapter.class );
    when( list.getAdapter() ).thenReturn( adapter );
    UiTestUtil.mockToolkitDivideIdentity( activity, 100, 120 );

    listener.onItemClick( list,
                          null,
                          Integer.parseInt( SELECTED_INDEX ),
                          Integer.parseInt( SELECTED_INDEX ) );

    PostRequest request = new PostRequest();
    request.addParam( "org.eclipse.swt.events.widgetSelected", WIDGET1_ID );
    request.addParam( "w1.cursorLocation.x", "100" );
    request.addParam( "w1.cursorLocation.y", "120" );
    verify( processor ).processPostRequest( request );
    verify( touchPositionBuffer ).clear();
  }
}
