/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class List_Test {

  @Test
  public void testCreate() {
    List list = new List( mock( TabrisActivity.class ) );

    assertFalse( list.isVerticalFadingEdgeEnabled() );
    assertEquals( ListSelectionAdapter.class, list.getAdapter().getClass() );
  }

  @Test
  public void testSetItemsOnEmptyAdapter() {
    List list = new List( mock( TabrisActivity.class ) );
    ListAdapter adapter = list.getAdapter();
    assertEquals( ListSelectionAdapter.class, adapter.getClass() );

    list.setItems( Arrays.asList( "foo", "bar", "baz" ), mock( TabrisActivity.class ) );

    assertEquals( adapter, list.getAdapter() );
    assertEquals( 3, list.getAdapter().getCount() );
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testSetItemsOnFilledAdapter() {
    List list = new List( mock( TabrisActivity.class ) );
    ListAdapter adapter = list.getAdapter();
    ( ( ArrayAdapter<String> )adapter ).add( "piep" );
    assertEquals( ListSelectionAdapter.class, adapter.getClass() );

    list.setItems( Arrays.asList( "foo", "bar", "baz" ), mock( TabrisActivity.class ) );

    assertEquals( adapter, list.getAdapter() );
    assertEquals( 3, list.getAdapter().getCount() );
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testSetNullItemsOnFilledAdapter() {
    List list = new List( mock( TabrisActivity.class ) );
    ListAdapter adapter = list.getAdapter();
    ( ( ArrayAdapter<String> )adapter ).add( "piep" );
    assertEquals( ListSelectionAdapter.class, adapter.getClass() );

    list.setItems( null, mock( TabrisActivity.class ) );

    assertEquals( adapter, list.getAdapter() );
    assertEquals( 1, list.getAdapter().getCount() );
  }
}
