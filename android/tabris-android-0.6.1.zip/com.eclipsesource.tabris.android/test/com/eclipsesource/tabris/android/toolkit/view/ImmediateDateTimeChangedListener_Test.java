/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.util.SparseArray;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateDateTimeChangedListener_Test {

  private static final String WIDGET_ID = "widgetId";

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testCreateNullProtocolProcessor() {
    new ImmediateDateTimeChangedListener( null, mock( SparseArray.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNullDateValues() {
    new ImmediateDateTimeChangedListener( mock( ProtocolProcessor.class ), null );
  }

  @Test
  public void testNotifyProtocolProcessor() {
    SparseArray<String> dateValues = new SparseArray<String>();
    dateValues.put( Calendar.YEAR, IProtocolConstants.DATE_TIME_YEAR );
    dateValues.put( Calendar.MONTH, IProtocolConstants.DATE_TIME_MONTH );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    ImmediateDateTimeChangedListener listener = new ImmediateDateTimeChangedListener( processor,
                                                                                      dateValues );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime();
    when( spinner.getDate() ).thenReturn( date );
    when( spinner.getTag() ).thenReturn( WIDGET_ID );

    listener.dateTimeChanged( spinner );

    PostRequest request = createPostRequest( dateValues, calendar );
    verify( processor ).processPostRequest( request );
  }

  private PostRequest createPostRequest( SparseArray<String> dateValues, Calendar calendar ) {
    PostRequest request = new PostRequest();
    for( int i = 0; i < dateValues.size(); i++ ) {
      request.addParam( WIDGET_ID + dateValues.valueAt( i ),
                        String.valueOf( calendar.get( dateValues.keyAt( i ) ) ) );
    }
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, WIDGET_ID );
    return request;
  }
}
