/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import android.widget.AdapterView;

public class DelegatingItemSelectedListener_Test {

  @Test
  public void testOnItemSelected() {
    RecordingListItemClickListener delegate = mock( RecordingListItemClickListener.class );
    DelegatingItemSelectedListener listener = new DelegatingItemSelectedListener( delegate );
    AdapterView<?> parent = mock( AdapterView.class );

    listener.onItemSelected( parent, null, 3, 4l );

    verify( delegate ).onItemClick( parent, null, 3, 4l );
  }
}
