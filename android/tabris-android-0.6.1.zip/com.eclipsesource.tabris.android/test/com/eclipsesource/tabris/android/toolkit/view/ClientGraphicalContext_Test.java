/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;

import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.parser.gson.GsonProtocolParser;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Canvas;
import com.eclipsesource.tabris.android.toolkit.view.ClientGraphicalContext;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ClientGraphicalContext_Test {

  private static final String WIDGET_ID = "w3";
  private ClientGraphicalContext gc;
  private IWidgetToolkit toolkit;
  private MotionEvent event;
  private Path path;
  private ArrayList<Integer> recordedCoords;
  private Paint paint;
  private android.graphics.Canvas canvas;
  private Canvas canvasView;
  private ProtocolProcessor processor;

  @Before
  public void setUp() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    canvasView = mock( Canvas.class );
    canvas = mock( android.graphics.Canvas.class );
    when( canvasView.getCanvas() ).thenReturn( canvas );
    when( canvasView.getTag() ).thenReturn( WIDGET_ID );
    gc = new ClientGraphicalContext( activity, canvasView );
    processor = activity.getProcessor();
    when( processor.getParser() ).thenReturn( new GsonProtocolParser() );
    toolkit = processor.getWidgetToolkit();
    event = mock( MotionEvent.class );
    path = mock( Path.class );
    gc.setLinePath( path );
    paint = mock( Paint.class );
    gc.setPaint( paint );
    recordedCoords = spy( new ArrayList<Integer>() );
    gc.setRecordedCoords( recordedCoords );
  }

  private void initMotionEvent( int action, float x, float y ) {
    when( toolkit.divideByDensityFactor( x ) ).thenReturn( x );
    when( toolkit.divideByDensityFactor( y ) ).thenReturn( y );
    when( event.getAction() ).thenReturn( action );
    when( event.getX() ).thenReturn( x );
    when( event.getY() ).thenReturn( y );
  }

  @Test
  public void testOnTouchDownWithDown() {
    initMotionEvent( MotionEvent.ACTION_DOWN, 10f, 20f );

    gc.onTouchEvent( event );

    verify( recordedCoords ).add( 10 );
    verify( recordedCoords ).add( 20 );
    verify( path ).moveTo( 10f, 20f );
  }

  @Test
  public void testOnTouchDownWithMove() {
    gc.setLastX( 50f );
    gc.setLastY( 100f );
    recordedCoords.add( 50 );
    recordedCoords.add( 100 );
    gc.setStrokeColor( 1234 );
    when( paint.getAlpha() ).thenReturn( 128 );
    when( paint.getStrokeWidth() ).thenReturn( 8f );
    initMotionEvent( MotionEvent.ACTION_MOVE, 200f, 300f );

    gc.onTouchEvent( event );

    verify( recordedCoords ).add( 200 );
    verify( recordedCoords ).add( 300 );
    InOrder inOrder = inOrder( path, paint, canvas, canvasView );
    inOrder.verify( path ).quadTo( ( 50f + 200f ) / 2f, ( 100f + 300f ) / 2f, 200f, 300f );
    inOrder.verify( paint ).setColor( 1234 );
    inOrder.verify( canvas ).drawPath( path, paint );
    inOrder.verify( paint ).setAlpha( 128 );
    inOrder.verify( canvasView ).invalidate( 46, 96, 204, 304 );
  }

  @Test
  public void testOnTouchDownWithUpToPoint() {
    recordedCoords.add( 10 );
    recordedCoords.add( 20 );
    gc.setLastX( 10f );
    gc.setLastY( 20f );
    gc.setStrokeColor( 1234 );
    when( paint.getAlpha() ).thenReturn( 128 );
    when( paint.getStrokeWidth() ).thenReturn( 8f );
    initMotionEvent( MotionEvent.ACTION_UP, 200f, 300f );

    gc.onTouchEvent( event );

    InOrder inOrder = inOrder( path, paint, canvas, canvasView, recordedCoords );

    inOrder.verify( recordedCoords ).clear();
    inOrder.verify( recordedCoords ).add( 10 );
    inOrder.verify( recordedCoords ).add( 20 );
    inOrder.verify( recordedCoords ).add( 10 + 1 );
    inOrder.verify( recordedCoords ).add( 20 );
    inOrder.verify( recordedCoords ).add( 10 );
    inOrder.verify( recordedCoords ).add( 20 + 1 );
    inOrder.verify( recordedCoords ).add( 10 - 1 );
    inOrder.verify( recordedCoords ).add( 20 );
    inOrder.verify( recordedCoords ).add( 10 );
    inOrder.verify( recordedCoords ).add( 20 - 1 );
    inOrder.verify( path ).rewind();
    inOrder.verify( recordedCoords ).clear();
  }

  @Test
  public void testOnTouchDownWithUpToPath() {
    recordedCoords.add( 10 );
    recordedCoords.add( 20 );
    gc.setLastX( 10f );
    gc.setLastY( 20f );
    gc.setStrokeColor( 1234 );
    when( paint.getAlpha() ).thenReturn( 128 );
    when( paint.getStrokeWidth() ).thenReturn( 8f );
    initMotionEvent( MotionEvent.ACTION_UP, 200f, 300f );

    gc.onTouchEvent( event );

    InOrder inOrder = inOrder( path, paint, canvas, canvasView, recordedCoords );

    inOrder.verify( path ).quadTo( 200f, 300f, 200f, 300f );
    inOrder.verify( paint ).setColor( 1234 );
    inOrder.verify( canvas ).drawPath( path, paint );
    inOrder.verify( paint ).setAlpha( 128 );
    inOrder.verify( canvasView ).invalidate( 6, 16, 204, 304 );
    inOrder.verify( path ).rewind();
    inOrder.verify( recordedCoords ).clear();
  }

  @Test
  public void testSendsPointPathToServer() throws Exception {
    recordedCoords.add( 10 );
    recordedCoords.add( 20 );
    gc.setLastX( 10f );
    gc.setLastY( 20f );
    gc.setStrokeColor( 1234 );
    when( paint.getAlpha() ).thenReturn( 128 );
    when( paint.getStrokeWidth() ).thenReturn( 8f );
    when( toolkit.divideByDensityFactor( 8f ) ).thenReturn( 8f );
    initMotionEvent( MotionEvent.ACTION_UP, 200f, 300f );

    gc.onTouchEvent( event );

    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + ".drawings",
                      "[[\"foreground\",[0,0,0,128]],[\"lineWidth\",[8.0]],[\"polyline\",[10,20,11,20,10,21,9,20,10,19]]]" );
    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testAddMoveToWhenNotTouchDownEvent() throws Exception {
    when( paint.getAlpha() ).thenReturn( 128 );
    when( paint.getStrokeWidth() ).thenReturn( 8f );
    initMotionEvent( MotionEvent.ACTION_MOVE, 200f, 300f );

    gc.onTouchEvent( event );

    verify( recordedCoords ).add( 200 );
    verify( recordedCoords ).add( 300 );
    verify( path ).moveTo( 200f, 300f );

    verify( recordedCoords ).add( 200 );
    verify( recordedCoords ).add( 300 );
    verify( path ).quadTo( 200f, 300f, 200f, 300f );
  }
}
