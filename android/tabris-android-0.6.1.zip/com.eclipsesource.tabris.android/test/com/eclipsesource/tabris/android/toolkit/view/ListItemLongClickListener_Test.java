/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ListItemLongClickListener_Test {

  private static final String WIDGET1_ID = "w3";

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNullProtocolProcessor() {
    new ListItemLongClickListener( null );
  }

  @Test
  public void testOnLongClick() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    ProtocolProcessor processor = activity.getProcessor();
    TouchPositionBuffer touchPositionBuffer = mock( TouchPositionBuffer.class );
    when( touchPositionBuffer.getX() ).thenReturn( 23f );
    when( touchPositionBuffer.getY() ).thenReturn( 42f );
    when( processor.getWidgetToolkit()
      .getListenerRegistry()
      .findListener( WIDGET1_ID, TouchPositionBuffer.class ) ).thenReturn( touchPositionBuffer );
    ListItemLongClickListener listener = new ListItemLongClickListener( processor );
    List view = mock( List.class );
    when( view.getTag() ).thenReturn( WIDGET1_ID );
    OnItemClickListener onItemClickListener = mock( OnItemClickListener.class );
    when( view.getOnItemClickListener() ).thenReturn( onItemClickListener );
    UiTestUtil.mockToolkitDivideIdentity( activity, 23, 42 );

    boolean consumed = listener.onItemLongClick( view, null, 23, 42 );

    assertTrue( consumed );
    verify( onItemClickListener ).onItemClick( eq( view ), isNull( View.class ), eq( 23 ), eq( 42l ) );
    verify( touchPositionBuffer ).getX();
    verify( touchPositionBuffer ).getY();
    PostRequest request = new PostRequest();
    request.addParam( EVENT_MENU_DETECT, WIDGET1_ID );
    request.addParam( EVENT_MENU_DETECT_X, "23" );
    request.addParam( EVENT_MENU_DETECT_Y, "42" );
    verify( processor ).processPostRequest( request );
  }
}
