/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.MotionEvent;
import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.view.LongClickListener;
import com.eclipsesource.tabris.android.toolkit.view.MouseEventTouchListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class LongClickListener_Test {

  private static final String WIDGET_ID = "w3";
  private TabrisActivity activity;
  private ProtocolProcessor processor;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = new TabrisActivity();
    toolkit = mock( AndroidWidgetToolkit.class );
    processor = mock( ProtocolProcessor.class );
    when( processor.getSessionTime() ).thenReturn( 3000l );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    activity.setProcessor( processor );
  }

  @Test
  public void testMenuDetectListener() {
    MouseEventTouchListener touchListener = mock( MouseEventTouchListener.class );

    LongClickListener listener = new LongClickListener( activity,
                                                        touchListener,
                                                        touchListener,
                                                        true );

    assertTrue( listener.isTransmittingMenuDetect() );
  }

  @Test
  public void testMenuDetectListenerAsRightClickDetector() {
    MouseEventTouchListener touchListener = mock( MouseEventTouchListener.class );

    LongClickListener listener = new LongClickListener( activity,
                                                        touchListener,
                                                        touchListener,
                                                        false );

    assertFalse( listener.isTransmittingMenuDetect() );
  }

  @Test
  public void testLongPressDetectedAsMenuDetect() {
    MouseEventTouchListener touchListener = createTouchListener( false );
    LongClickListener listener = new LongClickListener( activity,
                                                        touchListener,
                                                        touchListener,
                                                        true );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    when( toolkit.divideByDensityFactor( 10 ) ).thenReturn( 5 );
    when( toolkit.divideByDensityFactor( 30 ) ).thenReturn( 15 );

    boolean wasConsumed = listener.onLongClick( view );

    verify( touchListener ).clear();
    assertTrue( wasConsumed );
    PostRequest request = new PostRequest();
    request.addParam( EVENT_MENU_DETECT, WIDGET_ID );
    request.addParam( EVENT_MENU_DETECT + EVENT_MOUSE_COORD_X, "5" );
    request.addParam( EVENT_MENU_DETECT + EVENT_MOUSE_COORD_Y, "15" );
    request.addParam( W1_CURSOR_LOCATION_X, "5" );
    request.addParam( W1_CURSOR_LOCATION_Y, "15" );
    verify( processor ).processPostRequest( request );
  }

  @Test
  public void testLongPressDetectedAsRightClick() {
    MouseEventTouchListener touchListener = createTouchListener( true );
    LongClickListener listener = new LongClickListener( activity,
                                                        touchListener,
                                                        touchListener,
                                                        false );

    boolean wasConsumed = listener.onLongClick( mock( View.class ) );

    verify( touchListener ).longPressDetected();
    verify( touchListener ).clear();
    assertTrue( wasConsumed );
  }

  private MouseEventTouchListener createTouchListener( boolean isTransmittingUpDown ) {
    MouseEventTouchListener touchListener = mock( MouseEventTouchListener.class );
    when( touchListener.isTransmittingUpDown() ).thenReturn( isTransmittingUpDown );
    MotionEvent motionEvent = MotionEvent.obtain( 100, 1000, MotionEvent.ACTION_DOWN, 10f, 30f, 0 );
    when( touchListener.getLastMotion() ).thenReturn( motionEvent );
    return touchListener;
  }
}
