/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.ListScrollState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class RecordingOnScrollListener_Test {

  private static final String WIDGET_ID = "1";

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    new RecordingOnScrollListener( null );
  }

  @Test
  public void testRecordState() {
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingOnScrollListener listener = new RecordingOnScrollListener( stateRecorder );
    AbsListView view = mock( AbsListView.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    ListScrollState expectedState = new ListScrollState( WIDGET_ID, 3 );

    listener.onScroll( view, 3, 10, 100 );
    listener.onScrollStateChanged( view, OnScrollListener.SCROLL_STATE_IDLE );

    verify( stateRecorder ).recordState( expectedState );
  }
}
