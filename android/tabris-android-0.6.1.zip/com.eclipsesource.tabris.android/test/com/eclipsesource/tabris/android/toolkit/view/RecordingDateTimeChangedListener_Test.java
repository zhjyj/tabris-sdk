/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.util.SparseArray;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.DateTimeState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class RecordingDateTimeChangedListener_Test {

  private static final String WIDGET_ID = "widgetId";

  @Test(expected = IllegalArgumentException.class)
  @SuppressWarnings("unchecked")
  public void testCreateNullProtocolProcessor() {
    new RecordingDateTimeChangedListener( null, mock( SparseArray.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNullDateValues() {
    new RecordingDateTimeChangedListener( mock( StateRecorder.class ), null );
  }

  @Test
  public void testNotifiyStateRecorder() {
    SparseArray<String> dateValues = new SparseArray<String>();
    dateValues.put( Calendar.YEAR, IProtocolConstants.DATE_TIME_YEAR );
    dateValues.put( Calendar.MONTH, IProtocolConstants.DATE_TIME_MONTH );
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingDateTimeChangedListener listener = new RecordingDateTimeChangedListener( stateRecorder,
                                                                                      dateValues );
    DateTimeSpinner spinner = mock( DateTimeSpinner.class );
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime();
    when( spinner.getDate() ).thenReturn( date );
    when( spinner.getTag() ).thenReturn( WIDGET_ID );

    listener.dateTimeChanged( spinner );

    for( int i = 0; i < dateValues.size(); i++ ) {
      DateTimeState state = new DateTimeState( WIDGET_ID,
                                               dateValues.valueAt( i ),
                                               calendar.get( dateValues.keyAt( i ) ) );
      verify( stateRecorder ).recordState( state );
    }
  }

}
