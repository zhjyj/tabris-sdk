/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowListView;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.DelegatingItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.List;
import com.eclipsesource.tabris.android.toolkit.view.RecordingFocusTrackingListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingListItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingOnScrollListener;
import com.eclipsesource.tabris.android.toolkit.view.TouchPositionBuffer;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowListView;

@RunWith(RobolectricTestRunner.class)
public class ListOperator_Test {

  private static final String PARENT_ID = "w1";

  private static final String LIST_VIEW_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    toolkit = mock( IWidgetToolkit.class );
    processor.setWidgetToolkit( toolkit );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( processor.getStateRecorder() ).thenReturn( mock( StateRecorder.class ) );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    ListenerRegistry registry = mock( ListenerRegistry.class );
    when( toolkit.getListenerRegistry() ).thenReturn( registry );
    when( toolkit.getFocusTrackingListener() ).thenReturn( mock( RecordingFocusTrackingListener.class ) );
    rootLayout.addView( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ListOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ListOperator operator = new ListOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoProps() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateListViewNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ListOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateListViewParentNotFrameLayout() throws Exception {
    String listViewId = "ListView";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    ListView listView = new ListView( activity );
    listView.setTag( listViewId );
    rootLayout.addView( listView );

    AbstractWidgetOperator operator = new LabelOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( listViewId );
    op.setProperties( props );

    operator.create( op );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( LIST_VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateListViewOk() throws Exception {
    ListOperator operator = new ListOperator( activity );
    CreateOperation op = createValidCreateOperation();
    registerCompositTouchListener( LIST_VIEW_ID );

    operator.create( op );

    View view = parentLayout.findViewWithTag( LIST_VIEW_ID );
    verify( toolkit ).registerObjectById( eq( LIST_VIEW_ID ), eq( view ) );
    assertTrue( view instanceof List );
    assertEquals( LIST_VIEW_ID, view.getTag() );
    List list = ( List )view;
    OnItemClickListener onItemClickListener = list.getOnItemClickListener();
    assertNotNull( onItemClickListener );
    assertEquals( CompositeItemClickListener.class, onItemClickListener.getClass() );
    ArrayList<OnItemClickListener> listeners = ( ( CompositeItemClickListener )onItemClickListener ).getListeners();
    assertEquals( 1, listeners.size() );
    assertEquals( RecordingListItemClickListener.class, listeners.get( 0 ).getClass() );
    ShadowListView shadow = Robolectric.shadowOf( ( List )view );
    OnItemSelectedListener onItemSelectedListener = list.getOnItemSelectedListener();
    assertNotNull( onItemSelectedListener );
    assertEquals( DelegatingItemSelectedListener.class, onItemSelectedListener.getClass() );
    assertNotNull( shadow.getOnScrollListener() );
    assertEquals( RecordingOnScrollListener.class, shadow.getOnScrollListener().getClass() );
    verify( toolkit.getListenerRegistry(), times( 2 ) ).registerListener( eq( LIST_VIEW_ID ),
                                                                          any( TouchPositionBuffer.class ) );
  }

  @Test
  public void testGetType() {
    ListOperator listOperator = new ListOperator( new TabrisActivity() );

    String type = listOperator.getType();

    assertEquals( "rwt.widgets.List", type );
  }

  @Test
  public void testAttachSelectionListener() {
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    CompositeItemClickListener compositeListener = mock( CompositeItemClickListener.class );
    listView.setOnItemClickListener( compositeListener );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setSelection( true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );
    registerCompositTouchListener( LIST_VIEW_ID );

    op.listen( listenOp );

    ShadowListView shadow = Robolectric.shadowOf( listView );
    assertNotNull( shadow.getOnItemClickListener() );
    verify( compositeListener ).addListener( any( ImmediateListItemClickListener.class ) );
  }

  private CompositeTouchListener registerCompositTouchListener( String widgetId ) {
    ListenerRegistry registry = toolkit.getListenerRegistry();
    CompositeTouchListener compositTouchListener = mock( CompositeTouchListener.class );
    when( registry.findListener( widgetId, CompositeTouchListener.class ) ).thenReturn( compositTouchListener );
    return compositTouchListener;
  }

  @Test
  public void testRemoveSelectionListener() {
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    CompositeItemClickListener compositeListener = mock( CompositeItemClickListener.class );
    listView.setOnItemClickListener( compositeListener );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setSelection( true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );
    registerCompositTouchListener( LIST_VIEW_ID );

    op.listen( listenOp );

    listenProps.setSelection( false );

    op.listen( listenOp );

    ShadowListView shadow = Robolectric.shadowOf( listView );
    OnItemClickListener onItemClickListener = shadow.getOnItemClickListener();
    assertEquals( compositeListener, onItemClickListener );
    verify( compositeListener ).removeListeners( eq( ImmediateListItemClickListener.class ) );
  }

  @Test
  public void testAttachMenuDetectListener() {
    Robolectric.bindShadowClass( TabrisShadowListView.class );
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setMenuDetect( true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );

    op.listen( listenOp );

    TabrisShadowListView shadow = ( TabrisShadowListView )Robolectric.shadowOf( listView );
    assertNotNull( shadow.getOnItemLongClickListener() );
  }

  @Test
  public void testRemoveMenuDetectListener() {
    Robolectric.bindShadowClass( TabrisShadowListView.class );
    ListOperator op = new ListOperator( activity );
    List listView = createAndRegisterListView();
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( LIST_VIEW_ID );
    ListenProperties listenProps = new ListenProperties();
    listenProps.setMenuDetect( true );
    listenOp.setProperties( listenProps );
    when( op.findViewByTarget( listenOp ) ).thenReturn( listView );

    op.listen( listenOp );

    listenProps.setMenuDetect( false );

    op.listen( listenOp );

    TabrisShadowListView shadow = ( TabrisShadowListView )Robolectric.shadowOf( listView );
    assertNull( shadow.getOnItemLongClickListener() );
    assertFalse( listView.isLongClickable() );
  }

  private ListenerRegistry createAndRegisterListenerRegistry( ListOperator op ) {
    ListenerRegistry listenerRegistry = mock( ListenerRegistry.class );
    when( op.getListenerRegistry() ).thenReturn( listenerRegistry );
    return listenerRegistry;
  }

  private List createAndRegisterListView() {
    List result = new List( activity );
    result.setTag( LIST_VIEW_ID );
    when( toolkit.findObjectById( LIST_VIEW_ID, List.class ) ).thenReturn( result );
    parentLayout.addView( result );
    return result;
  }

  @Test
  public void testDestroy() {
    ListOperator op = new ListOperator( activity );
    ListenerRegistry listenerRegistry = createAndRegisterListenerRegistry( op );
    List listView = createAndRegisterListView();
    DestroyOperation destroyOp = new DestroyOperation();
    destroyOp.setTarget( LIST_VIEW_ID );
    when( op.findViewByTarget( destroyOp ) ).thenReturn( listView );

    op.destroy( destroyOp );

    verify( listenerRegistry ).unregisterListener( eq( LIST_VIEW_ID ),
                                                   eq( RecordingOnScrollListener.class ) );
    verify( toolkit.getListenerRegistry() ).unregisterListener( LIST_VIEW_ID,
                                                                TouchPositionBuffer.class );
  }
}
