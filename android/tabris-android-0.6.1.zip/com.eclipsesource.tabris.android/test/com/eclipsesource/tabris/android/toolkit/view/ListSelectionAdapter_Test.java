/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.content.Context;
import android.content.res.Resources;
import android.view.ViewGroup;
import android.widget.TextView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowTextView;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowTextView;

@RunWith(RobolectricTestRunner.class)
public class ListSelectionAdapter_Test {

  @Test
  public void testCreate() {
    Context context = mock( TabrisActivity.class );

    ListSelectionAdapter<String> adapter = new ListSelectionAdapter<String>( context,
                                                                             0,
                                                                             0,
                                                                             Arrays.asList( "foo" ) );

    assertEquals( ListSelectionAdapter.NOTHING_SELECTED, adapter.getSelection() );
  }

  @Test
  public void testSetSelection() {
    Context context = mock( TabrisActivity.class );
    ListSelectionAdapter<String> adapter = createThreeItemsAdapter( context );

    adapter.setSelection( 1 );

    assertEquals( 1, adapter.getSelection() );
  }

  @Test
  public void testGetSelectedView() {
    Robolectric.bindShadowClass( TabrisShadowTextView.class );
    Context context = mock( TabrisActivity.class );
    Resources res = mock( Resources.class );
    int expectedColor = -2;
    when( res.getColor( anyInt() ) ).thenReturn( new Integer( expectedColor ) );
    when( context.getResources() ).thenReturn( res );
    ListSelectionAdapter<String> adapter = createThreeItemsAdapter( context );
    adapter.setSelection( 1 );
    TextView convertView = new TextView( context );
    ViewGroup parent = mock( ViewGroup.class );

    adapter.getView( 1, convertView, parent );

    ShadowTextView shadow = Robolectric.shadowOf( convertView );
    assertEquals( expectedColor, shadow.getBackgroundColor() );
  }

  @Test
  public void testGetNotSelectedView() {
    Robolectric.bindShadowClass( TabrisShadowTextView.class );
    Context context = mock( TabrisActivity.class );
    ListSelectionAdapter<String> adapter = createThreeItemsAdapter( context );
    adapter.setSelection( 1 );
    TextView convertView = new TextView( context );
    ViewGroup parent = mock( ViewGroup.class );

    adapter.getView( 0, convertView, parent );

    ShadowTextView shadowView = Robolectric.shadowOf( convertView );
    assertNull( shadowView.getBackground() );
  }

  public ListSelectionAdapter<String> createThreeItemsAdapter( Context context ) {
    return new ListSelectionAdapter<String>( context, 0, 0, Arrays.asList( "foo", "bar", "baz" ) );
  }
}
