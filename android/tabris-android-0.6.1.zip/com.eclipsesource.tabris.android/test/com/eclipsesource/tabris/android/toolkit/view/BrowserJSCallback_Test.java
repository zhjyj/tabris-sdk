/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.BrowserJSCallback;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class BrowserJSCallback_Test {

  private static final String WIDGET_ID = "w54";

  @Test
  public void testSendResult() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithoutOnCreate();
    BrowserJSCallback callback = new BrowserJSCallback( activity, WIDGET_ID );

    callback.setResult( "result" );

    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + ".executeResult", "true" );
    request.addParam( WIDGET_ID + ".evaluateResult", "[result]" );
    Mockito.verify( processor ).processPostRequest( request );
  }

}
