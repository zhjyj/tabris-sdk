/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import org.mockito.Mockito;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowBitmapFactory;

@Implements(BitmapFactory.class)
public class TabrisShadowBitmapFactory extends ShadowBitmapFactory {

  @Implementation
  public static Bitmap decodeByteArray( byte[] data, int offset, int length ) {
    return Mockito.mock( Bitmap.class );
  }
}
