/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.AdapterView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateSpinnerItemSelectedListener;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ImmediateComboItemSelectedListener_Test {

  private static final String WIDGET_ID = "w2";

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() throws Exception {
    new ImmediateSpinnerItemSelectedListener( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testOnClickNull() throws Exception {
    ImmediateSpinnerItemSelectedListener listener = new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) );
    listener.onItemSelected( null, null, 0, 0 );
  }

  @Test
  public void testOnItemSelected() throws Exception {
    TabrisActivity activity = new TabrisActivity();
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    activity.setProcessor( processor );
    ImmediateSpinnerItemSelectedListener listener = new ImmediateSpinnerItemSelectedListener( processor );
    PostRequest request = new PostRequest();
    request.addParam( WIDGET_ID + IProtocolConstants.LIST_VISIBLE_POSTFIX, Boolean.FALSE.toString() );
    request.addParam( WIDGET_ID + IProtocolConstants.SELECTED_ITEM_POSTFIX, "12" );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, WIDGET_ID );
    View view = mock( View.class );
    AdapterView<?> parent = mock( AdapterView.class );
    when( parent.getTag() ).thenReturn( WIDGET_ID );

    listener.onItemSelected( parent, view, 12, 0 );

    verify( processor ).processPostRequest( request );
  }
}
