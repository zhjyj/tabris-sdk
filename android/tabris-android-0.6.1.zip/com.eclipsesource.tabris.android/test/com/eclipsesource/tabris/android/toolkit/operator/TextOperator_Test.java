/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowEditText;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeFocusListener_Test;
import com.eclipsesource.tabris.android.toolkit.view.Text;
import com.eclipsesource.tabris.android.toolkit.view.TextChangeListener;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowEditText;

@RunWith(RobolectricTestRunner.class)
public class TextOperator_Test {

  private static final String PASSWORD = "PASSWORD";
  private static final String PARENT_ID = "w2";
  private static final String EDIT_TEXT_ID = "w3";

  private TabrisActivity activity;
  private ListenerRegistry listenerRegistry;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = UiTestUtil.createUiActivityWithoutOnCreate();
    listenerRegistry = activity.getProcessor().getWidgetToolkit().getListenerRegistry();
    parentLayout = new FrameLayout( activity );
    toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test
  public void testGetType() {
    TextOperator textOperator = new TextOperator( new TabrisActivity() );

    String type = textOperator.getType();

    assertEquals( "rwt.widgets.Text", type );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullConstructor() {
    new TextOperator( null );
  }

  @Test
  public void testCreateOk() {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );

    View view = parentLayout.findViewWithTag( EDIT_TEXT_ID );
    verify( toolkit ).registerObjectById( EDIT_TEXT_ID, view );
    assertEquals( Text.class, view.getClass() );
    EditText editText = ( EditText )view;
    assertTrue( ( editText.getInputType() & EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE ) == 0 );
    verify( listenerRegistry, times( 2 ) ).registerListener( eq( EDIT_TEXT_ID ),
                                                             any( CompositeFocusListener_Test.class ) );
  }

  private CreateOperation createCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( EDIT_TEXT_ID );
    CreateProperties properties = new CreateProperties();
    properties.setParent( PARENT_ID );
    op.setProperties( properties );
    return op;
  }

  private CreateOperation createCreateOperationWithStyle( String style ) {
    CreateOperation op = createCreateOperation();
    List<String> styles = new ArrayList<String>();
    styles.add( style );
    op.getProperties().setStyle( styles );
    return op;
  }

  private EditText findCreatedWidget() {
    return ( EditText )parentLayout.findViewWithTag( EDIT_TEXT_ID );
  }

  @Test
  public void testCreatePasswordEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperationWithStyle( PASSWORD );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getTransformationMethod() instanceof PasswordTransformationMethod );
    assertTrue( view.getInputType() == InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS );
  }

  @Test
  public void testCreateReadOnlyEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();
    op.getProperties().setEditable( false );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getInputType() == InputType.TYPE_NULL );
  }

  @Test
  public void testHasTextListener() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );
    EditText view = findCreatedWidget();

    List<TextWatcher> watchers = ( ( ShadowEditText )Robolectric.shadowOf( view ) ).getWatchers();
    assertFalse( watchers.isEmpty() );
    boolean textChangeListenerFound = false;
    for( TextWatcher watcher : watchers ) {
      if( watcher instanceof TextChangeListener ) {
        textChangeListenerFound = true;
      }
    }
    assertTrue( textChangeListenerFound );
  }

  @Test
  @Ignore("The following asserts check for side effects of Android's EditText.setSingleLine() These side effects do not occur with robolectric!")
  public void testCreateSingleLineEditText() throws Exception {
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperationWithStyle( "SINGLE" );

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertTrue( view.getTransformationMethod() instanceof SingleLineTransformationMethod );
    assertTrue( ( view.getInputType() & EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE ) == EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE );
  }

  @Test
  public void testTextScaling() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TextOperator textOperator = new TextOperator( activity );
    CreateOperation op = createCreateOperation();

    textOperator.create( op );

    EditText view = findCreatedWidget();
    assertEquals( 16f, view.getTextSize(), 0 );
  }

  @Test
  public void testListenAddModifyListener() throws Exception {
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    AbstractWidgetOperator operator = new TextOperator( activity );
    ListenOperation op = createModifyListenOperation( EDIT_TEXT_ID, true );
    ShadowEditText shadowText = ( ShadowEditText )Robolectric.shadowOf( text );
    assertTrue( shadowText.getWatchers().isEmpty() );
    verify( listenerRegistry, never() ).registerListener( eq( EDIT_TEXT_ID ), anyObject() );

    operator.listen( op );

    assertEquals( 1, shadowText.getWatchers().size() );
    verify( listenerRegistry, times( 1 ) ).registerListener( eq( EDIT_TEXT_ID ), anyObject() );
  }

  @Test
  public void testAttachModifyListenerUpdatesRegistry() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    TextOperator operator = new TextOperator( activity );
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    TabrisShadowEditText shadowText = ( TabrisShadowEditText )Robolectric.shadowOf( text );
    assertEquals( 0, shadowText.getWatchers().size() );

    operator.attachModifyListener( createModifyListenOperation( EDIT_TEXT_ID, true ) );

    assertEquals( 1, shadowText.getWatchers().size() );
  }

  private EditText createEditTextInRootLayout( String targetId ) {
    EditText text = new EditText( activity );
    text.setTag( targetId );
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    when( widgetToolkit.findObjectById( targetId, EditText.class ) ).thenReturn( text );
    when( widgetToolkit.findObjectById( targetId, View.class ) ).thenReturn( text );
    return text;
  }

  private ListenOperation createModifyListenOperation( String targetId, boolean modify ) {
    ListenOperation op = new ListenOperation();
    op.setTarget( targetId );
    ListenProperties properties = new ListenProperties();
    properties.setModify( modify );
    op.setProperties( properties );
    return op;
  }

  @Test
  public void testListenRemoveModifyListener() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowEditText.class );
    EditText text = createEditTextInRootLayout( EDIT_TEXT_ID );
    TextWatcher listener = mock( TextWatcher.class );
    text.addTextChangedListener( listener );
    when( listenerRegistry.unregisterListener( EDIT_TEXT_ID, TextWatcher.class ) ).thenReturn( listener );
    AbstractWidgetOperator operator = new TextOperator( activity );
    ListenOperation op = createModifyListenOperation( EDIT_TEXT_ID, false );
    TabrisShadowEditText shadowText = ( TabrisShadowEditText )Robolectric.shadowOf( text );

    assertEquals( 1, shadowText.getWatchers().size() );

    operator.listen( op );

    assertEquals( 0, shadowText.getWatchers().size() );
  }
}
