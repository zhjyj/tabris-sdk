/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupport;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupportDirection;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollXState;
import com.eclipsesource.tabris.android.toolkit.view.state.ScrollYState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ScrollSupport_Test {

  private static final String WIDGET_ID = "w23";
  private StateRecorder stateRecorder;
  private ScrollSupport scrollSupport;
  private TabrisActivity activity;

  @Before
  public void setUp() {
    activity = UiTestUtil.createUiActivityWithMockedFields();
    stateRecorder = mock( StateRecorder.class );
    when( activity.getProcessor().getStateRecorder() ).thenReturn( stateRecorder );
    View view = mock( View.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    scrollSupport = new ScrollSupport( activity, view );
  }

  @Test
  public void testInitialDirection() throws Exception {
    ScrollSupport scrollSupport = new ScrollSupport( UiTestUtil.createUiActivity(),
                                                     mock( View.class ) );

    assertEquals( ScrollSupportDirection.X_AND_Y, scrollSupport.getDirection() );
  }

  @Test
  public void testSetDirection() throws Exception {
    ScrollSupport scrollSupport = new ScrollSupport( UiTestUtil.createUiActivity(),
                                                     mock( View.class ) );
    scrollSupport.setDirection( ScrollSupportDirection.X );

    assertEquals( ScrollSupportDirection.X, scrollSupport.getDirection() );

    scrollSupport.setDirection( ScrollSupportDirection.Y );

    assertEquals( ScrollSupportDirection.Y, scrollSupport.getDirection() );
  }

  @Test
  public void testOnScrollChangedWithXAndYRecordsState() {
    UiTestUtil.mockToolkitDivideIdentity( activity, 1, 2 );

    scrollSupport.onScrollChanged( 1, 2, 3, 4 );

    ScrollXState scrollXState = new ScrollXState( WIDGET_ID );
    scrollXState.setScrollX( 1 );
    verify( stateRecorder ).recordState( scrollXState );
    ScrollYState scrollYState = new ScrollYState( WIDGET_ID );
    scrollYState.setScrollY( 2 );
    verify( stateRecorder ).recordState( scrollYState );
  }

  @Test
  public void testOnScrollChangedWithXRecordsState() {
    scrollSupport.setDirection( ScrollSupportDirection.X );
    UiTestUtil.mockToolkitDivideIdentity( activity, 1 );

    scrollSupport.onScrollChanged( 1, 2, 3, 4 );

    ScrollXState scrollXState = new ScrollXState( WIDGET_ID );
    scrollXState.setScrollX( 1 );
    verify( stateRecorder ).recordState( scrollXState );
    verifyNoMoreInteractions( stateRecorder );
  }

  @Test
  public void testOnScrollChangedWithYRecordsState() {
    scrollSupport.setDirection( ScrollSupportDirection.Y );
    UiTestUtil.mockToolkitDivideIdentity( activity, 2 );

    scrollSupport.onScrollChanged( 1, 2, 3, 4 );

    ScrollYState scrollYState = new ScrollYState( WIDGET_ID );
    scrollYState.setScrollY( 2 );
    verify( stateRecorder ).recordState( scrollYState );
    verifyNoMoreInteractions( stateRecorder );
  }

  @Test
  public void testGetSetScrollTargetX() throws Exception {
    ScrollSupport scrollSupport = new ScrollSupport( UiTestUtil.createUiActivity(),
                                                     mock( View.class ) );

    assertEquals( 0, scrollSupport.getScrollTargetX() );

    scrollSupport.setScrollTargetX( 21 );

    assertEquals( 21, scrollSupport.getScrollTargetX() );
  }

  @Test
  public void testGetSetScrollTargetY() throws Exception {
    ScrollSupport scrollSupport = new ScrollSupport( UiTestUtil.createUiActivity(),
                                                     mock( View.class ) );

    assertEquals( 0, scrollSupport.getScrollTargetY() );

    scrollSupport.setScrollTargetY( 21 );

    assertEquals( 21, scrollSupport.getScrollTargetY() );
  }

}
