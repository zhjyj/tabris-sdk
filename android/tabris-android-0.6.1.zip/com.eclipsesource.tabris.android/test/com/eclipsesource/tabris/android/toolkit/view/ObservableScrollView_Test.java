/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.ObservableHorizontalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;
import com.eclipsesource.tabris.android.toolkit.view.ScrollSupportDirection;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ObservableScrollView_Test {

  private static final String WIDGET_ID = "w2";

  private TabrisActivity activity;
  private ObservableScrollView scrollView;

  @Before
  public void setUp() {
    activity = UiTestUtil.createUiActivityWithoutOnCreate();
    scrollView = new ObservableScrollView( activity );
  }

  @Test
  public void testCreateNestedScrollView() {
    scrollView.setTag( WIDGET_ID );

    scrollView.createNestedScrollViews();

    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    assertEquals( ObservableVerticalScrollView.class, verticalScroll.getClass() );
    assertEquals( ScrollSupportDirection.Y, verticalScroll.getScrollSupport().getDirection() );
    assertEquals( WIDGET_ID, verticalScroll.getTag() );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    assertEquals( ObservableHorizontalScrollView.class, horizontalScroll.getClass() );
    assertEquals( ScrollSupportDirection.X, horizontalScroll.getScrollSupport().getDirection() );
    assertEquals( WIDGET_ID, horizontalScroll.getTag() );
  }

  public void testGetHorizontalScroll() {
    scrollView.createNestedScrollViews();
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );

    ObservableHorizontalScrollView horizontalScrollActual = scrollView.getHorizontalScroll();

    assertEquals( horizontalScroll, horizontalScrollActual );
  }

  public void testGetVerticalScroll() {
    scrollView.createNestedScrollViews();
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );

    ObservableVerticalScrollView verticalScrollActual = scrollView.getVerticalScroll();

    assertEquals( verticalScroll, verticalScrollActual );
  }

  @Test
  public void testAddView() throws Exception {
    scrollView.createNestedScrollViews();
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    View view = new View( activity );

    scrollView.addView( view );

    assertEquals( horizontalScroll.getChildAt( 0 ), view );
  }

  @Test
  public void testRemoveView() throws Exception {
    scrollView.createNestedScrollViews();
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    View view = new View( activity );
    horizontalScroll.addView( view );

    scrollView.removeView( view );

    assertEquals( 0, horizontalScroll.getChildCount() );
  }

  @Test
  public void testRemoveViewAt() throws Exception {
    scrollView.createNestedScrollViews();
    ObservableVerticalScrollView verticalScroll = ( ObservableVerticalScrollView )scrollView.getChildAt( 0 );
    ObservableHorizontalScrollView horizontalScroll = ( ObservableHorizontalScrollView )verticalScroll.getChildAt( 0 );
    View view = new View( activity );
    horizontalScroll.addView( view );

    scrollView.removeViewAt( 0 );

    assertEquals( 0, horizontalScroll.getChildCount() );
  }
}
