/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.TableColumn;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TableColumnOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";
  private TabrisActivity activity;

  @Before
  public void setUp() {
    activity = UiTestUtil.createUiActivityWithMockedFields();
  }

  @Test
  public void testGetType() {
    TableColumnOperator op = new TableColumnOperator( new TabrisActivity() );

    assertEquals( TableColumnOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new TableColumnOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new TableColumnOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    TableColumnOperator operator = new TableColumnOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTabFolderNoProps() throws Exception {
    AbstractWidgetOperator operator = new TableColumnOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTabFolderNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new TableColumnOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTabFolderNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new TableColumnOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreate() throws Exception {
    TreeView treeView = mock( TreeView.class );
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( treeView );
    TableColumnOperator operator = new TableColumnOperator( activity );
    CreateOperation operation = new CreateOperation();
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    operation.setProperties( props );
    operation.setTarget( WIDGET_ID );

    operator.create( operation );

    verify( toolkit ).registerObjectById( eq( WIDGET_ID ), any( TableColumn.class ) );
  }

  @Test
  public void testDestroy() throws Exception {
    TableColumnOperator operator = new TableColumnOperator( activity );
    DestroyOperation operation = new DestroyOperation();
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.findObjectById( WIDGET_ID, View.class ) ).thenReturn( mock( TableColumn.class ) );
    operation.setTarget( WIDGET_ID );

    operator.destroy( operation );

    verify( toolkit ).unregisterObjectById( eq( WIDGET_ID ) );
  }

}
