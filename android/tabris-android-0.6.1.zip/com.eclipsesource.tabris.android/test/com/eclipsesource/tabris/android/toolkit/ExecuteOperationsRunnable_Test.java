/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.ExecuteOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.ExecuteOperationsRunnable;

public class ExecuteOperationsRunnable_Test {

  @Test
  public void testOperationFoundJsexFilter() {
    ExecuteOperation op = new ExecuteOperation();
    op.setTarget( "jsex" );
    ArrayList<Operation> operations = new ArrayList<Operation>();
    operations.add( op );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    ExecuteOperationsRunnable runnable = new ExecuteOperationsRunnable( toolkit, operations );

    runnable.run();

    verifyNoMoreInteractions( toolkit );
  }

}
