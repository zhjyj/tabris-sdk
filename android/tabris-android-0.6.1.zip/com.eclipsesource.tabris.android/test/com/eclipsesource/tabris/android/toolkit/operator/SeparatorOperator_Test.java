/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.test.shadow.TabrisProgressBar;
import com.eclipsesource.tabris.android.toolkit.SeparatorOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Separator;
import com.eclipsesource.tabris.android.toolkit.view.Separator.Orientation;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SeparatorOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentWidget;

  @Before
  public void setup() {
    activity = UiTestUtil.createUiActivity();
    parentWidget = new FrameLayout( activity );
    activity.getProcessor().getWidgetToolkit().registerObjectById( PARENT_ID, parentWidget );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateProgressBarNoProps() throws Exception {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateProgressBarNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateProgressBarNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private Separator getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof Separator );
    assertEquals( WIDGET_ID, view.getTag() );
    return ( Separator )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateDefault() throws Exception {
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Separator separator = getCreatedValidatedView();
    assertEquals( parentWidget, separator.getParent() );
    assertEquals( Orientation.VERTICAL, separator.getOrientation() );
  }

  @Test
  public void testCreateHorizontal() throws Exception {
    Robolectric.bindShadowClass( TabrisProgressBar.class );
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( "HORIZONTAL" ) );

    operator.create( op );

    Separator separator = getCreatedValidatedView();
    assertEquals( parentWidget, separator.getParent() );
    assertEquals( Orientation.HORIZONTAL, separator.getOrientation() );
  }

  @Test
  public void testCreateVertical() throws Exception {
    Robolectric.bindShadowClass( TabrisProgressBar.class );
    AbstractWidgetOperator operator = new SeparatorOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( "VERTICAL" ) );

    operator.create( op );

    Separator separator = getCreatedValidatedView();
    assertEquals( parentWidget, separator.getParent() );
    assertEquals( Orientation.VERTICAL, separator.getOrientation() );
  }

  @Test
  public void testGetType() throws Exception {
    SeparatorOperator op = new SeparatorOperator( new TabrisActivity() );
    assertEquals( "rwt.widgets.Separator", op.getType() );
  }

}
