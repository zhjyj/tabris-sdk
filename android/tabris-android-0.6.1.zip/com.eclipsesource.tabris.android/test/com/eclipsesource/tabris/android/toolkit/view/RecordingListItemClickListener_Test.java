/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.ListSelectionState;

public class RecordingListItemClickListener_Test {

  private static final String LIST_ID = "w2";

  @Test
  public void testListItemClicked() {
    StateRecorder stateRecorder = mock( StateRecorder.class );
    RecordingListItemClickListener listener = new RecordingListItemClickListener( stateRecorder );
    List view = mock( List.class );
    when( view.getTag() ).thenReturn( LIST_ID );
    ListSelectionAdapter<?> adapter = mock( ListSelectionAdapter.class );
    when( view.getAdapter() ).thenReturn( adapter );
    ListSelectionState selectionState = new ListSelectionState( LIST_ID, 23 );

    listener.onItemClick( view, null, 23, 23 );

    verify( stateRecorder ).recordState( selectionState );
    verify( adapter ).setSelection( 23 );
  }
}
