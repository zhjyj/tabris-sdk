/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.setter.TreeViewSetter;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;

public class TreeViewSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>();
    setter.execute( mock( TabrisActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>();
    setter.execute( mock( TabrisActivity.class ), mock( TreeView.class ), null );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testSetSelectionIgnored() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>();
    SetProperties props = new SetProperties();
    GenericObject genericObject = mock( GenericObject.class );
    props.setSelection( genericObject );

    setter.execute( mock( TabrisActivity.class ), mock( TreeView.class ), props );

    verify( genericObject, never() ).getObjectAs( any( Class.class ) );
  }
}
