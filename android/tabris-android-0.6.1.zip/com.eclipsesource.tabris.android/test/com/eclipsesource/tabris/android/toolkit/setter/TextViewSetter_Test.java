/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.TextView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.Font;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowAsyncTask;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.setter.TextViewSetter;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TextViewSetter_Test {

  private static final String EMPTY_STRING = "";
  private static final String TEXT_STRING = "Hello World!";

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    setter.execute( mock( TabrisActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    setter.execute( mock( TabrisActivity.class ), mock( TextView.class ), null );
  }

  @Test
  public void testSetTextOk() {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = new TextView( new TabrisActivity() );
    SetProperties properties = new SetProperties();
    properties.setText( TEXT_STRING );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    assertEquals( TEXT_STRING, textView.getText() );
  }

  @Test
  public void testSetTextNull() {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = new TextView( new TabrisActivity() );
    SetProperties properties = new SetProperties();

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    assertEquals( EMPTY_STRING, textView.getText() );
  }

  @Test
  public void testSetForegroundOk() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    List<Integer> colorTouple = Arrays.asList( 10, 20, 30, 40 );
    properties.setForeground( colorTouple );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    int color = SetterManager.colorToupleToInt( colorTouple );
    verify( textView ).setTextColor( color );
  }

  @Test
  public void testSetMessage() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    properties.setToolTip( "tooltip" );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verify( textView ).setHint( "tooltip" );
  }

  @Test
  public void testSetMessageNotSet() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verifyNoMoreInteractions( textView );
  }

  @Test
  public void testSetTooltip() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    properties.setMessage( "message" );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verify( textView ).setHint( "message" );
  }

  @Test
  public void testSetTooltipNotSet() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verifyNoMoreInteractions( textView );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetImageMalformed() throws Throwable {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView view = mock( TextView.class );
    SetProperties props = new SetProperties();
    props.setBackgroundImage( Arrays.asList( "somePath/toAn/Image", "256" ) );

    setter.execute( mock( TabrisActivity.class ), view, props );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetImageUrlMissing() throws Throwable {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView view = mock( TextView.class );
    SetProperties props = new SetProperties();
    props.setBackgroundImage( Arrays.asList( "", "256", "100" ) );

    setter.execute( mock( TabrisActivity.class ), view, props );
  }

  @Test
  public void testSetImageNoProps() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView view = mock( TextView.class );
    SetProperties props = new SetProperties();

    setter.execute( mock( TabrisActivity.class ), view, props );

    verifyZeroInteractions( view );
  }

  @Test
  public void testSetImage() throws Exception {
    Robolectric.bindShadowClass( TabrisShadowAsyncTask.class );
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView view = mock( TextView.class );
    when( view.getCompoundDrawables() ).thenReturn( new Drawable[ 4 ] );
    SetProperties props = new SetProperties();
    props.setImage( Arrays.asList( "somePath/toAn/Image", "256", "256" ) );
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    ITransportResult transportResult = mock( ITransportResult.class );
    ByteArrayInputStream inputImage = new ByteArrayInputStream( new byte[]{
      1, 2, 3
    } );
    when( activity.getProcessor().processGetRequest( any( GetRequest.class ) ) ).thenReturn( transportResult );
    when( transportResult.getResult() ).thenReturn( inputImage );

    setter.execute( activity, view, props );

    verify( view ).setCompoundDrawablesWithIntrinsicBounds( isNull( Drawable.class ),
                                                            any( Drawable.class ),
                                                            isNull( Drawable.class ),
                                                            isNull( Drawable.class ) );
    BitmapDrawableCache cache = activity.getProcessor().getWidgetToolkit().getBitmapCache();
    verify( cache ).decreaseReferenceCount( any( BitmapDrawable.class ) );
  }

  @Test
  public void testSetFontOk() throws Exception {
    // we can not check for the font family because there are no default fonts
    // available during unit test runtime
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TabrisActivity activity = new TabrisActivity();
    TextView textView = mock( TextView.class );
    SetProperties props = new SetProperties();
    Font font = new Font();
    font.setFamily( Arrays.asList( "SomeFontFamily" ) );
    font.setSize( 36 );
    font.setBold( true );
    font.setItalic( true );
    props.setFont( font );

    setter.execute( activity, textView, props );

    verify( textView ).setTextSize( 36 );
    verify( textView ).setTypeface( null, Typeface.BOLD_ITALIC );
  }

  @Test
  public void testSetFontVariation2() throws Exception {
    // we can not check for the font family because there are no default fonts
    // available during unit test runtime
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TabrisActivity activity = new TabrisActivity();
    TextView textView = mock( TextView.class );
    SetProperties props = new SetProperties();
    Font font = new Font();
    font.setFamily( Arrays.asList( "SomeFontFamily" ) );
    font.setBold( false );
    font.setItalic( false );
    props.setFont( font );

    setter.execute( activity, textView, props );

    verify( textView, never() ).setTextSize( anyFloat() );
    verify( textView ).setTypeface( null, Typeface.NORMAL );
  }

  @Test
  public void testSetAlignmentLeft() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    properties.setAlignment( "left" );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verify( textView ).setGravity( Gravity.LEFT | setter.getDefaultVerticalAlignment() );
  }

  @Test
  public void testSetAlignmentRight() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    properties.setAlignment( "right" );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verify( textView ).setGravity( Gravity.RIGHT | setter.getDefaultVerticalAlignment() );
  }

  @Test
  public void testSetAlignmentCenter() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();
    TextView textView = mock( TextView.class );
    SetProperties properties = new SetProperties();
    properties.setAlignment( "center" );

    setter.execute( mock( TabrisActivity.class ), textView, properties );

    verify( textView ).setGravity( Gravity.CENTER_HORIZONTAL | setter.getDefaultVerticalAlignment() );
  }

  @Test
  public void testGetDefaultVerticalAlignment() throws Exception {
    TextViewSetter<TextView> setter = new TextViewSetter<TextView>();

    int defaultVerticalAlignment = setter.getDefaultVerticalAlignment();

    assertEquals( Gravity.TOP, defaultVerticalAlignment );
  }
}
