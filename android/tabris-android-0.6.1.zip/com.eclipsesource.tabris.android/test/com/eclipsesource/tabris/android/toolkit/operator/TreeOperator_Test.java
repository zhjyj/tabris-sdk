/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.operator.AbstractWidgetOperator;
import com.eclipsesource.tabris.android.toolkit.operator.ShellOperator;
import com.eclipsesource.tabris.android.toolkit.operator.TreeOperator;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ExpansionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.SelectionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeOperator_Test {

  private static final String TREE_ID = "w3";

  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;

  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = new TabrisActivity();
    activity.setContentView( R.layout.protocol );
    ProtocolProcessor processor = new ProtocolProcessor();
    activity.setProcessor( processor );
    processor.setWidgetToolkit( new AndroidWidgetToolkit( activity ) );
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    rootLayout.addView( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new TreeOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    ShellOperator operator = new ShellOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoProps() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateTreeNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeNoParentFound() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivity();
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateTreeParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( buttonId );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateTreeOk() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    getCreatedValidatedView();
  }

  private TreeView getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, TREE_ID );
    assertTrue( view instanceof TreeView );
    assertEquals( TREE_ID, view.getTag() );
    assertHasListenerRegisteredViaCompositeListener( ( TreeView )view,
                                                     ExpansionTreeItemClickListener.class );
    return ( TreeView )view;
  }

  private void assertHasListenerRegisteredViaCompositeListener( TreeView treeView,
                                                                Class<? extends OnItemClickListener> listenerClass )
  {
    OnItemClickListener onItemClickListener = treeView.getOnItemClickListener();
    assertEquals( CompositeItemClickListener.class, onItemClickListener.getClass() );
    assertTrue( ( ( CompositeItemClickListener )onItemClickListener ).contains( listenerClass ) );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( TREE_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testGetType() throws Exception {
    TreeOperator op = new TreeOperator( new TabrisActivity() );
    assertEquals( TreeOperator.TYPE, op.getType() );
  }

  @Test
  public void testAttachSelectionListener() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    treeView.setOnItemClickListener( new CompositeItemClickListener() );
    activity.getProcessor().getWidgetToolkit().registerObjectById( TREE_ID, treeView );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    ListenProperties props = new ListenProperties();
    props.setSelection( true );
    listenOp.setProperties( props );

    op.listen( listenOp );

    assertHasListenerRegisteredViaCompositeListener( treeView, SelectionTreeItemClickListener.class );
  }

  @Test
  public void testAttachSelectionListenerNull() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    activity.getProcessor().getWidgetToolkit().registerObjectById( TREE_ID, treeView );
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    treeView.setOnItemClickListener( compListener );
    parentLayout.addView( treeView );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    listenOp.setProperties( new ListenProperties() );

    op.listen( listenOp );

    assertEquals( 0, compListener.getSize() );
  }

  @Test
  public void testRemoveSelectionListener() throws Exception {
    TreeOperator op = new TreeOperator( activity );
    TreeView treeView = new TreeView( activity );
    activity.getProcessor().getWidgetToolkit().registerObjectById( TREE_ID, treeView );
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    compListener.addListener( new SelectionTreeItemClickListener( activity ) );
    treeView.setOnItemClickListener( compListener );
    parentLayout.addView( treeView );
    ListenOperation listenOp = new ListenOperation();
    listenOp.setTarget( TREE_ID );
    ListenProperties props = new ListenProperties();
    props.setSelection( false );
    listenOp.setProperties( props );

    assertHasListenerRegisteredViaCompositeListener( treeView, SelectionTreeItemClickListener.class );

    op.listen( listenOp );

    assertEquals( 0, compListener.getSize() );
  }

  @Test
  public void testCreateTreeWithStyleVirtual() throws Exception {
    AbstractWidgetOperator operator = new TreeOperator( activity );
    CreateOperation op = createValidCreateOperation();
    op.getProperties().setStyle( Arrays.asList( TreeOperator.STYLE_VIRTUAL ) );

    operator.create( op );

    TreeView treeView = getCreatedValidatedView();
    assertTrue( treeView.hasVirtualTreeSupport() );
  }
}
