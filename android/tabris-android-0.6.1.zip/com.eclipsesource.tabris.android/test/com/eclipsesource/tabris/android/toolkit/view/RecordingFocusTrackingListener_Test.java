
package com.eclipsesource.tabris.android.toolkit.view;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.os.IBinder;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.state.FocusState;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class RecordingFocusTrackingListener_Test {

  private static final String WIDGET_ID = "w1";
  private static final String WIDGET2_ID = "w2";

  @Test
  public void testRecordStateOnNewViewTouched() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    RecordingFocusTrackingListener listener = new RecordingFocusTrackingListener( activity );
    View view = new View( activity );
    view.setTag( WIDGET_ID );

    boolean result = listener.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    StateRecorder stateRecorder = activity.getProcessor().getStateRecorder();
    verify( stateRecorder ).recordState( new FocusState( WIDGET_ID ) );
  }

  @Test
  public void testRecordStateOnAnotherViewTouched() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    RecordingFocusTrackingListener listener = new RecordingFocusTrackingListener( activity );
    listener.setPrevTag( WIDGET2_ID );
    View view = new View( activity );
    view.setTag( WIDGET_ID );

    boolean result = listener.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    StateRecorder stateRecorder = activity.getProcessor().getStateRecorder();
    verify( stateRecorder ).recordState( new FocusState( WIDGET_ID ) );
  }

  @Test
  public void tesNoStateRecordedWhenSameViewTouched() {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    RecordingFocusTrackingListener listener = new RecordingFocusTrackingListener( activity );
    listener.setPrevTag( WIDGET_ID );
    View view = new View( activity );
    view.setTag( WIDGET_ID );

    boolean result = listener.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    StateRecorder stateRecorder = activity.getProcessor().getStateRecorder();
    verify( stateRecorder, never() ).recordState( new FocusState( WIDGET_ID ) );
  }

  @Test
  public void testHidesKeyboardWhenNoneEditTextViewTouched() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    RecordingFocusTrackingListener listener = new RecordingFocusTrackingListener( activity );
    InputMethodManager imm = mock( InputMethodManager.class );
    listener.setInputMethodManager( imm );
    View view = new View( activity );
    view.setTag( WIDGET_ID );

    boolean result = listener.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    verify( imm ).hideSoftInputFromWindow( any( IBinder.class ), anyInt() );
  }

  @Test
  public void testNotifiesImmediateListenerWhenEditTextTouchedAndFocused() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = widgetToolkit.getListenerRegistry();
    CompositeFocusListener compFocusListener = new CompositeFocusListener();
    ImmediateFocusChangeListener focusListener = mock( ImmediateFocusChangeListener.class );
    compFocusListener.addListener( focusListener );
    when( listenerRegistry.findListener( WIDGET_ID, CompositeFocusListener.class ) ).thenReturn( compFocusListener );
    RecordingFocusTrackingListener listenerUnderTest = new RecordingFocusTrackingListener( activity );
    EditText view = mock( EditText.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    when( view.hasFocus() ).thenReturn( true );

    boolean result = listenerUnderTest.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    verify( focusListener ).onFocusChange( view, true );
  }

  @Test
  public void testImmediateListenerNotNotifiesWhenEditTextTouchedAndNotFocused() throws Exception {
    TabrisActivity activity = UiTestUtil.createUiActivityWithMockedFields();
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = widgetToolkit.getListenerRegistry();
    CompositeFocusListener compFocusListener = new CompositeFocusListener();
    ImmediateFocusChangeListener focusListener = mock( ImmediateFocusChangeListener.class );
    compFocusListener.addListener( focusListener );
    when( listenerRegistry.findListener( WIDGET_ID, CompositeFocusListener.class ) ).thenReturn( compFocusListener );
    RecordingFocusTrackingListener listenerUnderTest = new RecordingFocusTrackingListener( activity );
    EditText view = mock( EditText.class );
    when( view.getTag() ).thenReturn( WIDGET_ID );
    when( view.hasFocus() ).thenReturn( false );

    boolean result = listenerUnderTest.onTouch( view, MotionEvent.obtain( 0, 0, 0, 0, 0, 0 ) );

    assertFalse( result );
    verify( focusListener, never() ).onFocusChange( any( View.class ), anyBoolean() );
  }

}
