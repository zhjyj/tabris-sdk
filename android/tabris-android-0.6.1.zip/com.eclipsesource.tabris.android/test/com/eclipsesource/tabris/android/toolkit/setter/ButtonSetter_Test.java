/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CompoundButton;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.util.ColorUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class ButtonSetter_Test {

  class SetterUnderTest extends ButtonSetter<Button> {

    private final int buttonStyle;

    public SetterUnderTest( int buttonStyle ) {
      this.buttonStyle = buttonStyle;
    }

    @Override
    protected int getCurrentButtonStyle() {
      return buttonStyle;
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    setter.execute( mock( TabrisActivity.class ), null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    setter.execute( mock( TabrisActivity.class ), mock( CompoundButton.class ), null );
  }

  @Test
  public void testSetBackgroundNull() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    TabrisActivity activity = new TabrisActivity();
    SetProperties props = new SetProperties();
    CompoundButton button = mock( CompoundButton.class );

    setter.execute( activity, button, props );

    verifyNoMoreInteractions( button );
  }

  @Test
  public void testSetBackgroundOnButtonWithouthBgDrawable() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();
    TabrisActivity activity = new TabrisActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( 255, 255, 0 ) );
    CompoundButton button = mock( CompoundButton.class );
    when( button.getBackground() ).thenReturn( null );

    setter.execute( activity, button, props );

    verify( button ).setBackgroundColor( 0xFFFFFF00 );
  }

  @Test
  public void testSetBackgroundOnDrawableWithLightTheme() throws Exception {
    int r = 128;
    int g = 24;
    int b = 156;
    SetterUnderTest setter = new SetterUnderTest( R.style.Widget_Holo_Light_Button );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    TabrisActivity activity = new TabrisActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( r, g, b ) );
    CompoundButton button = mock( CompoundButton.class );
    Drawable bgDrawable = mock( Drawable.class );
    when( button.getBackground() ).thenReturn( bgDrawable );

    setter.execute( activity, button, props );

    verify( colorUtil ).applyColorFilter( bgDrawable,
                                          r / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME,
                                          g / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME,
                                          b / 255f + ButtonSetter.LUMINOCITY_LIGHT_THEME );
  }

  @Test
  public void testSetBackgroundOnDrawableWithDarkTheme() throws Exception {
    int r = 128;
    int g = 24;
    int b = 156;
    SetterUnderTest setter = new SetterUnderTest( R.style.Widget_Holo_Button );
    ColorUtil colorUtil = mock( ColorUtil.class );
    setter.setColorUtil( colorUtil );
    TabrisActivity activity = new TabrisActivity();
    SetProperties props = new SetProperties();
    props.setBackground( Arrays.asList( r, g, b ) );
    CompoundButton button = mock( CompoundButton.class );
    Drawable bgDrawable = mock( Drawable.class );
    when( button.getBackground() ).thenReturn( bgDrawable );

    setter.execute( activity, button, props );

    verify( colorUtil ).applyColorFilter( bgDrawable,
                                          r / 255f + ButtonSetter.LUMINOCITY_DARK_THEME,
                                          g / 255f + ButtonSetter.LUMINOCITY_DARK_THEME,
                                          b / 255f + ButtonSetter.LUMINOCITY_DARK_THEME );
  }

  @Test
  public void testGetDefaultVerticalAlignment() throws Exception {
    ButtonSetter<Button> setter = new ButtonSetter<Button>();

    int defaultVerticalAlignment = setter.getDefaultVerticalAlignment();

    assertEquals( Gravity.CENTER_VERTICAL, defaultVerticalAlignment );
  }

  @Test
  public void testSetBitmapDrawable() throws Exception {
    ButtonSetter<Button> buttonSetter = new ButtonSetter<Button>();
    Button button = mock( Button.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );

    buttonSetter.setBitmapDrawable( button, bitmapDrawable );

    verify( button ).setCompoundDrawablesWithIntrinsicBounds( eq( bitmapDrawable ),
                                                              isNull( BitmapDrawable.class ),
                                                              isNull( BitmapDrawable.class ),
                                                              isNull( BitmapDrawable.class ) );
  }

  @Test
  public void testGetBitmapDrawable() throws Exception {
    ButtonSetter<Button> buttonSetter = new ButtonSetter<Button>();
    Button button = mock( Button.class );
    BitmapDrawable bitmapDrawable = mock( BitmapDrawable.class );
    when( button.getCompoundDrawables() ).thenReturn( new Drawable[]{
      bitmapDrawable, null, null, null
    } );

    BitmapDrawable result = buttonSetter.getBitmapDrawable( button );

    assertEquals( result, bitmapDrawable );
  }
}
