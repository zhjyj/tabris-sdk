/** Automatically generated file. DO NOT MODIFY */
package com.eclipsesource.tabris.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}