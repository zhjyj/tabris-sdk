/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class WidgetSelectedState extends AbstractState {

  String widgetSelected = IProtocolConstants.EVENT_WIDGET_SELECTED;

  public WidgetSelectedState( String widgetID ) {
    super( widgetID );
  }

  @Override
  public String generateKey() {
    return widgetSelected;
  }

  @Override
  public String generateValue() {
    return widgetId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ( ( widgetSelected == null )
                                                          ? 0
                                                          : widgetSelected.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( !super.equals( obj ) ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    WidgetSelectedState other = ( WidgetSelectedState )obj;
    if( widgetSelected == null ) {
      if( other.widgetSelected != null ) {
        return false;
      }
    } else if( !widgetSelected.equals( other.widgetSelected ) ) {
      return false;
    }
    return true;
  }

}
