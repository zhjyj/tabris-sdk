
package com.eclipsesource.tabris.android;

import java.util.ArrayList;

public class RequestCodePool {

  private final ArrayList<Integer> pool;

  public RequestCodePool( int size ) {
    pool = new ArrayList<Integer>();
    // index starts at two because of predefined codes in Activity.class
    int totalSize = size + 2;
    for( int i = 2; i < totalSize; i++ ) {
      pool.add( i );
    }
  }

  public int takeRequestCode() {
    if( pool.isEmpty() ) {
      throw new IllegalStateException( "The request code pool is empty." );
    }
    return pool.remove( 0 );
  }

  public void returnRequestCode( int code ) {
    if( pool.contains( code ) ) {
      throw new IllegalArgumentException( "The request code pool already contains code " + code );
    }
    pool.add( code );
  }

}
