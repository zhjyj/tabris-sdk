/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import java.util.List;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

import com.eclipsesource.tabris.android.toolkit.setter.ViewSetter;

public class ApplyBoundsOnFinishAnimationListener implements AnimationListener {

  private final View view;
  private final List<Integer> bounds;
  private final ViewSetter<? extends View> viewSetter;

  public ApplyBoundsOnFinishAnimationListener( View view,
                                               List<Integer> bounds,
                                               ViewSetter<? extends View> viewSetter )
  {
    ValidationUtil.checkNullArg( this, view, View.class );
    ValidationUtil.checkNullArg( this, viewSetter, ViewSetter.class );
    ValidationUtil.checkNullArg( this, bounds, List.class );
    this.view = view;
    this.bounds = bounds;
    this.viewSetter = viewSetter;
  }

  public void onAnimationStart( Animation animation ) {
    // nothing to do here
  }

  public void onAnimationRepeat( Animation animation ) {
    // nothing to do here
  }

  public void onAnimationEnd( Animation animation ) {
    viewSetter.applyBoundsToView( view, bounds );
    view.requestLayout();
  }
}