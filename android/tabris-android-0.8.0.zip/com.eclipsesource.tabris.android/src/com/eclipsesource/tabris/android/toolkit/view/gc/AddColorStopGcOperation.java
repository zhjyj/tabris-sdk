/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class AddColorStopGcOperation extends AbstractGcOperation {

  private static final String OPERATION = "addColorStop";

  public AddColorStopGcOperation() {
    super( OPERATION );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 3 );
    Integer index = ( ( Number )properties.get( 1 ) ).intValue();
    List<?> touple = ( List<?> )properties.get( 2 );
    List<Integer> intTouple = PaintColorGcOperation.listToIntegerList( getOperation(), touple );
    int color = SetterManager.colorToupleToInt( intTouple );
    gc.getLinearGradient().addColor( index, color );
  }
}
