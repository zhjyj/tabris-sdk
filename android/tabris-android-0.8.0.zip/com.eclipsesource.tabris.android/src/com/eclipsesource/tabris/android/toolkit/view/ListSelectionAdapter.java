/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.eclipsesource.tabris.android.R;

public class ListSelectionAdapter<T> extends ArrayAdapter<T> {

  public static final int NOTHING_SELECTED = -1;
  private int selection;

  public ListSelectionAdapter( Context context,
                               int resource,
                               int textViewResourceId,
                               List<T> objects )
  {
    super( context, resource, textViewResourceId, objects );
    selection = NOTHING_SELECTED;
  }

  public void setSelection( int selectedIndex ) {
    selection = selectedIndex;
    notifyDataSetChanged();
  }

  public int getSelection() {
    return selection;
  }

  @Override
  public View getView( int position, View convertView, ViewGroup parent ) {
    View view = super.getView( position, convertView, parent );
    if( isPositionSelected( position ) ) {
      view.setBackgroundColor( getContext().getResources().getColor( R.color.list_item_selected ) );
    } else {
      view.setBackgroundDrawable( null );
    }
    return view;
  }

  private boolean isPositionSelected( int position ) {
    return selection == position;
  }
}
