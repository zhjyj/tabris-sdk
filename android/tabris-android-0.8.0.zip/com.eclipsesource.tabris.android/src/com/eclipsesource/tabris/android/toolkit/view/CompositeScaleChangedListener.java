/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class CompositeScaleChangedListener extends ListenerHolder<OnSeekBarChangeListener>
  implements OnSeekBarChangeListener
{

  public void onStopTrackingTouch( SeekBar seekBar ) {
    ArrayList<OnSeekBarChangeListener> listeners = getListeners();
    for( int i = 0; i < listeners.size(); i++ ) {
      listeners.get( i ).onStopTrackingTouch( seekBar );
    }
  }

  public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {
    // nothing to do here
  }

  public void onStartTrackingTouch( SeekBar seekBar ) {
    // nothing to do here
  }

}
