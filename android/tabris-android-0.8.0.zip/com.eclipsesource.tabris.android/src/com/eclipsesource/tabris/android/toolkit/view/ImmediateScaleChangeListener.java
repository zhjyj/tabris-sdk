/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class ImmediateScaleChangeListener implements OnSeekBarChangeListener {

  private final ProtocolProcessor processor;

  public ImmediateScaleChangeListener( ProtocolProcessor processor ) {
    this.processor = processor;
  }

  public void onStopTrackingTouch( SeekBar seekBar ) {
    if( seekBar instanceof Scale ) {
      Scale scale = ( Scale )seekBar;
      String widgetId = ( String )scale.getTag();
      String curProgress = String.valueOf( scale.getProgress() + scale.getMin() );
      PostRequest request = new PostRequest();
      request.addParam( EVENT_WIDGET_SELECTED, widgetId );
      request.addParam( widgetId + SELECTION_POSTFIX, curProgress );
      processor.processPostRequest( request );
    }
  }

  public void onStartTrackingTouch( SeekBar seekBar ) {
    // nothing to do here
  }

  public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {
    // nothing to do here
  }
}
