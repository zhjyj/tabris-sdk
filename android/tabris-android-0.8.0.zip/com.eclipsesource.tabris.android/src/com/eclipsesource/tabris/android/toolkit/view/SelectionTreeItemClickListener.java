/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.ArrayList;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class SelectionTreeItemClickListener implements OnItemClickListener {

  private final TabrisActivity activity;

  public SelectionTreeItemClickListener( TabrisActivity activity ) {
    this.activity = activity;
  }

  public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
    ProtocolProcessor processor = activity.getProcessor();
    PostRequest request = new PostRequest();
    if( parent.getParent() instanceof TreeView ) {
      TreeView treeView = ( TreeView )parent.getParent();
      ArrayList<TreeItemView> currentTreeItems = treeView.getCurrentTreeItems();
      if( currentTreeItems.size() > position ) {
        TreeItemView selectedItem = treeView.getCurrentTreeItems().get( position );
        populateSelectionParams( treeView, selectedItem, request );
        processor.processPostRequest( request );
      }
    }
  }

  private void populateSelectionParams( TreeView treeView, TreeItemView view, PostRequest request )
  {
    request.addParam( treeView.getTag() + IProtocolConstants.SELECTION_POSTFIX,
                      ( String )view.getTag() );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED_ITEM, ( String )view.getTag() );
    request.addParam( IProtocolConstants.EVENT_WIDGET_SELECTED, ( String )treeView.getTag() );
  }
}