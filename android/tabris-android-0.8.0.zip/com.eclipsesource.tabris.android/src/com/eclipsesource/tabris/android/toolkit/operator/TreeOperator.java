/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.ExpansionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.SelectionTreeItemClickListener;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.eclipsesource.tabris.android.toolkit.view.TreeViewAdapter;
import com.eclipsesource.tabris.android.toolkit.view.VirtualTreeSupport;

public class TreeOperator extends AbstractWidgetOperator {

  public static final String STYLE_VIRTUAL = "VIRTUAL";

  public static final String TYPE = "rwt.widgets.Grid";

  public TreeOperator( TabrisActivity activity ) {
    super( activity );
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    TreeView treeView = new TreeView( getActivity() );
    treeView.setAdapter( new TreeViewAdapter( getActivity(), treeView ) );
    attachDefaultListeners( treeView );
    attachVirtualListener( treeView, operation );
    initiateNewView( operation, treeView );
  }

  private void attachDefaultListeners( TreeView treeView ) {
    CompositeItemClickListener compListener = new CompositeItemClickListener();
    ExpansionTreeItemClickListener expansionTreeItemClickListener = new ExpansionTreeItemClickListener( getActivity() );
    compListener.addListener( expansionTreeItemClickListener );
    treeView.setOnItemClickListener( compListener );
  }

  private void attachVirtualListener( TreeView treeView, CreateOperation operation ) {
    List<String> style = operation.getProperties().getStyle();
    if( style != null && style.contains( STYLE_VIRTUAL ) ) {
      treeView.setVirtualTreeSupport( new VirtualTreeSupport( getActivity() ) );
    }
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final TreeView treeView = findObjectById( operation.getTarget(), TreeView.class );
    CompositeItemClickListener compListener = ( CompositeItemClickListener )treeView.getOnItemClickListener();
    compListener.addListener( new SelectionTreeItemClickListener( getActivity() ) );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    final TreeView treeView = findObjectById( operation.getTarget(), TreeView.class );
    CompositeItemClickListener compListener = ( CompositeItemClickListener )treeView.getOnItemClickListener();
    compListener.removeListeners( SelectionTreeItemClickListener.class );
  }

  public String getType() {
    return TYPE;
  }

}
