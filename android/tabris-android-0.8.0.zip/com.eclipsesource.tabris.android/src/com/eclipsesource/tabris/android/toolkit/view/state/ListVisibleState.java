/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class ListVisibleState implements IState {

  private final String widgetId;
  private final boolean visible;

  public ListVisibleState( String widgetId, boolean visible ) {
    this.widgetId = widgetId;
    this.visible = visible;
  }

  public String generateKey() {
    return widgetId + IProtocolConstants.LIST_VISIBLE_POSTFIX;
  }

  public String generateValue() {
    return String.valueOf( visible );
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( visible
                                       ? 1231
                                       : 1237 );
    result = prime * result + ( ( widgetId == null )
                                                    ? 0
                                                    : widgetId.hashCode() );
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj )
      return true;
    if( obj == null )
      return false;
    if( getClass() != obj.getClass() )
      return false;
    ListVisibleState other = ( ListVisibleState )obj;
    if( visible != other.visible )
      return false;
    if( widgetId == null ) {
      if( other.widgetId != null )
        return false;
    } else if( !widgetId.equals( other.widgetId ) )
      return false;
    return true;
  }

}
