/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.content.Context;
import android.widget.SeekBar;

public class Scale extends SeekBar {

  private int min;

  public Scale( Context context ) {
    this( context, android.R.attr.seekBarStyle );
  }

  protected Scale( Context context, int defStyle ) {
    super( context, null, defStyle );
    min = 0;
    setMax( 100 );
  }

  @Override
  public void setProgress( int progress ) {
    super.setProgress( progress - min );
  }

  @Override
  public synchronized void setMax( int max ) {
    super.setMax( max - min );
  }

  public void setMin( int min ) {
    this.min = min;
    setProgress( getProgress() );
    setMax( getMax() );
  }

  /** To be used for testing only. */
  public int getMin() {
    return min;
  }
}
