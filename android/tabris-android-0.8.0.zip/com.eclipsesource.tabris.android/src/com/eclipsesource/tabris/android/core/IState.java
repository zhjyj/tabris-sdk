/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

public interface IState {

  public String generateKey();

  public String generateValue();

}