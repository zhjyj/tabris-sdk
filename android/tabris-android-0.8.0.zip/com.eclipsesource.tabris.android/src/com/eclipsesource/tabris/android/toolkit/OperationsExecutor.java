/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import android.os.MessageQueue;
import android.os.MessageQueue.IdleHandler;

import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.toolkit.operator.ComboOperator;

public class OperationsExecutor {

  private final AndroidWidgetToolkit widgetToolkit;
  private final Queue<Operation> operationsQueue;
  private QueueEmptyHandler idleHandler;
  private boolean isRunning;

  class QueueEmptyHandler implements IdleHandler {

    public boolean queueIdle() {
      if( isRunning ) {
        synchronized( OperationsExecutor.this ) {
          if( operationsQueue.isEmpty() ) {
            finish();
          } else {
            executeNextOperations();
          }
        }
      }
      return true;
    }

  }

  public OperationsExecutor( AndroidWidgetToolkit widgetToolkit, MessageQueue queue ) {
    this.widgetToolkit = widgetToolkit;
    operationsQueue = new LinkedBlockingQueue<Operation>();
    idleHandler = new QueueEmptyHandler();
    queue.addIdleHandler( idleHandler );
    isRunning = false;
  }

  public void enqueue( Collection<Operation> operations ) {
    operationsQueue.addAll( operations );
  }

  public boolean isRunning() {
    return isRunning;
  }

  public synchronized void start() {
    isRunning = true;
    idleHandler.queueIdle();
  }

  private void executeNextOperations() {
    ArrayList<Operation> operations = getNextAtomicOperationsSet();
    ExecuteOperationsRunnable executor = new ExecuteOperationsRunnable( widgetToolkit, operations );
    widgetToolkit.executeInUiThread( executor );
  }

  private ArrayList<Operation> getNextAtomicOperationsSet() {
    ArrayList<Operation> result = new ArrayList<Operation>();
    int oldSize = operationsQueue.size();
    Operation operation;
    do {
      if( !operationsQueue.isEmpty() ) {
        operation = operationsQueue.remove();
        result.add( operation );
      } else {
        finish();
        break;
      }
    } while( !isAtomicOperationsSetSeparator( operation ) );

    return result;
  }

  private boolean isAtomicOperationsSetSeparator( Operation operation ) {
    if( operation != null && operation instanceof CreateOperation ) {
      CreateOperation createOperation = ( CreateOperation )operation;
      if( ComboOperator.TYPE.equals( createOperation.getType() ) ) {
        return true;
      }
    }
    return false;
  }

  private void finish() {
    isRunning = false;
  }

  /**
   * For testing purposes only.
   */
  void setIdleHandler( QueueEmptyHandler idleHandler ) {
    this.idleHandler = idleHandler;
  }

  /**
   * For testing purposes only.
   */
  public QueueEmptyHandler getIdleHandler() {
    return idleHandler;
  }
}
