/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.view.View;

import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;

public class ImmediateVideoStateListener implements IVideoStateListener {

  private final ProtocolProcessor processor;
  private final VideoHolder holder;

  public ImmediateVideoStateListener( ProtocolProcessor processor, VideoHolder holder ) {
    this.processor = processor;
    this.holder = holder;
  }

  public void videoStateChanged( VideoState videoState ) {
    processor.processPostRequest( createPlaybackModeRequestParam( holder, videoState.name()
      .toLowerCase() ) );
  }

  private PostRequest createPlaybackModeRequestParam( View videoHolder, String playerAction ) {
    return createPostRequest( videoHolder, VIDEO_PLAYBACK_MODE_POSTFIX, playerAction );
  }

  private PostRequest createPostRequest( View videoHolder, String postfix, String value ) {
    PostRequest request = new PostRequest();
    String widgetId = ( String )videoHolder.getTag();
    request.addParam( widgetId + postfix, value );
    return request;
  }
}
