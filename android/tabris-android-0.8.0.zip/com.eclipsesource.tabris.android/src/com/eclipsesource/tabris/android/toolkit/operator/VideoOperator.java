/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.view.View;
import android.view.ViewGroup;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;

public class VideoOperator extends AbstractWidgetOperator {

  static final String TYPE = "tabris.widgets.Video";

  public VideoOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    TabrisActivity activity = getActivity();
    ValidationUtil.validateCreateOperation( activity, operation );
    VideoHolder videoHolder = ( VideoHolder )activity.getLayoutInflater()
      .inflate( R.layout.video_holder, null );
    Video video = ( Video )videoHolder.findViewById( R.id.videoView );
    video.setHolder( videoHolder );
    videoHolder.setOriginalParent( getParentFromOperation( operation ) );
    initiateAsToplevelWidget( operation, videoHolder );
    getWidgetToolkit().addAppStateListener( videoHolder );
  }

  private View getParentFromOperation( CreateOperation operation ) {
    CreateProperties props = operation.getProperties();
    return findObjectById( props.getParent(), ViewGroup.class );
  }

  private void initiateAsToplevelWidget( CreateOperation operation, View view ) {
    setInitialLayoutParams( view );
    view.setTag( operation.getTarget() );
    registerAsToplevelWidget( view );
    applyProperties( operation, view );
  }

  private void registerAsToplevelWidget( View view ) {
    IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
    toolkit.registerObjectById( ( String )view.getTag(), view );
    ViewGroup display = toolkit.findObjectById( AndroidWidgetToolkit.DISPLAY_ID, ViewGroup.class );
    display.addView( view );
  }

  @Override
  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    VideoHolder videoHolder = getWidgetToolkit().findObjectById( operation.getTarget(),
                                                                 VideoHolder.class );
    getWidgetToolkit().removeAppStateListener( videoHolder );
    super.destroy( operation );
  }
}
