/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.Meta;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.parser.IProtocolParserCallback;
import com.eclipsesource.tabris.android.core.transport.GetRequest;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.core.transport.ITransportRequest;
import com.eclipsesource.tabris.android.core.transport.ITransportResult;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.core.util.StringUtil;
import com.eclipsesource.tabris.android.parser.gson.GsonProtocolParser;

public class ProtocolProcessor implements IProtocolParserCallback {

  private ITransport transport;
  private IProtocolParser parser;
  private IWidgetToolkit widgetToolkit;
  private Meta curMeta = new Meta();
  private long sessionStartTime;
  private ExecutorService requestThreadPool;
  private final StateRecorder stateRecorder;
  private final ReentrantReadWriteLock shutdownLock;

  public ProtocolProcessor() {
    requestThreadPool = Executors.newSingleThreadExecutor();
    stateRecorder = new StateRecorder();
    shutdownLock = new ReentrantReadWriteLock();
  }

  public void startSession() {
    verify();
    GsonProtocolParser initialRequestParser = new GsonProtocolParser();
    initialRequestParser.addProtocolParserCallback( new InitialRequestHandler( this ) );
    parser.addProtocolParserCallback( this );
    sessionStartTime = System.currentTimeMillis();
    sendInitialGetRequest( new GetRequest( "" ), initialRequestParser );
  }

  private void sendInitialGetRequest( GetRequest getRequest, IProtocolParser parser ) {
    shutdownLock.readLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new InitialGetRequestRunnable( getRequest, this, parser ) );
      }
    } finally {
      shutdownLock.readLock().unlock();
    }
  }

  public void sendInitialPostRequest( CallOperation probeOperation ) {
    PostRequest initialRequest = createInitialRequest( widgetToolkit.measureStrings( probeOperation ) );
    processPostRequest( initialRequest );
  }

  /**
   * Executes the {@link PostRequest} in an asynchronous fashion. The call
   * returns immediately.
   * 
   * @param request the {@link PostRequest} to execute
   */
  public void processPostRequest( final PostRequest request ) {
    attachRecordedState( request );
    shutdownLock.readLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.execute( new PostRequestRunnable( request, this ) );
      }
    } finally {
      shutdownLock.readLock().unlock();
    }
  }

  private void attachRecordedState( PostRequest request ) {
    for( IState state : stateRecorder.getRecording() ) {
      request.addParam( state.generateKey(), state.generateValue() );
    }
    stateRecorder.clearRecordedState();
  }

  public StateRecorder getStateRecorder() {
    return stateRecorder;
  }

  public ITransportResult processGetRequest( final GetRequest request ) {
    ITransportResult transportResult = transport.get( request );
    if( transportResult.hasException() && !request.isSilentRequest() ) {
      showError( transportResult.getException() );
    }
    return transportResult;
  }

  PostRequest createInitialRequest( HashMap<String, String> measurements ) {
    PostRequest request = new PostRequest();
    request.addParam( ITransportRequest.PARAM_RWT_INITIALIZE, StringUtil.TRUE );
    request.addParam( ITransportRequest.PARAM_UI_ROOT, ITransportRequest.PARAM_UI_ROOT_VALUE );
    request.addParam( ITransportRequest.PARAM_W1_BOUNDS_HEIGHT,
                      String.valueOf( widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceHeight() ) ) );
    request.addParam( ITransportRequest.PARAM_W1_BOUNDS_WIDTH,
                      String.valueOf( widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceWidth() ) ) );
    request.addParam( ITransportRequest.PARAM_W1_COLOR_DEPTH,
                      String.valueOf( widgetToolkit.getSurfaceColorDepth() ) );
    request.addParam( ITransportRequest.PARAM_W1_CURSOR_LOCATION_X, StringUtil.ZERO );
    request.addParam( ITransportRequest.PARAM_W1_CURSOR_LOCATION_Y, StringUtil.ZERO );
    request.addParam( ITransportRequest.PARAM_W1_DPI_X,
                      String.valueOf( widgetToolkit.getSurfaceDpiX() ) );
    request.addParam( ITransportRequest.PARAM_W1_DPI_Y,
                      String.valueOf( widgetToolkit.getSurfaceDpiY() ) );
    request.addParam( ITransportRequest.PARAM_W4T_HEIGHT,
                      String.valueOf( widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceHeight() ) ) );
    request.addParam( ITransportRequest.PARAM_W4T_WIDTH,
                      String.valueOf( widgetToolkit.divideByDensityFactor( widgetToolkit.getSurfaceWidth() ) ) );
    request.addParams( measurements );
    return request;
  }

  private void verify() {
    if( parser == null ) {
      throw new IllegalStateException( "The IProtocolParser can not be null" );
    }
    if( widgetToolkit == null ) {
      throw new IllegalStateException( "The IWidgetToolkit can not be null" );
    }
    if( transport == null ) {
      throw new IllegalStateException( "The ITransport can not be null" );
    }
  }

  private void showError( final Exception exception ) {
    widgetToolkit.showError( exception );
  }

  public ITransport getTransport() {
    return transport;
  }

  public void setTransport( ITransport transport ) {
    this.transport = transport;
  }

  public IProtocolParser getParser() {
    return parser;
  }

  public void setParser( IProtocolParser parser ) {
    this.parser = parser;
  }

  public IWidgetToolkit getWidgetToolkit() {
    return widgetToolkit;
  }

  public void setWidgetToolkit( IWidgetToolkit widgetToolkit ) {
    this.widgetToolkit = widgetToolkit;
  }

  public void operationsFound( final ArrayList<Operation> operations ) {
    try {
      widgetToolkit.process( operations );
    } catch( Exception e ) {
      showError( e );
    }
  }

  public void metaFound( Meta meta ) {
    if( meta.getRequestCounter() > 0 ) {
      this.curMeta = meta;
    }
    if( Meta.SESSION_TIMEOUT_ERROR.equals( meta.getError() ) ) {
      widgetToolkit.showError( new LocalizableException( LocalizableException.SESSION_TIMEOUT ) );
    }
  }

  void setMeta( Meta meta ) {
    this.curMeta = meta;
  }

  Meta getCurMeta() {
    return curMeta;
  }

  public long getSessionTime() {
    if( sessionStartTime == 0 ) {
      return 0;
    } else {
      return System.currentTimeMillis() - sessionStartTime;
    }
  }

  /** Should only be used for testing. */
  void setRequestThreadPool( ExecutorService postThreadPool ) {
    this.requestThreadPool = postThreadPool;
  }

  public void shutdown() {
    shutdownLock.writeLock().lock();
    try {
      if( requestThreadPool != null ) {
        requestThreadPool.shutdownNow();
        requestThreadPool = null;
      }
    } finally {
      shutdownLock.writeLock().unlock();
    }
    if( transport != null ) {
      transport.dispose();
    }
    if( widgetToolkit != null ) {
      widgetToolkit.dispose();
    }
  }
}
