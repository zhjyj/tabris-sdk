/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;

public class GeolocationOperator implements IOperator {

  public enum NeedsPositionFlavor {
    NEVER,
    ONCE,
    CONTINUOUS
  }

  static final String GEOLOCATION_TYPE = "tabris.Geolocation";
  private final TabrisActivity activity;

  public GeolocationOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return GEOLOCATION_TYPE;
  }

  public void create( CreateOperation operation ) {
    Geolocation geolocation = new Geolocation( activity, operation.getTarget() );
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    widgetToolkit.registerObjectById( operation.getTarget(), geolocation );
  }

  public void set( SetOperation operation ) {
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    Geolocation geolocation = widgetToolkit.findObjectById( operation.getTarget(),
                                                            Geolocation.class );
    checkObject( geolocation, operation );
    SetProperties properties = operation.getProperties();
    if( properties != null ) {
      synchronizeProperties( geolocation, properties );
    }
  }

  private void synchronizeProperties( Geolocation geolocation, SetProperties properties ) {
    synchronizeNeedsPosition( geolocation, properties );
    synchronizeHighAccuracy( geolocation, properties );
    synchronizeFrequency( geolocation, properties );
    synchronizeMaximumAge( geolocation, properties );
  }

  private void synchronizeNeedsPosition( Geolocation geolocation, SetProperties properties ) {
    String needsPosition = properties.getNeedsPosition();
    if( needsPosition != null ) {
      NeedsPositionFlavor flavor;
      if( needsPosition.equals( "NEVER" ) ) {
        flavor = NeedsPositionFlavor.NEVER;
      } else if( needsPosition.equals( "ONCE" ) ) {
        flavor = NeedsPositionFlavor.ONCE;
      } else if( needsPosition.equals( "CONTINUOUS" ) ) {
        flavor = NeedsPositionFlavor.CONTINUOUS;
      } else {
        String msg = "NeedsPositionFlavor " + needsPosition + " is not valid.";
        throw new IllegalArgumentException( msg );
      }
      geolocation.setNeedsPosition( flavor );
    }
  }

  private void synchronizeHighAccuracy( Geolocation geolocation, SetProperties properties ) {
    Boolean enableHighAccuracy = properties.getEnableHighAccuracy();
    if( enableHighAccuracy != null ) {
      geolocation.setEnableHighAccuracy( enableHighAccuracy );
    }
  }

  private void synchronizeFrequency( Geolocation geolocation, SetProperties properties ) {
    Integer frequency = properties.getFrequency();
    if( frequency != null ) {
      geolocation.setFrequency( frequency.intValue() );
    }
  }

  private void synchronizeMaximumAge( Geolocation geolocation, SetProperties properties ) {
    Integer maximumAge = properties.getMaximumAge();
    if( maximumAge != null ) {
      geolocation.setMaximumAge( maximumAge.intValue() );
    }
  }

  public void listen( ListenOperation operation ) {
    // nothing to do
  }

  public void call( CallOperation operation ) {
    // nothing to do
  }

  public void destroy( DestroyOperation operation ) {
    IWidgetToolkit widgetToolkit = activity.getProcessor().getWidgetToolkit();
    Geolocation geolocation = widgetToolkit.findObjectById( operation.getTarget(),
                                                            Geolocation.class );
    checkObject( geolocation, operation );
    geolocation.destroy();
    widgetToolkit.unregisterObjectById( operation.getTarget() );
  }

  private void checkObject( Geolocation geolocation, Operation operation ) {
    if( geolocation == null ) {
      throw new IllegalStateException( "Object with id "
                                       + operation.getTarget()
                                       + " does not exist." );
    }
  }
}
