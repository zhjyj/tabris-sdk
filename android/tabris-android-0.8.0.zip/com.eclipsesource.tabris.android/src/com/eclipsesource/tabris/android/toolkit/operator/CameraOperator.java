
package com.eclipsesource.tabris.android.toolkit.operator;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera.SourceType;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public class CameraOperator implements IOperator {

  public static final String TYPE = "tabris.Camera";

  private static final String SOURCE_TYPE_CAMERA = "camera";
  private static final String SOURCE_TYPE_PHOTO_LIBRARY = "photo_library";
  private static final String SOURCE_TYPE_SAVED_PHOTO_ALBUM = "saved_photo_album";
  private static final String METHOD_OPEN = "open";

  private final TabrisActivity activity;

  public CameraOperator( TabrisActivity activity ) {
    this.activity = activity;
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateOperation( operation );
    Camera camera = new Camera( activity, operation.getTarget(), new DateFactory() );
    IWidgetToolkit toolkit = getWidgetToolkit();
    toolkit.registerObjectById( operation.getTarget(), camera );
    CreateProperties properties = operation.getProperties();
    if( properties != null ) {
      applyProperties( operation.getTarget(), properties );
    }
  }

  public void set( SetOperation operation ) {
    ValidationUtil.validateSetOperation( operation );
    SetProperties properties = operation.getProperties();
    applyProperties( operation.getTarget(), properties );
  }

  protected void applyProperties( String target, SetProperties properties ) {
    applySourceType( target, properties );
    applyResolution( target, properties );
  }

  private void applySourceType( String target, SetProperties properties ) {
    String sourceType = properties.getSourceType();
    if( sourceType != null ) {
      Camera camera = getWidgetToolkit().findObjectById( target, Camera.class );
      if( sourceType.equals( SOURCE_TYPE_SAVED_PHOTO_ALBUM )
          || sourceType.equals( SOURCE_TYPE_PHOTO_LIBRARY ) )
      {
        camera.setSourceType( SourceType.GALLERY );
      } else if( sourceType.equals( SOURCE_TYPE_CAMERA ) ) {
        camera.setSourceType( SourceType.CAMERA );
      }
    }
  }

  private void applyResolution( String target, SetProperties properties ) {
    List<Integer> resolution = properties.getResolution();
    if( resolution != null ) {
      if( resolution.size() == 2 ) {
        Integer width = resolution.get( 0 );
        Integer height = resolution.get( 1 );
        if( width != null && height != null ) {
          Camera camera = getWidgetToolkit().findObjectById( target, Camera.class );
          camera.setResolution( width, height );
        } else {
          throw new IllegalArgumentException( "Resolution touple contains null elements. Received: "
                                              + resolution );
        }
      } else {
        throw new IllegalArgumentException( "Resolution touple does not have 2 elements. Received: "
                                            + resolution );
      }
    }
  }

  public void call( CallOperation operation ) {
    ValidationUtil.validateCallOperation( operation );
    String method = operation.getMethod();
    if( method.equals( METHOD_OPEN ) ) {
      Camera camera = getWidgetToolkit().findObjectById( operation.getTarget(), Camera.class );
      camera.requestImage();
    }
  }

  private IWidgetToolkit getWidgetToolkit() {
    return activity.getProcessor().getWidgetToolkit();
  }

  public void listen( ListenOperation operation ) {
    // nothing to do here
  }

  public void destroy( DestroyOperation operation ) {
    ValidationUtil.validateDestroyOperation( operation );
    IWidgetToolkit toolkit = getWidgetToolkit();
    toolkit.unregisterObjectById( operation.getTarget() );
  }
}
