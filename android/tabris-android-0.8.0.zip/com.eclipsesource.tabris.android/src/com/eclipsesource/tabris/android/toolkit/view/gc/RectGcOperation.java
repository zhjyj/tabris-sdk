/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import java.util.List;

import android.graphics.Path.Direction;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class RectGcOperation extends AbstractGcOperation {

  private static final String OPEARATION = "rect";

  public RectGcOperation( TabrisActivity activity ) {
    super( OPEARATION, activity );
  }

  public void execute( GraphicalContext gc, List<?> properties ) {
    assertPropertiesSize( properties, 5 );
    float left = getScaledFloat( properties, 1 );
    float top = getScaledFloat( properties, 2 );
    float right = getScaledFloat( properties, 3 );
    float bottom = getScaledFloat( properties, 4 );
    gc.getPath().addRect( left, top, right + left, bottom + top, Direction.CW );
  }

}
