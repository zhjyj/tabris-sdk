/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.Shell;

public class ShellAnimationSupport {

  private static final int WINDOW_ANIMATION_STYLE = android.R.attr.windowAnimationStyle;
  private static final int WINDOW_ANIMATION_MODAL_STYLE = R.attr.windowAnimationModalStyle;
  private static final int WINDOW_ANIMATION_MODAL_BACKGROUND_STYLE = R.attr.windowAnimationModalBackgroundStyle;

  public void playShellAnimations( Shell shell,
                                   int currentViewAnim,
                                   int prevViewAnim,
                                   TabrisActivity activity )
  {
    boolean prevIsMaximized = false;
    boolean curIsMaximized = shell.isMaximized();
    Shell previousShell = ( Shell )findPreviousView( shell, activity );
    if( previousShell != null ) {
      prevIsMaximized = previousShell.isMaximized();
    }
    if( prevIsMaximized && curIsMaximized ) {
      playAnimation( previousShell, prevViewAnim, activity );
    }
    if( curIsMaximized ) {
      playAnimation( shell, currentViewAnim, activity );
    }
  }

  void playAnimation( Shell shell, int prevViewAnim, TabrisActivity activity ) {
    int animId = getAnimIdFromStyle( activity, WINDOW_ANIMATION_STYLE, prevViewAnim );
    if( animId != 0 ) {
      shell.startAnimation( AnimationUtils.loadAnimation( activity, animId ) );
    }
  }

  public void playModalShellAnimation( Shell shell, int viewAnim, Activity activity ) {
    int animId = getAnimIdFromStyle( activity, WINDOW_ANIMATION_MODAL_STYLE, viewAnim );
    if( animId != 0 ) {
      shell.startAnimation( AnimationUtils.loadAnimation( activity, animId ) );
    }
  }

  public void playDimAnimation( View dim, int viewAnim, TabrisActivity activity ) {
    int animId = getAnimIdFromStyle( activity, WINDOW_ANIMATION_MODAL_BACKGROUND_STYLE, viewAnim );
    if( animId != 0 ) {
      dim.startAnimation( AnimationUtils.loadAnimation( activity, animId ) );
    }
  }

  View findPreviousView( View view, TabrisActivity activity ) {
    View prevView = null;
    ViewParent parent = view.getParent();
    if( parent instanceof ViewGroup ) {
      ViewGroup display = ( ViewGroup )parent;
      int childCount = display.getChildCount();
      for( int i = 0; i < childCount; i++ ) {
        View curChild = display.getChildAt( i );
        if( curChild == view && i > 0 ) {
          prevView = findShellBackwards( i - 1, display );
        }
      }
    }
    return prevView;
  }

  Shell findShellBackwards( int startIndex, ViewGroup display ) {
    View result = null;
    for( int i = startIndex; i >= 0; i-- ) {
      View curChild = display.getChildAt( i );
      if( curChild instanceof Shell ) {
        result = curChild;
        break;
      }
    }
    return ( Shell )result;
  }

  int getAnimIdFromStyle( Context context, int styleAttrId, int attrId ) {
    int attrResId = ThemeUtil.getAttrResId( context, styleAttrId );
    TypedArray animationArray = context.obtainStyledAttributes( attrResId, new int[]{
      attrId
    } );
    int animResId = animationArray.getResourceId( 0, 0 );
    animationArray.recycle();
    return animResId;
  }
}
