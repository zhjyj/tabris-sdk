/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateSpinnerItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingSpinnerItemSelectedListener;

public class ComboOperator extends AbstractWidgetOperator {

  public static final String TYPE = "rwt.widgets.Combo";

  public ComboOperator( TabrisActivity activity ) {
    super( activity );
  }

  public String getType() {
    return TYPE;
  }

  public void create( CreateOperation operation ) {
    ValidationUtil.validateCreateOperation( getActivity(), operation );
    Spinner spinner = new Spinner( getActivity() );
    attachAdapter( spinner, operation );
    CompositeItemSelectedListener compListener = setCompositeListener( operation, spinner );
    attachStateRecordingListener( compListener );
    initiateNewView( operation, spinner );
  }

  private void attachStateRecordingListener( CompositeItemSelectedListener compListener ) {
    StateRecorder stateRecorder = getProcessor().getStateRecorder();
    compListener.addListener( new RecordingSpinnerItemSelectedListener( stateRecorder ) );
  }

  private CompositeItemSelectedListener setCompositeListener( CreateOperation operation,
                                                              Spinner spinner )
  {
    ListenerRegistry listenerRegistry = getProcessor().getWidgetToolkit().getListenerRegistry();
    CompositeItemSelectedListener compListener = new CompositeItemSelectedListener();
    listenerRegistry.registerListener( operation.getTarget(), compListener );
    spinner.setOnItemSelectedListener( compListener );
    return compListener;
  }

  private void attachAdapter( Spinner spinner, CreateOperation operation ) {
    ArrayAdapter<String> adapter = new ArrayAdapter<String>( getActivity(),
                                                             android.R.layout.simple_spinner_item );
    adapter.setDropDownViewResource( R.layout.spinner_dropdown_item );
    spinner.setAdapter( adapter );
  }

  @Override
  protected void attachSelectionListener( ListenOperation operation ) {
    final Spinner spinner = ( Spinner )findViewByTarget( operation );
    String widgetId = ( String )spinner.getTag();
    ListenerRegistry listenerRegistry = getProcessor().getWidgetToolkit().getListenerRegistry();
    CompositeItemSelectedListener compListener = listenerRegistry.findListener( widgetId,
                                                                                CompositeItemSelectedListener.class );
    ImmediateSpinnerItemSelectedListener immediateListener = new ImmediateSpinnerItemSelectedListener( getProcessor() );
    compListener.addListener( immediateListener );
  }

  @Override
  protected void removeSelectionListener( ListenOperation operation ) {
    String tag = operation.getTarget();
    CompositeItemSelectedListener listener = getListenerRegistry().findListener( tag,
                                                                                 CompositeItemSelectedListener.class );
    listener.removeListeners( ImmediateSpinnerItemSelectedListener.class );
  }
}
