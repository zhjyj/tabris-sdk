
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.IActivityResultListener;
import com.eclipsesource.tabris.android.toolkit.util.ImageLoader;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class GalleryActivityResultListener implements IActivityResultListener {

  private static final String STR_ERROR = "ERROR";

  final TabrisActivity activity;
  final int requestCode;
  final String id;
  final int width;
  final int height;
  private ImageLoader imageLoader;

  public GalleryActivityResultListener( TabrisActivity activity,
                                        int requestCode,
                                        String id,
                                        int width,
                                        int height )
  {
    this.activity = activity;
    this.requestCode = requestCode;
    this.id = id;
    this.width = width;
    this.height = height;
    imageLoader = new ImageLoader();
  }

  public void receivedActivityResult( int requestCode, int resultCode, Intent intent ) {
    if( requestCode == this.requestCode ) {
      removeActivityResultListener();
      returnRequestCode();
      if( resultCode == Activity.RESULT_OK ) {
        if( intent != null && intent.getData() != null ) {
          String filePath = getAbsolutePathFromURI( intent.getData() );
          if( filePath != null ) {
            try {
              byte[] resizedImage = imageLoader.loadImage( new File( filePath ), width, height );
              sendImageToServer( resizedImage );
              return;
            } catch( Exception e ) {
              sendErrorToServer();
            }
          } else {
            sendErrorToServer();
          }
        } else {
          sendErrorToServer();
        }
      }
    }
  }

  private void sendErrorToServer() {
    PostRequest request = new PostRequest();
    request.addParam( id + IProtocolConstants.CAMERA_IMAGE_POSTFIX, STR_ERROR );
    activity.getProcessor().processPostRequest( request );
  }

  private void removeActivityResultListener() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.removeActivityResultListener( this );
  }

  private void returnRequestCode() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    RequestCodePool requestCodePool = toolkit.getRequestCodePool();
    requestCodePool.returnRequestCode( requestCode );
  }

  public String getAbsolutePathFromURI( Uri contentUri ) {
    String[] proj = {
      MediaStore.Images.Media.DATA
    };
    Cursor cursor = activity.getContentResolver().query( contentUri, proj, null, null, null );
    int columnIndex = cursor.getColumnIndexOrThrow( MediaStore.Images.Media.DATA );
    cursor.moveToFirst();
    String path = cursor.getString( columnIndex );
    cursor.close();
    return path;
  }

  private void sendImageToServer( byte[] imageData ) {
    PostRequest request = new PostRequest();
    String base64EncodedImage = Base64.encodeToString( imageData, Base64.DEFAULT );
    request.addParam( id + IProtocolConstants.CAMERA_IMAGE_POSTFIX, base64EncodedImage );
    activity.getProcessor().processPostRequest( request );
  }

  /** To be used for testing only. */
  void setImageLoader( ImageLoader imageLoader ) {
    this.imageLoader = imageLoader;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( activity == null )
                                                    ? 0
                                                    : activity.hashCode() );
    result = prime * result + height;
    result = prime * result + ( ( id == null )
                                              ? 0
                                              : id.hashCode() );
    result = prime * result + requestCode;
    result = prime * result + width;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    GalleryActivityResultListener other = ( GalleryActivityResultListener )obj;
    if( activity == null ) {
      if( other.activity != null ) {
        return false;
      }
    } else if( !activity.equals( other.activity ) ) {
      return false;
    }
    if( height != other.height ) {
      return false;
    }
    if( id == null ) {
      if( other.id != null ) {
        return false;
      }
    } else if( !id.equals( other.id ) ) {
      return false;
    }
    if( requestCode != other.requestCode ) {
      return false;
    }
    if( width != other.width ) {
      return false;
    }
    return true;
  }

}
