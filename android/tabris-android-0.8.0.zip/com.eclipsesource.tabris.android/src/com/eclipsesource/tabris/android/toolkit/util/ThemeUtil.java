/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.util;

import android.content.Context;
import android.util.TypedValue;

import com.eclipsesource.tabris.android.TabrisActivity;

public class ThemeUtil {

  public static int getAttrResId( Context context, int attrId ) {
    TypedValue outValue = new TypedValue();
    context.getTheme().resolveAttribute( attrId, outValue, true );
    return outValue.resourceId;
  }

  public static int getColorValue( TabrisActivity activity, int attrId ) {
    return activity.getResources().getColor( getAttrResId( activity, attrId ) );
  }
}
