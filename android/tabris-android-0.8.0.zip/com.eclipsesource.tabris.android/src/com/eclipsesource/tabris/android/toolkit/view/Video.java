/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import static com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants.*;
import android.content.Context;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnSeekCompleteListener;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.transport.PostRequest;

public class Video extends VideoView
  implements OnPreparedListener, OnInfoListener, OnErrorListener, OnCompletionListener,
  OnSeekCompleteListener
{

  private boolean isPrepared;
  private MediaPlayer mediaPlayer;
  private VideoHolder videoHolder;
  private VideoController videoController;
  private CustomMediaController mediaController;
  private boolean isLooping;
  private boolean shouldHaveMediaController;

  class CustomMediaController extends MediaController {

    public CustomMediaController( Context context ) {
      super( context );
    }

    @Override
    public void hide() {
      super.hide();
      if( videoHolder.isFullscreen() ) {
        videoHolder.switchLightsOff();
      }
    }

    @Override
    public boolean dispatchKeyEvent( KeyEvent event ) {
      int keyCode = event.getKeyCode();
      if( keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 ) {
        if( videoHolder.isFullscreen() ) {
          backPressedWhenFullScreen();
          return true;
        }
      }
      return super.dispatchKeyEvent( event );
    }
  }

  public Video( Context context ) {
    this( context, null );
  }

  public Video( Context context, AttributeSet attrs ) {
    super( context, attrs );
    setOnPreparedListener( this );
    isPrepared = false;
  }

  public void onPrepared( MediaPlayer mediaPlayer ) {
    if( this.mediaPlayer != mediaPlayer ) {
      this.mediaPlayer = mediaPlayer;
      registerCallbacks( mediaPlayer );
      registerMediaController();
      mediaPlayer.setLooping( isLooping );
      isPrepared = true;
      videoController.prepareCompleted();
    }
  }

  public void registerMediaController() {
    if( shouldHaveMediaController ) {
      mediaController = createMediaController( getContext() );
      super.setMediaController( mediaController );

      View anchor = videoHolder.getAnchorView();
      int[] location = new int[ 2 ];
      anchor.getLocationOnScreen( location );
      mediaController.setAnchorView( anchor );
    }
  }

  private void registerCallbacks( MediaPlayer mediaPlayer ) {
    mediaPlayer.setOnSeekCompleteListener( this );
    mediaPlayer.setOnInfoListener( this );
    setOnErrorListener( this );
    setOnCompletionListener( this );
  }

  public void onSeekComplete( MediaPlayer mp ) {
    videoController.seekCompleted();
  }

  public void onCompletion( MediaPlayer mp ) {
    videoController.done();
  }

  public boolean onInfo( MediaPlayer mp, int what, int extra ) {
    return videoController.info( what, extra );
  }

  public boolean onError( MediaPlayer mp, int what, int extra ) {
    return videoController.error( what, extra );
  }

  private boolean isReady() {
    return mediaPlayer != null && isPrepared;
  }

  @Override
  public void pause() {
    videoController.pause();
  }

  @Override
  public void start() {
    videoController.play();
  }

  @Override
  public void seekTo( int msec ) {
    videoController.setSeeking();
    super.seekTo( msec );
  }

  public void setUrl( String videoUrl ) {
    setVideoPath( videoUrl );
  }

  public void setUrl() {
    setUrl( videoHolder.getUrl() );
  }

  @Override
  public boolean onKeyDown( int keyCode, KeyEvent event ) {
    if( keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0 ) {
      if( videoHolder.isFullscreen() ) {
        backPressedWhenFullScreen();
        return true;
      }
    }
    return super.onKeyDown( keyCode, event );
  }

  private void backPressedWhenFullScreen() {
    videoHolder.leaveFullscreen();
    if( mediaController != null ) {
      mediaController.hide();
    }
    getProcessor().processPostRequest( createPresentationModeRequestParam( videoHolder, "embedded" ) );
  }

  private ProtocolProcessor getProcessor() {
    return ( ( TabrisActivity )getContext() ).getProcessor();
  }

  private PostRequest createPresentationModeRequestParam( View videoHolder, String presentationMode )
  {
    PostRequest request = new PostRequest();
    String widgetId = ( String )videoHolder.getTag();
    request.addParam( widgetId + VIDEO_PRESENTATION_MODE_POSTFIX, presentationMode );
    return request;
  }

  public Point getVideoDimensions() {
    if( isPrepared ) {
      return new Point( mediaPlayer.getVideoWidth(), mediaPlayer.getVideoHeight() );
    }
    return null;
  }

  public void setHolder( VideoHolder videoHolder ) {
    this.videoHolder = videoHolder;
  }

  public void setController( VideoController videoController ) {
    this.videoController = videoController;
  }

  public void doPlay() {
    super.start();
  }

  public void doPause() {
    super.pause();
  }

  public void doStop() {
    super.start();
    super.pause();
    super.seekTo( 0 );
  }

  public void doSkipBackward() {
    if( isReady() && canSeekBackward() ) {
      int currentPos = mediaPlayer.getCurrentPosition();
      int duration = mediaPlayer.getDuration();
      int newPos = 0;
      if( currentPos > ( duration / 10 ) ) {
        newPos = currentPos - duration / 10;
      }
      seekTo( newPos );
    }
  }

  public void doSkipForward() {
    if( isReady() && canSeekForward() ) {
      int currentPos = mediaPlayer.getCurrentPosition();
      int duration = mediaPlayer.getDuration();
      int newPos = duration;
      if( currentPos < ( duration - ( duration / 10 ) ) ) {
        newPos = currentPos + duration / 10;
      }
      seekTo( newPos );
    }
  }

  public void setLooping( boolean isLooping ) {
    this.isLooping = isLooping;
    if( isReady() ) {
      mediaPlayer.setLooping( isLooping );
    }
  }

  public boolean isLooping() {
    return isLooping;
  }

  public void showMediaController() {
    if( mediaController != null ) {
      mediaController.show();
    }
  }

  @Override
  public void setMediaController( MediaController controller ) {
    if( controller != null ) {
      throw new UnsupportedOperationException( "The video widget only supports its own MediaController." );
    } else {
      super.setMediaController( controller );
      mediaController = null;
    }
  }

  public void shouldHaveMediaController( boolean shouldHaveMediaController ) {
    this.shouldHaveMediaController = shouldHaveMediaController;
  }

  /**
   * For testing purposes only.
   * 
   * @param context
   * @return
   */
  protected CustomMediaController createMediaController( Context context ) {
    return new CustomMediaController( context );
  }

  /**
   * For testing purposes only.
   */
  protected CustomMediaController getMediaController() {
    return mediaController;
  }
}
