/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

import com.eclipsesource.tabris.android.core.IState;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.toolkit.view.state.ListVisibleState;
import com.eclipsesource.tabris.android.toolkit.view.state.SelectedItemState;

public class RecordingSpinnerItemSelectedListener implements OnItemSelectedListener {

  private final StateRecorder stateRecorder;

  public RecordingSpinnerItemSelectedListener( StateRecorder stateRecorder ) {
    if( stateRecorder == null ) {
      throw new IllegalArgumentException( "The state recorder can not be null" );
    }
    this.stateRecorder = stateRecorder;
  }

  public void onItemSelected( AdapterView<?> parent, View view, int position, long id ) {
    IState state = new ListVisibleState( ( String )parent.getTag(), false );
    stateRecorder.recordState( state );
    state = new SelectedItemState( ( String )parent.getTag(), position );
    stateRecorder.recordState( state );
  }

  public void onNothingSelected( AdapterView<?> parent ) {
    // nothing to do here. There is always something selected
  }

}
