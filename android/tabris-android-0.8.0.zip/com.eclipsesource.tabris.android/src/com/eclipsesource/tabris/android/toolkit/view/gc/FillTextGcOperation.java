/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.gc;

import android.graphics.Paint;
import android.text.StaticLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.toolkit.view.GraphicalContext;

public class FillTextGcOperation extends StrokeTextGcOperation {

  private static final String OPERATION = "fillText";

  public FillTextGcOperation( TabrisActivity activity ) {
    super( OPERATION, activity );
  }

  @Override
  protected void beforeDrawText( GraphicalContext gc, float x, float y, StaticLayout layout ) {
    Paint paint = gc.getPaint();
    int curColor = paint.getColor();
    int alpha = paint.getAlpha();
    paint.setColor( gc.getFillColor() );
    paint.setAlpha( alpha );
    gc.getCanvas().drawRect( x, y, x + getMaxLineWidth( layout ), y + layout.getHeight(), paint );
    paint.setColor( curColor );
  }

  private int getMaxLineWidth( StaticLayout layout ) {
    float maxLine = 0.0f;
    int lineCount = layout.getLineCount();
    for( int i = 0; i < lineCount; i++ ) {
      float lineLength = layout.getLineRight( i );
      if( lineLength > maxLine ) {
        maxLine = lineLength;
      }
    }
    return Math.round( maxLine );
  }

}
