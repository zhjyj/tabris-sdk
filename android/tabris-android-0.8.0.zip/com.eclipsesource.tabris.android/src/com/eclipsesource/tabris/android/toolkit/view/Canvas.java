/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.view.MotionEvent;

import com.eclipsesource.tabris.android.TabrisActivity;

public class Canvas extends Composite {

  static final Paint BITMAP_PAINT = new Paint();

  private Bitmap bitmap;
  private android.graphics.Canvas canvas;
  private final Paint clearPaint;
  private ClientGraphicalContext gc;
  private boolean clientDrawing;

  public Canvas( TabrisActivity activity ) {
    super( activity );
    setWillNotDraw( false );
    clearPaint = new Paint();
    clearPaint.setXfermode( new PorterDuffXfermode( Mode.CLEAR ) );
  }

  public void initCanvas( int width, int height ) {
    if( bitmap == null || width == 0 && height == 0 ) {
      createCanvasAndBitmap( width, height );
    } else if( width != canvas.getWidth() || height != canvas.getHeight() ) {
      destroyBitmap();
      createCanvasAndBitmap( width, height );
    } else {
      canvas.drawPaint( clearPaint );
    }
  }

  private void createCanvasAndBitmap( int width, int height ) {
    if( width > 0 && height > 0 ) {
      bitmap = Bitmap.createBitmap( width, height, Config.ARGB_8888 );
      canvas = new android.graphics.Canvas( bitmap );
    } else {
      destroyBitmap();
      canvas = new android.graphics.Canvas();
    }
  }

  @Override
  protected void onDraw( android.graphics.Canvas canvas ) {
    if( bitmap != null ) {
      canvas.drawBitmap( bitmap, 0, 0, BITMAP_PAINT );
    }
  }

  public android.graphics.Canvas getCanvas() {
    return canvas;
  }

  public void destroyBitmap() {
    if( bitmap != null ) {
      bitmap.recycle();
      bitmap = null;
    }
  }

  @Override
  public boolean onTouchEvent( MotionEvent event ) {
    if( clientDrawing ) {
      return gc.onTouchEvent( event );
    }
    return true;
  }

  public void setGc( ClientGraphicalContext gc ) {
    this.gc = gc;
  }

  public void setClientDrawingEnabled( boolean clientDrawing ) {
    this.clientDrawing = clientDrawing;
  }

  /** To be used for testing only. */
  public Bitmap getBitmap() {
    return bitmap;
  }

  /** To be used for testing only. */
  void setCanvas( android.graphics.Canvas canvas ) {
    this.canvas = canvas;
  }

}
