/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.LinkedList;

import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;

public class VideoOperationsExecutor implements IVideoStateListener {

  private final LinkedList<VideoState> queue;
  private final VideoController videoController;

  public VideoOperationsExecutor( VideoController videoController ) {
    this.videoController = videoController;
    queue = new LinkedList<VideoState>();
  }

  public void execute( VideoState videoState ) {
    queue.add( videoState );
    processQueue();
  }

  private void processQueue() {
    if( !queue.isEmpty() ) {
      if( !videoController.isInProgress() ) {
        handleFirstElementInQueue();
      }
    }
  }

  private void handleFirstElementInQueue() {
    VideoState videoState = queue.removeFirst();
    switch( videoState ) {
      case PLAY:
        videoController.play();
      break;
      case STOP:
        videoController.stop();
      break;
      case PAUSE:
        videoController.pause();
      break;
      case FAST_FORWARD:
        videoController.skipForward();
      break;
      case FAST_BACKWARD:
        videoController.skipBackward();
      break;
      case SET_URL:
        videoController.setUrl();
      break;
      default:
        throw new IllegalStateException( "invalid playback mode " + videoState );
    }
  }

  public void videoStateChanged( VideoState videoState ) {
    processQueue();
  }
}
