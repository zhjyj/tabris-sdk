/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

public class DelegatingItemSelectedListener implements OnItemSelectedListener {

  private final OnItemClickListener delegate;

  public DelegatingItemSelectedListener( OnItemClickListener delegate ) {
    this.delegate = delegate;
  }

  public void onItemSelected( AdapterView<?> parent, View view, int position, long id ) {
    delegate.onItemClick( parent, null, position, id );
  }

  public void onNothingSelected( AdapterView<?> parent ) {
    // not required
  }
}
