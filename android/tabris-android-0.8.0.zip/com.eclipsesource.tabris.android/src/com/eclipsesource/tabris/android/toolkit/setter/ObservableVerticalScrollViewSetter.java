/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import java.util.List;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.view.ObservableVerticalScrollView;

public class ObservableVerticalScrollViewSetter<T extends ObservableVerticalScrollView>
  extends ViewSetter<T>
{

  public ObservableVerticalScrollViewSetter( TabrisActivity activity ) {
    super( activity );
  }

  @Override
  public void execute( T view, SetProperties properties ) {
    super.execute( view, properties );
    setOrigin( view, properties );
  }

  private void setOrigin( ObservableVerticalScrollView view, SetProperties properties ) {
    List<Integer> origin = properties.getOrigin();
    if( origin != null ) {
      if( origin.size() < 2 ) {
        throw new IllegalArgumentException( "The origin property for scrolling has to have two params (x and y coords)" );
      }
      IWidgetToolkit toolkit = getProcessor().getWidgetToolkit();
      int x = toolkit.multiplyByDensityFactor( origin.get( 0 ) );
      int y = toolkit.multiplyByDensityFactor( origin.get( 1 ) );
      view.doSmoothScrollTo( x, y );
    }
  }

}