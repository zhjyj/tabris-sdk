/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view.state;

import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class TextState extends AbstractState {

  private final String text;

  public TextState( String widgetID, String text ) {
    super( widgetID );
    this.text = text;
  }

  @Override
  public String generateKey() {
    return widgetId + IProtocolConstants.TEXT_POSTFIX;
  }

  @Override
  public String generateValue() {
    return text;
  }

}