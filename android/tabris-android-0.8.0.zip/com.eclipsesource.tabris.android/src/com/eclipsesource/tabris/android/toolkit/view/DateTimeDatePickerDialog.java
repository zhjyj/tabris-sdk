/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.view;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.DatePicker;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.toolkit.util.ThemeUtil;

public class DateTimeDatePickerDialog extends DatePickerDialog implements IDateTimeSpinnerDialog {

  private DateTimeSpinner dateTimeSpinner;

  private final Calendar calendar;

  private final DialogHeader dialogHeader;

  private Calendar initialCalendar;

  public DateTimeDatePickerDialog( Activity activity, Calendar calendar ) {
    super( activity,
           ThemeUtil.getAttrResId( activity, R.attr.alertDialogTheme ),
           null,
           calendar.get( Calendar.YEAR ),
           calendar.get( Calendar.MONTH ),
           calendar.get( Calendar.DAY_OF_MONTH ) );
    this.calendar = calendar;
    initialCalendar = ( Calendar )calendar.clone();
    // we wrap the context in our own theme manually because robolectric does
    // not support shadowing the DatePickerDialog
    int themeResId = ThemeUtil.getAttrResId( activity, R.attr.alertDialogTheme );
    dialogHeader = new DialogHeader( new ContextThemeWrapper( activity, themeResId ) );
    dialogHeader.getIcon().setVisibility( View.GONE );
    setCustomTitle( dialogHeader.getHeader() );
  }

  @Override
  public void onClick( DialogInterface dialog, int which ) {
    super.onClick( dialog, which );
    updateInitialTimeAndSpinner();
    dateTimeSpinner.fireDateTimeChanged();
  }

  private void updateInitialTimeAndSpinner() {
    initialCalendar = ( Calendar )calendar.clone();
    updateDateTimeSpinner();
  }

  @Override
  public void onDateChanged( DatePicker view, int year, int month, int day ) {
    calendar.set( Calendar.YEAR, year );
    calendar.set( Calendar.MONTH, month );
    calendar.set( Calendar.DAY_OF_MONTH, day );
    updateDialogTitle();
  }

  private void updateDialogTitle() {
    dialogHeader.setTitleText( dateTimeSpinner.formatDate( calendar.getTime() ) );
  }

  public void setDateTimeSpinner( DateTimeSpinner dateTimeSpinner ) {
    this.dateTimeSpinner = dateTimeSpinner;
    updateDateTimeSpinner();
    updateDialogTitle();
  }

  private void updateDateTimeSpinner() {
    dateTimeSpinner.setDate( calendar.getTime() );
  }

  public void reset() {
    updateDate( initialCalendar.get( Calendar.YEAR ),
                initialCalendar.get( Calendar.MONTH ),
                initialCalendar.get( Calendar.DAY_OF_MONTH ) );
  }

  public void setYear( int year ) {
    updateDate( year, calendar.get( Calendar.MONTH ), calendar.get( Calendar.DAY_OF_MONTH ) );
    updateInitialTimeAndSpinner();
  }

  public void setMonth( int month ) {
    updateDate( calendar.get( Calendar.YEAR ), month, calendar.get( Calendar.DAY_OF_MONTH ) );
    updateInitialTimeAndSpinner();
  }

  public void setDay( int day ) {
    updateDate( calendar.get( Calendar.YEAR ), calendar.get( Calendar.MONTH ), day );
    updateInitialTimeAndSpinner();
  }

  public void setHours( int hours ) {
    // hours are not supported
  }

  public void setMinutes( int minutes ) {
    // minutes are not supported
  }
}
