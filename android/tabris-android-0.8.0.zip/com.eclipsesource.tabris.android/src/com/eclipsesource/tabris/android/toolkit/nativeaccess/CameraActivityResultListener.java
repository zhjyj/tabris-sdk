
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.util.Base64;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.IActivityResultListener;
import com.eclipsesource.tabris.android.toolkit.util.ImageLoader;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;

public class CameraActivityResultListener implements IActivityResultListener {

  private static final String STR_ERROR = "ERROR";

  private final TabrisActivity activity;
  private final int requestCode;
  private final String id;
  private final File photoFile;
  private final int width;
  private final int height;
  private ImageLoader imageLoader;

  public CameraActivityResultListener( TabrisActivity activity,
                                       int requestCode,
                                       String id,
                                       File photoFile,
                                       int width,
                                       int height )
  {
    this.activity = activity;
    this.requestCode = requestCode;
    this.id = id;
    this.width = width;
    this.height = height;
    this.photoFile = photoFile;
    imageLoader = new ImageLoader();
  }

  public void receivedActivityResult( int requestCode, int resultCode, Intent data ) {
    if( requestCode == this.requestCode ) {
      returnRequestCode();
      removeActivityResultListener();
      if( resultCode == Activity.RESULT_OK ) {
        if( photoFile.exists() ) {
          try {
            byte[] resizedImage = imageLoader.loadImage( photoFile, width, height );
            photoFile.delete();
            sendImageToServer( resizedImage );
            return;
          } catch( Exception e ) {
            sendErrorToServer();
          }
        } else {
          sendErrorToServer();
        }
      }
    }
  }

  private void removeActivityResultListener() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.removeActivityResultListener( this );
  }

  private void returnRequestCode() {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    RequestCodePool requestCodePool = toolkit.getRequestCodePool();
    requestCodePool.returnRequestCode( requestCode );
  }

  private void sendImageToServer( byte[] imageData ) {
    PostRequest request = new PostRequest();
    String base64EncodedImage = Base64.encodeToString( imageData, Base64.DEFAULT );
    request.addParam( id + IProtocolConstants.CAMERA_IMAGE_POSTFIX, base64EncodedImage );
    activity.getProcessor().processPostRequest( request );
  }

  private void sendErrorToServer() {
    PostRequest request = new PostRequest();
    request.addParam( id + IProtocolConstants.CAMERA_IMAGE_POSTFIX, STR_ERROR );
    activity.getProcessor().processPostRequest( request );
  }

  /** To be used for testing only. */
  void setImageLoader( ImageLoader imageLoader ) {
    this.imageLoader = imageLoader;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ( ( activity == null )
                                                    ? 0
                                                    : activity.hashCode() );
    result = prime * result + height;
    result = prime * result + ( ( id == null )
                                              ? 0
                                              : id.hashCode() );
    result = prime * result + ( ( photoFile == null )
                                                     ? 0
                                                     : photoFile.hashCode() );
    result = prime * result + requestCode;
    result = prime * result + width;
    return result;
  }

  @Override
  public boolean equals( Object obj ) {
    if( this == obj ) {
      return true;
    }
    if( obj == null ) {
      return false;
    }
    if( getClass() != obj.getClass() ) {
      return false;
    }
    CameraActivityResultListener other = ( CameraActivityResultListener )obj;
    if( activity == null ) {
      if( other.activity != null ) {
        return false;
      }
    } else if( !activity.equals( other.activity ) ) {
      return false;
    }
    if( height != other.height ) {
      return false;
    }
    if( id == null ) {
      if( other.id != null ) {
        return false;
      }
    } else if( !id.equals( other.id ) ) {
      return false;
    }
    if( photoFile == null ) {
      if( other.photoFile != null ) {
        return false;
      }
    } else if( !photoFile.equals( other.photoFile ) ) {
      return false;
    }
    if( requestCode != other.requestCode ) {
      return false;
    }
    if( width != other.width ) {
      return false;
    }
    return true;
  }

}
