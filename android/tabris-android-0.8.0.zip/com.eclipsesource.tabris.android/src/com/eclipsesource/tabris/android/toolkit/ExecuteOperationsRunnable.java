/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import java.util.ArrayList;

import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.ExecuteOperation;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.toolkit.util.ValidationUtil;

public final class ExecuteOperationsRunnable implements Runnable {

  private static final String TARGET_JSEX = "jsex";

  private final ArrayList<Operation> operations;
  private final AndroidWidgetToolkit toolkit;

  public ExecuteOperationsRunnable( AndroidWidgetToolkit toolkit, ArrayList<Operation> operations )
  {
    this.toolkit = toolkit;
    this.operations = operations;
  }

  public ExecuteOperationsRunnable( AndroidWidgetToolkit toolkit, Operation operation ) {
    this.toolkit = toolkit;
    this.operations = new ArrayList<Operation>();
    operations.add( operation );
  }

  private void executeOperation( Operation operation ) {
    if( !isJsexOperation( operation ) ) {
      ValidationUtil.validateOperation( operation );
      final IOperator operator = toolkit.getOperator( operation );
      if( operator != null ) {
        try {
          executeOperation( operation, operator );
        } catch( Throwable t ) {
          toolkit.showError( t );
        }
      } else if( operation instanceof CreateOperation ) {
        toolkit.showError( new IllegalStateException( "The element '"
                                                      + ( ( CreateOperation )operation ).getType()
                                                      + "' is currently not supported." ) );
      } else {
        toolkit.showError( new IllegalStateException( "Could not find operator for " + operation ) );
      }
    }
  }

  public void run() {
    for( int i = 0; i < operations.size(); i++ ) {
      executeOperation( operations.get( i ) );
    }
  }

  private void executeOperation( final Operation operation, final IOperator operator ) {
    if( operation instanceof CreateOperation ) {
      operator.create( ( CreateOperation )operation );
    } else if( operation instanceof SetOperation ) {
      operator.set( ( SetOperation )operation );
    } else if( operation instanceof ListenOperation ) {
      operator.listen( ( ListenOperation )operation );
    } else if( operation instanceof CallOperation ) {
      operator.call( ( CallOperation )operation );
    } else if( operation instanceof DestroyOperation ) {
      operator.destroy( ( DestroyOperation )operation );
    }
  }

  /**
   * A jsex operation executes javascript that is targeted towards the web
   * client. It can not be handled by a native client.
   * 
   * @param operation the {@link Operation} to validate
   * @return <code>true</code> if the operation is a {@link ExecuteOperation}
   *         and its target is set to "jsex"
   */
  private boolean isJsexOperation( Operation operation ) {
    if( operation instanceof ExecuteOperation ) {
      ExecuteOperation op = ( ExecuteOperation )operation;
      if( op.getTarget().equals( TARGET_JSEX ) ) {
        return true;
      }
    }
    return false;
  }
}