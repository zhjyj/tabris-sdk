/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.parser;

public class ParseException extends RuntimeException {

  private static final long serialVersionUID = 3826140747619358853L;

  public ParseException( String text, Throwable e ) {
    super( text, e );
  }

  public ParseException( String text ) {
    super( text );
  }
}
