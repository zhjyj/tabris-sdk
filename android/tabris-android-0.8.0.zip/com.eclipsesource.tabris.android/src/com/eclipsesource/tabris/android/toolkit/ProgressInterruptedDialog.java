/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import android.app.Activity;
import android.content.DialogInterface;

import com.eclipsesource.tabris.android.R;

public class ProgressInterruptedDialog extends ErrorDialog {

  public ProgressInterruptedDialog( final Activity activity, AndroidWidgetToolkit awt ) {
    super( activity, awt );
    dialog.setMessage( activity.getString( R.string.dialog_interrupted_progress_message ) );
  }

  @Override
  protected void createButtons( final Activity activity ) {
    dialog.setButton( DialogInterface.BUTTON_NEGATIVE,
                      activity.getString( R.string.dialog_interrupted_progress_button_close ),
                      new ActivityFinishListener( activity ) );

    dialog.setButton( DialogInterface.BUTTON_NEUTRAL,
                      activity.getString( R.string.dialog_interrupted_progress_button_wait ),
                      new DialogCancelListener() );
  }

}