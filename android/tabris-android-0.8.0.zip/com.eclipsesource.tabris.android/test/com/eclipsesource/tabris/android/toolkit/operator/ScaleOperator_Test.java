/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeScaleChangedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateScaleChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.RecordingScaleChangeListener;
import com.eclipsesource.tabris.android.toolkit.view.Scale;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.shadows.ShadowSeekBar;

@RunWith(TabrisTestRunner.class)
public class ScaleOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String WIDGET_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentWidget;
  private IWidgetToolkit toolkit;

  @Before
  public void setUp() {
    activity = UiTestUtil.createActivity();
    parentWidget = new FrameLayout( activity );
    toolkit = activity.getProcessor().getWidgetToolkit();
    toolkit.registerObjectById( PARENT_ID, parentWidget );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ScaleOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateScaleNoProps() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateScaleNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateScaleNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  private Scale getCreatedValidatedView() {
    View view = UiTestUtil.findViewById( activity, WIDGET_ID );
    assertTrue( view instanceof Scale );
    assertEquals( WIDGET_ID, view.getTag() );
    return ( Scale )view;
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( WIDGET_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    Scale scale = getCreatedValidatedView();

    assertEquals( parentWidget, scale.getParent() );
    CompositeScaleChangedListener compListener = toolkit.getListenerRegistry()
      .findListener( WIDGET_ID, CompositeScaleChangedListener.class );
    ShadowSeekBar shadowSeekBar = Robolectric.shadowOf( scale );
    assertEquals( compListener, shadowSeekBar.getOnSeekBarChangeListener() );
    compListener.findListener( RecordingScaleChangeListener.class );
  }

  @Test
  public void testAttachSelectionListenerTrue() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    ListenOperation operation = new ListenOperation();
    operation.setTarget( WIDGET_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( true );
    operation.setProperties( properties );
    CompositeScaleChangedListener compListener = new CompositeScaleChangedListener();
    toolkit.getListenerRegistry().registerListener( WIDGET_ID, compListener );

    assertNull( compListener.findListener( ImmediateScaleChangeListener.class ) );

    operator.listen( operation );

    assertNotNull( compListener.findListener( ImmediateScaleChangeListener.class ) );
  }

  @Test
  public void testAttachSelectionListenerFalse() throws Exception {
    AbstractWidgetOperator operator = new ScaleOperator( activity );
    ListenOperation operation = new ListenOperation();
    operation.setTarget( WIDGET_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( false );
    operation.setProperties( properties );
    CompositeScaleChangedListener compListener = new CompositeScaleChangedListener();
    compListener.addListener( new ImmediateScaleChangeListener( mock( ProtocolProcessor.class ) ) );
    toolkit.getListenerRegistry().registerListener( WIDGET_ID, compListener );

    assertNotNull( compListener.findListener( ImmediateScaleChangeListener.class ) );

    operator.listen( operation );

    assertNull( compListener.findListener( ImmediateScaleChangeListener.class ) );
  }

  @Test
  public void testGetType() throws Exception {
    ScaleOperator op = new ScaleOperator( new TabrisActivity() );
    assertEquals( "rwt.widgets.Scale", op.getType() );
  }

}
