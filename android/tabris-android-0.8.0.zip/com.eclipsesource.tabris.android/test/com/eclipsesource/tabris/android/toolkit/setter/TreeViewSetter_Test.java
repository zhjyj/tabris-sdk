/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.eclipsesource.tabris.android.core.model.GenericObject;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.TreeView;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class TreeViewSetter_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( UiTestUtil.createActivityWithMockedFields() );
    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( UiTestUtil.createActivityWithMockedFields() );
    setter.execute( mock( TreeView.class ), null );
  }

  @Test
  @SuppressWarnings("unchecked")
  public void testSetSelectionIgnored() throws Exception {
    TreeViewSetter<TreeView> setter = new TreeViewSetter<TreeView>( UiTestUtil.createActivityWithMockedFields() );
    SetProperties props = new SetProperties();
    GenericObject genericObject = mock( GenericObject.class );
    props.setSelection( genericObject );

    setter.execute( mock( TreeView.class ), props );

    verify( genericObject, never() ).getObjectAs( any( Class.class ) );
  }
}
