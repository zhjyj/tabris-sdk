/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import static org.mockito.Mockito.*;
import android.app.Activity;
import android.content.ContentResolver;
import android.view.KeyEvent;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowActivity;

@Implements(Activity.class)
public class TabrisShadowActivity extends ShadowActivity {

  private int themeResourceId;
  private int lastKeyDownKeyCode;
  private ContentResolver contentResolver;

  @Implementation
  public void setTheme( int resid ) {
    themeResourceId = resid;
  }

  public int getThemeResourceId() {
    return themeResourceId;
  }

  @Implementation
  public boolean onKeyDown( int keyCode, KeyEvent event ) {
    this.lastKeyDownKeyCode = keyCode;
    return false;
  }

  public int getLastKeyDownKeyCode() {
    return lastKeyDownKeyCode;
  }

  @Override
  @Implementation
  public ContentResolver getContentResolver() {
    if( contentResolver == null ) {
      contentResolver = mock( ContentResolver.class );
    }
    return contentResolver;
  }
}
