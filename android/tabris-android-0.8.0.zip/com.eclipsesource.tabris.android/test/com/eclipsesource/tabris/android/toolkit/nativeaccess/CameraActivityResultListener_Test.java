
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import android.app.Activity;
import android.content.Intent;
import android.util.Base64;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;
import com.eclipsesource.tabris.android.toolkit.util.ImageLoader;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CameraActivityResultListener_Test {

  @Mock
  private DateFactory dateFactory;

  private TabrisActivity activity;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks( this );
    activity = UiTestUtil.createActivityWithMockedFields();
    when( dateFactory.getDate() ).thenReturn( new Date() );
    RequestCodePool requestCodePool = activity.getProcessor()
      .getWidgetToolkit()
      .getRequestCodePool();
    when( requestCodePool.takeRequestCode() ).thenReturn( 123 );
  }

  @Test
  public void receivedCameraRequestShouldSendImageToServer() throws Exception {
    File file = mock( File.class );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              123,
                                                                              "c12",
                                                                              file,
                                                                              400,
                                                                              500 );
    when( file.exists() ).thenReturn( true );
    ImageLoader imageLoader = mock( ImageLoader.class );
    byte[] imageData = new byte[]{
      1, 2, 3
    };
    when( imageLoader.loadImage( file, 0, 0 ) ).thenReturn( imageData );
    listener.setImageLoader( imageLoader );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, new Intent() );

    verify( file ).delete();
    verify( imageLoader ).loadImage( file, 400, 500 );
    PostRequest request = new PostRequest();
    String base64EncodedImage = Base64.encodeToString( imageData, Base64.DEFAULT );
    request.addParam( "c12" + IProtocolConstants.CAMERA_IMAGE_POSTFIX, base64EncodedImage );
    verify( activity.getProcessor() ).processPostRequest( request );
  }

  @Test
  public void shouldSendErrorWhenPhotoFileDoesNotExist() {
    File file = mock( File.class );
    when( file.exists() ).thenReturn( false );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              123,
                                                                              "c12",
                                                                              file,
                                                                              400,
                                                                              500 );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, new Intent() );

    verifyErrorIsSendToServer();
  }

  @Test
  public void shouldSendErrorWhenImageCanNotBeLoaded() throws Exception {
    File file = mock( File.class );
    when( file.exists() ).thenReturn( true );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              123,
                                                                              "c12",
                                                                              file,
                                                                              400,
                                                                              500 );
    ImageLoader imageLoader = mock( ImageLoader.class );
    when( imageLoader.loadImage( file, 400, 500 ) ).thenThrow( new RuntimeException() );
    listener.setImageLoader( imageLoader );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, new Intent() );

    verifyErrorIsSendToServer();
  }

  private void verifyErrorIsSendToServer() {
    PostRequest request = new PostRequest();
    request.addParam( "c12" + IProtocolConstants.CAMERA_IMAGE_POSTFIX, "ERROR" );
    verify( activity.getProcessor() ).processPostRequest( request );
  }

  @Test
  public void hashCodeShouldProduceHashCode() throws Exception {
    File file = mock( File.class );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              123,
                                                                              "c12",
                                                                              file,
                                                                              400,
                                                                              500 );

    assertTrue( listener.hashCode() != 0 );
  }

  @Test
  public void listenersShouldNotBeEqual() throws Exception {
    File file = mock( File.class );
    CameraActivityResultListener listener1 = new CameraActivityResultListener( activity,
                                                                               123,
                                                                               "c12",
                                                                               file,
                                                                               400,
                                                                               500 );
    CameraActivityResultListener listener2 = new CameraActivityResultListener( null,
                                                                               0,
                                                                               null,
                                                                               null,
                                                                               0,
                                                                               0 );

    assertFalse( listener2.equals( listener1 ) );
  }
}
