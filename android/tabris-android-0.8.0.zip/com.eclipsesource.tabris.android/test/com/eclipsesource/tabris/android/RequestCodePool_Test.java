
package com.eclipsesource.tabris.android;

import static org.junit.Assert.*;

import org.junit.Test;

public class RequestCodePool_Test {

  @Test
  public void takingRequestCodeShouldReturnRequestCode() {
    RequestCodePool pool = new RequestCodePool( 2 );

    int code1 = pool.takeRequestCode();
    int code2 = pool.takeRequestCode();

    assertTrue( code1 != 0 );
    assertTrue( code2 != 0 );
  }

  @Test
  public void takingRequestCodeBeyondSizeShouldThrowException() {
    RequestCodePool pool = new RequestCodePool( 2 );

    pool.takeRequestCode();
    pool.takeRequestCode();
    try {
      pool.takeRequestCode();
      fail( "Should not reach this point" );
    } catch( Exception e ) {
    }
  }

  @Test
  public void shouldReturnRequestCode() throws Exception {
    RequestCodePool pool = new RequestCodePool( 2 );

    pool.takeRequestCode();
    int code = pool.takeRequestCode();

    pool.returnRequestCode( code );

    pool.takeRequestCode();
  }

  @Test(expected = IllegalArgumentException.class)
  public void shouldThrowExceptionWhenAlreadyExistingCodeIsReturned() throws Exception {
    RequestCodePool pool = new RequestCodePool( 2 );

    int code = pool.takeRequestCode();
    pool.returnRequestCode( code );
    pool.returnRequestCode( code );
  }
}
