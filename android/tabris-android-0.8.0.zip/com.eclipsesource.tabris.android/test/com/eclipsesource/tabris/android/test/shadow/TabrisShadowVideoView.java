/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import android.widget.MediaController;
import android.widget.VideoView;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;

@Implements(VideoView.class)
public class TabrisShadowVideoView extends ShadowVideoView {

  private MediaController mediaController;

  @Implementation
  public void setMediaController( MediaController controller ) {
    this.mediaController = controller;
  }

  public MediaController getMediaController() {
    return mediaController;
  }
}
