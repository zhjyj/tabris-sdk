/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.Spinner;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.ListenOperation;
import com.eclipsesource.tabris.android.core.model.ListenProperties;
import com.eclipsesource.tabris.android.test.TabrisTestRunner;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeItemSelectedListener;
import com.eclipsesource.tabris.android.toolkit.view.ImmediateSpinnerItemSelectedListener;

@RunWith(TabrisTestRunner.class)
public class ComboOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String COMBO_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivity();
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    activity.getProcessor().getWidgetToolkit().registerObjectById( PARENT_ID, parentLayout );
  }

  @Test
  public void testGetType() {
    AbstractWidgetOperator op = new ComboOperator( activity );

    assertEquals( ComboOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new ComboOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateComboNoProps() throws Exception {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateComboNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateComboNoParentFound() throws Exception {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( COMBO_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "unknownParent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateComboOk() throws Exception {
    AbstractWidgetOperator operator = new ComboOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    View view = UiTestUtil.findViewById( activity, COMBO_ID );
    assertTrue( view instanceof Spinner );
    assertEquals( COMBO_ID, view.getTag() );
    ListenerRegistry listenerRegistry = activity.getProcessor()
      .getWidgetToolkit()
      .getListenerRegistry();
    Object listener = listenerRegistry.findListener( COMBO_ID, CompositeItemSelectedListener.class );
    assertNotNull( listener );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( COMBO_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    props.setItems( Arrays.asList( "Entry" ) );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testAttachSelectionListener() throws Exception {
    CompositeItemSelectedListener compListener = createSpinnerWithCompListener();
    AbstractWidgetOperator operator = new ComboOperator( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( COMBO_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( true );
    op.setProperties( properties );

    assertEquals( 0, compListener.getSize() );

    operator.listen( op );

    assertEquals( 1, compListener.getSize() );
  }

  @Test
  public void testRemoveSelectionListener() throws Exception {
    CompositeItemSelectedListener compListener = createSpinnerWithCompListener();
    compListener.addListener( new ImmediateSpinnerItemSelectedListener( mock( ProtocolProcessor.class ) ) );
    AbstractWidgetOperator operator = new ComboOperator( activity );
    ListenOperation op = new ListenOperation();
    op.setTarget( COMBO_ID );
    ListenProperties properties = new ListenProperties();
    properties.setSelection( false );
    op.setProperties( properties );

    assertEquals( 1, compListener.getSize() );

    operator.listen( op );

    assertEquals( 0, compListener.getSize() );
  }

  private CompositeItemSelectedListener createSpinnerWithCompListener() {
    Spinner spinner = new Spinner( activity );
    spinner.setTag( COMBO_ID );
    CompositeItemSelectedListener compListener = new CompositeItemSelectedListener();
    spinner.setOnItemSelectedListener( compListener );
    activity.getProcessor().getWidgetToolkit().registerObjectById( COMBO_ID, spinner );
    ListenerRegistry reg = activity.getProcessor().getWidgetToolkit().getListenerRegistry();
    reg.registerListener( COMBO_ID, compListener );
    return compListener;
  }
}
