/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.test;

import static org.mockito.Mockito.*;

import java.util.List;

import android.content.Intent;
import android.view.View;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.core.StateRecorder;
import com.eclipsesource.tabris.android.core.parser.IProtocolParser;
import com.eclipsesource.tabris.android.core.transport.ITransport;
import com.eclipsesource.tabris.android.toolkit.BitmapDrawableCache;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.view.RecordingFocusTrackingListener;

public class UiTestUtil {

  public static TabrisActivity createActivity() {
    TabrisActivity uiActivity = createActivityWithoutOnCreate();
    uiActivity.onCreate( null );
    return uiActivity;
  }

  public static TabrisActivity createActivityWithMockedFields() {
    ProtocolProcessor processor = mock( ProtocolProcessor.class );
    IWidgetToolkit toolkit = mock( IWidgetToolkit.class );
    when( toolkit.getBitmapCache() ).thenReturn( mock( BitmapDrawableCache.class ) );
    when( toolkit.getListenerRegistry() ).thenReturn( mock( ListenerRegistry.class ) );
    when( toolkit.getFocusTrackingListener() ).thenReturn( mock( RecordingFocusTrackingListener.class ) );
    when( toolkit.getSetterManager() ).thenReturn( mock( SetterManager.class ) );
    when( toolkit.getRequestCodePool() ).thenReturn( mock( RequestCodePool.class ) );
    when( processor.getTransport() ).thenReturn( mock( ITransport.class ) );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( processor.getStateRecorder() ).thenReturn( mock( StateRecorder.class ) );
    when( processor.getParser() ).thenReturn( mock( IProtocolParser.class ) );
    TabrisActivity uiActivity = new TabrisActivity();
    uiActivity.setProcessor( processor );
    return uiActivity;
  }

  public static TabrisActivity createActivityWithoutOnCreate() {
    TabrisActivity activity = createActivityWithMockedFields();
    Intent intent = new Intent();
    intent.putExtra( TabrisActivity.END_POINT, "http://localhost" );
    activity.setIntent( intent );
    return activity;
  }

  public static void mockToolkitMultiply( TabrisActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.multiplyByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivide( TabrisActivity activity, int input, int output ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.divideByDensityFactor( input ) ).thenReturn( output );
  }

  public static void mockToolkitDivideIdentity( TabrisActivity activity, int... numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( int i : numbers ) {
      when( toolkit.divideByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static void mockToolkitMultiplyIdentity( TabrisActivity activity, int... numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( int i : numbers ) {
      when( toolkit.multiplyByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static void mockToolkitMultiplyIdentity( TabrisActivity activity, List<Integer> numbers ) {
    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    for( Integer i : numbers ) {
      when( toolkit.multiplyByDensityFactor( i ) ).thenReturn( i );
    }
  }

  public static <T> T findObjectById( TabrisActivity activity, String id, Class<? extends T> clazz )
  {
    return activity.getProcessor().getWidgetToolkit().findObjectById( id, clazz );
  }

  public static View findViewById( TabrisActivity activity, String id ) {
    return findObjectById( activity, id, View.class );
  }
}
