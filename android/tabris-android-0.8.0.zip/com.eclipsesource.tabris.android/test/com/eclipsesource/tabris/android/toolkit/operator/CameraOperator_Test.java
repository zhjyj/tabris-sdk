
package com.eclipsesource.tabris.android.toolkit.operator;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IOperator;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CallOperation;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.core.model.SetOperation;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera.SourceType;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class CameraOperator_Test {

  private static final String PARENT_ID = "w2";
  private static final String CAMERA_ID = "w3";

  private TabrisActivity activity;
  private FrameLayout parentLayout;
  private IWidgetToolkit toolkit;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFields();
    toolkit = activity.getProcessor().getWidgetToolkit();
    when( toolkit.getListenerRegistry() ).thenReturn( new ListenerRegistry() );
    parentLayout = new FrameLayout( activity );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    IOperator operator = new CameraOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    IOperator operator = new CameraOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    IOperator operator = new CameraOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCameraNoProps() throws Exception {
    IOperator operator = new CameraOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateCameraNoParentSet() throws Exception {
    IOperator operator = new CameraOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( CAMERA_ID );
    op.setProperties( new CreateProperties() );
    return op;
  }

  @Test
  public void testCreateOk() throws Exception {
    CameraOperator operator = spy( new CameraOperator( activity ) );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    verify( toolkit ).registerObjectById( eq( CAMERA_ID ), isA( Camera.class ) );
    verify( operator ).applyProperties( CAMERA_ID, op.getProperties() );
  }

  @Test
  public void testSetShouldApplyProperties() throws Exception {
    CameraOperator operator = spy( new CameraOperator( activity ) );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    setOp.setProperties( props );

    operator.set( setOp );

    verify( operator ).applyProperties( CAMERA_ID, props );
  }

  @Test
  public void testInputSourceCameraShouldSetSourceToCamera() throws Exception {
    verifyInputSourceTypeSetsOutputSourceType( "camera", SourceType.CAMERA );
  }

  @Test
  public void testInputSourcePhotoLibraryShouldSetSourceToGallery() throws Exception {
    verifyInputSourceTypeSetsOutputSourceType( "photo_library", SourceType.GALLERY );
  }

  @Test
  public void testInputSourceSavedPhotoAlbumShouldSetSourceToGallery() throws Exception {
    verifyInputSourceTypeSetsOutputSourceType( "saved_photo_album", SourceType.GALLERY );
  }

  private void verifyInputSourceTypeSetsOutputSourceType( String inputSourceType,
                                                          SourceType outputSourceType )
  {
    CameraOperator operator = new CameraOperator( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    props.setSourceType( inputSourceType );
    setOp.setProperties( props );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.set( setOp );

    verify( camera ).setSourceType( outputSourceType );
  }

  @Test
  public void testSettingResolutionShouldChangeResolutionOnCamera() throws Exception {
    CameraOperator operator = new CameraOperator( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    props.setResolution( new ArrayList<Integer>( Arrays.asList( 123, 321 ) ) );
    setOp.setProperties( props );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.set( setOp );

    verify( camera ).setResolution( 123, 321 );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSettingResolutionWithoutTwoElementsShouldThrowException() throws Exception {
    CameraOperator operator = new CameraOperator( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    props.setResolution( new ArrayList<Integer>( Arrays.asList( 123 ) ) );
    setOp.setProperties( props );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.set( setOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSettingResolutionWithNullHeightShouldThrowException() throws Exception {
    CameraOperator operator = new CameraOperator( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    props.setResolution( new ArrayList<Integer>( Arrays.asList( 123, null ) ) );
    setOp.setProperties( props );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.set( setOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSettingResolutionWithNullWidthShouldThrowException() throws Exception {
    CameraOperator operator = new CameraOperator( activity );
    SetOperation setOp = new SetOperation();
    setOp.setTarget( CAMERA_ID );
    SetProperties props = new SetProperties();
    props.setResolution( new ArrayList<Integer>( Arrays.asList( null, 123 ) ) );
    setOp.setProperties( props );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.set( setOp );
  }

  @Test
  public void testCallOperationOpenShouldRequestImage() throws Exception {
    CameraOperator operator = new CameraOperator( activity );
    CallOperation callOp = new CallOperation();
    callOp.setMethod( "open" );
    callOp.setTarget( CAMERA_ID );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.call( callOp );

    verify( camera ).requestImage();
  }

  @Test
  public void testDestroyShouldRemoveCameraAndUnregisterAsActivityResultListener() throws Exception
  {
    CameraOperator operator = new CameraOperator( activity );
    DestroyOperation destroyOp = new DestroyOperation();
    destroyOp.setTarget( CAMERA_ID );
    Camera camera = mock( Camera.class );
    when( toolkit.findObjectById( CAMERA_ID, Camera.class ) ).thenReturn( camera );

    operator.destroy( destroyOp );

    verify( toolkit ).unregisterObjectById( CAMERA_ID );
  }
}
