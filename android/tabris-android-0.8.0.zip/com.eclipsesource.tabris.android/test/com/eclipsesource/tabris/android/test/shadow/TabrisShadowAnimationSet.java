/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import java.util.ArrayList;
import java.util.List;

import android.view.animation.Animation;
import android.view.animation.AnimationSet;

import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowAnimation;

@Implements(AnimationSet.class)
public class TabrisShadowAnimationSet extends ShadowAnimation {

  List<Animation> animations = new ArrayList<Animation>();

  @Implementation
  public void addAnimation( Animation a ) {
    animations.add( a );
  }

  @Implementation
  public List<Animation> getAnimations() {
    return animations;
  }

}
