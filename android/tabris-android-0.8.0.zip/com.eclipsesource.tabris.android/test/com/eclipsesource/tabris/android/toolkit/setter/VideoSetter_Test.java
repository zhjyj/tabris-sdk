/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.setter;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.graphics.Point;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.model.SetProperties;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoController.VideoState;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;
import com.eclipsesource.tabris.android.toolkit.view.VideoOperationsExecutor;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class VideoSetter_Test {

  private VideoHolder holder;
  private Video video;
  private VideoOperationsExecutor executor;

  @Before
  public void setup() {
    holder = mock( VideoHolder.class );
    executor = mock( VideoOperationsExecutor.class );
    when( holder.getVideoOperationsExecutor() ).thenReturn( executor );
    video = mock( Video.class );
    when( holder.getVideo() ).thenReturn( video );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullView() throws Exception {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );

    setter.execute( null, mock( SetProperties.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExecuteNullProperties() throws Exception {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );

    setter.execute( mock( VideoHolder.class ), null );
  }

  @Test
  public void testSetterFound() {
    HashMap<Class<? extends View>, IViewSetter<? extends View>> viewSetter = new SetterManager( new TabrisActivity() ).getViewSetter();

    Assert.assertTrue( "VideoSetter not found in list of setters.",
                       viewSetter.containsKey( VideoHolder.class ) );
  }

  @Test
  public void testApplyBoundsToViewNonFullscreen() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    activity.setContentView( R.layout.protocol );
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, bounds );
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( activity );
    when( holder.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    when( holder.calculateOriginalParentPosition() ).thenReturn( new Point( 1, 1 ) );
    SurfaceHolder surfaceHolder = mock( SurfaceHolder.class );
    when( video.getHolder() ).thenReturn( surfaceHolder );
    when( holder.getOriginalParent() ).thenReturn( activity.findViewById( R.id.root_layout ) );

    setter.applyBoundsToView( holder, bounds );

    verify( holder ).calculateOriginalParentPosition();
    verify( surfaceHolder ).setFixedSize( bounds.get( 2 ), bounds.get( 3 ) );
    verify( holder ).bufferBounds( bounds );
  }

  @Test
  public void testApplyBoundsToViewFullscreen() {
    TabrisActivity activity = UiTestUtil.createActivityWithMockedFields();
    activity.setContentView( R.layout.protocol );
    List<Integer> bounds = Arrays.asList( 10, 20, 30, 40 );
    UiTestUtil.mockToolkitMultiplyIdentity( activity, bounds );
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( activity );
    when( holder.getLayoutParams() ).thenReturn( mock( MarginLayoutParams.class ) );
    SurfaceHolder surfaceHolder = mock( SurfaceHolder.class );
    when( video.getHolder() ).thenReturn( surfaceHolder );
    when( holder.getOriginalParent() ).thenReturn( activity.findViewById( R.id.root_layout ) );
    when( holder.isFullscreen() ).thenReturn( true );

    setter.applyBoundsToView( holder, bounds );

    verify( holder ).applyFullScreenBounds( activity );
    verify( holder ).bufferBounds( bounds );
  }

  @Test
  public void testSetUrl() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setVideoURL( "someURL" );

    setter.execute( holder, props );

    verify( holder ).setUrl( "someURL" );
    verify( executor ).execute( VideoState.SET_URL );
  }

  @Test
  public void testSetUrlAndPlay() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setVideoURL( "someURL" );
    props.setPlayback_mode( "play" );

    setter.execute( holder, props );

    verify( holder ).setUrl( "someURL" );
    verify( executor ).execute( VideoState.SET_URL );
    verify( executor ).execute( VideoState.PLAY );
  }

  @Test
  public void testSetNullUrl() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setVideoURL( null );

    setter.execute( holder, props );

    verifyNoMoreInteractions( video );
  }

  @Test
  public void testSetNullPlaybackMode() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setPlayback_mode( null );

    setter.execute( holder, props );

    verifyNoMoreInteractions( video );
  }

  @Test
  public void testSetPlaybackModes() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );

    HashMap<VideoState, String> playbackModesToTest = getVideoStatesUnderTest();
    for( Entry<VideoState, String> playbackMode : playbackModesToTest.entrySet() ) {
      SetProperties props = new SetProperties();
      props.setPlayback_mode( playbackMode.getValue() );

      setter.execute( holder, props );

      verify( executor ).execute( playbackMode.getKey() );
    }
  }

  private HashMap<VideoState, String> getVideoStatesUnderTest() {
    HashMap<VideoState, String> result = new HashMap<VideoState, String>();
    result.put( VideoState.PLAY, "play" );
    result.put( VideoState.PAUSE, "pause" );
    result.put( VideoState.STOP, "stop" );
    result.put( VideoState.FAST_BACKWARD, "fast_backward" );
    result.put( VideoState.FAST_FORWARD, "fast_forward" );
    return result;
  }

  @Test
  public void testSetLooping() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setRepeat( true );

    setter.execute( holder, props );

    verify( video ).setLooping( true );
  }

  @Test
  public void testSetFullscreen() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setPresentation_mode( "full_screen" );

    setter.execute( holder, props );

    verify( holder ).enterFullscreen();
  }

  @Test
  public void testSetFullscreenToEmbedded() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setPresentation_mode( "embedded" );

    setter.execute( holder, props );

    verify( holder ).leaveFullscreen();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetFullscreenToUnknown() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setPresentation_mode( "foo" );

    setter.execute( holder, props );
  }

  @Test
  public void testSetControls() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setControls_visible( true );

    setter.execute( holder, props );

    verify( holder ).getVideo();
    verify( video ).shouldHaveMediaController( true );
    verify( video ).registerMediaController();
  }

  @Test
  public void testSetControlsFalse() {
    VideoSetter<VideoHolder> setter = new VideoSetter<VideoHolder>( new TabrisActivity() );
    SetProperties props = new SetProperties();
    props.setControls_visible( false );

    setter.execute( holder, props );

    verify( holder ).getVideo();
    verify( video ).shouldHaveMediaController( false );
    verify( video ).setMediaController( null );
  }

}
