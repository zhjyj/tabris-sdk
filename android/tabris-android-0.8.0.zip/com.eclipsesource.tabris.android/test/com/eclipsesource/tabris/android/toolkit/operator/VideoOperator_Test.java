/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.core.model.DestroyOperation;
import com.eclipsesource.tabris.android.toolkit.AndroidWidgetToolkit;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Video;
import com.eclipsesource.tabris.android.toolkit.view.VideoHolder;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowVideoView;

@RunWith(RobolectricTestRunner.class)
public class VideoOperator_Test {

  private static final String VIEW_ID = "w3";
  private static final String PARENT_ID = "w2";
  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;
  private ViewGroup display;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFields();
    toolkit = activity.getProcessor().getWidgetToolkit();
    ListenerRegistry listenerRegistry = new ListenerRegistry();
    listenerRegistry.registerListener( VIEW_ID, new CompositeTouchListener() );
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    display = new FrameLayout( activity );
    display.setTag( AndroidWidgetToolkit.DISPLAY_ID );
    when( toolkit.findObjectById( AndroidWidgetToolkit.DISPLAY_ID, View.class ) ).thenReturn( display );
    when( toolkit.findObjectById( AndroidWidgetToolkit.DISPLAY_ID, ViewGroup.class ) ).thenReturn( display );
    when( toolkit.getListenerRegistry() ).thenReturn( listenerRegistry );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
  }

  @Test
  public void testGetType() {
    VideoOperator op = new VideoOperator( activity );

    assertEquals( VideoOperator.TYPE, op.getType() );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new VideoOperator( activity );

    operator.create( null );
  }

  @Test
  public void testCreateOk() {
    AbstractWidgetOperator operator = new VideoOperator( activity );
    CreateOperation op = createValidCreateOperation();

    operator.create( op );

    VideoHolder holder = getCreatedValidatedView();
    verify( toolkit ).registerObjectById( VIEW_ID, holder );
    FrameLayout parent = ( FrameLayout )holder.getParent();
    assertEquals( AndroidWidgetToolkit.DISPLAY_ID, parent.getTag() );
    assertEquals( PARENT_ID, holder.getOriginalParent().getTag() );
    Video video = holder.getVideo();
    ShadowVideoView shadowView = Robolectric.shadowOf( video );
    assertEquals( video, shadowView.getOnPreparedListener() );
    verify( toolkit ).addAppStateListener( holder );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( VIEW_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  private VideoHolder getCreatedValidatedView() {
    View view = display.findViewWithTag( VIEW_ID );
    assertTrue( view instanceof VideoHolder );
    assertEquals( VIEW_ID, view.getTag() );
    return ( VideoHolder )view;
  }

  @Test
  public void testDestroyShouldUnregisterFromAppStateListeners() throws Exception {
    AbstractWidgetOperator operator = new VideoOperator( activity );
    CreateOperation op = createValidCreateOperation();
    operator.create( op );
    VideoHolder holder = getCreatedValidatedView();
    DestroyOperation destroyOperation = new DestroyOperation();
    destroyOperation.setTarget( VIEW_ID );
    when( toolkit.findObjectById( VIEW_ID, View.class ) ).thenReturn( holder );
    when( toolkit.findObjectById( VIEW_ID, VideoHolder.class ) ).thenReturn( holder );

    operator.destroy( destroyOperation );

    verify( toolkit ).removeAppStateListener( holder );
  }
}
