/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.test.shadow;

import static org.mockito.Mockito.*;
import android.os.Looper;
import android.os.MessageQueue;

import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.internal.Implementation;
import com.xtremelabs.robolectric.internal.Implements;
import com.xtremelabs.robolectric.shadows.ShadowLooper;

@Implements(Looper.class)
public class TabrisShadowLooper extends ShadowLooper {

  private final static Looper mainLooper = Robolectric.Reflection.newInstanceOf( Looper.class );

  @Implementation
  public static Looper getMainLooper() {
    return mainLooper;
  }

  @Implementation
  public static MessageQueue myQueue() {
    return mock( MessageQueue.class );
  }
}
