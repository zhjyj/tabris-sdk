/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.os.MessageQueue;
import android.os.MessageQueue.IdleHandler;

import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.Operation;
import com.eclipsesource.tabris.android.toolkit.OperationsExecutor.QueueEmptyHandler;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class OperationsExecutor_Test {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void testCreateOk() {
    MessageQueue queue = mock( MessageQueue.class );
    OperationsExecutor executor = new OperationsExecutor( mock( AndroidWidgetToolkit.class ), queue );

    assertFalse( executor.isRunning() );
    verify( queue ).addIdleHandler( any( IdleHandler.class ) );
  }

  @Test
  public void testEnqueueWithEmptyOperations() {
    MessageQueue queue = mock( MessageQueue.class );
    OperationsExecutor executor = new OperationsExecutor( mock( AndroidWidgetToolkit.class ), queue );
    QueueEmptyHandler idleHandler = mock( QueueEmptyHandler.class );
    executor.setIdleHandler( idleHandler );
    Collection<Operation> operations = new ArrayList<Operation>();
    executor.enqueue( operations );

    executor.start();

    verify( idleHandler ).queueIdle();
  }

  @Test
  public void testQueueIdleHandlerOnStoppedExecutor() {
    MessageQueue queue = mock( MessageQueue.class );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    OperationsExecutor executor = new OperationsExecutor( toolkit, queue );
    QueueEmptyHandler idleHandler = executor.getIdleHandler();

    boolean result = idleHandler.queueIdle();

    assertTrue( result );
    verifyNoMoreInteractions( toolkit );
  }

  @Test
  public void testStartWithEmptyOperations() {
    MessageQueue queue = mock( MessageQueue.class );
    OperationsExecutor executor = new OperationsExecutor( mock( AndroidWidgetToolkit.class ), queue );

    executor.start();

    assertFalse( executor.isRunning() );
  }

  @Test
  public void testQueueEmptyHandlerWithTwoOperations() {
    MessageQueue queue = mock( MessageQueue.class );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    OperationsExecutor executor = new OperationsExecutor( toolkit, queue );
    executor.enqueue( Arrays.asList( new Operation[]{
      mock( Operation.class ), mock( CreateOperation.class )
    } ) );

    executor.start();

    verify( toolkit, times( 1 ) ).executeInUiThread( any( ExecuteOperationsRunnable.class ) );
    assertFalse( executor.isRunning() );
  }

  @Test
  public void testQueueEmptyHandlerWithTwoBunchesOfOperations() {
    MessageQueue queue = mock( MessageQueue.class );
    AndroidWidgetToolkit toolkit = mock( AndroidWidgetToolkit.class );
    OperationsExecutor executor = new OperationsExecutor( toolkit, queue );
    QueueEmptyHandler idleHandler = executor.getIdleHandler();
    CreateOperation separatorOperation = mock( CreateOperation.class );
    when( separatorOperation.getType() ).thenReturn( "rwt.widgets.Combo" );
    executor.enqueue( Arrays.asList( new Operation[]{
      mock( Operation.class ), separatorOperation
    } ) );

    executor.start();

    assertTrue( executor.isRunning() );
    verify( toolkit, times( 1 ) ).executeInUiThread( any( ExecuteOperationsRunnable.class ) );

    boolean result = idleHandler.queueIdle();

    assertTrue( result );
    assertFalse( executor.isRunning() );
    verify( toolkit, times( 1 ) ).executeInUiThread( any( ExecuteOperationsRunnable.class ) );
  }
}
