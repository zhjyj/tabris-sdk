
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.ProtocolProcessor;
import com.eclipsesource.tabris.android.toolkit.nativeaccess.Camera.SourceType;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class Camera_Test {

  @Mock
  private TabrisActivity activity;

  @Mock
  private ProtocolProcessor processor;

  @Mock
  private IWidgetToolkit toolkit;

  @Mock
  private RequestCodePool requestCodePool;

  @Mock
  private DateFactory dateFactory;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks( this );
    when( dateFactory.getDate() ).thenReturn( new Date() );
    when( activity.getProcessor() ).thenReturn( processor );
    when( processor.getWidgetToolkit() ).thenReturn( toolkit );
    when( toolkit.getRequestCodePool() ).thenReturn( requestCodePool );
    when( requestCodePool.takeRequestCode() ).thenReturn( 123 );
  }

  public boolean deleteDirectory( File path ) {
    if( path.exists() ) {
      File[] files = path.listFiles();
      if( files == null ) {
        return true;
      }
      for( int i = 0; i < files.length; i++ ) {
        if( files[ i ].isDirectory() ) {
          deleteDirectory( files[ i ] );
        } else {
          files[ i ].delete();
        }
      }
    }
    return path.delete();
  }

  @Test
  public void requestingCameraImageShouldStartCameraIntentWithFilePathInExtra() {
    Camera camera = new Camera( activity, "c12", dateFactory );
    camera.setSourceType( SourceType.CAMERA );
    camera.setResolution( 100, 200 );
    when( activity.getPackageName() ).thenReturn( "packageName" );

    camera.requestImage();

    File externalStorageDir = Environment.getExternalStorageDirectory();
    String sep = File.separator;
    String path = sep + "Android" + sep + "data" + sep + "packageName" + sep + "images";
    String storageDir = externalStorageDir.getAbsolutePath() + sep + path;
    String date = new SimpleDateFormat( "yyyyMMdd_HHmmss" ).format( dateFactory.getDate() );
    File imageFile = new File( storageDir + sep + "IMG_" + date + "_c12.jpg" );
    assertTrue( new File( storageDir, ".nomedia" ).exists() );
    Intent intent = new Intent( MediaStore.ACTION_IMAGE_CAPTURE );
    intent.putExtra( MediaStore.EXTRA_OUTPUT, Uri.fromFile( imageFile ) );
    verify( activity ).startActivityForResult( intent, 123 );
    CameraActivityResultListener listener = new CameraActivityResultListener( activity,
                                                                              123,
                                                                              "c12",
                                                                              imageFile,
                                                                              100,
                                                                              200 );
    verify( toolkit ).addActivityResultListener( listener );

    deleteDirectory( externalStorageDir );
  }

  @Test
  public void failedCameraRequestShouldCleanUpAndThrowException() throws Exception {
    Camera camera = new Camera( activity, "c12", dateFactory );
    camera.setSourceType( SourceType.CAMERA );
    when( activity.getPackageName() ).thenReturn( "packageName" );
    doThrow( ActivityNotFoundException.class ).when( activity )
      .startActivityForResult( any( Intent.class ), anyInt() );

    try {
      camera.requestImage();
      fail( "Should have thrown an exception." );
    } catch( ActivityNotFoundException e ) {
      // expected exception
    }
    verify( requestCodePool ).returnRequestCode( 123 );
    verify( toolkit ).removeActivityResultListener( isA( CameraActivityResultListener.class ) );
  }

  @Test
  public void requestingGalleryImageShouldStartImagePickIntent() {
    Camera camera = new Camera( activity, "c12", dateFactory );
    camera.setSourceType( SourceType.GALLERY );
    camera.setResolution( 300, 400 );

    camera.requestImage();

    Intent intent = new Intent( Intent.ACTION_PICK );
    intent.setType( "image/*" );
    verify( activity ).startActivityForResult( intent, 123 );
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                300,
                                                                                400 );
    verify( toolkit ).addActivityResultListener( listener );
  }

  @Test
  public void failedGalleryRequestShouldCleanUpAndThrowException() throws Exception {
    Camera camera = new Camera( activity, "c12", dateFactory );
    camera.setSourceType( SourceType.GALLERY );
    when( activity.getPackageName() ).thenReturn( "packageName" );
    doThrow( ActivityNotFoundException.class ).when( activity )
      .startActivityForResult( any( Intent.class ), anyInt() );

    try {
      camera.requestImage();
      fail( "Should have thrown an exception." );
    } catch( ActivityNotFoundException e ) {
      // expected exception
    }
    verify( requestCodePool ).returnRequestCode( 123 );
    verify( toolkit ).removeActivityResultListener( isA( GalleryActivityResultListener.class ) );
  }

}
