
package com.eclipsesource.tabris.android.toolkit.nativeaccess;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;

import com.eclipsesource.tabris.android.RequestCodePool;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.transport.PostRequest;
import com.eclipsesource.tabris.android.test.shadow.TabrisShadowActivity;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.util.DateFactory;
import com.eclipsesource.tabris.android.toolkit.util.ImageLoader;
import com.eclipsesource.tabris.android.toolkit.view.IProtocolConstants;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class GalleryActivityResultListener_Test {

  @Mock
  private DateFactory dateFactory;

  private TabrisActivity activity;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks( this );
    Robolectric.bindShadowClass( TabrisShadowActivity.class );
    activity = UiTestUtil.createActivityWithMockedFields();
    Robolectric.shadowOf( activity );
    when( dateFactory.getDate() ).thenReturn( new Date() );
    RequestCodePool requestCodePool = activity.getProcessor()
      .getWidgetToolkit()
      .getRequestCodePool();
    when( requestCodePool.takeRequestCode() ).thenReturn( 123 );
  }

  @Test
  public void receivedGalleryRequestShouldSendImageToServer() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );
    File file = new File( "file://absolutFileName" );
    ImageLoader imageLoader = mock( ImageLoader.class );
    byte[] imageData = new byte[]{};
    when( imageLoader.loadImage( eq( file ), eq( 200 ), eq( 300 ) ) ).thenReturn( imageData );
    listener.setImageLoader( imageLoader );
    Intent intent = new Intent();
    Uri uri = Uri.parse( "uri://path" );
    intent.setData( uri );
    String[] projection = {
      MediaStore.Images.Media.DATA
    };
    ContentResolver contentResolver = activity.getContentResolver();
    Cursor cursor = mock( Cursor.class );
    when( contentResolver.query( uri, projection, null, null, null ) ).thenReturn( cursor );
    when( cursor.getColumnIndexOrThrow( MediaStore.Images.Media.DATA ) ).thenReturn( 1 );
    when( cursor.getString( 1 ) ).thenReturn( "file://absolutFileName" );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, intent );

    verify( cursor ).moveToFirst();
    verify( cursor ).getString( 1 );
    verify( cursor ).close();
    verify( imageLoader ).loadImage( file, 200, 300 );
    PostRequest request = new PostRequest();
    String base64EncodedImage = Base64.encodeToString( imageData, Base64.DEFAULT );
    request.addParam( "c12" + IProtocolConstants.CAMERA_IMAGE_POSTFIX, base64EncodedImage );
    verify( activity.getProcessor() ).processPostRequest( request );
  }

  @Test
  public void whenRequestCodeMatchesUnregisterAsListenerAndReturnRequestCode() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );

    listener.receivedActivityResult( 123, Activity.RESULT_CANCELED, new Intent() );

    IWidgetToolkit toolkit = activity.getProcessor().getWidgetToolkit();
    verify( toolkit ).removeActivityResultListener( listener );
    verify( toolkit.getRequestCodePool() ).returnRequestCode( 123 );
  }

  @Test
  public void nullIntentShouldSendError() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, null );

    verifyErrorIsSendToServer();
  }

  @Test
  public void nullIntentDataShouldSendError() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );
    Intent intent = new Intent();

    listener.receivedActivityResult( 123, Activity.RESULT_OK, intent );

    verifyErrorIsSendToServer();
  }

  @Test
  public void whenFileLocationIsUnknownShouldSendError() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );
    Intent intent = new Intent();
    Uri uri = Uri.parse( "uri://path" );
    intent.setData( uri );
    String[] projection = {
      MediaStore.Images.Media.DATA
    };
    ContentResolver contentResolver = activity.getContentResolver();
    Cursor cursor = mock( Cursor.class );
    when( contentResolver.query( uri, projection, null, null, null ) ).thenReturn( cursor );
    when( cursor.getColumnIndexOrThrow( MediaStore.Images.Media.DATA ) ).thenReturn( 1 );
    when( cursor.getString( 1 ) ).thenReturn( null );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, intent );

    verifyErrorIsSendToServer();
  }

  @Test
  public void whenImageCanNotBeLoadedShouldSendError() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );
    File file = new File( "file://absolutFileName" );
    ImageLoader imageLoader = mock( ImageLoader.class );
    when( imageLoader.loadImage( eq( file ), eq( 200 ), eq( 300 ) ) ).thenThrow( new IOException() );
    listener.setImageLoader( imageLoader );
    Intent intent = new Intent();
    Uri uri = Uri.parse( "uri://path" );
    intent.setData( uri );
    String[] projection = {
      MediaStore.Images.Media.DATA
    };
    ContentResolver contentResolver = activity.getContentResolver();
    Cursor cursor = mock( Cursor.class );
    when( contentResolver.query( uri, projection, null, null, null ) ).thenReturn( cursor );
    when( cursor.getColumnIndexOrThrow( MediaStore.Images.Media.DATA ) ).thenReturn( 1 );
    when( cursor.getString( 1 ) ).thenReturn( "file://absolutFileName" );

    listener.receivedActivityResult( 123, Activity.RESULT_OK, intent );

    verifyErrorIsSendToServer();
  }

  private void verifyErrorIsSendToServer() {
    PostRequest request = new PostRequest();
    request.addParam( "c12" + IProtocolConstants.CAMERA_IMAGE_POSTFIX, "ERROR" );
    verify( activity.getProcessor() ).processPostRequest( request );
  }

  @Test
  public void hashCodeShouldProduceHashCode() throws Exception {
    GalleryActivityResultListener listener = new GalleryActivityResultListener( activity,
                                                                                123,
                                                                                "c12",
                                                                                200,
                                                                                300 );

    assertTrue( listener.hashCode() != 0 );
  }

  @Test
  public void listenersShouldNotBeEqual() throws Exception {
    GalleryActivityResultListener listener1 = new GalleryActivityResultListener( activity,
                                                                                 123,
                                                                                 "c12",
                                                                                 200,
                                                                                 300 );
    GalleryActivityResultListener listener2 = new GalleryActivityResultListener( null,
                                                                                 0,
                                                                                 null,
                                                                                 0,
                                                                                 0 );

    assertFalse( listener2.equals( listener1 ) );
  }
}
