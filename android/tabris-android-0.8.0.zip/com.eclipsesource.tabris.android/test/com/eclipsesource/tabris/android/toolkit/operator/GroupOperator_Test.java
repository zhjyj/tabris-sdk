/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.toolkit.operator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.eclipsesource.tabris.android.R;
import com.eclipsesource.tabris.android.TabrisActivity;
import com.eclipsesource.tabris.android.core.IWidgetToolkit;
import com.eclipsesource.tabris.android.core.model.CreateOperation;
import com.eclipsesource.tabris.android.core.model.CreateProperties;
import com.eclipsesource.tabris.android.toolkit.ListenerRegistry;
import com.eclipsesource.tabris.android.toolkit.setter.SetterManager;
import com.eclipsesource.tabris.android.toolkit.test.UiTestUtil;
import com.eclipsesource.tabris.android.toolkit.view.CompositeTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.ConsumingTouchListener;
import com.eclipsesource.tabris.android.toolkit.view.Group;
import com.xtremelabs.robolectric.Robolectric;
import com.xtremelabs.robolectric.RobolectricTestRunner;
import com.xtremelabs.robolectric.shadows.ShadowFrameLayout;

@RunWith(RobolectricTestRunner.class)
public class GroupOperator_Test {

  private static final String GROUP_ID = "w3";
  private static final String PARENT_ID = "w1";

  private TabrisActivity activity;
  private IWidgetToolkit toolkit;
  private FrameLayout parentLayout;

  @Before
  public void setup() {
    activity = UiTestUtil.createActivityWithMockedFields();
    activity.setContentView( R.layout.protocol );
    toolkit = activity.getProcessor().getWidgetToolkit();
    parentLayout = new FrameLayout( activity );
    parentLayout.setTag( PARENT_ID );
    when( toolkit.findObjectById( PARENT_ID, ViewGroup.class ) ).thenReturn( parentLayout );
    when( toolkit.findObjectById( PARENT_ID, View.class ) ).thenReturn( parentLayout );
    when( toolkit.getListenerRegistry() ).thenReturn( new ListenerRegistry() );
    when( toolkit.getSetterManager() ).thenReturn( mock( SetterManager.class ) );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNull() {
    AbstractWidgetOperator operator = new GroupOperator( activity );

    operator.create( null );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateNoTarget() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = mock( CreateOperation.class );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateInvalid() {
    GroupOperator operator = new GroupOperator( activity );
    CreateOperation op = mock( CreateOperation.class );
    when( op.getTarget() ).thenReturn( "" );

    operator.create( op );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateGroupNoProps() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation createOp = new CreateOperation();

    operator.create( createOp );
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateGroupNoParentSet() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation createOp = new CreateOperation();
    CreateProperties props = new CreateProperties();
    createOp.setProperties( props );

    operator.create( createOp );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateGroupNoParentFound() throws Exception {
    LinearLayout linearLayout = new LinearLayout( activity );
    linearLayout.setTag( R.id.root_layout );
    activity.setContentView( linearLayout );
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( "parent" );
    op.setProperties( props );

    operator.create( op );
  }

  @Test(expected = IllegalStateException.class)
  public void testCreateGroupParentNotFrameLayout() throws Exception {
    String buttonId = "button";
    FrameLayout rootLayout = ( FrameLayout )activity.findViewById( R.id.root_layout );
    Button button = new Button( activity );
    button.setTag( buttonId );
    rootLayout.addView( button );

    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( buttonId );
    op.setProperties( props );

    operator.create( op );
  }

  @Test
  public void testCreateGroupOk() throws Exception {
    AbstractWidgetOperator operator = new GroupOperator( activity );
    CreateOperation op = createValidCreateOperation();
    UiTestUtil.mockToolkitDivideIdentity( activity, 8, 14, 18, 38 );

    operator.create( op );

    Group group = ( Group )parentLayout.findViewWithTag( GROUP_ID );
    verify( toolkit ).registerObjectById( eq( GROUP_ID ), eq( group ) );
    assertNotNull( group );
    ShadowFrameLayout shadowComp = Robolectric.shadowOf( group );
    CompositeTouchListener listener = ( CompositeTouchListener )shadowComp.getOnTouchListener();
    assertEquals( CompositeTouchListener.class, listener.getClass() );
    assertEquals( ConsumingTouchListener.class,
                  listener.findListener( ConsumingTouchListener.class ).getClass() );
  }

  private CreateOperation createValidCreateOperation() {
    CreateOperation op = new CreateOperation();
    op.setTarget( GROUP_ID );
    CreateProperties props = new CreateProperties();
    props.setParent( PARENT_ID );
    op.setProperties( props );
    return op;
  }

  @Test
  public void testGetType() throws Exception {
    GroupOperator op = new GroupOperator( new TabrisActivity() );
    assertEquals( GroupOperator.TYPE, op.getType() );
  }
}
