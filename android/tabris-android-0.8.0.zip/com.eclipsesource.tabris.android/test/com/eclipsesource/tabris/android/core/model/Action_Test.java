/*
 * Copyright(c) 2012 EclipseSource. All Rights Reserved.
 */

package com.eclipsesource.tabris.android.core.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eclipsesource.tabris.android.core.model.Action;
import com.eclipsesource.tabris.android.core.model.CreateOperation;

public class Action_Test {

  @Test(expected = IllegalArgumentException.class)
  public void testFindActionNullArg() {
    Action.findAction( null );
  }

  @Test
  public void testFindActionNotFound() {
    Action action = Action.findAction( "1234567890" );

    assertNull( action );
  }

  @Test
  public void testFindActionOk() {
    Action action = Action.findAction( CreateOperation.ACTION );

    assertEquals( Action.CREATE, action );
  }

}
