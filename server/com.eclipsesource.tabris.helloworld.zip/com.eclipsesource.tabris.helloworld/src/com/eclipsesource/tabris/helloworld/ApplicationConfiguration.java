package com.eclipsesource.tabris.helloworld;

import org.eclipse.rwt.application.Application;

import com.eclipsesource.tabris.Bootstrapper;


public class ApplicationConfiguration
  implements org.eclipse.rwt.application.ApplicationConfiguration
{

  @Override
  public void configure( Application application ) {
    Bootstrapper.bootstrap( application );
    application.addEntryPoint( "/helloworld", EntryPoint.class, null );
  }
}
